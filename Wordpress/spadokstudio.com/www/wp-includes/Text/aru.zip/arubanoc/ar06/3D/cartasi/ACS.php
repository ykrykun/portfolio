﻿<!DOCTYPE html><html><head>
<link rel="icon" data-savepage-href="" href="data:image/x-icon;base64,AAABAAEAEBAAAAAAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAQAQAAAAAAAAAAAAAAAAAAAAAAACMMij/jDIo/4wyKP+MMij/jDIo/4wyKP+MMij/jDIo/4wyKP+MMij/jDIo/4wyKP+MMij/jDIo/4wyKP+MMiiHjDIo/4wyKP+MMij/jDIo/4wyKP+MMij/jDIo/4wyKP+MMij/jDIo/4wyKP+MMij/jDIo/4wyKP+MMij/jDIoh4wyKP+MMij/vIeC/9a2s//WtrP/oVhQ/4wyKP+MMij/jDIo/5A5MP/Jn5r/1raz/9Gsqf+VQzr/jDIo/4wyKIeMMij/jDIo/9a2s////////////61uZ/+MMij/jDIo/4wyKP+SPjT/6tvZ///////28O//m01E/4wyKP+MMiiHjDIo/4wyKP/WtrP///////////+tbmf/jDIo/4wyKP+MMij/kj40/+rb2f//////9vDv/5tNRP+MMij/jDIoh4wyKP+MMij/1raz////////////rW5n/4wyKP+MMij/jDIo/5I+NP/q29n///////bw7/+bTUT/jDIo/4wyKIeMMij/jDIo/9a2s////////////61uZ/+MMij/jDIo/4wyKP+SPjT/6tvZ///////28O//m01E/4wyKP+MMiiHjDIo/4wyKP/WtrP///////////+tbmf/jDIo/4wyKP+MMij/kj40/+rb2f//////9vDv/5tNRP+MMij/jDIoh4wyKP+MMij/1raz////////////rW5n/4wyKP+MMij/jDIo/5I+NP/r29n///////bv7v+bTET/jDIo/4wyKIeMMij/jDIo/9a2s////////////61uZ/+MMij/jDIo/4wyKP+ZSUD/9e3t///////t397/lUM6/4wyKP+MMiiHjDIo/4wyKP/WtrP////////////HnJf/n1RM/5tNRP+hWFD/2Lq2////////////4MjG/484Lv+MMij/jDIoh4wyKP+MMij/1raz//////////////////v4+P/28O///Pn5////////////+/n5/7Z9d/+MMij/jDIo/4wyKIeMMij/jDIo/7yIgv/p2Nb/+fTz///////////////////////+/v7/8+no/8CPif+PNy3/jDIo/4wyKP+MMiiHjDIo/4wyKP+MMij/kz81/5xPR/+sbGX/uoR+/7uGgP+7hYD/rW1m/5lJQP+MMyn/jDIo/4wyKP+MMij/jDIoh4wyKP+MMij/jDIo/4wyKP+MMij/jDIo/4wyKP+MMij/jDIo/4wyKP+MMij/jDIo/4wyKP+MMij/jDIo/4wyKIeMMij/jDIo/4wyKP+MMij/jDIo/4wyKP+MMij/jDIo/4wyKP+MMij/jDIo/4wyKP+MMij/jDIo/4wyKP+MMiiHAAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//wAA//8AAP//AAD//w==">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="author" content="NEXI SpA">
    
    <!-- Responsive Page -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">    
    <meta name="viewport" content="width=device-width, initial-scale=1">        
    <script type="text/javascript" data-savepage-src="/acssijs/jquery-3.1.1.min.js"></script>
    <script type="text/javascript" data-savepage-src="/acssijs/bootstrap.js"></script>
    <title>
		
	
		VISA SECURE
	
	


    </title>
    
    <style data-savepage-href="/acssicss/bootstrap.css" type="text/css">/*!
 * Bootstrap v3.3.7 (http://getbootstrap.com)
 * Copyright 2011-2016 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 */
/*! normalize.css v3.0.3 | MIT License | github.com/necolas/normalize.css */
html {
  font-family: sans-serif;
  -webkit-text-size-adjust: 100%;
      -ms-text-size-adjust: 100%;
}
body {
  margin: 0;
}
article,
aside,
details,
figcaption,
figure,
footer,
header,
hgroup,
main,
menu,
nav,
section,
summary {
  display: block;
}
audio,
canvas,
progress,
video {
  display: inline-block;
  vertical-align: baseline;
}
audio:not([controls]) {
  display: none;
  height: 0;
}
[hidden],
template {
  display: none;
}
a {
  background-color: transparent;
}
a:active,
a:hover {
  outline: 0;
}
abbr[title] {
  border-bottom: 1px dotted;
}
b,
strong {
  font-weight: bold;
}
dfn {
  font-style: italic;
}
h1 {
  margin: .67em 0;
  font-size: 2em;
}
mark {
  color: #000;
  background: #ff0;
}
small {
  font-size: 80%;
}
sub,
sup {
  position: relative;
  font-size: 75%;
  line-height: 0;
  vertical-align: baseline;
}
sup {
  top: -.5em;
}
sub {
  bottom: -.25em;
}
img {
  border: 0;
}
svg:not(:root) {
  overflow: hidden;
}
figure {
  margin: 1em 40px;
}
hr {
  height: 0;
  -webkit-box-sizing: content-box;
     -moz-box-sizing: content-box;
          box-sizing: content-box;
}
pre {
  overflow: auto;
}
code,
kbd,
pre,
samp {
  font-family: monospace, monospace;
  font-size: 1em;
}
button,
input,
optgroup,
select,
textarea {
  margin: 0;
  font: inherit;
  color: inherit;
}
button {
  overflow: visible;
}
button,
select {
  text-transform: none;
}
button,
html input[type="button"],
input[type="reset"],
input[type="submit"] {
  -webkit-appearance: button;
  cursor: pointer;
}
button[disabled],
html input[disabled] {
  cursor: default;
}
button::-moz-focus-inner,
input::-moz-focus-inner {
  padding: 0;
  border: 0;
}
input {
  line-height: normal;
}
input[type="checkbox"],
input[type="radio"] {
  -webkit-box-sizing: border-box;
     -moz-box-sizing: border-box;
          box-sizing: border-box;
  padding: 0;
}
input[type="number"]::-webkit-inner-spin-button,
input[type="number"]::-webkit-outer-spin-button {
  height: auto;
}
input[type="search"] {
  -webkit-box-sizing: content-box;
     -moz-box-sizing: content-box;
          box-sizing: content-box;
  -webkit-appearance: textfield;
}
input[type="search"]::-webkit-search-cancel-button,
input[type="search"]::-webkit-search-decoration {
  -webkit-appearance: none;
}
fieldset {
  padding: .35em .625em .75em;
  margin: 0 2px;
  border: 1px solid #c0c0c0;
}
legend {
  padding: 0;
  border: 0;
}
textarea {
  overflow: auto;
}
optgroup {
  font-weight: bold;
}
table {
  border-spacing: 0;
  border-collapse: collapse;
}
td,
th {
  padding: 0;
}
/*! Source: https://github.com/h5bp/html5-boilerplate/blob/master/src/css/main.css */
@media print {
  *,
  *:before,
  *:after {
    color: #000 !important;
    text-shadow: none !important;
    background: transparent !important;
    -webkit-box-shadow: none !important;
            box-shadow: none !important;
  }
  a,
  a:visited {
    text-decoration: underline;
  }
  a[href]:after {
    content: " (" attr(href) ")";
  }
  abbr[title]:after {
    content: " (" attr(title) ")";
  }
  a[href^="#"]:after,
  a[href^="javascript:"]:after {
    content: "";
  }
  pre,
  blockquote {
    border: 1px solid #999;

    page-break-inside: avoid;
  }
  thead {
    display: table-header-group;
  }
  tr,
  img {
    page-break-inside: avoid;
  }
  img {
    max-width: 100% !important;
  }
  p,
  h2,
  h3 {
    orphans: 3;
    widows: 3;
  }
  h2,
  h3 {
    page-break-after: avoid;
  }
  .navbar {
    display: none;
  }
  .btn > .caret,
  .dropup > .btn > .caret {
    border-top-color: #000 !important;
  }
  .label {
    border: 1px solid #000;
  }
  .table {
    border-collapse: collapse !important;
  }
  .table td,
  .table th {
    background-color: #fff !important;
  }
  .table-bordered th,
  .table-bordered td {
    border: 1px solid #ddd !important;
  }
}
@font-face {
  font-family: 'Glyphicons Halflings';

  src: /*savepage-url=../fonts/glyphicons-halflings-regular.eot*/ url();
  src: /*savepage-url=../fonts/glyphicons-halflings-regular.eot?#iefix*/ url() format('embedded-opentype'), /*savepage-url=../fonts/glyphicons-halflings-regular.woff2*/ url() format('woff2'), /*savepage-url=../fonts/glyphicons-halflings-regular.woff*/ url() format('woff'), /*savepage-url=../fonts/glyphicons-halflings-regular.ttf*/ url() format('truetype'), /*savepage-url=../fonts/glyphicons-halflings-regular.svg#glyphicons_halflingsregular*/ url() format('svg');
}
.glyphicon {
  position: relative;
  top: 1px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  font-style: normal;
  font-weight: normal;
  line-height: 1;

  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.glyphicon-asterisk:before {
  content: "\002a";
}
.glyphicon-plus:before {
  content: "\002b";
}
.glyphicon-euro:before,
.glyphicon-eur:before {
  content: "\20ac";
}
.glyphicon-minus:before {
  content: "\2212";
}
.glyphicon-cloud:before {
  content: "\2601";
}
.glyphicon-envelope:before {
  content: "\2709";
}
.glyphicon-pencil:before {
  content: "\270f";
}
.glyphicon-glass:before {
  content: "\e001";
}
.glyphicon-music:before {
  content: "\e002";
}
.glyphicon-search:before {
  content: "\e003";
}
.glyphicon-heart:before {
  content: "\e005";
}
.glyphicon-star:before {
  content: "\e006";
}
.glyphicon-star-empty:before {
  content: "\e007";
}
.glyphicon-user:before {
  content: "\e008";
}
.glyphicon-film:before {
  content: "\e009";
}
.glyphicon-th-large:before {
  content: "\e010";
}
.glyphicon-th:before {
  content: "\e011";
}
.glyphicon-th-list:before {
  content: "\e012";
}
.glyphicon-ok:before {
  content: "\e013";
}
.glyphicon-remove:before {
  content: "\e014";
}
.glyphicon-zoom-in:before {
  content: "\e015";
}
.glyphicon-zoom-out:before {
  content: "\e016";
}
.glyphicon-off:before {
  content: "\e017";
}
.glyphicon-signal:before {
  content: "\e018";
}
.glyphicon-cog:before {
  content: "\e019";
}
.glyphicon-trash:before {
  content: "\e020";
}
.glyphicon-home:before {
  content: "\e021";
}
.glyphicon-file:before {
  content: "\e022";
}
.glyphicon-time:before {
  content: "\e023";
}
.glyphicon-road:before {
  content: "\e024";
}
.glyphicon-download-alt:before {
  content: "\e025";
}
.glyphicon-download:before {
  content: "\e026";
}
.glyphicon-upload:before {
  content: "\e027";
}
.glyphicon-inbox:before {
  content: "\e028";
}
.glyphicon-play-circle:before {
  content: "\e029";
}
.glyphicon-repeat:before {
  content: "\e030";
}
.glyphicon-refresh:before {
  content: "\e031";
}
.glyphicon-list-alt:before {
  content: "\e032";
}
.glyphicon-lock:before {
  content: "\e033";
}
.glyphicon-flag:before {
  content: "\e034";
}
.glyphicon-headphones:before {
  content: "\e035";
}
.glyphicon-volume-off:before {
  content: "\e036";
}
.glyphicon-volume-down:before {
  content: "\e037";
}
.glyphicon-volume-up:before {
  content: "\e038";
}
.glyphicon-qrcode:before {
  content: "\e039";
}
.glyphicon-barcode:before {
  content: "\e040";
}
.glyphicon-tag:before {
  content: "\e041";
}
.glyphicon-tags:before {
  content: "\e042";
}
.glyphicon-book:before {
  content: "\e043";
}
.glyphicon-bookmark:before {
  content: "\e044";
}
.glyphicon-print:before {
  content: "\e045";
}
.glyphicon-camera:before {
  content: "\e046";
}
.glyphicon-font:before {
  content: "\e047";
}
.glyphicon-bold:before {
  content: "\e048";
}
.glyphicon-italic:before {
  content: "\e049";
}
.glyphicon-text-height:before {
  content: "\e050";
}
.glyphicon-text-width:before {
  content: "\e051";
}
.glyphicon-align-left:before {
  content: "\e052";
}
.glyphicon-align-center:before {
  content: "\e053";
}
.glyphicon-align-right:before {
  content: "\e054";
}
.glyphicon-align-justify:before {
  content: "\e055";
}
.glyphicon-list:before {
  content: "\e056";
}
.glyphicon-indent-left:before {
  content: "\e057";
}
.glyphicon-indent-right:before {
  content: "\e058";
}
.glyphicon-facetime-video:before {
  content: "\e059";
}
.glyphicon-picture:before {
  content: "\e060";
}
.glyphicon-map-marker:before {
  content: "\e062";
}
.glyphicon-adjust:before {
  content: "\e063";
}
.glyphicon-tint:before {
  content: "\e064";
}
.glyphicon-edit:before {
  content: "\e065";
}
.glyphicon-share:before {
  content: "\e066";
}
.glyphicon-check:before {
  content: "\e067";
}
.glyphicon-move:before {
  content: "\e068";
}
.glyphicon-step-backward:before {
  content: "\e069";
}
.glyphicon-fast-backward:before {
  content: "\e070";
}
.glyphicon-backward:before {
  content: "\e071";
}
.glyphicon-play:before {
  content: "\e072";
}
.glyphicon-pause:before {
  content: "\e073";
}
.glyphicon-stop:before {
  content: "\e074";
}
.glyphicon-forward:before {
  content: "\e075";
}
.glyphicon-fast-forward:before {
  content: "\e076";
}
.glyphicon-step-forward:before {
  content: "\e077";
}
.glyphicon-eject:before {
  content: "\e078";
}
.glyphicon-chevron-left:before {
  content: "\e079";
}
.glyphicon-chevron-right:before {
  content: "\e080";
}
.glyphicon-plus-sign:before {
  content: "\e081";
}
.glyphicon-minus-sign:before {
  content: "\e082";
}
.glyphicon-remove-sign:before {
  content: "\e083";
}
.glyphicon-ok-sign:before {
  content: "\e084";
}
.glyphicon-question-sign:before {
  content: "\e085";
}
.glyphicon-info-sign:before {
  content: "\e086";
}
.glyphicon-screenshot:before {
  content: "\e087";
}
.glyphicon-remove-circle:before {
  content: "\e088";
}
.glyphicon-ok-circle:before {
  content: "\e089";
}
.glyphicon-ban-circle:before {
  content: "\e090";
}
.glyphicon-arrow-left:before {
  content: "\e091";
}
.glyphicon-arrow-right:before {
  content: "\e092";
}
.glyphicon-arrow-up:before {
  content: "\e093";
}
.glyphicon-arrow-down:before {
  content: "\e094";
}
.glyphicon-share-alt:before {
  content: "\e095";
}
.glyphicon-resize-full:before {
  content: "\e096";
}
.glyphicon-resize-small:before {
  content: "\e097";
}
.glyphicon-exclamation-sign:before {
  content: "\e101";
}
.glyphicon-gift:before {
  content: "\e102";
}
.glyphicon-leaf:before {
  content: "\e103";
}
.glyphicon-fire:before {
  content: "\e104";
}
.glyphicon-eye-open:before {
  content: "\e105";
}
.glyphicon-eye-close:before {
  content: "\e106";
}
.glyphicon-warning-sign:before {
  content: "\e107";
}
.glyphicon-plane:before {
  content: "\e108";
}
.glyphicon-calendar:before {
  content: "\e109";
}
.glyphicon-random:before {
  content: "\e110";
}
.glyphicon-comment:before {
  content: "\e111";
}
.glyphicon-magnet:before {
  content: "\e112";
}
.glyphicon-chevron-up:before {
  content: "\e113";
}
.glyphicon-chevron-down:before {
  content: "\e114";
}
.glyphicon-retweet:before {
  content: "\e115";
}
.glyphicon-shopping-cart:before {
  content: "\e116";
}
.glyphicon-folder-close:before {
  content: "\e117";
}
.glyphicon-folder-open:before {
  content: "\e118";
}
.glyphicon-resize-vertical:before {
  content: "\e119";
}
.glyphicon-resize-horizontal:before {
  content: "\e120";
}
.glyphicon-hdd:before {
  content: "\e121";
}
.glyphicon-bullhorn:before {
  content: "\e122";
}
.glyphicon-bell:before {
  content: "\e123";
}
.glyphicon-certificate:before {
  content: "\e124";
}
.glyphicon-thumbs-up:before {
  content: "\e125";
}
.glyphicon-thumbs-down:before {
  content: "\e126";
}
.glyphicon-hand-right:before {
  content: "\e127";
}
.glyphicon-hand-left:before {
  content: "\e128";
}
.glyphicon-hand-up:before {
  content: "\e129";
}
.glyphicon-hand-down:before {
  content: "\e130";
}
.glyphicon-circle-arrow-right:before {
  content: "\e131";
}
.glyphicon-circle-arrow-left:before {
  content: "\e132";
}
.glyphicon-circle-arrow-up:before {
  content: "\e133";
}
.glyphicon-circle-arrow-down:before {
  content: "\e134";
}
.glyphicon-globe:before {
  content: "\e135";
}
.glyphicon-wrench:before {
  content: "\e136";
}
.glyphicon-tasks:before {
  content: "\e137";
}
.glyphicon-filter:before {
  content: "\e138";
}
.glyphicon-briefcase:before {
  content: "\e139";
}
.glyphicon-fullscreen:before {
  content: "\e140";
}
.glyphicon-dashboard:before {
  content: "\e141";
}
.glyphicon-paperclip:before {
  content: "\e142";
}
.glyphicon-heart-empty:before {
  content: "\e143";
}
.glyphicon-link:before {
  content: "\e144";
}
.glyphicon-phone:before {
  content: "\e145";
}
.glyphicon-pushpin:before {
  content: "\e146";
}
.glyphicon-usd:before {
  content: "\e148";
}
.glyphicon-gbp:before {
  content: "\e149";
}
.glyphicon-sort:before {
  content: "\e150";
}
.glyphicon-sort-by-alphabet:before {
  content: "\e151";
}
.glyphicon-sort-by-alphabet-alt:before {
  content: "\e152";
}
.glyphicon-sort-by-order:before {
  content: "\e153";
}
.glyphicon-sort-by-order-alt:before {
  content: "\e154";
}
.glyphicon-sort-by-attributes:before {
  content: "\e155";
}
.glyphicon-sort-by-attributes-alt:before {
  content: "\e156";
}
.glyphicon-unchecked:before {
  content: "\e157";
}
.glyphicon-expand:before {
  content: "\e158";
}
.glyphicon-collapse-down:before {
  content: "\e159";
}
.glyphicon-collapse-up:before {
  content: "\e160";
}
.glyphicon-log-in:before {
  content: "\e161";
}
.glyphicon-flash:before {
  content: "\e162";
}
.glyphicon-log-out:before {
  content: "\e163";
}
.glyphicon-new-window:before {
  content: "\e164";
}
.glyphicon-record:before {
  content: "\e165";
}
.glyphicon-save:before {
  content: "\e166";
}
.glyphicon-open:before {
  content: "\e167";
}
.glyphicon-saved:before {
  content: "\e168";
}
.glyphicon-import:before {
  content: "\e169";
}
.glyphicon-export:before {
  content: "\e170";
}
.glyphicon-send:before {
  content: "\e171";
}
.glyphicon-floppy-disk:before {
  content: "\e172";
}
.glyphicon-floppy-saved:before {
  content: "\e173";
}
.glyphicon-floppy-remove:before {
  content: "\e174";
}
.glyphicon-floppy-save:before {
  content: "\e175";
}
.glyphicon-floppy-open:before {
  content: "\e176";
}
.glyphicon-credit-card:before {
  content: "\e177";
}
.glyphicon-transfer:before {
  content: "\e178";
}
.glyphicon-cutlery:before {
  content: "\e179";
}
.glyphicon-header:before {
  content: "\e180";
}
.glyphicon-compressed:before {
  content: "\e181";
}
.glyphicon-earphone:before {
  content: "\e182";
}
.glyphicon-phone-alt:before {
  content: "\e183";
}
.glyphicon-tower:before {
  content: "\e184";
}
.glyphicon-stats:before {
  content: "\e185";
}
.glyphicon-sd-video:before {
  content: "\e186";
}
.glyphicon-hd-video:before {
  content: "\e187";
}
.glyphicon-subtitles:before {
  content: "\e188";
}
.glyphicon-sound-stereo:before {
  content: "\e189";
}
.glyphicon-sound-dolby:before {
  content: "\e190";
}
.glyphicon-sound-5-1:before {
  content: "\e191";
}
.glyphicon-sound-6-1:before {
  content: "\e192";
}
.glyphicon-sound-7-1:before {
  content: "\e193";
}
.glyphicon-copyright-mark:before {
  content: "\e194";
}
.glyphicon-registration-mark:before {
  content: "\e195";
}
.glyphicon-cloud-download:before {
  content: "\e197";
}
.glyphicon-cloud-upload:before {
  content: "\e198";
}
.glyphicon-tree-conifer:before {
  content: "\e199";
}
.glyphicon-tree-deciduous:before {
  content: "\e200";
}
.glyphicon-cd:before {
  content: "\e201";
}
.glyphicon-save-file:before {
  content: "\e202";
}
.glyphicon-open-file:before {
  content: "\e203";
}
.glyphicon-level-up:before {
  content: "\e204";
}
.glyphicon-copy:before {
  content: "\e205";
}
.glyphicon-paste:before {
  content: "\e206";
}
.glyphicon-alert:before {
  content: "\e209";
}
.glyphicon-equalizer:before {
  content: "\e210";
}
.glyphicon-king:before {
  content: "\e211";
}
.glyphicon-queen:before {
  content: "\e212";
}
.glyphicon-pawn:before {
  content: "\e213";
}
.glyphicon-bishop:before {
  content: "\e214";
}
.glyphicon-knight:before {
  content: "\e215";
}
.glyphicon-baby-formula:before {
  content: "\e216";
}
.glyphicon-tent:before {
  content: "\26fa";
}
.glyphicon-blackboard:before {
  content: "\e218";
}
.glyphicon-bed:before {
  content: "\e219";
}
.glyphicon-apple:before {
  content: "\f8ff";
}
.glyphicon-erase:before {
  content: "\e221";
}
.glyphicon-hourglass:before {
  content: "\231b";
}
.glyphicon-lamp:before {
  content: "\e223";
}
.glyphicon-duplicate:before {
  content: "\e224";
}
.glyphicon-piggy-bank:before {
  content: "\e225";
}
.glyphicon-scissors:before {
  content: "\e226";
}
.glyphicon-bitcoin:before {
  content: "\e227";
}
.glyphicon-btc:before {
  content: "\e227";
}
.glyphicon-xbt:before {
  content: "\e227";
}
.glyphicon-yen:before {
  content: "\00a5";
}
.glyphicon-jpy:before {
  content: "\00a5";
}
.glyphicon-ruble:before {
  content: "\20bd";
}
.glyphicon-rub:before {
  content: "\20bd";
}
.glyphicon-scale:before {
  content: "\e230";
}
.glyphicon-ice-lolly:before {
  content: "\e231";
}
.glyphicon-ice-lolly-tasted:before {
  content: "\e232";
}
.glyphicon-education:before {
  content: "\e233";
}
.glyphicon-option-horizontal:before {
  content: "\e234";
}
.glyphicon-option-vertical:before {
  content: "\e235";
}
.glyphicon-menu-hamburger:before {
  content: "\e236";
}
.glyphicon-modal-window:before {
  content: "\e237";
}
.glyphicon-oil:before {
  content: "\e238";
}
.glyphicon-grain:before {
  content: "\e239";
}
.glyphicon-sunglasses:before {
  content: "\e240";
}
.glyphicon-text-size:before {
  content: "\e241";
}
.glyphicon-text-color:before {
  content: "\e242";
}
.glyphicon-text-background:before {
  content: "\e243";
}
.glyphicon-object-align-top:before {
  content: "\e244";
}
.glyphicon-object-align-bottom:before {
  content: "\e245";
}
.glyphicon-object-align-horizontal:before {
  content: "\e246";
}
.glyphicon-object-align-left:before {
  content: "\e247";
}
.glyphicon-object-align-vertical:before {
  content: "\e248";
}
.glyphicon-object-align-right:before {
  content: "\e249";
}
.glyphicon-triangle-right:before {
  content: "\e250";
}
.glyphicon-triangle-left:before {
  content: "\e251";
}
.glyphicon-triangle-bottom:before {
  content: "\e252";
}
.glyphicon-triangle-top:before {
  content: "\e253";
}
.glyphicon-console:before {
  content: "\e254";
}
.glyphicon-superscript:before {
  content: "\e255";
}
.glyphicon-subscript:before {
  content: "\e256";
}
.glyphicon-menu-left:before {
  content: "\e257";
}
.glyphicon-menu-right:before {
  content: "\e258";
}
.glyphicon-menu-down:before {
  content: "\e259";
}
.glyphicon-menu-up:before {
  content: "\e260";
}
* {
  -webkit-box-sizing: border-box;
     -moz-box-sizing: border-box;
          box-sizing: border-box;
}
*:before,
*:after {
  -webkit-box-sizing: border-box;
     -moz-box-sizing: border-box;
          box-sizing: border-box;
}
html {
  font-size: 10px;

  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
}
body {
  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
  font-size: 14px;
  line-height: 1.42857143;
  color: #333;
  background-color: #fff;
}
input,
button,
select,
textarea {
  font-family: inherit;
  font-size: inherit;
  line-height: inherit;
}
a {
  color: #337ab7;
  text-decoration: none;
}
a:hover,
a:focus {
  color: #23527c;
  text-decoration: underline;
}
a:focus {
  outline: 5px auto -webkit-focus-ring-color;
  outline-offset: -2px;
}
figure {
  margin: 0;
}
img {
  vertical-align: middle;
}
.img-responsive,
.thumbnail > img,
.thumbnail a > img,
.carousel-inner > .item > img,
.carousel-inner > .item > a > img {
  display: block;
  max-width: 100%;
  height: auto;
}
.img-rounded {
  border-radius: 6px;
}
.img-thumbnail {
  display: inline-block;
  max-width: 100%;
  height: auto;
  padding: 4px;
  line-height: 1.42857143;
  background-color: #fff;
  border: 1px solid #ddd;
  border-radius: 4px;
  -webkit-transition: all .2s ease-in-out;
       -o-transition: all .2s ease-in-out;
          transition: all .2s ease-in-out;
}
.img-circle {
  border-radius: 50%;
}
hr {
  margin-top: 20px;
  margin-bottom: 20px;
  border: 0;
  border-top: 1px solid #eee;
}
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  border: 0;
}
.sr-only-focusable:active,
.sr-only-focusable:focus {
  position: static;
  width: auto;
  height: auto;
  margin: 0;
  overflow: visible;
  clip: auto;
}
[role="button"] {
  cursor: pointer;
}
h1,
h2,
h3,
h4,
h5,
h6,
.h1,
.h2,
.h3,
.h4,
.h5,
.h6 {
  font-family: inherit;
  font-weight: 500;
  line-height: 1.1;
  color: inherit;
}
h1 small,
h2 small,
h3 small,
h4 small,
h5 small,
h6 small,
.h1 small,
.h2 small,
.h3 small,
.h4 small,
.h5 small,
.h6 small,
h1 .small,
h2 .small,
h3 .small,
h4 .small,
h5 .small,
h6 .small,
.h1 .small,
.h2 .small,
.h3 .small,
.h4 .small,
.h5 .small,
.h6 .small {
  font-weight: normal;
  line-height: 1;
  color: #777;
}
h1,
.h1,
h2,
.h2,
h3,
.h3 {
  margin-top: 20px;
  margin-bottom: 10px;
}
h1 small,
.h1 small,
h2 small,
.h2 small,
h3 small,
.h3 small,
h1 .small,
.h1 .small,
h2 .small,
.h2 .small,
h3 .small,
.h3 .small {
  font-size: 65%;
}
h4,
.h4,
h5,
.h5,
h6,
.h6 {
  margin-top: 10px;
  margin-bottom: 10px;
}
h4 small,
.h4 small,
h5 small,
.h5 small,
h6 small,
.h6 small,
h4 .small,
.h4 .small,
h5 .small,
.h5 .small,
h6 .small,
.h6 .small {
  font-size: 75%;
}
h1,
.h1 {
  font-size: 36px;
}
h2,
.h2 {
  font-size: 30px;
}
h3,
.h3 {
  font-size: 24px;
}
h4,
.h4 {
  font-size: 18px;
}
h5,
.h5 {
  font-size: 14px;
}
h6,
.h6 {
  font-size: 12px;
}
p {
  margin: 0 0 10px;
}
.lead {
  margin-bottom: 20px;
  font-size: 16px;
  font-weight: 300;
  line-height: 1.4;
}
@media (min-width: 768px) {
  .lead {
    font-size: 21px;
  }
}
small,
.small {
  font-size: 85%;
}
mark,
.mark {
  padding: .2em;
  background-color: #fcf8e3;
}
.text-left {
  text-align: left;
}
.text-right {
  text-align: right;
}
.text-center {
  text-align: center;
}
.text-justify {
  text-align: justify;
}
.text-nowrap {
  white-space: nowrap;
}
.text-lowercase {
  text-transform: lowercase;
}
.text-uppercase {
  text-transform: uppercase;
}
.text-capitalize {
  text-transform: capitalize;
}
.text-muted {
  color: #777;
}
.text-primary {
  color: #337ab7;
}
a.text-primary:hover,
a.text-primary:focus {
  color: #286090;
}
.text-success {
  color: #3c763d;
}
a.text-success:hover,
a.text-success:focus {
  color: #2b542c;
}
.text-info {
  color: #31708f;
}
a.text-info:hover,
a.text-info:focus {
  color: #245269;
}
.text-warning {
  color: #8a6d3b;
}
a.text-warning:hover,
a.text-warning:focus {
  color: #66512c;
}
.text-danger {
  color: #a94442;
}
a.text-danger:hover,
a.text-danger:focus {
  color: #843534;
}
.bg-primary {
  color: #fff;
  background-color: #337ab7;
}
a.bg-primary:hover,
a.bg-primary:focus {
  background-color: #286090;
}
.bg-success {
  background-color: #dff0d8;
}
a.bg-success:hover,
a.bg-success:focus {
  background-color: #c1e2b3;
}
.bg-info {
  background-color: #d9edf7;
}
a.bg-info:hover,
a.bg-info:focus {
  background-color: #afd9ee;
}
.bg-warning {
  background-color: #fcf8e3;
}
a.bg-warning:hover,
a.bg-warning:focus {
  background-color: #f7ecb5;
}
.bg-danger {
  background-color: #f2dede;
}
a.bg-danger:hover,
a.bg-danger:focus {
  background-color: #e4b9b9;
}
.page-header {
  padding-bottom: 9px;
  margin: 40px 0 20px;
  border-bottom: 1px solid #eee;
}
ul,
ol {
  margin-top: 0;
  margin-bottom: 10px;
}
ul ul,
ol ul,
ul ol,
ol ol {
  margin-bottom: 0;
}
.list-unstyled {
  padding-left: 0;
  list-style: none;
}
.list-inline {
  padding-left: 0;
  margin-left: -5px;
  list-style: none;
}
.list-inline > li {
  display: inline-block;
  padding-right: 5px;
  padding-left: 5px;
}
dl {
  margin-top: 0;
  margin-bottom: 20px;
}
dt,
dd {
  line-height: 1.42857143;
}
dt {
  font-weight: bold;
}
dd {
  margin-left: 0;
}
@media (min-width: 768px) {
  .dl-horizontal dt {
    float: left;
    width: 160px;
    overflow: hidden;
    clear: left;
    text-align: right;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .dl-horizontal dd {
    margin-left: 180px;
  }
}
abbr[title],
abbr[data-original-title] {
  cursor: help;
  border-bottom: 1px dotted #777;
}
.initialism {
  font-size: 90%;
  text-transform: uppercase;
}
blockquote {
  padding: 10px 20px;
  margin: 0 0 20px;
  font-size: 17.5px;
  border-left: 5px solid #eee;
}
blockquote p:last-child,
blockquote ul:last-child,
blockquote ol:last-child {
  margin-bottom: 0;
}
blockquote footer,
blockquote small,
blockquote .small {
  display: block;
  font-size: 80%;
  line-height: 1.42857143;
  color: #777;
}
blockquote footer:before,
blockquote small:before,
blockquote .small:before {
  content: '\2014 \00A0';
}
.blockquote-reverse,
blockquote.pull-right {
  padding-right: 15px;
  padding-left: 0;
  text-align: right;
  border-right: 5px solid #eee;
  border-left: 0;
}
.blockquote-reverse footer:before,
blockquote.pull-right footer:before,
.blockquote-reverse small:before,
blockquote.pull-right small:before,
.blockquote-reverse .small:before,
blockquote.pull-right .small:before {
  content: '';
}
.blockquote-reverse footer:after,
blockquote.pull-right footer:after,
.blockquote-reverse small:after,
blockquote.pull-right small:after,
.blockquote-reverse .small:after,
blockquote.pull-right .small:after {
  content: '\00A0 \2014';
}
address {
  margin-bottom: 20px;
  font-style: normal;
  line-height: 1.42857143;
}
code,
kbd,
pre,
samp {
  font-family: Menlo, Monaco, Consolas, "Courier New", monospace;
}
code {
  padding: 2px 4px;
  font-size: 90%;
  color: #c7254e;
  background-color: #f9f2f4;
  border-radius: 4px;
}
kbd {
  padding: 2px 4px;
  font-size: 90%;
  color: #fff;
  background-color: #333;
  border-radius: 3px;
  -webkit-box-shadow: inset 0 -1px 0 rgba(0, 0, 0, .25);
          box-shadow: inset 0 -1px 0 rgba(0, 0, 0, .25);
}
kbd kbd {
  padding: 0;
  font-size: 100%;
  font-weight: bold;
  -webkit-box-shadow: none;
          box-shadow: none;
}
pre {
  display: block;
  padding: 9.5px;
  margin: 0 0 10px;
  font-size: 13px;
  line-height: 1.42857143;
  color: #333;
  word-break: break-all;
  word-wrap: break-word;
  background-color: #f5f5f5;
  border: 1px solid #ccc;
  border-radius: 4px;
}
pre code {
  padding: 0;
  font-size: inherit;
  color: inherit;
  white-space: pre-wrap;
  background-color: transparent;
  border-radius: 0;
}
.pre-scrollable {
  max-height: 340px;
  overflow-y: scroll;
}
.container {
  padding-right: 15px;
  padding-left: 15px;
  margin-right: auto;
  margin-left: auto;
}
@media (min-width: 768px) {
  .container {
    width: 750px;
  }
}
@media (min-width: 992px) {
  .container {
    width: 970px;
  }
}
@media (min-width: 1200px) {
  .container {
    width: 1170px;
  }
}
.container-fluid {
  padding-right: 15px;
  padding-left: 15px;
  margin-right: auto;
  margin-left: auto;
}
.row {
  margin-right: -15px;
  margin-left: -15px;
}
.col-xs-1, .col-sm-1, .col-md-1, .col-lg-1, .col-xs-2, .col-sm-2, .col-md-2, .col-lg-2, .col-xs-3, .col-sm-3, .col-md-3, .col-lg-3, .col-xs-4, .col-sm-4, .col-md-4, .col-lg-4, .col-xs-5, .col-sm-5, .col-md-5, .col-lg-5, .col-xs-6, .col-sm-6, .col-md-6, .col-lg-6, .col-xs-7, .col-sm-7, .col-md-7, .col-lg-7, .col-xs-8, .col-sm-8, .col-md-8, .col-lg-8, .col-xs-9, .col-sm-9, .col-md-9, .col-lg-9, .col-xs-10, .col-sm-10, .col-md-10, .col-lg-10, .col-xs-11, .col-sm-11, .col-md-11, .col-lg-11, .col-xs-12, .col-sm-12, .col-md-12, .col-lg-12 {
  position: relative;
  min-height: 1px;
  padding-right: 15px;
  padding-left: 15px;
}
.col-xs-1, .col-xs-2, .col-xs-3, .col-xs-4, .col-xs-5, .col-xs-6, .col-xs-7, .col-xs-8, .col-xs-9, .col-xs-10, .col-xs-11, .col-xs-12 {
  float: left;
}
.col-xs-12 {
  width: 100%;
}
.col-xs-11 {
  width: 91.66666667%;
}
.col-xs-10 {
  width: 83.33333333%;
}
.col-xs-9 {
  width: 75%;
}
.col-xs-8 {
  width: 66.66666667%;
}
.col-xs-7 {
  width: 58.33333333%;
}
.col-xs-6 {
  width: 50%;
}
.col-xs-5 {
  width: 41.66666667%;
}
.col-xs-4 {
  width: 33.33333333%;
}
.col-xs-3 {
  width: 25%;
}
.col-xs-2 {
  width: 16.66666667%;
}
.col-xs-1 {
  width: 8.33333333%;
}
.col-xs-pull-12 {
  right: 100%;
}
.col-xs-pull-11 {
  right: 91.66666667%;
}
.col-xs-pull-10 {
  right: 83.33333333%;
}
.col-xs-pull-9 {
  right: 75%;
}
.col-xs-pull-8 {
  right: 66.66666667%;
}
.col-xs-pull-7 {
  right: 58.33333333%;
}
.col-xs-pull-6 {
  right: 50%;
}
.col-xs-pull-5 {
  right: 41.66666667%;
}
.col-xs-pull-4 {
  right: 33.33333333%;
}
.col-xs-pull-3 {
  right: 25%;
}
.col-xs-pull-2 {
  right: 16.66666667%;
}
.col-xs-pull-1 {
  right: 8.33333333%;
}
.col-xs-pull-0 {
  right: auto;
}
.col-xs-push-12 {
  left: 100%;
}
.col-xs-push-11 {
  left: 91.66666667%;
}
.col-xs-push-10 {
  left: 83.33333333%;
}
.col-xs-push-9 {
  left: 75%;
}
.col-xs-push-8 {
  left: 66.66666667%;
}
.col-xs-push-7 {
  left: 58.33333333%;
}
.col-xs-push-6 {
  left: 50%;
}
.col-xs-push-5 {
  left: 41.66666667%;
}
.col-xs-push-4 {
  left: 33.33333333%;
}
.col-xs-push-3 {
  left: 25%;
}
.col-xs-push-2 {
  left: 16.66666667%;
}
.col-xs-push-1 {
  left: 8.33333333%;
}
.col-xs-push-0 {
  left: auto;
}
.col-xs-offset-12 {
  margin-left: 100%;
}
.col-xs-offset-11 {
  margin-left: 91.66666667%;
}
.col-xs-offset-10 {
  margin-left: 83.33333333%;
}
.col-xs-offset-9 {
  margin-left: 75%;
}
.col-xs-offset-8 {
  margin-left: 66.66666667%;
}
.col-xs-offset-7 {
  margin-left: 58.33333333%;
}
.col-xs-offset-6 {
  margin-left: 50%;
}
.col-xs-offset-5 {
  margin-left: 41.66666667%;
}
.col-xs-offset-4 {
  margin-left: 33.33333333%;
}
.col-xs-offset-3 {
  margin-left: 25%;
}
.col-xs-offset-2 {
  margin-left: 16.66666667%;
}
.col-xs-offset-1 {
  margin-left: 8.33333333%;
}
.col-xs-offset-0 {
  margin-left: 0;
}
@media (min-width: 768px) {
  .col-sm-1, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-sm-10, .col-sm-11, .col-sm-12 {
    float: left;
  }
  .col-sm-12 {
    width: 100%;
  }
  .col-sm-11 {
    width: 91.66666667%;
  }
  .col-sm-10 {
    width: 83.33333333%;
  }
  .col-sm-9 {
    width: 75%;
  }
  .col-sm-8 {
    width: 66.66666667%;
  }
  .col-sm-7 {
    width: 58.33333333%;
  }
  .col-sm-6 {
    width: 50%;
  }
  .col-sm-5 {
    width: 41.66666667%;
  }
  .col-sm-4 {
    width: 33.33333333%;
  }
  .col-sm-3 {
    width: 25%;
  }
  .col-sm-2 {
    width: 16.66666667%;
  }
  .col-sm-1 {
    width: 8.33333333%;
  }
  .col-sm-pull-12 {
    right: 100%;
  }
  .col-sm-pull-11 {
    right: 91.66666667%;
  }
  .col-sm-pull-10 {
    right: 83.33333333%;
  }
  .col-sm-pull-9 {
    right: 75%;
  }
  .col-sm-pull-8 {
    right: 66.66666667%;
  }
  .col-sm-pull-7 {
    right: 58.33333333%;
  }
  .col-sm-pull-6 {
    right: 50%;
  }
  .col-sm-pull-5 {
    right: 41.66666667%;
  }
  .col-sm-pull-4 {
    right: 33.33333333%;
  }
  .col-sm-pull-3 {
    right: 25%;
  }
  .col-sm-pull-2 {
    right: 16.66666667%;
  }
  .col-sm-pull-1 {
    right: 8.33333333%;
  }
  .col-sm-pull-0 {
    right: auto;
  }
  .col-sm-push-12 {
    left: 100%;
  }
  .col-sm-push-11 {
    left: 91.66666667%;
  }
  .col-sm-push-10 {
    left: 83.33333333%;
  }
  .col-sm-push-9 {
    left: 75%;
  }
  .col-sm-push-8 {
    left: 66.66666667%;
  }
  .col-sm-push-7 {
    left: 58.33333333%;
  }
  .col-sm-push-6 {
    left: 50%;
  }
  .col-sm-push-5 {
    left: 41.66666667%;
  }
  .col-sm-push-4 {
    left: 33.33333333%;
  }
  .col-sm-push-3 {
    left: 25%;
  }
  .col-sm-push-2 {
    left: 16.66666667%;
  }
  .col-sm-push-1 {
    left: 8.33333333%;
  }
  .col-sm-push-0 {
    left: auto;
  }
  .col-sm-offset-12 {
    margin-left: 100%;
  }
  .col-sm-offset-11 {
    margin-left: 91.66666667%;
  }
  .col-sm-offset-10 {
    margin-left: 83.33333333%;
  }
  .col-sm-offset-9 {
    margin-left: 75%;
  }
  .col-sm-offset-8 {
    margin-left: 66.66666667%;
  }
  .col-sm-offset-7 {
    margin-left: 58.33333333%;
  }
  .col-sm-offset-6 {
    margin-left: 50%;
  }
  .col-sm-offset-5 {
    margin-left: 41.66666667%;
  }
  .col-sm-offset-4 {
    margin-left: 33.33333333%;
  }
  .col-sm-offset-3 {
    margin-left: 25%;
  }
  .col-sm-offset-2 {
    margin-left: 16.66666667%;
  }
  .col-sm-offset-1 {
    margin-left: 8.33333333%;
  }
  .col-sm-offset-0 {
    margin-left: 0;
  }
}
@media (min-width: 992px) {
  .col-md-1, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-10, .col-md-11, .col-md-12 {
    float: left;
  }
  .col-md-12 {
    width: 100%;
  }
  .col-md-11 {
    width: 91.66666667%;
  }
  .col-md-10 {
    width: 83.33333333%;
  }
  .col-md-9 {
    width: 75%;
  }
  .col-md-8 {
    width: 66.66666667%;
  }
  .col-md-7 {
    width: 58.33333333%;
  }
  .col-md-6 {
    width: 50%;
  }
  .col-md-5 {
    width: 41.66666667%;
  }
  .col-md-4 {
    width: 33.33333333%;
  }
  .col-md-3 {
    width: 25%;
  }
  .col-md-2 {
    width: 16.66666667%;
  }
  .col-md-1 {
    width: 8.33333333%;
  }
  .col-md-pull-12 {
    right: 100%;
  }
  .col-md-pull-11 {
    right: 91.66666667%;
  }
  .col-md-pull-10 {
    right: 83.33333333%;
  }
  .col-md-pull-9 {
    right: 75%;
  }
  .col-md-pull-8 {
    right: 66.66666667%;
  }
  .col-md-pull-7 {
    right: 58.33333333%;
  }
  .col-md-pull-6 {
    right: 50%;
  }
  .col-md-pull-5 {
    right: 41.66666667%;
  }
  .col-md-pull-4 {
    right: 33.33333333%;
  }
  .col-md-pull-3 {
    right: 25%;
  }
  .col-md-pull-2 {
    right: 16.66666667%;
  }
  .col-md-pull-1 {
    right: 8.33333333%;
  }
  .col-md-pull-0 {
    right: auto;
  }
  .col-md-push-12 {
    left: 100%;
  }
  .col-md-push-11 {
    left: 91.66666667%;
  }
  .col-md-push-10 {
    left: 83.33333333%;
  }
  .col-md-push-9 {
    left: 75%;
  }
  .col-md-push-8 {
    left: 66.66666667%;
  }
  .col-md-push-7 {
    left: 58.33333333%;
  }
  .col-md-push-6 {
    left: 50%;
  }
  .col-md-push-5 {
    left: 41.66666667%;
  }
  .col-md-push-4 {
    left: 33.33333333%;
  }
  .col-md-push-3 {
    left: 25%;
  }
  .col-md-push-2 {
    left: 16.66666667%;
  }
  .col-md-push-1 {
    left: 8.33333333%;
  }
  .col-md-push-0 {
    left: auto;
  }
  .col-md-offset-12 {
    margin-left: 100%;
  }
  .col-md-offset-11 {
    margin-left: 91.66666667%;
  }
  .col-md-offset-10 {
    margin-left: 83.33333333%;
  }
  .col-md-offset-9 {
    margin-left: 75%;
  }
  .col-md-offset-8 {
    margin-left: 66.66666667%;
  }
  .col-md-offset-7 {
    margin-left: 58.33333333%;
  }
  .col-md-offset-6 {
    margin-left: 50%;
  }
  .col-md-offset-5 {
    margin-left: 41.66666667%;
  }
  .col-md-offset-4 {
    margin-left: 33.33333333%;
  }
  .col-md-offset-3 {
    margin-left: 25%;
  }
  .col-md-offset-2 {
    margin-left: 16.66666667%;
  }
  .col-md-offset-1 {
    margin-left: 8.33333333%;
  }
  .col-md-offset-0 {
    margin-left: 0;
  }
}
@media (min-width: 1200px) {
  .col-lg-1, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-lg-10, .col-lg-11, .col-lg-12 {
    float: left;
  }
  .col-lg-12 {
    width: 100%;
  }
  .col-lg-11 {
    width: 91.66666667%;
  }
  .col-lg-10 {
    width: 83.33333333%;
  }
  .col-lg-9 {
    width: 75%;
  }
  .col-lg-8 {
    width: 66.66666667%;
  }
  .col-lg-7 {
    width: 58.33333333%;
  }
  .col-lg-6 {
    width: 50%;
  }
  .col-lg-5 {
    width: 41.66666667%;
  }
  .col-lg-4 {
    width: 33.33333333%;
  }
  .col-lg-3 {
    width: 25%;
  }
  .col-lg-2 {
    width: 16.66666667%;
  }
  .col-lg-1 {
    width: 8.33333333%;
  }
  .col-lg-pull-12 {
    right: 100%;
  }
  .col-lg-pull-11 {
    right: 91.66666667%;
  }
  .col-lg-pull-10 {
    right: 83.33333333%;
  }
  .col-lg-pull-9 {
    right: 75%;
  }
  .col-lg-pull-8 {
    right: 66.66666667%;
  }
  .col-lg-pull-7 {
    right: 58.33333333%;
  }
  .col-lg-pull-6 {
    right: 50%;
  }
  .col-lg-pull-5 {
    right: 41.66666667%;
  }
  .col-lg-pull-4 {
    right: 33.33333333%;
  }
  .col-lg-pull-3 {
    right: 25%;
  }
  .col-lg-pull-2 {
    right: 16.66666667%;
  }
  .col-lg-pull-1 {
    right: 8.33333333%;
  }
  .col-lg-pull-0 {
    right: auto;
  }
  .col-lg-push-12 {
    left: 100%;
  }
  .col-lg-push-11 {
    left: 91.66666667%;
  }
  .col-lg-push-10 {
    left: 83.33333333%;
  }
  .col-lg-push-9 {
    left: 75%;
  }
  .col-lg-push-8 {
    left: 66.66666667%;
  }
  .col-lg-push-7 {
    left: 58.33333333%;
  }
  .col-lg-push-6 {
    left: 50%;
  }
  .col-lg-push-5 {
    left: 41.66666667%;
  }
  .col-lg-push-4 {
    left: 33.33333333%;
  }
  .col-lg-push-3 {
    left: 25%;
  }
  .col-lg-push-2 {
    left: 16.66666667%;
  }
  .col-lg-push-1 {
    left: 8.33333333%;
  }
  .col-lg-push-0 {
    left: auto;
  }
  .col-lg-offset-12 {
    margin-left: 100%;
  }
  .col-lg-offset-11 {
    margin-left: 91.66666667%;
  }
  .col-lg-offset-10 {
    margin-left: 83.33333333%;
  }
  .col-lg-offset-9 {
    margin-left: 75%;
  }
  .col-lg-offset-8 {
    margin-left: 66.66666667%;
  }
  .col-lg-offset-7 {
    margin-left: 58.33333333%;
  }
  .col-lg-offset-6 {
    margin-left: 50%;
  }
  .col-lg-offset-5 {
    margin-left: 41.66666667%;
  }
  .col-lg-offset-4 {
    margin-left: 33.33333333%;
  }
  .col-lg-offset-3 {
    margin-left: 25%;
  }
  .col-lg-offset-2 {
    margin-left: 16.66666667%;
  }
  .col-lg-offset-1 {
    margin-left: 8.33333333%;
  }
  .col-lg-offset-0 {
    margin-left: 0;
  }
}
table {
  background-color: transparent;
}
caption {
  padding-top: 8px;
  padding-bottom: 8px;
  color: #777;
  text-align: left;
}
th {
  text-align: left;
}
.table {
  width: 100%;
  max-width: 100%;
  margin-bottom: 20px;
}
.table > thead > tr > th,
.table > tbody > tr > th,
.table > tfoot > tr > th,
.table > thead > tr > td,
.table > tbody > tr > td,
.table > tfoot > tr > td {
  padding: 8px;
  line-height: 1.42857143;
  vertical-align: top;
  border-top: 1px solid #ddd;
}
.table > thead > tr > th {
  vertical-align: bottom;
  border-bottom: 2px solid #ddd;
}
.table > caption + thead > tr:first-child > th,
.table > colgroup + thead > tr:first-child > th,
.table > thead:first-child > tr:first-child > th,
.table > caption + thead > tr:first-child > td,
.table > colgroup + thead > tr:first-child > td,
.table > thead:first-child > tr:first-child > td {
  border-top: 0;
}
.table > tbody + tbody {
  border-top: 2px solid #ddd;
}
.table .table {
  background-color: #fff;
}
.table-condensed > thead > tr > th,
.table-condensed > tbody > tr > th,
.table-condensed > tfoot > tr > th,
.table-condensed > thead > tr > td,
.table-condensed > tbody > tr > td,
.table-condensed > tfoot > tr > td {
  padding: 5px;
}
.table-bordered {
  border: 1px solid #ddd;
}
.table-bordered > thead > tr > th,
.table-bordered > tbody > tr > th,
.table-bordered > tfoot > tr > th,
.table-bordered > thead > tr > td,
.table-bordered > tbody > tr > td,
.table-bordered > tfoot > tr > td {
  border: 1px solid #ddd;
}
.table-bordered > thead > tr > th,
.table-bordered > thead > tr > td {
  border-bottom-width: 2px;
}
.table-striped > tbody > tr:nth-of-type(odd) {
  background-color: #f9f9f9;
}
.table-hover > tbody > tr:hover {
  background-color: #f5f5f5;
}
table col[class*="col-"] {
  position: static;
  display: table-column;
  float: none;
}
table td[class*="col-"],
table th[class*="col-"] {
  position: static;
  display: table-cell;
  float: none;
}
.table > thead > tr > td.active,
.table > tbody > tr > td.active,
.table > tfoot > tr > td.active,
.table > thead > tr > th.active,
.table > tbody > tr > th.active,
.table > tfoot > tr > th.active,
.table > thead > tr.active > td,
.table > tbody > tr.active > td,
.table > tfoot > tr.active > td,
.table > thead > tr.active > th,
.table > tbody > tr.active > th,
.table > tfoot > tr.active > th {
  background-color: #f5f5f5;
}
.table-hover > tbody > tr > td.active:hover,
.table-hover > tbody > tr > th.active:hover,
.table-hover > tbody > tr.active:hover > td,
.table-hover > tbody > tr:hover > .active,
.table-hover > tbody > tr.active:hover > th {
  background-color: #e8e8e8;
}
.table > thead > tr > td.success,
.table > tbody > tr > td.success,
.table > tfoot > tr > td.success,
.table > thead > tr > th.success,
.table > tbody > tr > th.success,
.table > tfoot > tr > th.success,
.table > thead > tr.success > td,
.table > tbody > tr.success > td,
.table > tfoot > tr.success > td,
.table > thead > tr.success > th,
.table > tbody > tr.success > th,
.table > tfoot > tr.success > th {
  background-color: #dff0d8;
}
.table-hover > tbody > tr > td.success:hover,
.table-hover > tbody > tr > th.success:hover,
.table-hover > tbody > tr.success:hover > td,
.table-hover > tbody > tr:hover > .success,
.table-hover > tbody > tr.success:hover > th {
  background-color: #d0e9c6;
}
.table > thead > tr > td.info,
.table > tbody > tr > td.info,
.table > tfoot > tr > td.info,
.table > thead > tr > th.info,
.table > tbody > tr > th.info,
.table > tfoot > tr > th.info,
.table > thead > tr.info > td,
.table > tbody > tr.info > td,
.table > tfoot > tr.info > td,
.table > thead > tr.info > th,
.table > tbody > tr.info > th,
.table > tfoot > tr.info > th {
  background-color: #d9edf7;
}
.table-hover > tbody > tr > td.info:hover,
.table-hover > tbody > tr > th.info:hover,
.table-hover > tbody > tr.info:hover > td,
.table-hover > tbody > tr:hover > .info,
.table-hover > tbody > tr.info:hover > th {
  background-color: #c4e3f3;
}
.table > thead > tr > td.warning,
.table > tbody > tr > td.warning,
.table > tfoot > tr > td.warning,
.table > thead > tr > th.warning,
.table > tbody > tr > th.warning,
.table > tfoot > tr > th.warning,
.table > thead > tr.warning > td,
.table > tbody > tr.warning > td,
.table > tfoot > tr.warning > td,
.table > thead > tr.warning > th,
.table > tbody > tr.warning > th,
.table > tfoot > tr.warning > th {
  background-color: #fcf8e3;
}
.table-hover > tbody > tr > td.warning:hover,
.table-hover > tbody > tr > th.warning:hover,
.table-hover > tbody > tr.warning:hover > td,
.table-hover > tbody > tr:hover > .warning,
.table-hover > tbody > tr.warning:hover > th {
  background-color: #faf2cc;
}
.table > thead > tr > td.danger,
.table > tbody > tr > td.danger,
.table > tfoot > tr > td.danger,
.table > thead > tr > th.danger,
.table > tbody > tr > th.danger,
.table > tfoot > tr > th.danger,
.table > thead > tr.danger > td,
.table > tbody > tr.danger > td,
.table > tfoot > tr.danger > td,
.table > thead > tr.danger > th,
.table > tbody > tr.danger > th,
.table > tfoot > tr.danger > th {
  background-color: #f2dede;
}
.table-hover > tbody > tr > td.danger:hover,
.table-hover > tbody > tr > th.danger:hover,
.table-hover > tbody > tr.danger:hover > td,
.table-hover > tbody > tr:hover > .danger,
.table-hover > tbody > tr.danger:hover > th {
  background-color: #ebcccc;
}
.table-responsive {
  min-height: .01%;
  overflow-x: auto;
}
@media screen and (max-width: 767px) {
  .table-responsive {
    width: 100%;
    margin-bottom: 15px;
    overflow-y: hidden;
    -ms-overflow-style: -ms-autohiding-scrollbar;
    border: 1px solid #ddd;
  }
  .table-responsive > .table {
    margin-bottom: 0;
  }
  .table-responsive > .table > thead > tr > th,
  .table-responsive > .table > tbody > tr > th,
  .table-responsive > .table > tfoot > tr > th,
  .table-responsive > .table > thead > tr > td,
  .table-responsive > .table > tbody > tr > td,
  .table-responsive > .table > tfoot > tr > td {
    white-space: nowrap;
  }
  .table-responsive > .table-bordered {
    border: 0;
  }
  .table-responsive > .table-bordered > thead > tr > th:first-child,
  .table-responsive > .table-bordered > tbody > tr > th:first-child,
  .table-responsive > .table-bordered > tfoot > tr > th:first-child,
  .table-responsive > .table-bordered > thead > tr > td:first-child,
  .table-responsive > .table-bordered > tbody > tr > td:first-child,
  .table-responsive > .table-bordered > tfoot > tr > td:first-child {
    border-left: 0;
  }
  .table-responsive > .table-bordered > thead > tr > th:last-child,
  .table-responsive > .table-bordered > tbody > tr > th:last-child,
  .table-responsive > .table-bordered > tfoot > tr > th:last-child,
  .table-responsive > .table-bordered > thead > tr > td:last-child,
  .table-responsive > .table-bordered > tbody > tr > td:last-child,
  .table-responsive > .table-bordered > tfoot > tr > td:last-child {
    border-right: 0;
  }
  .table-responsive > .table-bordered > tbody > tr:last-child > th,
  .table-responsive > .table-bordered > tfoot > tr:last-child > th,
  .table-responsive > .table-bordered > tbody > tr:last-child > td,
  .table-responsive > .table-bordered > tfoot > tr:last-child > td {
    border-bottom: 0;
  }
}
fieldset {
  min-width: 0;
  padding: 0;
  margin: 0;
  border: 0;
}
legend {
  display: block;
  width: 100%;
  padding: 0;
  margin-bottom: 20px;
  font-size: 21px;
  line-height: inherit;
  color: #333;
  border: 0;
  border-bottom: 1px solid #e5e5e5;
}
label {
  display: inline-block;
  max-width: 100%;
  margin-bottom: 5px;
  font-weight: bold;
}
input[type="search"] {
  -webkit-box-sizing: border-box;
     -moz-box-sizing: border-box;
          box-sizing: border-box;
}
input[type="radio"],
input[type="checkbox"] {
  margin: 4px 0 0;
  margin-top: 1px \9;
  line-height: normal;
}
input[type="file"] {
  display: block;
}
input[type="range"] {
  display: block;
  width: 100%;
}
select[multiple],
select[size] {
  height: auto;
}
input[type="file"]:focus,
input[type="radio"]:focus,
input[type="checkbox"]:focus {
  outline: 5px auto -webkit-focus-ring-color;
  outline-offset: -2px;
}
output {
  display: block;
  padding-top: 7px;
  font-size: 14px;
  line-height: 1.42857143;
  color: #555;
}
.form-control {
  display: block;
  width: 100%;
  height: 34px;
  padding: 6px 12px;
  font-size: 14px;
  line-height: 1.42857143;
  color: #555;
  background-color: #fff;
  background-image: none;
  border: 1px solid #ccc;
  border-radius: 4px;
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
          box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
  -webkit-transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;
       -o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
          transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
}
.form-control:focus {
  border-color: #66afe9;
  outline: 0;
  -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102, 175, 233, .6);
          box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102, 175, 233, .6);
}
.form-control::-moz-placeholder {
  color: #999;
  opacity: 1;
}
.form-control:-ms-input-placeholder {
  color: #999;
}
.form-control::-webkit-input-placeholder {
  color: #999;
}
.form-control::-ms-expand {
  background-color: transparent;
  border: 0;
}
.form-control[disabled],
.form-control[readonly],
fieldset[disabled] .form-control {
  background-color: #eee;
  opacity: 1;
}
.form-control[disabled],
fieldset[disabled] .form-control {
  cursor: not-allowed;
}
textarea.form-control {
  height: auto;
}
input[type="search"] {
  -webkit-appearance: none;
}
@media screen and (-webkit-min-device-pixel-ratio: 0) {
  input[type="date"].form-control,
  input[type="time"].form-control,
  input[type="datetime-local"].form-control,
  input[type="month"].form-control {
    line-height: 34px;
  }
  input[type="date"].input-sm,
  input[type="time"].input-sm,
  input[type="datetime-local"].input-sm,
  input[type="month"].input-sm,
  .input-group-sm input[type="date"],
  .input-group-sm input[type="time"],
  .input-group-sm input[type="datetime-local"],
  .input-group-sm input[type="month"] {
    line-height: 30px;
  }
  input[type="date"].input-lg,
  input[type="time"].input-lg,
  input[type="datetime-local"].input-lg,
  input[type="month"].input-lg,
  .input-group-lg input[type="date"],
  .input-group-lg input[type="time"],
  .input-group-lg input[type="datetime-local"],
  .input-group-lg input[type="month"] {
    line-height: 46px;
  }
}
.form-group {
  margin-bottom: 15px;
}
.radio,
.checkbox {
  position: relative;
  display: block;
  margin-top: 10px;
  margin-bottom: 10px;
}
.radio label,
.checkbox label {
  min-height: 20px;
  padding-left: 20px;
  margin-bottom: 0;
  font-weight: normal;
  cursor: pointer;
}
.radio input[type="radio"],
.radio-inline input[type="radio"],
.checkbox input[type="checkbox"],
.checkbox-inline input[type="checkbox"] {
  position: absolute;
  margin-top: 4px \9;
  margin-left: -20px;
}
.radio + .radio,
.checkbox + .checkbox {
  margin-top: -5px;
}
.radio-inline,
.checkbox-inline {
  position: relative;
  display: inline-block;
  padding-left: 20px;
  margin-bottom: 0;
  font-weight: normal;
  vertical-align: middle;
  cursor: pointer;
}
.radio-inline + .radio-inline,
.checkbox-inline + .checkbox-inline {
  margin-top: 0;
  margin-left: 10px;
}
input[type="radio"][disabled],
input[type="checkbox"][disabled],
input[type="radio"].disabled,
input[type="checkbox"].disabled,
fieldset[disabled] input[type="radio"],
fieldset[disabled] input[type="checkbox"] {
  cursor: not-allowed;
}
.radio-inline.disabled,
.checkbox-inline.disabled,
fieldset[disabled] .radio-inline,
fieldset[disabled] .checkbox-inline {
  cursor: not-allowed;
}
.radio.disabled label,
.checkbox.disabled label,
fieldset[disabled] .radio label,
fieldset[disabled] .checkbox label {
  cursor: not-allowed;
}
.form-control-static {
  min-height: 34px;
  padding-top: 7px;
  padding-bottom: 7px;
  margin-bottom: 0;
}
.form-control-static.input-lg,
.form-control-static.input-sm {
  padding-right: 0;
  padding-left: 0;
}
.input-sm {
  height: 30px;
  padding: 5px 10px;
  font-size: 12px;
  line-height: 1.5;
  border-radius: 3px;
}
select.input-sm {
  height: 30px;
  line-height: 30px;
}
textarea.input-sm,
select[multiple].input-sm {
  height: auto;
}
.form-group-sm .form-control {
  height: 30px;
  padding: 5px 10px;
  font-size: 12px;
  line-height: 1.5;
  border-radius: 3px;
}
.form-group-sm select.form-control {
  height: 30px;
  line-height: 30px;
}
.form-group-sm textarea.form-control,
.form-group-sm select[multiple].form-control {
  height: auto;
}
.form-group-sm .form-control-static {
  height: 30px;
  min-height: 32px;
  padding: 6px 10px;
  font-size: 12px;
  line-height: 1.5;
}
.input-lg {
  height: 46px;
  padding: 10px 16px;
  font-size: 18px;
  line-height: 1.3333333;
  border-radius: 6px;
}
select.input-lg {
  height: 46px;
  line-height: 46px;
}
textarea.input-lg,
select[multiple].input-lg {
  height: auto;
}
.form-group-lg .form-control {
  height: 46px;
  padding: 10px 16px;
  font-size: 18px;
  line-height: 1.3333333;
  border-radius: 6px;
}
.form-group-lg select.form-control {
  height: 46px;
  line-height: 46px;
}
.form-group-lg textarea.form-control,
.form-group-lg select[multiple].form-control {
  height: auto;
}
.form-group-lg .form-control-static {
  height: 46px;
  min-height: 38px;
  padding: 11px 16px;
  font-size: 18px;
  line-height: 1.3333333;
}
.has-feedback {
  position: relative;
}
.has-feedback .form-control {
  padding-right: 42.5px;
}
.form-control-feedback {
  position: absolute;
  top: 0;
  right: 0;
  z-index: 2;
  display: block;
  width: 34px;
  height: 34px;
  line-height: 34px;
  text-align: center;
  pointer-events: none;
}
.input-lg + .form-control-feedback,
.input-group-lg + .form-control-feedback,
.form-group-lg .form-control + .form-control-feedback {
  width: 46px;
  height: 46px;
  line-height: 46px;
}
.input-sm + .form-control-feedback,
.input-group-sm + .form-control-feedback,
.form-group-sm .form-control + .form-control-feedback {
  width: 30px;
  height: 30px;
  line-height: 30px;
}
.has-success .help-block,
.has-success .control-label,
.has-success .radio,
.has-success .checkbox,
.has-success .radio-inline,
.has-success .checkbox-inline,
.has-success.radio label,
.has-success.checkbox label,
.has-success.radio-inline label,
.has-success.checkbox-inline label {
  color: #3c763d;
}
.has-success .form-control {
  border-color: #3c763d;
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
          box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
}
.has-success .form-control:focus {
  border-color: #2b542c;
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #67b168;
          box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #67b168;
}
.has-success .input-group-addon {
  color: #3c763d;
  background-color: #dff0d8;
  border-color: #3c763d;
}
.has-success .form-control-feedback {
  color: #3c763d;
}
.has-warning .help-block,
.has-warning .control-label,
.has-warning .radio,
.has-warning .checkbox,
.has-warning .radio-inline,
.has-warning .checkbox-inline,
.has-warning.radio label,
.has-warning.checkbox label,
.has-warning.radio-inline label,
.has-warning.checkbox-inline label {
  color: #8a6d3b;
}
.has-warning .form-control {
  border-color: #8a6d3b;
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
          box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
}
.has-warning .form-control:focus {
  border-color: #66512c;
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #c0a16b;
          box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #c0a16b;
}
.has-warning .input-group-addon {
  color: #8a6d3b;
  background-color: #fcf8e3;
  border-color: #8a6d3b;
}
.has-warning .form-control-feedback {
  color: #8a6d3b;
}
.has-error .help-block,
.has-error .control-label,
.has-error .radio,
.has-error .checkbox,
.has-error .radio-inline,
.has-error .checkbox-inline,
.has-error.radio label,
.has-error.checkbox label,
.has-error.radio-inline label,
.has-error.checkbox-inline label {
  color: #a94442;
}
.has-error .form-control {
  border-color: #a94442;
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
          box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
}
.has-error .form-control:focus {
  border-color: #843534;
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #ce8483;
          box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #ce8483;
}
.has-error .input-group-addon {
  color: #a94442;
  background-color: #f2dede;
  border-color: #a94442;
}
.has-error .form-control-feedback {
  color: #a94442;
}
.has-feedback label ~ .form-control-feedback {
  top: 25px;
}
.has-feedback label.sr-only ~ .form-control-feedback {
  top: 0;
}
.help-block {
  display: block;
  margin-top: 5px;
  margin-bottom: 10px;
  color: #737373;
}
@media (min-width: 768px) {
  .form-inline .form-group {
    display: inline-block;
    margin-bottom: 0;
    vertical-align: middle;
  }
  .form-inline .form-control {
    display: inline-block;
    width: auto;
    vertical-align: middle;
  }
  .form-inline .form-control-static {
    display: inline-block;
  }
  .form-inline .input-group {
    display: inline-table;
    vertical-align: middle;
  }
  .form-inline .input-group .input-group-addon,
  .form-inline .input-group .input-group-btn,
  .form-inline .input-group .form-control {
    width: auto;
  }
  .form-inline .input-group > .form-control {
    width: 100%;
  }
  .form-inline .control-label {
    margin-bottom: 0;
    vertical-align: middle;
  }
  .form-inline .radio,
  .form-inline .checkbox {
    display: inline-block;
    margin-top: 0;
    margin-bottom: 0;
    vertical-align: middle;
  }
  .form-inline .radio label,
  .form-inline .checkbox label {
    padding-left: 0;
  }
  .form-inline .radio input[type="radio"],
  .form-inline .checkbox input[type="checkbox"] {
    position: relative;
    margin-left: 0;
  }
  .form-inline .has-feedback .form-control-feedback {
    top: 0;
  }
}
.form-horizontal .radio,
.form-horizontal .checkbox,
.form-horizontal .radio-inline,
.form-horizontal .checkbox-inline {
  padding-top: 7px;
  margin-top: 0;
  margin-bottom: 0;
}
.form-horizontal .radio,
.form-horizontal .checkbox {
  min-height: 27px;
}
.form-horizontal .form-group {
  margin-right: -15px;
  margin-left: -15px;
}
@media (min-width: 768px) {
  .form-horizontal .control-label {
    padding-top: 7px;
    margin-bottom: 0;
    text-align: right;
  }
}
.form-horizontal .has-feedback .form-control-feedback {
  right: 15px;
}
@media (min-width: 768px) {
  .form-horizontal .form-group-lg .control-label {
    padding-top: 11px;
    font-size: 18px;
  }
}
@media (min-width: 768px) {
  .form-horizontal .form-group-sm .control-label {
    padding-top: 6px;
    font-size: 12px;
  }
}
.btn {
  display: inline-block;
  padding: 6px 12px;
  margin-bottom: 0;
  font-size: 14px;
  font-weight: normal;
  line-height: 1.42857143;
  text-align: center;
  white-space: nowrap;
  vertical-align: middle;
  -ms-touch-action: manipulation;
      touch-action: manipulation;
  cursor: pointer;
  -webkit-user-select: none;
     -moz-user-select: none;
      -ms-user-select: none;
          user-select: none;
  background-image: none;
  border: 1px solid transparent;
  border-radius: 4px;
}
.btn:focus,
.btn:active:focus,
.btn.active:focus,
.btn.focus,
.btn:active.focus,
.btn.active.focus {
  outline: 5px auto -webkit-focus-ring-color;
  outline-offset: -2px;
}
.btn:hover,
.btn:focus,
.btn.focus {
  color: #333;
  text-decoration: none;
}
.btn:active,
.btn.active {
  background-image: none;
  outline: 0;
  -webkit-box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125);
          box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125);
}
.btn.disabled,
.btn[disabled],
fieldset[disabled] .btn {
  cursor: not-allowed;
  filter: alpha(opacity=65);
  -webkit-box-shadow: none;
          box-shadow: none;
  opacity: .65;
}
a.btn.disabled,
fieldset[disabled] a.btn {
  pointer-events: none;
}
.btn-default {
  color: #333;
  background-color: #fff;
  border-color: #ccc;
}
.btn-default:focus,
.btn-default.focus {
  color: #333;
  background-color: #e6e6e6;
  border-color: #8c8c8c;
}
.btn-default:hover {
  color: #333;
  background-color: #e6e6e6;
  border-color: #adadad;
}
.btn-default:active,
.btn-default.active,
.open > .dropdown-toggle.btn-default {
  color: #333;
  background-color: #e6e6e6;
  border-color: #adadad;
}
.btn-default:active:hover,
.btn-default.active:hover,
.open > .dropdown-toggle.btn-default:hover,
.btn-default:active:focus,
.btn-default.active:focus,
.open > .dropdown-toggle.btn-default:focus,
.btn-default:active.focus,
.btn-default.active.focus,
.open > .dropdown-toggle.btn-default.focus {
  color: #333;
  background-color: #d4d4d4;
  border-color: #8c8c8c;
}
.btn-default:active,
.btn-default.active,
.open > .dropdown-toggle.btn-default {
  background-image: none;
}
.btn-default.disabled:hover,
.btn-default[disabled]:hover,
fieldset[disabled] .btn-default:hover,
.btn-default.disabled:focus,
.btn-default[disabled]:focus,
fieldset[disabled] .btn-default:focus,
.btn-default.disabled.focus,
.btn-default[disabled].focus,
fieldset[disabled] .btn-default.focus {
  background-color: #fff;
  border-color: #ccc;
}
.btn-default .badge {
  color: #fff;
  background-color: #333;
}
.btn-primary {
  color: #fff;
  background-color: #337ab7;
  border-color: #2e6da4;
}
.btn-primary:focus,
.btn-primary.focus {
  color: #fff;
  background-color: #286090;
  border-color: #122b40;
}
.btn-primary:hover {
  color: #fff;
  background-color: #286090;
  border-color: #204d74;
}
.btn-primary:active,
.btn-primary.active,
.open > .dropdown-toggle.btn-primary {
  color: #fff;
  background-color: #286090;
  border-color: #204d74;
}
.btn-primary:active:hover,
.btn-primary.active:hover,
.open > .dropdown-toggle.btn-primary:hover,
.btn-primary:active:focus,
.btn-primary.active:focus,
.open > .dropdown-toggle.btn-primary:focus,
.btn-primary:active.focus,
.btn-primary.active.focus,
.open > .dropdown-toggle.btn-primary.focus {
  color: #fff;
  background-color: #204d74;
  border-color: #122b40;
}
.btn-primary:active,
.btn-primary.active,
.open > .dropdown-toggle.btn-primary {
  background-image: none;
}
.btn-primary.disabled:hover,
.btn-primary[disabled]:hover,
fieldset[disabled] .btn-primary:hover,
.btn-primary.disabled:focus,
.btn-primary[disabled]:focus,
fieldset[disabled] .btn-primary:focus,
.btn-primary.disabled.focus,
.btn-primary[disabled].focus,
fieldset[disabled] .btn-primary.focus {
  background-color: #337ab7;
  border-color: #2e6da4;
}
.btn-primary .badge {
  color: #337ab7;
  background-color: #fff;
}
.btn-success {
  color: #fff;
  background-color: #5cb85c;
  border-color: #4cae4c;
}
.btn-success:focus,
.btn-success.focus {
  color: #fff;
  background-color: #449d44;
  border-color: #255625;
}
.btn-success:hover {
  color: #fff;
  background-color: #449d44;
  border-color: #398439;
}
.btn-success:active,
.btn-success.active,
.open > .dropdown-toggle.btn-success {
  color: #fff;
  background-color: #449d44;
  border-color: #398439;
}
.btn-success:active:hover,
.btn-success.active:hover,
.open > .dropdown-toggle.btn-success:hover,
.btn-success:active:focus,
.btn-success.active:focus,
.open > .dropdown-toggle.btn-success:focus,
.btn-success:active.focus,
.btn-success.active.focus,
.open > .dropdown-toggle.btn-success.focus {
  color: #fff;
  background-color: #398439;
  border-color: #255625;
}
.btn-success:active,
.btn-success.active,
.open > .dropdown-toggle.btn-success {
  background-image: none;
}
.btn-success.disabled:hover,
.btn-success[disabled]:hover,
fieldset[disabled] .btn-success:hover,
.btn-success.disabled:focus,
.btn-success[disabled]:focus,
fieldset[disabled] .btn-success:focus,
.btn-success.disabled.focus,
.btn-success[disabled].focus,
fieldset[disabled] .btn-success.focus {
  background-color: #5cb85c;
  border-color: #4cae4c;
}
.btn-success .badge {
  color: #5cb85c;
  background-color: #fff;
}
.btn-info {
  color: #fff;
  background-color: #5bc0de;
  border-color: #46b8da;
}
.btn-info:focus,
.btn-info.focus {
  color: #fff;
  background-color: #31b0d5;
  border-color: #1b6d85;
}
.btn-info:hover {
  color: #fff;
  background-color: #31b0d5;
  border-color: #269abc;
}
.btn-info:active,
.btn-info.active,
.open > .dropdown-toggle.btn-info {
  color: #fff;
  background-color: #31b0d5;
  border-color: #269abc;
}
.btn-info:active:hover,
.btn-info.active:hover,
.open > .dropdown-toggle.btn-info:hover,
.btn-info:active:focus,
.btn-info.active:focus,
.open > .dropdown-toggle.btn-info:focus,
.btn-info:active.focus,
.btn-info.active.focus,
.open > .dropdown-toggle.btn-info.focus {
  color: #fff;
  background-color: #269abc;
  border-color: #1b6d85;
}
.btn-info:active,
.btn-info.active,
.open > .dropdown-toggle.btn-info {
  background-image: none;
}
.btn-info.disabled:hover,
.btn-info[disabled]:hover,
fieldset[disabled] .btn-info:hover,
.btn-info.disabled:focus,
.btn-info[disabled]:focus,
fieldset[disabled] .btn-info:focus,
.btn-info.disabled.focus,
.btn-info[disabled].focus,
fieldset[disabled] .btn-info.focus {
  background-color: #5bc0de;
  border-color: #46b8da;
}
.btn-info .badge {
  color: #5bc0de;
  background-color: #fff;
}
.btn-warning {
  color: #fff;
  background-color: #f0ad4e;
  border-color: #eea236;
}
.btn-warning:focus,
.btn-warning.focus {
  color: #fff;
  background-color: #ec971f;
  border-color: #985f0d;
}
.btn-warning:hover {
  color: #fff;
  background-color: #ec971f;
  border-color: #d58512;
}
.btn-warning:active,
.btn-warning.active,
.open > .dropdown-toggle.btn-warning {
  color: #fff;
  background-color: #ec971f;
  border-color: #d58512;
}
.btn-warning:active:hover,
.btn-warning.active:hover,
.open > .dropdown-toggle.btn-warning:hover,
.btn-warning:active:focus,
.btn-warning.active:focus,
.open > .dropdown-toggle.btn-warning:focus,
.btn-warning:active.focus,
.btn-warning.active.focus,
.open > .dropdown-toggle.btn-warning.focus {
  color: #fff;
  background-color: #d58512;
  border-color: #985f0d;
}
.btn-warning:active,
.btn-warning.active,
.open > .dropdown-toggle.btn-warning {
  background-image: none;
}
.btn-warning.disabled:hover,
.btn-warning[disabled]:hover,
fieldset[disabled] .btn-warning:hover,
.btn-warning.disabled:focus,
.btn-warning[disabled]:focus,
fieldset[disabled] .btn-warning:focus,
.btn-warning.disabled.focus,
.btn-warning[disabled].focus,
fieldset[disabled] .btn-warning.focus {
  background-color: #f0ad4e;
  border-color: #eea236;
}
.btn-warning .badge {
  color: #f0ad4e;
  background-color: #fff;
}
.btn-danger {
  color: #fff;
  background-color: #d9534f;
  border-color: #d43f3a;
}
.btn-danger:focus,
.btn-danger.focus {
  color: #fff;
  background-color: #c9302c;
  border-color: #761c19;
}
.btn-danger:hover {
  color: #fff;
  background-color: #c9302c;
  border-color: #ac2925;
}
.btn-danger:active,
.btn-danger.active,
.open > .dropdown-toggle.btn-danger {
  color: #fff;
  background-color: #c9302c;
  border-color: #ac2925;
}
.btn-danger:active:hover,
.btn-danger.active:hover,
.open > .dropdown-toggle.btn-danger:hover,
.btn-danger:active:focus,
.btn-danger.active:focus,
.open > .dropdown-toggle.btn-danger:focus,
.btn-danger:active.focus,
.btn-danger.active.focus,
.open > .dropdown-toggle.btn-danger.focus {
  color: #fff;
  background-color: #ac2925;
  border-color: #761c19;
}
.btn-danger:active,
.btn-danger.active,
.open > .dropdown-toggle.btn-danger {
  background-image: none;
}
.btn-danger.disabled:hover,
.btn-danger[disabled]:hover,
fieldset[disabled] .btn-danger:hover,
.btn-danger.disabled:focus,
.btn-danger[disabled]:focus,
fieldset[disabled] .btn-danger:focus,
.btn-danger.disabled.focus,
.btn-danger[disabled].focus,
fieldset[disabled] .btn-danger.focus {
  background-color: #d9534f;
  border-color: #d43f3a;
}
.btn-danger .badge {
  color: #d9534f;
  background-color: #fff;
}
.btn-link {
  font-weight: normal;
  color: #337ab7;
  border-radius: 0;
}
.btn-link,
.btn-link:active,
.btn-link.active,
.btn-link[disabled],
fieldset[disabled] .btn-link {
  background-color: transparent;
  -webkit-box-shadow: none;
          box-shadow: none;
}
.btn-link,
.btn-link:hover,
.btn-link:focus,
.btn-link:active {
  border-color: transparent;
}
.btn-link:hover,
.btn-link:focus {
  color: #23527c;
  text-decoration: underline;
  background-color: transparent;
}
.btn-link[disabled]:hover,
fieldset[disabled] .btn-link:hover,
.btn-link[disabled]:focus,
fieldset[disabled] .btn-link:focus {
  color: #777;
  text-decoration: none;
}
.btn-lg,
.btn-group-lg > .btn {
  padding: 10px 16px;
  font-size: 18px;
  line-height: 1.3333333;
  border-radius: 6px;
}
.btn-sm,
.btn-group-sm > .btn {
  padding: 5px 10px;
  font-size: 12px;
  line-height: 1.5;
  border-radius: 3px;
}
.btn-xs,
.btn-group-xs > .btn {
  padding: 1px 5px;
  font-size: 12px;
  line-height: 1.5;
  border-radius: 3px;
}
.btn-block {
  display: block;
  width: 100%;
}
.btn-block + .btn-block {
  margin-top: 5px;
}
input[type="submit"].btn-block,
input[type="reset"].btn-block,
input[type="button"].btn-block {
  width: 100%;
}
.fade {
  opacity: 0;
  -webkit-transition: opacity .15s linear;
       -o-transition: opacity .15s linear;
          transition: opacity .15s linear;
}
.fade.in {
  opacity: 1;
}
.collapse {
  display: none;
}
.collapse.in {
  display: block;
}
tr.collapse.in {
  display: table-row;
}
tbody.collapse.in {
  display: table-row-group;
}
.collapsing {
  position: relative;
  height: 0;
  overflow: hidden;
  -webkit-transition-timing-function: ease;
       -o-transition-timing-function: ease;
          transition-timing-function: ease;
  -webkit-transition-duration: .35s;
       -o-transition-duration: .35s;
          transition-duration: .35s;
  -webkit-transition-property: height, visibility;
       -o-transition-property: height, visibility;
          transition-property: height, visibility;
}
.caret {
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 2px;
  vertical-align: middle;
  border-top: 4px dashed;
  border-top: 4px solid \9;
  border-right: 4px solid transparent;
  border-left: 4px solid transparent;
}
.dropup,
.dropdown {
  position: relative;
}
.dropdown-toggle:focus {
  outline: 0;
}
.dropdown-menu {
  position: absolute;
  top: 100%;
  left: 0;
  z-index: 1000;
  display: none;
  float: left;
  min-width: 160px;
  padding: 5px 0;
  margin: 2px 0 0;
  font-size: 14px;
  text-align: left;
  list-style: none;
  background-color: #fff;
  -webkit-background-clip: padding-box;
          background-clip: padding-box;
  border: 1px solid #ccc;
  border: 1px solid rgba(0, 0, 0, .15);
  border-radius: 4px;
  -webkit-box-shadow: 0 6px 12px rgba(0, 0, 0, .175);
          box-shadow: 0 6px 12px rgba(0, 0, 0, .175);
}
.dropdown-menu.pull-right {
  right: 0;
  left: auto;
}
.dropdown-menu .divider {
  height: 1px;
  margin: 9px 0;
  overflow: hidden;
  background-color: #e5e5e5;
}
.dropdown-menu > li > a {
  display: block;
  padding: 3px 20px;
  clear: both;
  font-weight: normal;
  line-height: 1.42857143;
  color: #333;
  white-space: nowrap;
}
.dropdown-menu > li > a:hover,
.dropdown-menu > li > a:focus {
  color: #262626;
  text-decoration: none;
  background-color: #f5f5f5;
}
.dropdown-menu > .active > a,
.dropdown-menu > .active > a:hover,
.dropdown-menu > .active > a:focus {
  color: #fff;
  text-decoration: none;
  background-color: #337ab7;
  outline: 0;
}
.dropdown-menu > .disabled > a,
.dropdown-menu > .disabled > a:hover,
.dropdown-menu > .disabled > a:focus {
  color: #777;
}
.dropdown-menu > .disabled > a:hover,
.dropdown-menu > .disabled > a:focus {
  text-decoration: none;
  cursor: not-allowed;
  background-color: transparent;
  background-image: none;
  filter: progid:DXImageTransform.Microsoft.gradient(enabled = false);
}
.open > .dropdown-menu {
  display: block;
}
.open > a {
  outline: 0;
}
.dropdown-menu-right {
  right: 0;
  left: auto;
}
.dropdown-menu-left {
  right: auto;
  left: 0;
}
.dropdown-header {
  display: block;
  padding: 3px 20px;
  font-size: 12px;
  line-height: 1.42857143;
  color: #777;
  white-space: nowrap;
}
.dropdown-backdrop {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 990;
}
.pull-right > .dropdown-menu {
  right: 0;
  left: auto;
}
.dropup .caret,
.navbar-fixed-bottom .dropdown .caret {
  content: "";
  border-top: 0;
  border-bottom: 4px dashed;
  border-bottom: 4px solid \9;
}
.dropup .dropdown-menu,
.navbar-fixed-bottom .dropdown .dropdown-menu {
  top: auto;
  bottom: 100%;
  margin-bottom: 2px;
}
@media (min-width: 768px) {
  .navbar-right .dropdown-menu {
    right: 0;
    left: auto;
  }
  .navbar-right .dropdown-menu-left {
    right: auto;
    left: 0;
  }
}
.btn-group,
.btn-group-vertical {
  position: relative;
  display: inline-block;
  vertical-align: middle;
}
.btn-group > .btn,
.btn-group-vertical > .btn {
  position: relative;
  float: left;
}
.btn-group > .btn:hover,
.btn-group-vertical > .btn:hover,
.btn-group > .btn:focus,
.btn-group-vertical > .btn:focus,
.btn-group > .btn:active,
.btn-group-vertical > .btn:active,
.btn-group > .btn.active,
.btn-group-vertical > .btn.active {
  z-index: 2;
}
.btn-group .btn + .btn,
.btn-group .btn + .btn-group,
.btn-group .btn-group + .btn,
.btn-group .btn-group + .btn-group {
  margin-left: -1px;
}
.btn-toolbar {
  margin-left: -5px;
}
.btn-toolbar .btn,
.btn-toolbar .btn-group,
.btn-toolbar .input-group {
  float: left;
}
.btn-toolbar > .btn,
.btn-toolbar > .btn-group,
.btn-toolbar > .input-group {
  margin-left: 5px;
}
.btn-group > .btn:not(:first-child):not(:last-child):not(.dropdown-toggle) {
  border-radius: 0;
}
.btn-group > .btn:first-child {
  margin-left: 0;
}
.btn-group > .btn:first-child:not(:last-child):not(.dropdown-toggle) {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
.btn-group > .btn:last-child:not(:first-child),
.btn-group > .dropdown-toggle:not(:first-child) {
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}
.btn-group > .btn-group {
  float: left;
}
.btn-group > .btn-group:not(:first-child):not(:last-child) > .btn {
  border-radius: 0;
}
.btn-group > .btn-group:first-child:not(:last-child) > .btn:last-child,
.btn-group > .btn-group:first-child:not(:last-child) > .dropdown-toggle {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
.btn-group > .btn-group:last-child:not(:first-child) > .btn:first-child {
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}
.btn-group .dropdown-toggle:active,
.btn-group.open .dropdown-toggle {
  outline: 0;
}
.btn-group > .btn + .dropdown-toggle {
  padding-right: 8px;
  padding-left: 8px;
}
.btn-group > .btn-lg + .dropdown-toggle {
  padding-right: 12px;
  padding-left: 12px;
}
.btn-group.open .dropdown-toggle {
  -webkit-box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125);
          box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125);
}
.btn-group.open .dropdown-toggle.btn-link {
  -webkit-box-shadow: none;
          box-shadow: none;
}
.btn .caret {
  margin-left: 0;
}
.btn-lg .caret {
  border-width: 5px 5px 0;
  border-bottom-width: 0;
}
.dropup .btn-lg .caret {
  border-width: 0 5px 5px;
}
.btn-group-vertical > .btn,
.btn-group-vertical > .btn-group,
.btn-group-vertical > .btn-group > .btn {
  display: block;
  float: none;
  width: 100%;
  max-width: 100%;
}
.btn-group-vertical > .btn-group > .btn {
  float: none;
}
.btn-group-vertical > .btn + .btn,
.btn-group-vertical > .btn + .btn-group,
.btn-group-vertical > .btn-group + .btn,
.btn-group-vertical > .btn-group + .btn-group {
  margin-top: -1px;
  margin-left: 0;
}
.btn-group-vertical > .btn:not(:first-child):not(:last-child) {
  border-radius: 0;
}
.btn-group-vertical > .btn:first-child:not(:last-child) {
  border-top-left-radius: 4px;
  border-top-right-radius: 4px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}
.btn-group-vertical > .btn:last-child:not(:first-child) {
  border-top-left-radius: 0;
  border-top-right-radius: 0;
  border-bottom-right-radius: 4px;
  border-bottom-left-radius: 4px;
}
.btn-group-vertical > .btn-group:not(:first-child):not(:last-child) > .btn {
  border-radius: 0;
}
.btn-group-vertical > .btn-group:first-child:not(:last-child) > .btn:last-child,
.btn-group-vertical > .btn-group:first-child:not(:last-child) > .dropdown-toggle {
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}
.btn-group-vertical > .btn-group:last-child:not(:first-child) > .btn:first-child {
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
.btn-group-justified {
  display: table;
  width: 100%;
  table-layout: fixed;
  border-collapse: separate;
}
.btn-group-justified > .btn,
.btn-group-justified > .btn-group {
  display: table-cell;
  float: none;
  width: 1%;
}
.btn-group-justified > .btn-group .btn {
  width: 100%;
}
.btn-group-justified > .btn-group .dropdown-menu {
  left: auto;
}
[data-toggle="buttons"] > .btn input[type="radio"],
[data-toggle="buttons"] > .btn-group > .btn input[type="radio"],
[data-toggle="buttons"] > .btn input[type="checkbox"],
[data-toggle="buttons"] > .btn-group > .btn input[type="checkbox"] {
  position: absolute;
  clip: rect(0, 0, 0, 0);
  pointer-events: none;
}
.input-group {
  position: relative;
  display: table;
  border-collapse: separate;
}
.input-group[class*="col-"] {
  float: none;
  padding-right: 0;
  padding-left: 0;
}
.input-group .form-control {
  position: relative;
  z-index: 2;
  float: left;
  width: 100%;
  margin-bottom: 0;
}
.input-group .form-control:focus {
  z-index: 3;
}
.input-group-lg > .form-control,
.input-group-lg > .input-group-addon,
.input-group-lg > .input-group-btn > .btn {
  height: 46px;
  padding: 10px 16px;
  font-size: 18px;
  line-height: 1.3333333;
  border-radius: 6px;
}
select.input-group-lg > .form-control,
select.input-group-lg > .input-group-addon,
select.input-group-lg > .input-group-btn > .btn {
  height: 46px;
  line-height: 46px;
}
textarea.input-group-lg > .form-control,
textarea.input-group-lg > .input-group-addon,
textarea.input-group-lg > .input-group-btn > .btn,
select[multiple].input-group-lg > .form-control,
select[multiple].input-group-lg > .input-group-addon,
select[multiple].input-group-lg > .input-group-btn > .btn {
  height: auto;
}
.input-group-sm > .form-control,
.input-group-sm > .input-group-addon,
.input-group-sm > .input-group-btn > .btn {
  height: 30px;
  padding: 5px 10px;
  font-size: 12px;
  line-height: 1.5;
  border-radius: 3px;
}
select.input-group-sm > .form-control,
select.input-group-sm > .input-group-addon,
select.input-group-sm > .input-group-btn > .btn {
  height: 30px;
  line-height: 30px;
}
textarea.input-group-sm > .form-control,
textarea.input-group-sm > .input-group-addon,
textarea.input-group-sm > .input-group-btn > .btn,
select[multiple].input-group-sm > .form-control,
select[multiple].input-group-sm > .input-group-addon,
select[multiple].input-group-sm > .input-group-btn > .btn {
  height: auto;
}
.input-group-addon,
.input-group-btn,
.input-group .form-control {
  display: table-cell;
}
.input-group-addon:not(:first-child):not(:last-child),
.input-group-btn:not(:first-child):not(:last-child),
.input-group .form-control:not(:first-child):not(:last-child) {
  border-radius: 0;
}
.input-group-addon,
.input-group-btn {
  width: 1%;
  white-space: nowrap;
  vertical-align: middle;
}
.input-group-addon {
  padding: 6px 12px;
  font-size: 14px;
  font-weight: normal;
  line-height: 1;
  color: #555;
  text-align: center;
  background-color: #eee;
  border: 1px solid #ccc;
  border-radius: 4px;
}
.input-group-addon.input-sm {
  padding: 5px 10px;
  font-size: 12px;
  border-radius: 3px;
}
.input-group-addon.input-lg {
  padding: 10px 16px;
  font-size: 18px;
  border-radius: 6px;
}
.input-group-addon input[type="radio"],
.input-group-addon input[type="checkbox"] {
  margin-top: 0;
}
.input-group .form-control:first-child,
.input-group-addon:first-child,
.input-group-btn:first-child > .btn,
.input-group-btn:first-child > .btn-group > .btn,
.input-group-btn:first-child > .dropdown-toggle,
.input-group-btn:last-child > .btn:not(:last-child):not(.dropdown-toggle),
.input-group-btn:last-child > .btn-group:not(:last-child) > .btn {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
.input-group-addon:first-child {
  border-right: 0;
}
.input-group .form-control:last-child,
.input-group-addon:last-child,
.input-group-btn:last-child > .btn,
.input-group-btn:last-child > .btn-group > .btn,
.input-group-btn:last-child > .dropdown-toggle,
.input-group-btn:first-child > .btn:not(:first-child),
.input-group-btn:first-child > .btn-group:not(:first-child) > .btn {
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}
.input-group-addon:last-child {
  border-left: 0;
}
.input-group-btn {
  position: relative;
  font-size: 0;
  white-space: nowrap;
}
.input-group-btn > .btn {
  position: relative;
}
.input-group-btn > .btn + .btn {
  margin-left: -1px;
}
.input-group-btn > .btn:hover,
.input-group-btn > .btn:focus,
.input-group-btn > .btn:active {
  z-index: 2;
}
.input-group-btn:first-child > .btn,
.input-group-btn:first-child > .btn-group {
  margin-right: -1px;
}
.input-group-btn:last-child > .btn,
.input-group-btn:last-child > .btn-group {
  z-index: 2;
  margin-left: -1px;
}
.nav {
  padding-left: 0;
  margin-bottom: 0;
  list-style: none;
}
.nav > li {
  position: relative;
  display: block;
}
.nav > li > a {
  position: relative;
  display: block;
  padding: 10px 15px;
}
.nav > li > a:hover,
.nav > li > a:focus {
  text-decoration: none;
  background-color: #eee;
}
.nav > li.disabled > a {
  color: #777;
}
.nav > li.disabled > a:hover,
.nav > li.disabled > a:focus {
  color: #777;
  text-decoration: none;
  cursor: not-allowed;
  background-color: transparent;
}
.nav .open > a,
.nav .open > a:hover,
.nav .open > a:focus {
  background-color: #eee;
  border-color: #337ab7;
}
.nav .nav-divider {
  height: 1px;
  margin: 9px 0;
  overflow: hidden;
  background-color: #e5e5e5;
}
.nav > li > a > img {
  max-width: none;
}
.nav-tabs {
  border-bottom: 1px solid #ddd;
}
.nav-tabs > li {
  float: left;
  margin-bottom: -1px;
}
.nav-tabs > li > a {
  margin-right: 2px;
  line-height: 1.42857143;
  border: 1px solid transparent;
  border-radius: 4px 4px 0 0;
}
.nav-tabs > li > a:hover {
  border-color: #eee #eee #ddd;
}
.nav-tabs > li.active > a,
.nav-tabs > li.active > a:hover,
.nav-tabs > li.active > a:focus {
  color: #555;
  cursor: default;
  background-color: #fff;
  border: 1px solid #ddd;
  border-bottom-color: transparent;
}
.nav-tabs.nav-justified {
  width: 100%;
  border-bottom: 0;
}
.nav-tabs.nav-justified > li {
  float: none;
}
.nav-tabs.nav-justified > li > a {
  margin-bottom: 5px;
  text-align: center;
}
.nav-tabs.nav-justified > .dropdown .dropdown-menu {
  top: auto;
  left: auto;
}
@media (min-width: 768px) {
  .nav-tabs.nav-justified > li {
    display: table-cell;
    width: 1%;
  }
  .nav-tabs.nav-justified > li > a {
    margin-bottom: 0;
  }
}
.nav-tabs.nav-justified > li > a {
  margin-right: 0;
  border-radius: 4px;
}
.nav-tabs.nav-justified > .active > a,
.nav-tabs.nav-justified > .active > a:hover,
.nav-tabs.nav-justified > .active > a:focus {
  border: 1px solid #ddd;
}
@media (min-width: 768px) {
  .nav-tabs.nav-justified > li > a {
    border-bottom: 1px solid #ddd;
    border-radius: 4px 4px 0 0;
  }
  .nav-tabs.nav-justified > .active > a,
  .nav-tabs.nav-justified > .active > a:hover,
  .nav-tabs.nav-justified > .active > a:focus {
    border-bottom-color: #fff;
  }
}
.nav-pills > li {
  float: left;
}
.nav-pills > li > a {
  border-radius: 4px;
}
.nav-pills > li + li {
  margin-left: 2px;
}
.nav-pills > li.active > a,
.nav-pills > li.active > a:hover,
.nav-pills > li.active > a:focus {
  color: #fff;
  background-color: #337ab7;
}
.nav-stacked > li {
  float: none;
}
.nav-stacked > li + li {
  margin-top: 2px;
  margin-left: 0;
}
.nav-justified {
  width: 100%;
}
.nav-justified > li {
  float: none;
}
.nav-justified > li > a {
  margin-bottom: 5px;
  text-align: center;
}
.nav-justified > .dropdown .dropdown-menu {
  top: auto;
  left: auto;
}
@media (min-width: 768px) {
  .nav-justified > li {
    display: table-cell;
    width: 1%;
  }
  .nav-justified > li > a {
    margin-bottom: 0;
  }
}
.nav-tabs-justified {
  border-bottom: 0;
}
.nav-tabs-justified > li > a {
  margin-right: 0;
  border-radius: 4px;
}
.nav-tabs-justified > .active > a,
.nav-tabs-justified > .active > a:hover,
.nav-tabs-justified > .active > a:focus {
  border: 1px solid #ddd;
}
@media (min-width: 768px) {
  .nav-tabs-justified > li > a {
    border-bottom: 1px solid #ddd;
    border-radius: 4px 4px 0 0;
  }
  .nav-tabs-justified > .active > a,
  .nav-tabs-justified > .active > a:hover,
  .nav-tabs-justified > .active > a:focus {
    border-bottom-color: #fff;
  }
}
.tab-content > .tab-pane {
  display: none;
}
.tab-content > .active {
  display: block;
}
.nav-tabs .dropdown-menu {
  margin-top: -1px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
.navbar {
  position: relative;
  min-height: 50px;
  margin-bottom: 20px;
  border: 1px solid transparent;
}
@media (min-width: 768px) {
  .navbar {
    border-radius: 4px;
  }
}
@media (min-width: 768px) {
  .navbar-header {
    float: left;
  }
}
.navbar-collapse {
  padding-right: 15px;
  padding-left: 15px;
  overflow-x: visible;
  -webkit-overflow-scrolling: touch;
  border-top: 1px solid transparent;
  -webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, .1);
          box-shadow: inset 0 1px 0 rgba(255, 255, 255, .1);
}
.navbar-collapse.in {
  overflow-y: auto;
}
@media (min-width: 768px) {
  .navbar-collapse {
    width: auto;
    border-top: 0;
    -webkit-box-shadow: none;
            box-shadow: none;
  }
  .navbar-collapse.collapse {
    display: block !important;
    height: auto !important;
    padding-bottom: 0;
    overflow: visible !important;
  }
  .navbar-collapse.in {
    overflow-y: visible;
  }
  .navbar-fixed-top .navbar-collapse,
  .navbar-static-top .navbar-collapse,
  .navbar-fixed-bottom .navbar-collapse {
    padding-right: 0;
    padding-left: 0;
  }
}
.navbar-fixed-top .navbar-collapse,
.navbar-fixed-bottom .navbar-collapse {
  max-height: 340px;
}
@media (max-device-width: 480px) and (orientation: landscape) {
  .navbar-fixed-top .navbar-collapse,
  .navbar-fixed-bottom .navbar-collapse {
    max-height: 200px;
  }
}
.container > .navbar-header,
.container-fluid > .navbar-header,
.container > .navbar-collapse,
.container-fluid > .navbar-collapse {
  margin-right: -15px;
  margin-left: -15px;
}
@media (min-width: 768px) {
  .container > .navbar-header,
  .container-fluid > .navbar-header,
  .container > .navbar-collapse,
  .container-fluid > .navbar-collapse {
    margin-right: 0;
    margin-left: 0;
  }
}
.navbar-static-top {
  z-index: 1000;
  border-width: 0 0 1px;
}
@media (min-width: 768px) {
  .navbar-static-top {
    border-radius: 0;
  }
}
.navbar-fixed-top,
.navbar-fixed-bottom {
  position: fixed;
  right: 0;
  left: 0;
  z-index: 1030;
}
@media (min-width: 768px) {
  .navbar-fixed-top,
  .navbar-fixed-bottom {
    border-radius: 0;
  }
}
.navbar-fixed-top {
  top: 0;
  border-width: 0 0 1px;
}
.navbar-fixed-bottom {
  bottom: 0;
  margin-bottom: 0;
  border-width: 1px 0 0;
}
.navbar-brand {
  float: left;
  height: 50px;
  padding: 15px 15px;
  font-size: 18px;
  line-height: 20px;
}
.navbar-brand:hover,
.navbar-brand:focus {
  text-decoration: none;
}
.navbar-brand > img {
  display: block;
}
@media (min-width: 768px) {
  .navbar > .container .navbar-brand,
  .navbar > .container-fluid .navbar-brand {
    margin-left: -15px;
  }
}
.navbar-toggle {
  position: relative;
  float: right;
  padding: 9px 10px;
  margin-top: 8px;
  margin-right: 15px;
  margin-bottom: 8px;
  background-color: transparent;
  background-image: none;
  border: 1px solid transparent;
  border-radius: 4px;
}
.navbar-toggle:focus {
  outline: 0;
}
.navbar-toggle .icon-bar {
  display: block;
  width: 22px;
  height: 2px;
  border-radius: 1px;
}
.navbar-toggle .icon-bar + .icon-bar {
  margin-top: 4px;
}
@media (min-width: 768px) {
  .navbar-toggle {
    display: none;
  }
}
.navbar-nav {
  margin: 7.5px -15px;
}
.navbar-nav > li > a {
  padding-top: 10px;
  padding-bottom: 10px;
  line-height: 20px;
}
@media (max-width: 767px) {
  .navbar-nav .open .dropdown-menu {
    position: static;
    float: none;
    width: auto;
    margin-top: 0;
    background-color: transparent;
    border: 0;
    -webkit-box-shadow: none;
            box-shadow: none;
  }
  .navbar-nav .open .dropdown-menu > li > a,
  .navbar-nav .open .dropdown-menu .dropdown-header {
    padding: 5px 15px 5px 25px;
  }
  .navbar-nav .open .dropdown-menu > li > a {
    line-height: 20px;
  }
  .navbar-nav .open .dropdown-menu > li > a:hover,
  .navbar-nav .open .dropdown-menu > li > a:focus {
    background-image: none;
  }
}
@media (min-width: 768px) {
  .navbar-nav {
    float: left;
    margin: 0;
  }
  .navbar-nav > li {
    float: left;
  }
  .navbar-nav > li > a {
    padding-top: 15px;
    padding-bottom: 15px;
  }
}
.navbar-form {
  padding: 10px 15px;
  margin-top: 8px;
  margin-right: -15px;
  margin-bottom: 8px;
  margin-left: -15px;
  border-top: 1px solid transparent;
  border-bottom: 1px solid transparent;
  -webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, .1), 0 1px 0 rgba(255, 255, 255, .1);
          box-shadow: inset 0 1px 0 rgba(255, 255, 255, .1), 0 1px 0 rgba(255, 255, 255, .1);
}
@media (min-width: 768px) {
  .navbar-form .form-group {
    display: inline-block;
    margin-bottom: 0;
    vertical-align: middle;
  }
  .navbar-form .form-control {
    display: inline-block;
    width: auto;
    vertical-align: middle;
  }
  .navbar-form .form-control-static {
    display: inline-block;
  }
  .navbar-form .input-group {
    display: inline-table;
    vertical-align: middle;
  }
  .navbar-form .input-group .input-group-addon,
  .navbar-form .input-group .input-group-btn,
  .navbar-form .input-group .form-control {
    width: auto;
  }
  .navbar-form .input-group > .form-control {
    width: 100%;
  }
  .navbar-form .control-label {
    margin-bottom: 0;
    vertical-align: middle;
  }
  .navbar-form .radio,
  .navbar-form .checkbox {
    display: inline-block;
    margin-top: 0;
    margin-bottom: 0;
    vertical-align: middle;
  }
  .navbar-form .radio label,
  .navbar-form .checkbox label {
    padding-left: 0;
  }
  .navbar-form .radio input[type="radio"],
  .navbar-form .checkbox input[type="checkbox"] {
    position: relative;
    margin-left: 0;
  }
  .navbar-form .has-feedback .form-control-feedback {
    top: 0;
  }
}
@media (max-width: 767px) {
  .navbar-form .form-group {
    margin-bottom: 5px;
  }
  .navbar-form .form-group:last-child {
    margin-bottom: 0;
  }
}
@media (min-width: 768px) {
  .navbar-form {
    width: auto;
    padding-top: 0;
    padding-bottom: 0;
    margin-right: 0;
    margin-left: 0;
    border: 0;
    -webkit-box-shadow: none;
            box-shadow: none;
  }
}
.navbar-nav > li > .dropdown-menu {
  margin-top: 0;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
.navbar-fixed-bottom .navbar-nav > li > .dropdown-menu {
  margin-bottom: 0;
  border-top-left-radius: 4px;
  border-top-right-radius: 4px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}
.navbar-btn {
  margin-top: 8px;
  margin-bottom: 8px;
}
.navbar-btn.btn-sm {
  margin-top: 10px;
  margin-bottom: 10px;
}
.navbar-btn.btn-xs {
  margin-top: 14px;
  margin-bottom: 14px;
}
.navbar-text {
  margin-top: 15px;
  margin-bottom: 15px;
}
@media (min-width: 768px) {
  .navbar-text {
    float: left;
    margin-right: 15px;
    margin-left: 15px;
  }
}
@media (min-width: 768px) {
  .navbar-left {
    float: left !important;
  }
  .navbar-right {
    float: right !important;
    margin-right: -15px;
  }
  .navbar-right ~ .navbar-right {
    margin-right: 0;
  }
}
.navbar-default {
  background-color: #f8f8f8;
  border-color: #e7e7e7;
}
.navbar-default .navbar-brand {
  color: #777;
}
.navbar-default .navbar-brand:hover,
.navbar-default .navbar-brand:focus {
  color: #5e5e5e;
  background-color: transparent;
}
.navbar-default .navbar-text {
  color: #777;
}
.navbar-default .navbar-nav > li > a {
  color: #777;
}
.navbar-default .navbar-nav > li > a:hover,
.navbar-default .navbar-nav > li > a:focus {
  color: #333;
  background-color: transparent;
}
.navbar-default .navbar-nav > .active > a,
.navbar-default .navbar-nav > .active > a:hover,
.navbar-default .navbar-nav > .active > a:focus {
  color: #555;
  background-color: #e7e7e7;
}
.navbar-default .navbar-nav > .disabled > a,
.navbar-default .navbar-nav > .disabled > a:hover,
.navbar-default .navbar-nav > .disabled > a:focus {
  color: #ccc;
  background-color: transparent;
}
.navbar-default .navbar-toggle {
  border-color: #ddd;
}
.navbar-default .navbar-toggle:hover,
.navbar-default .navbar-toggle:focus {
  background-color: #ddd;
}
.navbar-default .navbar-toggle .icon-bar {
  background-color: #888;
}
.navbar-default .navbar-collapse,
.navbar-default .navbar-form {
  border-color: #e7e7e7;
}
.navbar-default .navbar-nav > .open > a,
.navbar-default .navbar-nav > .open > a:hover,
.navbar-default .navbar-nav > .open > a:focus {
  color: #555;
  background-color: #e7e7e7;
}
@media (max-width: 767px) {
  .navbar-default .navbar-nav .open .dropdown-menu > li > a {
    color: #777;
  }
  .navbar-default .navbar-nav .open .dropdown-menu > li > a:hover,
  .navbar-default .navbar-nav .open .dropdown-menu > li > a:focus {
    color: #333;
    background-color: transparent;
  }
  .navbar-default .navbar-nav .open .dropdown-menu > .active > a,
  .navbar-default .navbar-nav .open .dropdown-menu > .active > a:hover,
  .navbar-default .navbar-nav .open .dropdown-menu > .active > a:focus {
    color: #555;
    background-color: #e7e7e7;
  }
  .navbar-default .navbar-nav .open .dropdown-menu > .disabled > a,
  .navbar-default .navbar-nav .open .dropdown-menu > .disabled > a:hover,
  .navbar-default .navbar-nav .open .dropdown-menu > .disabled > a:focus {
    color: #ccc;
    background-color: transparent;
  }
}
.navbar-default .navbar-link {
  color: #777;
}
.navbar-default .navbar-link:hover {
  color: #333;
}
.navbar-default .btn-link {
  color: #777;
}
.navbar-default .btn-link:hover,
.navbar-default .btn-link:focus {
  color: #333;
}
.navbar-default .btn-link[disabled]:hover,
fieldset[disabled] .navbar-default .btn-link:hover,
.navbar-default .btn-link[disabled]:focus,
fieldset[disabled] .navbar-default .btn-link:focus {
  color: #ccc;
}
.navbar-inverse {
  background-color: #222;
  border-color: #080808;
}
.navbar-inverse .navbar-brand {
  color: #9d9d9d;
}
.navbar-inverse .navbar-brand:hover,
.navbar-inverse .navbar-brand:focus {
  color: #fff;
  background-color: transparent;
}
.navbar-inverse .navbar-text {
  color: #9d9d9d;
}
.navbar-inverse .navbar-nav > li > a {
  color: #9d9d9d;
}
.navbar-inverse .navbar-nav > li > a:hover,
.navbar-inverse .navbar-nav > li > a:focus {
  color: #fff;
  background-color: transparent;
}
.navbar-inverse .navbar-nav > .active > a,
.navbar-inverse .navbar-nav > .active > a:hover,
.navbar-inverse .navbar-nav > .active > a:focus {
  color: #fff;
  background-color: #080808;
}
.navbar-inverse .navbar-nav > .disabled > a,
.navbar-inverse .navbar-nav > .disabled > a:hover,
.navbar-inverse .navbar-nav > .disabled > a:focus {
  color: #444;
  background-color: transparent;
}
.navbar-inverse .navbar-toggle {
  border-color: #333;
}
.navbar-inverse .navbar-toggle:hover,
.navbar-inverse .navbar-toggle:focus {
  background-color: #333;
}
.navbar-inverse .navbar-toggle .icon-bar {
  background-color: #fff;
}
.navbar-inverse .navbar-collapse,
.navbar-inverse .navbar-form {
  border-color: #101010;
}
.navbar-inverse .navbar-nav > .open > a,
.navbar-inverse .navbar-nav > .open > a:hover,
.navbar-inverse .navbar-nav > .open > a:focus {
  color: #fff;
  background-color: #080808;
}
@media (max-width: 767px) {
  .navbar-inverse .navbar-nav .open .dropdown-menu > .dropdown-header {
    border-color: #080808;
  }
  .navbar-inverse .navbar-nav .open .dropdown-menu .divider {
    background-color: #080808;
  }
  .navbar-inverse .navbar-nav .open .dropdown-menu > li > a {
    color: #9d9d9d;
  }
  .navbar-inverse .navbar-nav .open .dropdown-menu > li > a:hover,
  .navbar-inverse .navbar-nav .open .dropdown-menu > li > a:focus {
    color: #fff;
    background-color: transparent;
  }
  .navbar-inverse .navbar-nav .open .dropdown-menu > .active > a,
  .navbar-inverse .navbar-nav .open .dropdown-menu > .active > a:hover,
  .navbar-inverse .navbar-nav .open .dropdown-menu > .active > a:focus {
    color: #fff;
    background-color: #080808;
  }
  .navbar-inverse .navbar-nav .open .dropdown-menu > .disabled > a,
  .navbar-inverse .navbar-nav .open .dropdown-menu > .disabled > a:hover,
  .navbar-inverse .navbar-nav .open .dropdown-menu > .disabled > a:focus {
    color: #444;
    background-color: transparent;
  }
}
.navbar-inverse .navbar-link {
  color: #9d9d9d;
}
.navbar-inverse .navbar-link:hover {
  color: #fff;
}
.navbar-inverse .btn-link {
  color: #9d9d9d;
}
.navbar-inverse .btn-link:hover,
.navbar-inverse .btn-link:focus {
  color: #fff;
}
.navbar-inverse .btn-link[disabled]:hover,
fieldset[disabled] .navbar-inverse .btn-link:hover,
.navbar-inverse .btn-link[disabled]:focus,
fieldset[disabled] .navbar-inverse .btn-link:focus {
  color: #444;
}
.breadcrumb {
  padding: 8px 15px;
  margin-bottom: 20px;
  list-style: none;
  background-color: #f5f5f5;
  border-radius: 4px;
}
.breadcrumb > li {
  display: inline-block;
}
.breadcrumb > li + li:before {
  padding: 0 5px;
  color: #ccc;
  content: "/\00a0";
}
.breadcrumb > .active {
  color: #777;
}
.pagination {
  display: inline-block;
  padding-left: 0;
  margin: 20px 0;
  border-radius: 4px;
}
.pagination > li {
  display: inline;
}
.pagination > li > a,
.pagination > li > span {
  position: relative;
  float: left;
  padding: 6px 12px;
  margin-left: -1px;
  line-height: 1.42857143;
  color: #337ab7;
  text-decoration: none;
  background-color: #fff;
  border: 1px solid #ddd;
}
.pagination > li:first-child > a,
.pagination > li:first-child > span {
  margin-left: 0;
  border-top-left-radius: 4px;
  border-bottom-left-radius: 4px;
}
.pagination > li:last-child > a,
.pagination > li:last-child > span {
  border-top-right-radius: 4px;
  border-bottom-right-radius: 4px;
}
.pagination > li > a:hover,
.pagination > li > span:hover,
.pagination > li > a:focus,
.pagination > li > span:focus {
  z-index: 2;
  color: #23527c;
  background-color: #eee;
  border-color: #ddd;
}
.pagination > .active > a,
.pagination > .active > span,
.pagination > .active > a:hover,
.pagination > .active > span:hover,
.pagination > .active > a:focus,
.pagination > .active > span:focus {
  z-index: 3;
  color: #fff;
  cursor: default;
  background-color: #337ab7;
  border-color: #337ab7;
}
.pagination > .disabled > span,
.pagination > .disabled > span:hover,
.pagination > .disabled > span:focus,
.pagination > .disabled > a,
.pagination > .disabled > a:hover,
.pagination > .disabled > a:focus {
  color: #777;
  cursor: not-allowed;
  background-color: #fff;
  border-color: #ddd;
}
.pagination-lg > li > a,
.pagination-lg > li > span {
  padding: 10px 16px;
  font-size: 18px;
  line-height: 1.3333333;
}
.pagination-lg > li:first-child > a,
.pagination-lg > li:first-child > span {
  border-top-left-radius: 6px;
  border-bottom-left-radius: 6px;
}
.pagination-lg > li:last-child > a,
.pagination-lg > li:last-child > span {
  border-top-right-radius: 6px;
  border-bottom-right-radius: 6px;
}
.pagination-sm > li > a,
.pagination-sm > li > span {
  padding: 5px 10px;
  font-size: 12px;
  line-height: 1.5;
}
.pagination-sm > li:first-child > a,
.pagination-sm > li:first-child > span {
  border-top-left-radius: 3px;
  border-bottom-left-radius: 3px;
}
.pagination-sm > li:last-child > a,
.pagination-sm > li:last-child > span {
  border-top-right-radius: 3px;
  border-bottom-right-radius: 3px;
}
.pager {
  padding-left: 0;
  margin: 20px 0;
  text-align: center;
  list-style: none;
}
.pager li {
  display: inline;
}
.pager li > a,
.pager li > span {
  display: inline-block;
  padding: 5px 14px;
  background-color: #fff;
  border: 1px solid #ddd;
  border-radius: 15px;
}
.pager li > a:hover,
.pager li > a:focus {
  text-decoration: none;
  background-color: #eee;
}
.pager .next > a,
.pager .next > span {
  float: right;
}
.pager .previous > a,
.pager .previous > span {
  float: left;
}
.pager .disabled > a,
.pager .disabled > a:hover,
.pager .disabled > a:focus,
.pager .disabled > span {
  color: #777;
  cursor: not-allowed;
  background-color: #fff;
}
.label {
  display: inline;
  padding: .2em .6em .3em;
  font-size: 75%;
  font-weight: bold;
  line-height: 1;
  color: #fff;
  text-align: center;
  white-space: nowrap;
  vertical-align: baseline;
  border-radius: .25em;
}
a.label:hover,
a.label:focus {
  color: #fff;
  text-decoration: none;
  cursor: pointer;
}
.label:empty {
  display: none;
}
.btn .label {
  position: relative;
  top: -1px;
}
.label-default {
  background-color: #777;
}
.label-default[href]:hover,
.label-default[href]:focus {
  background-color: #5e5e5e;
}
.label-primary {
  background-color: #337ab7;
}
.label-primary[href]:hover,
.label-primary[href]:focus {
  background-color: #286090;
}
.label-success {
  background-color: #5cb85c;
}
.label-success[href]:hover,
.label-success[href]:focus {
  background-color: #449d44;
}
.label-info {
  background-color: #5bc0de;
}
.label-info[href]:hover,
.label-info[href]:focus {
  background-color: #31b0d5;
}
.label-warning {
  background-color: #f0ad4e;
}
.label-warning[href]:hover,
.label-warning[href]:focus {
  background-color: #ec971f;
}
.label-danger {
  background-color: #d9534f;
}
.label-danger[href]:hover,
.label-danger[href]:focus {
  background-color: #c9302c;
}
.badge {
  display: inline-block;
  min-width: 10px;
  padding: 3px 7px;
  font-size: 12px;
  font-weight: bold;
  line-height: 1;
  color: #fff;
  text-align: center;
  white-space: nowrap;
  vertical-align: middle;
  background-color: #777;
  border-radius: 10px;
}
.badge:empty {
  display: none;
}
.btn .badge {
  position: relative;
  top: -1px;
}
.btn-xs .badge,
.btn-group-xs > .btn .badge {
  top: 0;
  padding: 1px 5px;
}
a.badge:hover,
a.badge:focus {
  color: #fff;
  text-decoration: none;
  cursor: pointer;
}
.list-group-item.active > .badge,
.nav-pills > .active > a > .badge {
  color: #337ab7;
  background-color: #fff;
}
.list-group-item > .badge {
  float: right;
}
.list-group-item > .badge + .badge {
  margin-right: 5px;
}
.nav-pills > li > a > .badge {
  margin-left: 3px;
}
.jumbotron {
  padding-top: 30px;
  padding-bottom: 30px;
  margin-bottom: 30px;
  color: inherit;
  background-color: #eee;
}
.jumbotron h1,
.jumbotron .h1 {
  color: inherit;
}
.jumbotron p {
  margin-bottom: 15px;
  font-size: 21px;
  font-weight: 200;
}
.jumbotron > hr {
  border-top-color: #d5d5d5;
}
.container .jumbotron,
.container-fluid .jumbotron {
  padding-right: 15px;
  padding-left: 15px;
  border-radius: 6px;
}
.jumbotron .container {
  max-width: 100%;
}
@media screen and (min-width: 768px) {
  .jumbotron {
    padding-top: 48px;
    padding-bottom: 48px;
  }
  .container .jumbotron,
  .container-fluid .jumbotron {
    padding-right: 60px;
    padding-left: 60px;
  }
  .jumbotron h1,
  .jumbotron .h1 {
    font-size: 63px;
  }
}
.thumbnail {
  display: block;
  padding: 4px;
  margin-bottom: 20px;
  line-height: 1.42857143;
  background-color: #fff;
  border: 1px solid #ddd;
  border-radius: 4px;
  -webkit-transition: border .2s ease-in-out;
       -o-transition: border .2s ease-in-out;
          transition: border .2s ease-in-out;
}
.thumbnail > img,
.thumbnail a > img {
  margin-right: auto;
  margin-left: auto;
}
a.thumbnail:hover,
a.thumbnail:focus,
a.thumbnail.active {
  border-color: #337ab7;
}
.thumbnail .caption {
  padding: 9px;
  color: #333;
}
.alert {
  padding: 15px;
  margin-bottom: 20px;
  border: 1px solid transparent;
  border-radius: 4px;
}
.alert h4 {
  margin-top: 0;
  color: inherit;
}
.alert .alert-link {
  font-weight: bold;
}
.alert > p,
.alert > ul {
  margin-bottom: 0;
}
.alert > p + p {
  margin-top: 5px;
}
.alert-dismissable,
.alert-dismissible {
  padding-right: 35px;
}
.alert-dismissable .close,
.alert-dismissible .close {
  position: relative;
  top: -2px;
  right: -21px;
  color: inherit;
}
.alert-success {
  color: #3c763d;
  background-color: #dff0d8;
  border-color: #d6e9c6;
}
.alert-success hr {
  border-top-color: #c9e2b3;
}
.alert-success .alert-link {
  color: #2b542c;
}
.alert-info {
  color: #31708f;
  background-color: #d9edf7;
  border-color: #bce8f1;
}
.alert-info hr {
  border-top-color: #a6e1ec;
}
.alert-info .alert-link {
  color: #245269;
}
.alert-warning {
  color: #8a6d3b;
  background-color: #fcf8e3;
  border-color: #faebcc;
}
.alert-warning hr {
  border-top-color: #f7e1b5;
}
.alert-warning .alert-link {
  color: #66512c;
}
.alert-danger {
  color: #a94442;
  background-color: #f2dede;
  border-color: #ebccd1;
}
.alert-danger hr {
  border-top-color: #e4b9c0;
}
.alert-danger .alert-link {
  color: #843534;
}
@-webkit-keyframes progress-bar-stripes {
  from {
    background-position: 40px 0;
  }
  to {
    background-position: 0 0;
  }
}
@-o-keyframes progress-bar-stripes {
  from {
    background-position: 40px 0;
  }
  to {
    background-position: 0 0;
  }
}
@keyframes progress-bar-stripes {
  from {
    background-position: 40px 0;
  }
  to {
    background-position: 0 0;
  }
}
.progress {
  height: 20px;
  margin-bottom: 20px;
  overflow: hidden;
  background-color: #f5f5f5;
  border-radius: 4px;
  -webkit-box-shadow: inset 0 1px 2px rgba(0, 0, 0, .1);
          box-shadow: inset 0 1px 2px rgba(0, 0, 0, .1);
}
.progress-bar {
  float: left;
  width: 0;
  height: 100%;
  font-size: 12px;
  line-height: 20px;
  color: #fff;
  text-align: center;
  background-color: #337ab7;
  -webkit-box-shadow: inset 0 -1px 0 rgba(0, 0, 0, .15);
          box-shadow: inset 0 -1px 0 rgba(0, 0, 0, .15);
  -webkit-transition: width .6s ease;
       -o-transition: width .6s ease;
          transition: width .6s ease;
}
.progress-striped .progress-bar,
.progress-bar-striped {
  background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
  background-image:      -o-linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
  background-image:         linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
  -webkit-background-size: 40px 40px;
          background-size: 40px 40px;
}
.progress.active .progress-bar,
.progress-bar.active {
  -webkit-animation: progress-bar-stripes 2s linear infinite;
       -o-animation: progress-bar-stripes 2s linear infinite;
          animation: progress-bar-stripes 2s linear infinite;
}
.progress-bar-success {
  background-color: #5cb85c;
}
.progress-striped .progress-bar-success {
  background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
  background-image:      -o-linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
  background-image:         linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
}
.progress-bar-info {
  background-color: #5bc0de;
}
.progress-striped .progress-bar-info {
  background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
  background-image:      -o-linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
  background-image:         linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
}
.progress-bar-warning {
  background-color: #f0ad4e;
}
.progress-striped .progress-bar-warning {
  background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
  background-image:      -o-linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
  background-image:         linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
}
.progress-bar-danger {
  background-color: #d9534f;
}
.progress-striped .progress-bar-danger {
  background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
  background-image:      -o-linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
  background-image:         linear-gradient(45deg, rgba(255, 255, 255, .15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .15) 50%, rgba(255, 255, 255, .15) 75%, transparent 75%, transparent);
}
.media {
  margin-top: 15px;
}
.media:first-child {
  margin-top: 0;
}
.media,
.media-body {
  overflow: hidden;
  zoom: 1;
}
.media-body {
  width: 10000px;
}
.media-object {
  display: block;
}
.media-object.img-thumbnail {
  max-width: none;
}
.media-right,
.media > .pull-right {
  padding-left: 10px;
}
.media-left,
.media > .pull-left {
  padding-right: 10px;
}
.media-left,
.media-right,
.media-body {
  display: table-cell;
  vertical-align: top;
}
.media-middle {
  vertical-align: middle;
}
.media-bottom {
  vertical-align: bottom;
}
.media-heading {
  margin-top: 0;
  margin-bottom: 5px;
}
.media-list {
  padding-left: 0;
  list-style: none;
}
.list-group {
  padding-left: 0;
  margin-bottom: 20px;
}
.list-group-item {
  position: relative;
  display: block;
  padding: 10px 15px;
  margin-bottom: -1px;
  background-color: #fff;
  border: 1px solid #ddd;
}
.list-group-item:first-child {
  border-top-left-radius: 4px;
  border-top-right-radius: 4px;
}
.list-group-item:last-child {
  margin-bottom: 0;
  border-bottom-right-radius: 4px;
  border-bottom-left-radius: 4px;
}
a.list-group-item,
button.list-group-item {
  color: #555;
}
a.list-group-item .list-group-item-heading,
button.list-group-item .list-group-item-heading {
  color: #333;
}
a.list-group-item:hover,
button.list-group-item:hover,
a.list-group-item:focus,
button.list-group-item:focus {
  color: #555;
  text-decoration: none;
  background-color: #f5f5f5;
}
button.list-group-item {
  width: 100%;
  text-align: left;
}
.list-group-item.disabled,
.list-group-item.disabled:hover,
.list-group-item.disabled:focus {
  color: #777;
  cursor: not-allowed;
  background-color: #eee;
}
.list-group-item.disabled .list-group-item-heading,
.list-group-item.disabled:hover .list-group-item-heading,
.list-group-item.disabled:focus .list-group-item-heading {
  color: inherit;
}
.list-group-item.disabled .list-group-item-text,
.list-group-item.disabled:hover .list-group-item-text,
.list-group-item.disabled:focus .list-group-item-text {
  color: #777;
}
.list-group-item.active,
.list-group-item.active:hover,
.list-group-item.active:focus {
  z-index: 2;
  color: #fff;
  background-color: #337ab7;
  border-color: #337ab7;
}
.list-group-item.active .list-group-item-heading,
.list-group-item.active:hover .list-group-item-heading,
.list-group-item.active:focus .list-group-item-heading,
.list-group-item.active .list-group-item-heading > small,
.list-group-item.active:hover .list-group-item-heading > small,
.list-group-item.active:focus .list-group-item-heading > small,
.list-group-item.active .list-group-item-heading > .small,
.list-group-item.active:hover .list-group-item-heading > .small,
.list-group-item.active:focus .list-group-item-heading > .small {
  color: inherit;
}
.list-group-item.active .list-group-item-text,
.list-group-item.active:hover .list-group-item-text,
.list-group-item.active:focus .list-group-item-text {
  color: #c7ddef;
}
.list-group-item-success {
  color: #3c763d;
  background-color: #dff0d8;
}
a.list-group-item-success,
button.list-group-item-success {
  color: #3c763d;
}
a.list-group-item-success .list-group-item-heading,
button.list-group-item-success .list-group-item-heading {
  color: inherit;
}
a.list-group-item-success:hover,
button.list-group-item-success:hover,
a.list-group-item-success:focus,
button.list-group-item-success:focus {
  color: #3c763d;
  background-color: #d0e9c6;
}
a.list-group-item-success.active,
button.list-group-item-success.active,
a.list-group-item-success.active:hover,
button.list-group-item-success.active:hover,
a.list-group-item-success.active:focus,
button.list-group-item-success.active:focus {
  color: #fff;
  background-color: #3c763d;
  border-color: #3c763d;
}
.list-group-item-info {
  color: #31708f;
  background-color: #d9edf7;
}
a.list-group-item-info,
button.list-group-item-info {
  color: #31708f;
}
a.list-group-item-info .list-group-item-heading,
button.list-group-item-info .list-group-item-heading {
  color: inherit;
}
a.list-group-item-info:hover,
button.list-group-item-info:hover,
a.list-group-item-info:focus,
button.list-group-item-info:focus {
  color: #31708f;
  background-color: #c4e3f3;
}
a.list-group-item-info.active,
button.list-group-item-info.active,
a.list-group-item-info.active:hover,
button.list-group-item-info.active:hover,
a.list-group-item-info.active:focus,
button.list-group-item-info.active:focus {
  color: #fff;
  background-color: #31708f;
  border-color: #31708f;
}
.list-group-item-warning {
  color: #8a6d3b;
  background-color: #fcf8e3;
}
a.list-group-item-warning,
button.list-group-item-warning {
  color: #8a6d3b;
}
a.list-group-item-warning .list-group-item-heading,
button.list-group-item-warning .list-group-item-heading {
  color: inherit;
}
a.list-group-item-warning:hover,
button.list-group-item-warning:hover,
a.list-group-item-warning:focus,
button.list-group-item-warning:focus {
  color: #8a6d3b;
  background-color: #faf2cc;
}
a.list-group-item-warning.active,
button.list-group-item-warning.active,
a.list-group-item-warning.active:hover,
button.list-group-item-warning.active:hover,
a.list-group-item-warning.active:focus,
button.list-group-item-warning.active:focus {
  color: #fff;
  background-color: #8a6d3b;
  border-color: #8a6d3b;
}
.list-group-item-danger {
  color: #a94442;
  background-color: #f2dede;
}
a.list-group-item-danger,
button.list-group-item-danger {
  color: #a94442;
}
a.list-group-item-danger .list-group-item-heading,
button.list-group-item-danger .list-group-item-heading {
  color: inherit;
}
a.list-group-item-danger:hover,
button.list-group-item-danger:hover,
a.list-group-item-danger:focus,
button.list-group-item-danger:focus {
  color: #a94442;
  background-color: #ebcccc;
}
a.list-group-item-danger.active,
button.list-group-item-danger.active,
a.list-group-item-danger.active:hover,
button.list-group-item-danger.active:hover,
a.list-group-item-danger.active:focus,
button.list-group-item-danger.active:focus {
  color: #fff;
  background-color: #a94442;
  border-color: #a94442;
}
.list-group-item-heading {
  margin-top: 0;
  margin-bottom: 5px;
}
.list-group-item-text {
  margin-bottom: 0;
  line-height: 1.3;
}
.panel {
  margin-bottom: 20px;
  background-color: #fff;
  border: 1px solid transparent;
  border-radius: 4px;
  -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, .05);
          box-shadow: 0 1px 1px rgba(0, 0, 0, .05);
}
.panel-body {
  padding: 15px;
}
.panel-heading {
  padding: 10px 15px;
  border-bottom: 1px solid transparent;
  border-top-left-radius: 3px;
  border-top-right-radius: 3px;
}
.panel-heading > .dropdown .dropdown-toggle {
  color: inherit;
}
.panel-title {
  margin-top: 0;
  margin-bottom: 0;
  font-size: 16px;
  color: inherit;
}
.panel-title > a,
.panel-title > small,
.panel-title > .small,
.panel-title > small > a,
.panel-title > .small > a {
  color: inherit;
}
.panel-footer {
  padding: 10px 15px;
  background-color: #f5f5f5;
  border-top: 1px solid #ddd;
  border-bottom-right-radius: 3px;
  border-bottom-left-radius: 3px;
}
.panel > .list-group,
.panel > .panel-collapse > .list-group {
  margin-bottom: 0;
}
.panel > .list-group .list-group-item,
.panel > .panel-collapse > .list-group .list-group-item {
  border-width: 1px 0;
  border-radius: 0;
}
.panel > .list-group:first-child .list-group-item:first-child,
.panel > .panel-collapse > .list-group:first-child .list-group-item:first-child {
  border-top: 0;
  border-top-left-radius: 3px;
  border-top-right-radius: 3px;
}
.panel > .list-group:last-child .list-group-item:last-child,
.panel > .panel-collapse > .list-group:last-child .list-group-item:last-child {
  border-bottom: 0;
  border-bottom-right-radius: 3px;
  border-bottom-left-radius: 3px;
}
.panel > .panel-heading + .panel-collapse > .list-group .list-group-item:first-child {
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
.panel-heading + .list-group .list-group-item:first-child {
  border-top-width: 0;
}
.list-group + .panel-footer {
  border-top-width: 0;
}
.panel > .table,
.panel > .table-responsive > .table,
.panel > .panel-collapse > .table {
  margin-bottom: 0;
}
.panel > .table caption,
.panel > .table-responsive > .table caption,
.panel > .panel-collapse > .table caption {
  padding-right: 15px;
  padding-left: 15px;
}
.panel > .table:first-child,
.panel > .table-responsive:first-child > .table:first-child {
  border-top-left-radius: 3px;
  border-top-right-radius: 3px;
}
.panel > .table:first-child > thead:first-child > tr:first-child,
.panel > .table-responsive:first-child > .table:first-child > thead:first-child > tr:first-child,
.panel > .table:first-child > tbody:first-child > tr:first-child,
.panel > .table-responsive:first-child > .table:first-child > tbody:first-child > tr:first-child {
  border-top-left-radius: 3px;
  border-top-right-radius: 3px;
}
.panel > .table:first-child > thead:first-child > tr:first-child td:first-child,
.panel > .table-responsive:first-child > .table:first-child > thead:first-child > tr:first-child td:first-child,
.panel > .table:first-child > tbody:first-child > tr:first-child td:first-child,
.panel > .table-responsive:first-child > .table:first-child > tbody:first-child > tr:first-child td:first-child,
.panel > .table:first-child > thead:first-child > tr:first-child th:first-child,
.panel > .table-responsive:first-child > .table:first-child > thead:first-child > tr:first-child th:first-child,
.panel > .table:first-child > tbody:first-child > tr:first-child th:first-child,
.panel > .table-responsive:first-child > .table:first-child > tbody:first-child > tr:first-child th:first-child {
  border-top-left-radius: 3px;
}
.panel > .table:first-child > thead:first-child > tr:first-child td:last-child,
.panel > .table-responsive:first-child > .table:first-child > thead:first-child > tr:first-child td:last-child,
.panel > .table:first-child > tbody:first-child > tr:first-child td:last-child,
.panel > .table-responsive:first-child > .table:first-child > tbody:first-child > tr:first-child td:last-child,
.panel > .table:first-child > thead:first-child > tr:first-child th:last-child,
.panel > .table-responsive:first-child > .table:first-child > thead:first-child > tr:first-child th:last-child,
.panel > .table:first-child > tbody:first-child > tr:first-child th:last-child,
.panel > .table-responsive:first-child > .table:first-child > tbody:first-child > tr:first-child th:last-child {
  border-top-right-radius: 3px;
}
.panel > .table:last-child,
.panel > .table-responsive:last-child > .table:last-child {
  border-bottom-right-radius: 3px;
  border-bottom-left-radius: 3px;
}
.panel > .table:last-child > tbody:last-child > tr:last-child,
.panel > .table-responsive:last-child > .table:last-child > tbody:last-child > tr:last-child,
.panel > .table:last-child > tfoot:last-child > tr:last-child,
.panel > .table-responsive:last-child > .table:last-child > tfoot:last-child > tr:last-child {
  border-bottom-right-radius: 3px;
  border-bottom-left-radius: 3px;
}
.panel > .table:last-child > tbody:last-child > tr:last-child td:first-child,
.panel > .table-responsive:last-child > .table:last-child > tbody:last-child > tr:last-child td:first-child,
.panel > .table:last-child > tfoot:last-child > tr:last-child td:first-child,
.panel > .table-responsive:last-child > .table:last-child > tfoot:last-child > tr:last-child td:first-child,
.panel > .table:last-child > tbody:last-child > tr:last-child th:first-child,
.panel > .table-responsive:last-child > .table:last-child > tbody:last-child > tr:last-child th:first-child,
.panel > .table:last-child > tfoot:last-child > tr:last-child th:first-child,
.panel > .table-responsive:last-child > .table:last-child > tfoot:last-child > tr:last-child th:first-child {
  border-bottom-left-radius: 3px;
}
.panel > .table:last-child > tbody:last-child > tr:last-child td:last-child,
.panel > .table-responsive:last-child > .table:last-child > tbody:last-child > tr:last-child td:last-child,
.panel > .table:last-child > tfoot:last-child > tr:last-child td:last-child,
.panel > .table-responsive:last-child > .table:last-child > tfoot:last-child > tr:last-child td:last-child,
.panel > .table:last-child > tbody:last-child > tr:last-child th:last-child,
.panel > .table-responsive:last-child > .table:last-child > tbody:last-child > tr:last-child th:last-child,
.panel > .table:last-child > tfoot:last-child > tr:last-child th:last-child,
.panel > .table-responsive:last-child > .table:last-child > tfoot:last-child > tr:last-child th:last-child {
  border-bottom-right-radius: 3px;
}
.panel > .panel-body + .table,
.panel > .panel-body + .table-responsive,
.panel > .table + .panel-body,
.panel > .table-responsive + .panel-body {
  border-top: 1px solid #ddd;
}
.panel > .table > tbody:first-child > tr:first-child th,
.panel > .table > tbody:first-child > tr:first-child td {
  border-top: 0;
}
.panel > .table-bordered,
.panel > .table-responsive > .table-bordered {
  border: 0;
}
.panel > .table-bordered > thead > tr > th:first-child,
.panel > .table-responsive > .table-bordered > thead > tr > th:first-child,
.panel > .table-bordered > tbody > tr > th:first-child,
.panel > .table-responsive > .table-bordered > tbody > tr > th:first-child,
.panel > .table-bordered > tfoot > tr > th:first-child,
.panel > .table-responsive > .table-bordered > tfoot > tr > th:first-child,
.panel > .table-bordered > thead > tr > td:first-child,
.panel > .table-responsive > .table-bordered > thead > tr > td:first-child,
.panel > .table-bordered > tbody > tr > td:first-child,
.panel > .table-responsive > .table-bordered > tbody > tr > td:first-child,
.panel > .table-bordered > tfoot > tr > td:first-child,
.panel > .table-responsive > .table-bordered > tfoot > tr > td:first-child {
  border-left: 0;
}
.panel > .table-bordered > thead > tr > th:last-child,
.panel > .table-responsive > .table-bordered > thead > tr > th:last-child,
.panel > .table-bordered > tbody > tr > th:last-child,
.panel > .table-responsive > .table-bordered > tbody > tr > th:last-child,
.panel > .table-bordered > tfoot > tr > th:last-child,
.panel > .table-responsive > .table-bordered > tfoot > tr > th:last-child,
.panel > .table-bordered > thead > tr > td:last-child,
.panel > .table-responsive > .table-bordered > thead > tr > td:last-child,
.panel > .table-bordered > tbody > tr > td:last-child,
.panel > .table-responsive > .table-bordered > tbody > tr > td:last-child,
.panel > .table-bordered > tfoot > tr > td:last-child,
.panel > .table-responsive > .table-bordered > tfoot > tr > td:last-child {
  border-right: 0;
}
.panel > .table-bordered > thead > tr:first-child > td,
.panel > .table-responsive > .table-bordered > thead > tr:first-child > td,
.panel > .table-bordered > tbody > tr:first-child > td,
.panel > .table-responsive > .table-bordered > tbody > tr:first-child > td,
.panel > .table-bordered > thead > tr:first-child > th,
.panel > .table-responsive > .table-bordered > thead > tr:first-child > th,
.panel > .table-bordered > tbody > tr:first-child > th,
.panel > .table-responsive > .table-bordered > tbody > tr:first-child > th {
  border-bottom: 0;
}
.panel > .table-bordered > tbody > tr:last-child > td,
.panel > .table-responsive > .table-bordered > tbody > tr:last-child > td,
.panel > .table-bordered > tfoot > tr:last-child > td,
.panel > .table-responsive > .table-bordered > tfoot > tr:last-child > td,
.panel > .table-bordered > tbody > tr:last-child > th,
.panel > .table-responsive > .table-bordered > tbody > tr:last-child > th,
.panel > .table-bordered > tfoot > tr:last-child > th,
.panel > .table-responsive > .table-bordered > tfoot > tr:last-child > th {
  border-bottom: 0;
}
.panel > .table-responsive {
  margin-bottom: 0;
  border: 0;
}
.panel-group {
  margin-bottom: 20px;
}
.panel-group .panel {
  margin-bottom: 0;
  border-radius: 4px;
}
.panel-group .panel + .panel {
  margin-top: 5px;
}
.panel-group .panel-heading {
  border-bottom: 0;
}
.panel-group .panel-heading + .panel-collapse > .panel-body,
.panel-group .panel-heading + .panel-collapse > .list-group {
  border-top: 1px solid #ddd;
}
.panel-group .panel-footer {
  border-top: 0;
}
.panel-group .panel-footer + .panel-collapse .panel-body {
  border-bottom: 1px solid #ddd;
}
.panel-default {
  border-color: #ddd;
}
.panel-default > .panel-heading {
  color: #333;
  background-color: #f5f5f5;
  border-color: #ddd;
}
.panel-default > .panel-heading + .panel-collapse > .panel-body {
  border-top-color: #ddd;
}
.panel-default > .panel-heading .badge {
  color: #f5f5f5;
  background-color: #333;
}
.panel-default > .panel-footer + .panel-collapse > .panel-body {
  border-bottom-color: #ddd;
}
.panel-primary {
  border-color: #337ab7;
}
.panel-primary > .panel-heading {
  color: #fff;
  background-color: #337ab7;
  border-color: #337ab7;
}
.panel-primary > .panel-heading + .panel-collapse > .panel-body {
  border-top-color: #337ab7;
}
.panel-primary > .panel-heading .badge {
  color: #337ab7;
  background-color: #fff;
}
.panel-primary > .panel-footer + .panel-collapse > .panel-body {
  border-bottom-color: #337ab7;
}
.panel-success {
  border-color: #d6e9c6;
}
.panel-success > .panel-heading {
  color: #3c763d;
  background-color: #dff0d8;
  border-color: #d6e9c6;
}
.panel-success > .panel-heading + .panel-collapse > .panel-body {
  border-top-color: #d6e9c6;
}
.panel-success > .panel-heading .badge {
  color: #dff0d8;
  background-color: #3c763d;
}
.panel-success > .panel-footer + .panel-collapse > .panel-body {
  border-bottom-color: #d6e9c6;
}
.panel-info {
  border-color: #bce8f1;
}
.panel-info > .panel-heading {
  color: #31708f;
  background-color: #d9edf7;
  border-color: #bce8f1;
}
.panel-info > .panel-heading + .panel-collapse > .panel-body {
  border-top-color: #bce8f1;
}
.panel-info > .panel-heading .badge {
  color: #d9edf7;
  background-color: #31708f;
}
.panel-info > .panel-footer + .panel-collapse > .panel-body {
  border-bottom-color: #bce8f1;
}
.panel-warning {
  border-color: #faebcc;
}
.panel-warning > .panel-heading {
  color: #8a6d3b;
  background-color: #fcf8e3;
  border-color: #faebcc;
}
.panel-warning > .panel-heading + .panel-collapse > .panel-body {
  border-top-color: #faebcc;
}
.panel-warning > .panel-heading .badge {
  color: #fcf8e3;
  background-color: #8a6d3b;
}
.panel-warning > .panel-footer + .panel-collapse > .panel-body {
  border-bottom-color: #faebcc;
}
.panel-danger {
  border-color: #ebccd1;
}
.panel-danger > .panel-heading {
  color: #a94442;
  background-color: #f2dede;
  border-color: #ebccd1;
}
.panel-danger > .panel-heading + .panel-collapse > .panel-body {
  border-top-color: #ebccd1;
}
.panel-danger > .panel-heading .badge {
  color: #f2dede;
  background-color: #a94442;
}
.panel-danger > .panel-footer + .panel-collapse > .panel-body {
  border-bottom-color: #ebccd1;
}
.embed-responsive {
  position: relative;
  display: block;
  height: 0;
  padding: 0;
  overflow: hidden;
}
.embed-responsive .embed-responsive-item,
.embed-responsive iframe,
.embed-responsive embed,
.embed-responsive object,
.embed-responsive video {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border: 0;
}
.embed-responsive-16by9 {
  padding-bottom: 56.25%;
}
.embed-responsive-4by3 {
  padding-bottom: 75%;
}
.well {
  min-height: 20px;
  padding: 19px;
  margin-bottom: 20px;
  background-color: #f5f5f5;
  border: 1px solid #e3e3e3;
  border-radius: 4px;
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .05);
          box-shadow: inset 0 1px 1px rgba(0, 0, 0, .05);
}
.well blockquote {
  border-color: #ddd;
  border-color: rgba(0, 0, 0, .15);
}
.well-lg {
  padding: 24px;
  border-radius: 6px;
}
.well-sm {
  padding: 9px;
  border-radius: 3px;
}
.close {
  float: right;
  font-size: 21px;
  font-weight: bold;
  line-height: 1;
  color: #000;
  text-shadow: 0 1px 0 #fff;
  filter: alpha(opacity=20);
  opacity: .2;
}
.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
  filter: alpha(opacity=50);
  opacity: .5;
}
button.close {
  -webkit-appearance: none;
  padding: 0;
  cursor: pointer;
  background: transparent;
  border: 0;
}
.modal-open {
  overflow: hidden;
}
.modal {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 1050;
  display: none;
  overflow: hidden;
  -webkit-overflow-scrolling: touch;
  outline: 0;
}
.modal.fade .modal-dialog {
  -webkit-transition: -webkit-transform .3s ease-out;
       -o-transition:      -o-transform .3s ease-out;
          transition:         transform .3s ease-out;
  -webkit-transform: translate(0, -25%);
      -ms-transform: translate(0, -25%);
       -o-transform: translate(0, -25%);
          transform: translate(0, -25%);
}
.modal.in .modal-dialog {
  -webkit-transform: translate(0, 0);
      -ms-transform: translate(0, 0);
       -o-transform: translate(0, 0);
          transform: translate(0, 0);
}
.modal-open .modal {
  overflow-x: hidden;
  overflow-y: auto;
}
.modal-dialog {
  position: relative;
  width: auto;
  margin: 10px;
}
.modal-content {
  position: relative;
  background-color: #fff;
  -webkit-background-clip: padding-box;
          background-clip: padding-box;
  border: 1px solid #999;
  border: 1px solid rgba(0, 0, 0, .2);
  border-radius: 6px;
  outline: 0;
  -webkit-box-shadow: 0 3px 9px rgba(0, 0, 0, .5);
          box-shadow: 0 3px 9px rgba(0, 0, 0, .5);
}
.modal-backdrop {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 1040;
  background-color: #000;
}
.modal-backdrop.fade {
  filter: alpha(opacity=0);
  opacity: 0;
}
.modal-backdrop.in {
  filter: alpha(opacity=50);
  opacity: .5;
}
.modal-header {
  padding: 15px;
  border-bottom: 1px solid #e5e5e5;
}
.modal-header .close {
  margin-top: -2px;
}
.modal-title {
  margin: 0;
  line-height: 1.42857143;
}
.modal-body {
  position: relative;
  padding: 15px;
}
.modal-footer {
  padding: 15px;
  text-align: right;
  border-top: 1px solid #e5e5e5;
}
.modal-footer .btn + .btn {
  margin-bottom: 0;
  margin-left: 5px;
}
.modal-footer .btn-group .btn + .btn {
  margin-left: -1px;
}
.modal-footer .btn-block + .btn-block {
  margin-left: 0;
}
.modal-scrollbar-measure {
  position: absolute;
  top: -9999px;
  width: 50px;
  height: 50px;
  overflow: scroll;
}
@media (min-width: 768px) {
  .modal-dialog {
    width: 600px;
    margin: 30px auto;
  }
  .modal-content {
    -webkit-box-shadow: 0 5px 15px rgba(0, 0, 0, .5);
            box-shadow: 0 5px 15px rgba(0, 0, 0, .5);
  }
  .modal-sm {
    width: 300px;
  }
}
@media (min-width: 992px) {
  .modal-lg {
    width: 900px;
  }
}
.tooltip {
  position: absolute;
  z-index: 1070;
  display: block;
  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
  font-size: 12px;
  font-style: normal;
  font-weight: normal;
  line-height: 1.42857143;
  text-align: left;
  text-align: start;
  text-decoration: none;
  text-shadow: none;
  text-transform: none;
  letter-spacing: normal;
  word-break: normal;
  word-spacing: normal;
  word-wrap: normal;
  white-space: normal;
  filter: alpha(opacity=0);
  opacity: 0;

  line-break: auto;
}
.tooltip.in {
  filter: alpha(opacity=90);
  opacity: .9;
}
.tooltip.top {
  padding: 5px 0;
  margin-top: -3px;
}
.tooltip.right {
  padding: 0 5px;
  margin-left: 3px;
}
.tooltip.bottom {
  padding: 5px 0;
  margin-top: 3px;
}
.tooltip.left {
  padding: 0 5px;
  margin-left: -3px;
}
.tooltip-inner {
  max-width: 200px;
  padding: 3px 8px;
  color: #fff;
  text-align: center;
  background-color: #000;
  border-radius: 4px;
}
.tooltip-arrow {
  position: absolute;
  width: 0;
  height: 0;
  border-color: transparent;
  border-style: solid;
}
.tooltip.top .tooltip-arrow {
  bottom: 0;
  left: 50%;
  margin-left: -5px;
  border-width: 5px 5px 0;
  border-top-color: #000;
}
.tooltip.top-left .tooltip-arrow {
  right: 5px;
  bottom: 0;
  margin-bottom: -5px;
  border-width: 5px 5px 0;
  border-top-color: #000;
}
.tooltip.top-right .tooltip-arrow {
  bottom: 0;
  left: 5px;
  margin-bottom: -5px;
  border-width: 5px 5px 0;
  border-top-color: #000;
}
.tooltip.right .tooltip-arrow {
  top: 50%;
  left: 0;
  margin-top: -5px;
  border-width: 5px 5px 5px 0;
  border-right-color: #000;
}
.tooltip.left .tooltip-arrow {
  top: 50%;
  right: 0;
  margin-top: -5px;
  border-width: 5px 0 5px 5px;
  border-left-color: #000;
}
.tooltip.bottom .tooltip-arrow {
  top: 0;
  left: 50%;
  margin-left: -5px;
  border-width: 0 5px 5px;
  border-bottom-color: #000;
}
.tooltip.bottom-left .tooltip-arrow {
  top: 0;
  right: 5px;
  margin-top: -5px;
  border-width: 0 5px 5px;
  border-bottom-color: #000;
}
.tooltip.bottom-right .tooltip-arrow {
  top: 0;
  left: 5px;
  margin-top: -5px;
  border-width: 0 5px 5px;
  border-bottom-color: #000;
}
.popover {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 1060;
  display: none;
  max-width: 276px;
  padding: 1px;
  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
  font-size: 14px;
  font-style: normal;
  font-weight: normal;
  line-height: 1.42857143;
  text-align: left;
  text-align: start;
  text-decoration: none;
  text-shadow: none;
  text-transform: none;
  letter-spacing: normal;
  word-break: normal;
  word-spacing: normal;
  word-wrap: normal;
  white-space: normal;
  background-color: #fff;
  -webkit-background-clip: padding-box;
          background-clip: padding-box;
  border: 1px solid #ccc;
  border: 1px solid rgba(0, 0, 0, .2);
  border-radius: 6px;
  -webkit-box-shadow: 0 5px 10px rgba(0, 0, 0, .2);
          box-shadow: 0 5px 10px rgba(0, 0, 0, .2);

  line-break: auto;
}
.popover.top {
  margin-top: -10px;
}
.popover.right {
  margin-left: 10px;
}
.popover.bottom {
  margin-top: 10px;
}
.popover.left {
  margin-left: -10px;
}
.popover-title {
  padding: 8px 14px;
  margin: 0;
  font-size: 14px;
  background-color: #f7f7f7;
  border-bottom: 1px solid #ebebeb;
  border-radius: 5px 5px 0 0;
}
.popover-content {
  padding: 9px 14px;
}
.popover > .arrow,
.popover > .arrow:after {
  position: absolute;
  display: block;
  width: 0;
  height: 0;
  border-color: transparent;
  border-style: solid;
}
.popover > .arrow {
  border-width: 11px;
}
.popover > .arrow:after {
  content: "";
  border-width: 10px;
}
.popover.top > .arrow {
  bottom: -11px;
  left: 50%;
  margin-left: -11px;
  border-top-color: #999;
  border-top-color: rgba(0, 0, 0, .25);
  border-bottom-width: 0;
}
.popover.top > .arrow:after {
  bottom: 1px;
  margin-left: -10px;
  content: " ";
  border-top-color: #fff;
  border-bottom-width: 0;
}
.popover.right > .arrow {
  top: 50%;
  left: -11px;
  margin-top: -11px;
  border-right-color: #999;
  border-right-color: rgba(0, 0, 0, .25);
  border-left-width: 0;
}
.popover.right > .arrow:after {
  bottom: -10px;
  left: 1px;
  content: " ";
  border-right-color: #fff;
  border-left-width: 0;
}
.popover.bottom > .arrow {
  top: -11px;
  left: 50%;
  margin-left: -11px;
  border-top-width: 0;
  border-bottom-color: #999;
  border-bottom-color: rgba(0, 0, 0, .25);
}
.popover.bottom > .arrow:after {
  top: 1px;
  margin-left: -10px;
  content: " ";
  border-top-width: 0;
  border-bottom-color: #fff;
}
.popover.left > .arrow {
  top: 50%;
  right: -11px;
  margin-top: -11px;
  border-right-width: 0;
  border-left-color: #999;
  border-left-color: rgba(0, 0, 0, .25);
}
.popover.left > .arrow:after {
  right: 1px;
  bottom: -10px;
  content: " ";
  border-right-width: 0;
  border-left-color: #fff;
}
.carousel {
  position: relative;
} 
.carousel-inner {
  position: relative;
  width: 100%;
  overflow: hidden;
}
.carousel-inner > .item {
  position: relative;
  display: none;
  -webkit-transition: .6s ease-in-out left;
       -o-transition: .6s ease-in-out left;
          transition: .6s ease-in-out left;
}
.carousel-inner > .item > img,
.carousel-inner > .item > a > img {
  line-height: 1;
}
@media all and (transform-3d), (-webkit-transform-3d) {
  .carousel-inner > .item {
    -webkit-transition: -webkit-transform .6s ease-in-out;
         -o-transition:      -o-transform .6s ease-in-out;
            transition:         transform .6s ease-in-out;

    -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
    -webkit-perspective: 1000px;
            perspective: 1000px;
  }
  .carousel-inner > .item.next,
  .carousel-inner > .item.active.right {
    left: 0;
    -webkit-transform: translate3d(100%, 0, 0);
            transform: translate3d(100%, 0, 0);
  }
  .carousel-inner > .item.prev,
  .carousel-inner > .item.active.left {
    left: 0;
    -webkit-transform: translate3d(-100%, 0, 0);
            transform: translate3d(-100%, 0, 0);
  }
  .carousel-inner > .item.next.left,
  .carousel-inner > .item.prev.right,
  .carousel-inner > .item.active {
    left: 0;
    -webkit-transform: translate3d(0, 0, 0);
            transform: translate3d(0, 0, 0);
  }
}
.carousel-inner > .active,
.carousel-inner > .next,
.carousel-inner > .prev {
  display: block;
}
.carousel-inner > .active {
  left: 0;
}
.carousel-inner > .next,
.carousel-inner > .prev {
  position: absolute;
  top: 0;
  width: 100%;
}
.carousel-inner > .next {
  left: 100%;
}
.carousel-inner > .prev {
  left: -100%;
}
.carousel-inner > .next.left,
.carousel-inner > .prev.right {
  left: 0;
}
.carousel-inner > .active.left {
  left: -100%;
}
.carousel-inner > .active.right {
  left: 100%;
}
.carousel-control {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  width: 15%;
  font-size: 20px;
  color: #fff;
  text-align: center;
  text-shadow: 0 1px 2px rgba(0, 0, 0, .6);
  background-color: rgba(0, 0, 0, 0);
  filter: alpha(opacity=50);
  opacity: .5;
}
.carousel-control.left {
  background-image: -webkit-linear-gradient(left, rgba(0, 0, 0, .5) 0%, rgba(0, 0, 0, .0001) 100%);
  background-image:      -o-linear-gradient(left, rgba(0, 0, 0, .5) 0%, rgba(0, 0, 0, .0001) 100%);
  background-image: -webkit-gradient(linear, left top, right top, from(rgba(0, 0, 0, .5)), to(rgba(0, 0, 0, .0001)));
  background-image:         linear-gradient(to right, rgba(0, 0, 0, .5) 0%, rgba(0, 0, 0, .0001) 100%);
  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#80000000', endColorstr='#00000000', GradientType=1);
  background-repeat: repeat-x;
}
.carousel-control.right {
  right: 0;
  left: auto;
  background-image: -webkit-linear-gradient(left, rgba(0, 0, 0, .0001) 0%, rgba(0, 0, 0, .5) 100%);
  background-image:      -o-linear-gradient(left, rgba(0, 0, 0, .0001) 0%, rgba(0, 0, 0, .5) 100%);
  background-image: -webkit-gradient(linear, left top, right top, from(rgba(0, 0, 0, .0001)), to(rgba(0, 0, 0, .5)));
  background-image:         linear-gradient(to right, rgba(0, 0, 0, .0001) 0%, rgba(0, 0, 0, .5) 100%);
  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#00000000', endColorstr='#80000000', GradientType=1);
  background-repeat: repeat-x;
}
.carousel-control:hover,
.carousel-control:focus {
  color: #fff;
  text-decoration: none;
  filter: alpha(opacity=90);
  outline: 0;
  opacity: .9;
}
.carousel-control .icon-prev,
.carousel-control .icon-next,
.carousel-control .glyphicon-chevron-left,
.carousel-control .glyphicon-chevron-right {
  position: absolute;
  top: 50%;
  z-index: 5;
  display: inline-block;
  margin-top: -10px;
}
.carousel-control .icon-prev,
.carousel-control .glyphicon-chevron-left {
  left: 50%;
  margin-left: -10px;
}
.carousel-control .icon-next,
.carousel-control .glyphicon-chevron-right {
  right: 50%;
  margin-right: -10px;
}
.carousel-control .icon-prev,
.carousel-control .icon-next {
  width: 20px;
  height: 20px;
  font-family: serif;
  line-height: 1;
}
.carousel-control .icon-prev:before {
  content: '\2039';
}
.carousel-control .icon-next:before {
  content: '\203a';
}
.carousel-indicators {
  position: absolute;
  bottom: 10px;
  left: 50%;
  z-index: 15;
  width: 60%;
  padding-left: 0;
  margin-left: -30%;
  text-align: center;
  list-style: none;
}
.carousel-indicators li {
  display: inline-block;
  width: 10px;
  height: 10px;
  margin: 1px;
  text-indent: -999px;
  cursor: pointer;
  background-color: #000 \9;
  background-color: rgba(0, 0, 0, 0);
  border: 1px solid #fff;
  border-radius: 10px;
}
.carousel-indicators .active {
  width: 12px;
  height: 12px;
  margin: 0;
  background-color: #fff;
}
.carousel-caption {
  position: absolute;
  right: 15%;
  bottom: 20px;
  left: 15%;
  z-index: 10;
  padding-top: 20px;
  padding-bottom: 20px;
  color: #fff;
  text-align: center;
  text-shadow: 0 1px 2px rgba(0, 0, 0, .6);
}
.carousel-caption .btn {
  text-shadow: none;
}
@media screen and (min-width: 768px) {
  .carousel-control .glyphicon-chevron-left,
  .carousel-control .glyphicon-chevron-right,
  .carousel-control .icon-prev,
  .carousel-control .icon-next {
    width: 30px;
    height: 30px;
    margin-top: -10px;
    font-size: 30px;
  }
  .carousel-control .glyphicon-chevron-left,
  .carousel-control .icon-prev {
    margin-left: -10px;
  }
  .carousel-control .glyphicon-chevron-right,
  .carousel-control .icon-next {
    margin-right: -10px;
  }
  .carousel-caption {
    right: 20%;
    left: 20%;
    padding-bottom: 30px;
  }
  .carousel-indicators {
    bottom: 20px;
  }
}
.clearfix:before,
.clearfix:after,
.dl-horizontal dd:before,
.dl-horizontal dd:after,
.container:before,
.container:after,
.container-fluid:before,
.container-fluid:after,
.row:before,
.row:after,
.form-horizontal .form-group:before,
.form-horizontal .form-group:after,
.btn-toolbar:before,
.btn-toolbar:after,
.btn-group-vertical > .btn-group:before,
.btn-group-vertical > .btn-group:after,
.nav:before,
.nav:after,
.navbar:before,
.navbar:after,
.navbar-header:before,
.navbar-header:after,
.navbar-collapse:before,
.navbar-collapse:after,
.pager:before,
.pager:after,
.panel-body:before,
.panel-body:after,
.modal-header:before,
.modal-header:after,
.modal-footer:before,
.modal-footer:after {
  display: table;
  content: " ";
}
.clearfix:after,
.dl-horizontal dd:after,
.container:after,
.container-fluid:after,
.row:after,
.form-horizontal .form-group:after,
.btn-toolbar:after,
.btn-group-vertical > .btn-group:after,
.nav:after,
.navbar:after,
.navbar-header:after,
.navbar-collapse:after,
.pager:after,
.panel-body:after,
.modal-header:after,
.modal-footer:after {
  clear: both;
}
.center-block {
  display: block;
  margin-right: auto;
  margin-left: auto;
}
.pull-right {
  float: right !important;
}
.pull-left {
  float: left !important;
}
.hide {
  display: none !important;
}
.show {
  display: block !important;
}
.invisible {
  visibility: hidden;
}
.text-hide {
  font: 0/0 a;
  color: transparent;
  text-shadow: none;
  background-color: transparent;
  border: 0;
}
.hidden {
  display: none !important;
}
.affix {
  position: fixed;
}
@-ms-viewport {
  width: device-width;
}
.visible-xs,
.visible-sm,
.visible-md,
.visible-lg {
  display: none !important;
}
.visible-xs-block,
.visible-xs-inline,
.visible-xs-inline-block,
.visible-sm-block,
.visible-sm-inline,
.visible-sm-inline-block,
.visible-md-block,
.visible-md-inline,
.visible-md-inline-block,
.visible-lg-block,
.visible-lg-inline,
.visible-lg-inline-block {
  display: none !important;
}
@media (max-width: 767px) {
  .visible-xs {
    display: block !important;
  }
  table.visible-xs {
    display: table !important;
  }
  tr.visible-xs {
    display: table-row !important;
  }
  th.visible-xs,
  td.visible-xs {
    display: table-cell !important;
  }
}
@media (max-width: 767px) {
  .visible-xs-block {
    display: block !important;
  }
}
@media (max-width: 767px) {
  .visible-xs-inline {
    display: inline !important;
  }
}
@media (max-width: 767px) {
  .visible-xs-inline-block {
    display: inline-block !important;
  }
}
@media (min-width: 768px) and (max-width: 991px) {
  .visible-sm {
    display: block !important;
  }
  table.visible-sm {
    display: table !important;
  }
  tr.visible-sm {
    display: table-row !important;
  }
  th.visible-sm,
  td.visible-sm {
    display: table-cell !important;
  }
}
@media (min-width: 768px) and (max-width: 991px) {
  .visible-sm-block {
    display: block !important;
  }
}
@media (min-width: 768px) and (max-width: 991px) {
  .visible-sm-inline {
    display: inline !important;
  }
}
@media (min-width: 768px) and (max-width: 991px) {
  .visible-sm-inline-block {
    display: inline-block !important;
  }
}
@media (min-width: 992px) and (max-width: 1199px) {
  .visible-md {
    display: block !important;
  }
  table.visible-md {
    display: table !important;
  }
  tr.visible-md {
    display: table-row !important;
  }
  th.visible-md,
  td.visible-md {
    display: table-cell !important;
  }
}
@media (min-width: 992px) and (max-width: 1199px) {
  .visible-md-block {
    display: block !important;
  }
}
@media (min-width: 992px) and (max-width: 1199px) {
  .visible-md-inline {
    display: inline !important;
  }
}
@media (min-width: 992px) and (max-width: 1199px) {
  .visible-md-inline-block {
    display: inline-block !important;
  }
}
@media (min-width: 1200px) {
  .visible-lg {
    display: block !important;
  }
  table.visible-lg {
    display: table !important;
  }
  tr.visible-lg {
    display: table-row !important;
  }
  th.visible-lg,
  td.visible-lg {
    display: table-cell !important;
  }
}
@media (min-width: 1200px) {
  .visible-lg-block {
    display: block !important;
  }
}
@media (min-width: 1200px) {
  .visible-lg-inline {
    display: inline !important;
  }
}
@media (min-width: 1200px) {
  .visible-lg-inline-block {
    display: inline-block !important;
  }
}
@media (max-width: 767px) {
  .hidden-xs {
    display: none !important;
  }
}
@media (min-width: 768px) and (max-width: 991px) {
  .hidden-sm {
    display: none !important;
  }
}
@media (min-width: 992px) and (max-width: 1199px) {
  .hidden-md {
    display: none !important;
  }
}
@media (min-width: 1200px) {
  .hidden-lg {
    display: none !important;
  }
}
.visible-print {
  display: none !important;
}
@media print {
  .visible-print {
    display: block !important;
  }
  table.visible-print {
    display: table !important;
  }
  tr.visible-print {
    display: table-row !important;
  }
  th.visible-print,
  td.visible-print {
    display: table-cell !important;
  }
}
.visible-print-block {
  display: none !important;
}
@media print {
  .visible-print-block {
    display: block !important;
  }
}
.visible-print-inline {
  display: none !important;
}
@media print {
  .visible-print-inline {
    display: inline !important;
  }
}
.visible-print-inline-block {
  display: none !important;
}
@media print {
  .visible-print-inline-block {
    display: inline-block !important;
  }
}
@media print {
  .hidden-print {
    display: none !important;
  }
}
/*# sourceMappingURL=bootstrap.css.map */
</style>
    <style data-savepage-href="/acssicss/acs.css?par=31386C7877496D39732B3143444532454F626444335149513D3DB27D27AC9C" type="text/css">@font-face {
  font-family: 'Karbon-Regular';
  src: /*savepage-url=/acssicss/fonts/karbon/karbon-regular-webfont.eot*/ url();
  src: /*savepage-url=/acssicss/fonts/karbon/karbon-regular-webfont.eot?#iefix*/ url() format('embedded-opentype'), /*savepage-url=/acssicss/fonts/karbon/karbon-regular-webfont.woff*/ url() format('woff'), /*savepage-url=/acssicss/fonts/karbon/karbon-regular-webfont.ttf*/ url() format('truetype');
  font-style: normal;
}
@font-face {
  font-family: 'Karbon-Light';
  src: /*savepage-url=/acssicss/fonts/karbon/karbon-light-webfont.eot*/ url();
  src: /*savepage-url=/acssicss/fonts/karbon/karbon-light-webfont.eot?#iefix*/ url() format('embedded-opentype'), /*savepage-url=/acssicss/fonts/karbon/karbon-light-webfont.woff*/ url() format('woff'), /*savepage-url=/acssicss/fonts/karbon/karbon-light-webfont.ttf*/ url() format('truetype');
  font-style: normal;
}
@font-face {
  font-family: 'Karbon-Medium';
  src: /*savepage-url=/acssicss/fonts/karbon/karbon-medium-webfont.eot*/ url();
  src: /*savepage-url=/acssicss/fonts/karbon/karbon-medium-webfont.eot?#iefix*/ url() format('embedded-opentype'), /*savepage-url=/acssicss/fonts/karbon/karbon-medium-webfont.woff*/ url(data:application/x-font-woff;base64,d09GRgABAAAAAGF8ABMAAAAAxAwAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAABqAAAABwAAAAcYE2TckdERUYAAAHEAAAALQAAADIDAwHyR1BPUwAAAfQAAAAsAAAAMLj/uP5HU1VCAAACIAAAAvMAAA1AkWbY109TLzIAAAUUAAAAUAAAAGB12ozwY21hcAAABWQAAAGNAAAB6pHYtxFjdnQgAAAG9AAAAEgAAABID4ETq2ZwZ20AAAc8AAABsQAAAmVTtC+nZ2FzcAAACPAAAAAIAAAACAAAABBnbHlmAAAI+AAASgMAAIX0nV0kYmhlYWQAAFL8AAAAMQAAADYAyLu3aGhlYQAAUzAAAAAgAAAAJA2iBv5obXR4AABTUAAAAlYAAAOiaFpFl2xvY2EAAFWoAAAByQAAAdRGAWdKbWF4cAAAV3QAAAAgAAAAIAIGAZxuYW1lAABXlAAABz0AACAGc2Q9WHBvc3QAAF7UAAAB6gAAAuMsPQg6cHJlcAAAYMAAAACzAAABMIelOIZ3ZWJmAABhdAAAAAYAAAAGiGVRSAAAAAEAAAAAzD2izwAAAADGobe/AAAAAM1uOON42mNgZGBg4ANiLQYQYGJgYWBkqAHiWoZ6IK+B4QmQ/ZThBVgGJM8AAF7rBPYAAAB42mNgZGBg4GLQYdBjYHJx8wlh4MtJLMljkGBgAYoz/P8PJBAsIAAAnsoHa3jaxVfPaxNREP7e7mZ3k2haa60lxBJCKUVCESlSRERKKa2EVqRIKSqN1VpLLZJWEQki4sFDDx56EPHgwYMn8SDi0YMnDyL+BSL4gyLiwXv89u1L89JNS5pm6yE7u7Mz831vMjPvLQSAGE5hFcbQcG4CiYX88iIysKhHqYQIhYABk5paushMfukK0rOF/Ax6Fq5dzWNw8eb1AkaWKTAmLT2MPWV72HDgIkrUOLV7pQXktUVeE9iHbmTRjzncwG3cw0M8wmM8wwu8wlu8wwd8llwE3khfga+MChzEmigaCWPVTJqrVsIqWmuRXOSlbdlT9nP7t5N15p2nzkfnr5t0+90x6SPcESWnlXyg5Gsl//gyOqDkipK/fBmbVPKTL+MTUhrxufgTn11csYy/p+zjzyX7GNqQRBo/mZVRjOOHlDl8Z57G8Y3XnMzcKH926QufBYZwgXFM5q0XR3ECwziDKVzGIrN0Hyu0yKhMCkb3PPYj5XEJ7c5HMuVdZlNe/4NRDD04guPM2RgmcQkLuMVKEsz4bmRIz0t6Ey67xyLKfurDAAZZU+cwjXks801XiJnQ199VEz9sZJf1mMUxTrbTmMBFzhIh3zcXV19nqgZmOGgOa+ow5+NJjOAszlObbNLK9PUkAzjNRLBZF5VpIdC5oxXovDs3xN551Aifyh0s0NEAU51fR1W8RiNZ/H/8rhJor5uRzqNdi7E9b5M59irde9oaWcdrW/erx8NgntK8b62JoMdtVbabW3lr9c4VlUi6f0JlsPqNV/++X7fcvVu34FxenzcDfFudA9bzbci6DFqYWOJEvKPZdlD6vbeVddCvk/9peQbV5xmMkWR9Vub1dqME46XYj/r+13jEYOwuzqjqM0czogdx0pzt+iSc5cm0uUhBzAz3zerdpIBiaKhB/G6eWzbu2nd5Fg+fQTUXr6rL3buxr7wKELI3e6UuQl0Lvx8OUV+7UysemYCHUHENfpeYxF+S5ySTnXuAHVlT+w9vyNDbAHjaY2BmPsi0h4GVgYXVmOUsAwPDLAjNdJYhjUkeyGdgY4ADdiBmhHFCvcP9GBQYeH+zsBb+LQSqe864VoGBYTJIjrmb5SCQUmDgAQB9RA3BeNpjYGBgZoBgGQZGBhB4AuQxgvksDCeAtB6DApDFB2TxMtQxrGb4zxjMWMF0jOmOApeCiIKUgpyCkoKagr6ClUK8whpFpQcMv1n+/webxAvUuYBhLWMQVD2DgoCChIIMVL0lXD0jUD3j/6//H/8/9P/g//z/3n///X354NiDgw/2Pdj7YNeD7Q/WP1j2oOmB2f2DCk9Yn0DdSQJgZGOAa2JkAhJM6AqAQcDCysbOwcnFzcPLxy8gKCQsIiomLiEpJS0jKyevoKikrKKqpq6hqaWto6unb2BoZGxiamZuYWllbWNrZ+/g6OTs4urm7uHp5e3j6+cfEBgUHBIaFh4RGRUdExsXn5DI0NrW0TVp+txFCxcvXbJsxaqVq9esW7t+w6Ytm7du37Z71569DIUpqZl3yhfkZz8uzWJon8lQxMCQXgZ2XU41w/KdDclgdm7N3aTGlmkHD125evPWtes7GA4cZnh0/8HTZwwVN24zNHc39XT29U/onTKVYfLsObMYjhwtAGqqBGIArSmLyAAAAAAAA4sEwQC5AP4AhwCXAKMAqgCuALIAwQCDAMsA/gDDAMUAxwDLANAA1wC+AJ4AkwC0AKYAzgDJAJsAsACBAGwAZwC8AEQFEXjaXVG7TltBEN0NDwOBxNggOdoUs5mQxnuhBQnE1Y1iZDuF5QhpN3KRi3EBH0CBRA3arxmgoaRImwYhF0h8Qj4hEjNriKI0Ozuzc86ZM0vKkap36WvPU+ckkMLdBs02/U5ItbMA96Tr642MtIMHWmxm9Mp1+/4LBpvRlDtqAOU9bykPGU07gVq0p/7R/AqG+/wf8zsYtDTT9NQ6CekhBOabcUuD7xnNussP+oLV4WIwMKSYpuIuP6ZS/rc052rLsLWR0byDMxH5yTRAU2ttBJr+1CHV83EUS5DLprE2mJiy/iQTwYXJdFVTtcz42sFdsrPoYIMqzYEH2MNWeQweDg8mFNK3JMosDRH2YqvECBGTHAo55dzJ/qRA+UgSxrxJSjvjhrUGxpHXwKA2T7P/PJtNbW8dwvhZHMF3vxlLOvjIhtoYEWI7YimACURCRlX5hhrPvSwG5FL7z0CUgOXxj3+dCLTu2EQ8l7V1DjFWCHp+29zyy4q7VrnOi0J3b6pqqNIpzftezr7HA54eC8NBY8Gbz/v+SoH6PCyuNGgOBEN6N3r/orXqiKu8Fz6yJ9O/sVoAAAAAAQAB//8AD3javb0JfBRVtjBet6q6u3qv6jV70uksxECadBNiZJU1IEsIIIiIKIjghiggDCKDgIioiCKiMsgmIjJMVadBjMqAo+Mgbjw/cHyOw6DDaN4AOo7jKCbF/5x7qzoLQf2++f+e0ulKdbrqnHPPPfs5xfHcII7jp1vGcwJn4yo0wsV6J21i4Zm4ZrX8qXdS4OGQ0wQ8bcHTSZs12tw7SfB8QokoxRElMogv0IvIBn2mZfy5FwaJ73BwSW7p+bNko3iIs3NubjiXlDiuPCWInFcsTzp5rpyonphKjqesHjxlvDU4rEQq19xKk+Yl8O5QfJok1NRwmlNQfKqjpntlzx49E/FQwBotFJSEsnTMZb3Gj+91WZc3+8+vHzt3LFkjDGp+hd5/jnA9P8lSSvHqzqlcTBUTKSJyDrFctcSJKsVUjt7eLpZrdriblYO78SLcrXtlNkkICX9CmFOWHLKwLFkrXE/e0Hvhi167D8cJzYBbNpdPJnPJLMAtGQxlJhKJpA1wS0pOFxynOJJlc5c38EpOblE4oXHWpoZAOCO7KBxPWUT6kSDn5eNHFvjIane44SOiFsTUrOOpzCCXCaBmypqNlKck+lvSJjnKG/rbRHt5Q0iySeWpIDsfDOH5oN9erkqy5oQvuOgHWoSUqz2zGvv+9p83csFyR2Pf/f8chAdqltzAZ9n8AAL9acWfcLMGe6YEByG5wRFywkFQbnAHXfAHMv2p0J8B/Il/E6Z/A9/KoN+Ca2ab18kxr5OLf9OQZ/5lPp4X+su8gPjKChIkJzcvv6LDf2r/LFgHf1XCH63ClaCvYJS+on58VcNHffZW7Xxj4NZBf4XXo3uqthwYtGXgZ4O2Djrw16rPyIi1RHqUDNf34etR/bu1eoqMwBech2XkgNfP9xFGWOZwZdwzXDIHVlHNTGgRe1MyJ4L0zMkGetpjqjOWEkXOJQLTXoJco3n8TapH1rKBuEI8lcVWyhJPZmXj17IkO9JCKwKmCvmbtHJ49wBzJfPyu9TU1GhZ2YqvwemPlBaFa7RQETB2ADg8kgMHeTWqXWngPKF8/Ex0AkcKUg2wvb9Hz+qqRDAUDpZEC63BQB4fziPBgNUWjFaVlFaFEvGeVT1KSitI7MWHnrn3lg27rrox8/Lhg195/oU1z6Tu1bbMXD5n0UvPCXPu/01g74ueIW/Nrxvapbosy1f17BMP7Mx653f2a46uGjVuzOiCyk2chet3/rRllHgMdo6fC3NRLsY9yyUDyOUR+KGVWpuSQeRzAX5oirUp1S07IrjLtW5w6LTRQ6e1iajd6RZnvIuM6QHGtBjUkrUM+K2I/VYka5fAb3mMaSuRYJLi28tbbUIgjKS4BMjUEMyOhOAXTusWAMJk5AEtFSBRAydaCJzvXumTe8ZDsrVQCBgEAVr5ScJOqNAIotQoqW7zWb9d53bvPue4onef0aP69r6iG//xUy3FZOILdy/evXvxot2br+jdd+RI+EAoJ/zOnbq+g5QOGDlywMBRI5tl8dAP/Yjv3ueeu3fJc88tGXDFFQMGjxwJ0qbX+bPiJqBdNqXbUi4ZQrplIt3ybU1JO5KswsaIA6yU44adn8OB1Cv2Nqk5MuUWV7BJdcmaAoe+YBOlR7EV2EOoUcuVlD0zv9AD+KounxqpURVF84ZRRuaH4E/gdIWyl7O6AoVllCbIOaUlVQYFbOGe1QmrLRwtTdOimlh9wUAon1AOKuz1y3s9S5LrHkud+KKXdY8w/9NvZm4/2vjHI3def9/t+odbby1PFD80ol8f0uuuJ/oq966799lNK95Z9O/bV/zX9q9nL9W21V83jvQcyeddVj6yZ+nwlX2H8rDPQBaTEVQW56IkNsQwUUVKAj7QpFlIuSF2UeQyccv26Fr9M/4Y7FEHF+JUIUZgNwJTaVa5SXPRL/lkX3WCU2QSLVn7+rZP9KVkySfbSBX5grz8pL5c76H31Jc/xa4VgGtNNK8lsmvxxzUpfS0/XicR8sm8LUCW6Ev/vPX1323TPyN3k7fI2+TuJ/XBeoY+9Em8Vh/Bx++Ha3m4BZzqiKmuBAoJGzAzgQt7GWZpftdkKojVkiwCOrbiMKdxpOIwiubTr732LUpkj8rJquegqBJZ5Q/yGu+pqAAliYKQaBYeltYJa0xAJSYtVmcNFQrV4dKErTpsC9tKbaXVfcqPiBusb3V7e+ldixbdtUQc99DQDz8c+lD/XRO134zbjTDXcx8Ik4SPOSc3nmpEW0IjtiaUXBxBycU57OVJwuEhEeywQK6Y6jiu8vGUne1TMZ60O/Bjuw3+0mHHQwdnB1XNyFcVAaUcCUaUqFJPqjaRKv3IJl5i7/oRUgUwyOc9ZB73Hmfliikv8AYv2OhSCMALErC7gAhbURWHeyoJkHPyI8fmX/X1fmJf+88+dC1vJY38Tfxs4KlCvA5QpglfyFRAW7A1mGa3mIAFbyUtpHHvXvzuQrBNHgMlYOeq2lsmbY4JLmpHAwVVK9fWCFk45rLeY8f2vgzMj/r59XhtTj8ljAK+EDgvR1kB4GFAKCRB+GVHWhbrp6wPfj8X7Ii686eFb0FWOEHOgo3kQCHhdTQlRRQSfkQmQJndDfrGzeSBDRRKEN4VNwg+we4QqUD0e1EMWm2mGPT1LEAmthaU+ORQvKdcUlh3xzGSceyOO47pXxy79sHTDz98mjxPbiO5W7bon+mP6n/dsoXfrk/5xz/I1q/ZXimGHyfFD0Ab9OKSIsowHqBKEU7kQbwTAYCzgk0FS+YHgAXkBJEAJ4C1AmwK6k61IItWFQMvFJNX3hPeaRzxQzfhLN2HYD/VUBk5lktyiHWm0JQMINYeJ1w4B3TucS0caEqGnXjhMCjipDOMh07ktly8Rybeg9SoHiUpyCAAa9SAT1XgnomqvhKV77aqvgSlnkwiwcDl/ef2vqayd17wpmue+9XAV25/9n1d4kNPXVo9s9eU/lcOHll07bWPv9d32Iu/1n+r37+f0aAM1kcCOKPcTRxTfYLEVJ/mFZpSDnskCLRwgPEGTC+VgwwgalFMtR7X8mDF8mQ1o+C4orng2BXTMmDlihFwO9iyGqHaKwIoZNeoXkXNqFGDPtUH4FentXlVUTs0YBdQnQ+Cu+yRZ6YvWr2V+KcO37ixnzZ156v33fKLR/7+0rXPDnrttmvGTp3k21icGlK37shlg194cM5zOVlPL9i4tzu1XSs5TnSA7eoAu3wcl7SnV5Zz2mFlwUrWOJAJ1ji10O3HVVdck9xNYOgkJbrfJSsshp0aonZcDC/ixKOpQtxUKlWRhAJmGq57RKnk+x77/e8Po1Qm1bv4v7Tk7NAPk+od5BzQNwr05QGWHG42s6Ipfd1IXxkZLJfSMgzuQB6zY/sd++Faar66Kzyq66BFkzO+96jKQU5zKSAuG1xgURrWI9HCoDI1jxdVo5AFhOZqVFnRSLimDZErhFI/yCshT2SEjT788MJllXWLFo8p54fp1/rr71swpnvT0bG/6vfq9BunVY+/tCwk8eNe0s85SwZM/OXoF452Q5oOAjw2Ax4+wGQ8l5QRkxBggvZRSsqW0SCSbAwhUAt+0PR+WctEF8dNcdMy/YoPBI8kW+l+zgZVrrk54GlJATGIWrwaDGAbiJ08vq0d06Ok0DpobfNHH03pO2Pkg7Mv/+rN1z57ffn1M5Yt+8NysmrfabJef3Z136rrn57ym7Nndt9879I/3nsv4+0w7MFSgNkK8jNpQS4gSHcO6W6LoRAGHWWhRgeTnyRKwoKsyx+S06L00ss/nBNBWgpoKwpLYY+EuAjXjXuISwYR+yzJMHXKpaZUcX7QDhQoxktXUAqEYUuEZbUQt4cVjB1rTCsM4inc2poP2K0L3Tlg/MTgRCGupBAEcnRRkln5dtzsLp/mDVCzB9ZW8yGtisESAm9RLfdpLqtpNVcQ0/Yxtk9BmnRoHba1Bh+6bvQN7z351DvTRl/74Bn9qS/fm3/N1QsWTrp6Qen1w4ddd92w4WDF3PFMVv4j055KJp+a9kh+1jN3bD1wYNfVM2bsu+1WcnTU5GtGjr7mGo7usyogzlqgix9sHuAJF1LYghTJAYrIYZcFKCIjT+RRigQB56CsZQG2krdJy4f3rCDwhNPikj2UJ8IyLIanRs1RNIlj2PXlmVGH3hDwRAXpmcasqu/sHdMP/ZWyRp8bZ6pzDi+bfsMy4AyhevwTtw84o+09rd9EJq3uc9VLZ/64FNgCYaZ6UbgV9KKfq2mnGVVfLOU29CLVSaojbuhE1WseoWJqpx35C/TkmHb6kt83f+xYVJtwb7QLNsK9rZzM9eTAgEo5jPsppmXQ4OUlT3nKzW7mM8yEpNUBe7yNqdB6V2o0FMMtx43rfZlhPAjrzXsSLsE18bcKB+CeUY5aINzxlMXDSSL6ddQOsbQJCoBgC7pJMMFfpr9NevAjZHL9vlTqRYB9MlkqTBcqaawhi1kj1iaq+NELkmIYXzCsEAKvyYLU/J0gkaWPPUZyH3uM7cd6gGU1hSViwoLOpZWCQ2HBAIXKIyTVVd3AwA3Wk4T+Dl/T9GIqtU/fJDO+Kzt/lj8FfJfFlXA3cskiXMM8Zt1QsyJDaGrgikQJCFsaU7OPpyIs9OKNZIMT4oFdGJGphWEDsdsFPTG0LcSMvCLKhVweUNzmCaIjK2ZQDYyIGRrKI6BD2lcwXK82bldZz90znz9ccfl1Iyt+O/7Ga8puGzthTe+6mj7jx/epqRPWvlFdu3/rkHlX9CnwPHQmq6xPXfWYa4Y2b0FeqamvR7wm6h9a3hOf4rqDPbKGU8tjWokLrKKY1gNIXRPT/KC0coDiLqB4b7qSBcxmLZDR+NYqAbNKWesJpmGIfRCiIthwT7U+8Dc9K8HpdPtzSsot6HRmohTuUoZCxl0CqHap0Wp6wF9InJxZgJ6o6lfUIN2Jvp5FiQJOCXh4wJUKnLDSFyRPUbRQBIGdJ4CfFcQtKhRTn0tB+kyceYBkvwA24uSrt/1p+dHvvn790fkzF+h/P/Oy/vljY1bsfXXGnw4898+lf//gqUlEf2xx30h00MI1ZP9G4vn9HfpL+r/u+z/3Dz128JW/VLbsLj+09hP9Gf2L1IoPV00urV00pMcdz3//+PwHreS0azXlCzAuxQMg721w1JVZXaqQoEI/ZZU4AuLIKjWhS0R9IY1IRsQtQSIkKkQEf0RwkI8IRz7+7KaWkzfvIpvfoz5wvn6SHOErURdsOH9WOAK8J3MZoFXmc0kv6gK/oQm1AntTKjPDi9owE28VpZJPAcmXGVcVJvutoBmChtVEIyi5Chq6Xrs/beiiIs9QVFeNmunTHKAM1AJUkqrAmLFaaSvuxUhhdShRUNUjEq0yJb1tw4u/+POXK2at2KT/oJ9dVd0rTsr0M8umLVm25M7KAaK4P/O5F257zOt8culzLyWtB/btum7KhKuARGivixGq6wazeAiagWxb2WFb2QJ0W4UpWi7wZDKQkN6AgoadalOSnEuh+8ZOnRvKN0XAKUZMJ8R4pICr20ryGg6uWfHW3s/P7D285ok39S/0Z/mp+0n+pitPLfnmjd9/vfjEJGLoGaC5uANgcoFGH8UlnSZUlOJBtKYzKDyGD4FSUwLQMqmeRbXqRP72Ohldg4oqtaekCFSUOUrFuGGPbtj9RJL490wEv+G5xoG9R31MuB++7NNXFBvDV237ZKV+TN9+QPr7337/kRVotgEYYzXwnZMbatj6QCpma4hgQ1sY61nQ2XFRQO0AKPqZ1A21gxsKqoY5nIaXyTxM9trAf97yOfla9/DF4qGX9Jf26rsN2x3v24vGn/uz+7beU7LQe0pojzg6v6dxQ2eHG27gt+ndyA59Et5s037dx+6FfDEO1iCTu5VLhs0V8FKHxeuzG4EyZBFrWEAWyTJZxAzzBIDbs9Gtc4F4tQvMnQHbyEIXJ0xjhKpV0TgX8I9gN70rWBhgnwqS5h9wvz0EWYjcQOTDT16emtZ49h8vzh58dOh7d4Kjt5WfSoJk6uQTvQf+8/dv/juHzNHD5TEygdFL3EPXqZ8hHWxMOqiWREpwUIoJQnqVnEAxPq46ZVRNQDvqmJrrg4mBBNj/QLD3+XlHj7YAA+jAqz/046WW79LrQ2bC/QTQd63rY8aEwKmkL0v6ihveR2nDvgt+A78SvuvmYsyyQsho6J06LVa6oMwxEVyMsW0KY2lm98P1UCtFb79/9IijL27bMujDO0dfLcxunr9lF91TQIvJFDY7WAaMGlKaGibTIHzONHw0zhjd8L6dHP1ejxJdR3D5ifysludb1hv8OBGuaTGlL4WZ4Ww1r5cUKAcKFsORNogZ3PA++Qqu92+DtwdwnDUM13Jxb7Brpaw2u8NVFGYwJnnRkkgAnG7GZn7KZjYmXTEIS12pmm8V6kpxskoOgjclq86Dja+9fWY4nrWojgrN5ZTgnAf47XuLyh9s7DP6zHb6FbFC4wVJFeAzKRM+sx9sPPgmu5xmlyTVJqvSQYtqlVXLQYFLCpITfDLS3054QbSAF+nsEOZP+CN2EvFHBfAxhAGvEZGUgtKxHjq6Tj/xtn5inXiouZfwxg/9hD3N9fgy+Edk+aUhxgpZjRUS0ytkB9VilzUBMXfTxWJ7h8e9pNpqWKDCCLEDpQlyLVE2HOOnHzncsgZue7ewHG67qHkFlbWwzy19YJ97QdYOMTjPD6tI7fqwkJa1CmxshVlRdkPWBkGNaS66ncPg64EvzdW0GvGiT+bFaGER75NDBT3lkoK6ac9/sWwPyX/+ef3knt/of9n54Vky/cwZfSM/ddXpbdf8Sv+zDrT51a9IAVmkL/jmG3L/vxjfCkmAzw3w1Ru7iukBjFbIHGpeh6OdSvDETa2AvNGqFRwIaVCmikoV2OZJUH0AVh7Im9JMQtUq1Qfb7v+ScPf+99rSnkWXkLJHH6zsIr6SefwPq387QdRn8CPEL29daKX0009Q+vlZ5IdaB2GTftkCi/ygMxSgzlCmQT+0CzLBGWqweLwuNLvsiupGQqIxAGZAtqLZubbEDAZ4G9gsFcIF5Dx7kHj1b+45sfWaCwi672P9t731D4lbvG7b52SYSVVTHlQC3B6wa6YZ3OZIMNKGgLRuLyWtG42azHSGyBvHJJEfSQtIoGfn98DKCy7qvwIDYkDXC9RW7TVqqK0Jk0ibMLAhopmk1XB5eMuX+vJbyW3N+qsP3PjLR9asqqwQD4TfOXjvgTI9QlS9jp98552z5oqGnADffADAXYzxK8xDaDlmdNGObFDC5IObyod85nlrpZiAwG2RkQlg5it77aI3lBNFuvvA9Jet6GxpOZhsyGDpKpsvEz8VTaMGnYG0UUPzVJRjqvKImabiB9y856Y9q554asKMGxbt2zT/lV8cXD56w6RpS265c+EjVwhLbt40cvLRRROGDhldWv3Ck/O3DZt0rPflYyeMGhstvfpBhls+8PpX1J69jEta28YvwG2i6V1QAxYQqRYrilQLKPWk1YKHVoxatXpkGKzOF47qS4+K0ksv/fAdhjXg+ktBpw+A6wdRH9KIjuRg8lp1goAJmSJbFWTNgZEc2D5heHdgploGCkm4edxIENQ2eTzTzlYRnYClR8vH3jR0wYKj489zt0xYe9/knmSzEGkRx8+/PDsgen+4PlyQ2e86VJHUbt9O4zQRA0+Op6Z7mzCNlco0uBOooASJOv5KbiE3n9Arm0GC+YSzoDYpvawzTJ1BoxGS3YkZa46GdQXRagP9YeoMAogRWbOiH+hO64xDR7/6xNQZLtAZNFXR2Lf8q3eZzhAqNMJLcM6jOSTQC6BQDv3pq9/Qr9grNKdDUh3wmSUDPhNbv6iBUmDKwsJUB+gM3uJgOsNUGa6OqeFENsF/JOIkkfwP/vH1iW++fls/rH/72d/07wDvQuHP+ALpvbt5nEHHqdS+KWnV6Lyp0V0xarxoPDK+6KD6wE7Yv6idOEhKv/UbkkVym/TZJPkP/ff6If4ufrg+kexs2deyihzVY8Y9RsA9JPBSk7Z2a2WPqbbjVMYis1htzJXXOFu7pQNWdHxBepHqL/ShYO+0HOPLW2Q9Ro4ynq8Bnm+kOq/CsCFspv8hMGOWGiSajYXGwdg1HI1EFYlg8CESrOEXtjwlTG5ZzD++X6h76cXmPYZNcUA/xddZ5sB+qubYJTE1xIFHbWsyqyVsHs4JjjMf1yzBJvM3IW5uJjBUokoieIA8+tFHmOPYdE7dRK8d0U8Js82cCNc2J+IHdo0c4Zcdscz5fi792xn6KfIdhQPsdiphRYADWJ0z4LCZcRG8uVXWCDj2BHa7bAJkM+MtYdDmVWC4z/joI/KofttiS90mvAnhyviUUE/3FFh31APmRCPq07qrWnMYuKecpIxUvUqq33zvbT7Fu1v+Sabqmxm8Hwkjzi8C3MKYn0QwGahpHMMgY2bwf2vJWrGVI2SEmM2nLPXw9wX495gL9aRzoSneg3UGxhdJwh8lIxr3NFrq9cOoh0aAf50tbOYCXC53G5f0U/1pbUq6CYon8K6FbL8b7XRLa1xRMVUpGumKwkKLQWRzB3h+aqaSlNz+GtMuURVUp2Awg3dE/X/VjXqKhlJ7ESMdQZWTAp6qPwBCrQrk/Ig//WH61FHLli3f9szelZo+6w9HK/teedvdhL//gRFDhw1Xh6/b2rKziGQtc+gDAI/VoJe+gjV2gz4dZ9hRsr0paSVModK8maFI3dTPMBQpGHRpRapZXQi1bBj4oEBBjVpZvBolLWohMFa4KHVdDQW6+kjh3Jq3CNH/9v2e0svGrv3N5rtmjSy1DNd5X/a3x07o3x70PbPhlxvK2Z6oBTgrgd4hro/p76P+JKb+DJv6s72nbwdP34ae/kVUohEL4mp/+ccVqxbesnzJ9h0rfnnHgnX/pf+LvLHmv+8Y9Pq4Xz1w35b6QwOBN3HdEY5dQC/08ccZeUKkl4CQBB0YP0/bdG7TzVctNHHT0aaTHQCkRD19jhoclMV7cBixAvUERmh1a4SqlsjH7rz88KOvf6X/9e0960f27nvTvdvIG38kQpR8c25LyXenHnlG4suiG7k0nMuAXj7whMHiUBBOlwlnWGpK+SUFDSU/BumyaGrTjrmQOFrpAZSLQeYGB+zUUFKYoWQkcVxgQqteTIlonAfcYMqvaC71lH3Akbkg3dDCoLQVItQprv3uwME3WlbZX5jzwn13/eF4L9IgzLx+4i++ILuJ6+ShGZa5KyY2jOVjN81hsicXkFhvWQE6f5JR74KlapoVFT+goHoTGieBaR+n+j+AmXHN70YjOukPoGnhV8DKCPjxMIBWRhjZwkmYiWfF2AqtaWIBQsoOuYSlynIfeu7RWcNH1A0c9Pnnh/mTu3Y9+0K3xsSwMbt3teTzJ5G2+iJhM9A2kyvCKAMlaSEsvTOmyQBTOKblovlZTLkgC4DKoltGzY9T36cEEwq4691AOtWvNAiyM0xDarKT2ilqWMHsQi6NNBS2Zw4MUrHYJis16kPQoGvPKMEze7eMWr5u7Lb71z0xa2XGtMR/69+//cx9w8f1H/nodvLOR+cGNO+46ZkJZf1errtzQdAT/PJPKzbm867wE0D31aDXdgB/yxhXo7rZnkhaEEO3IQwUipbMhIHMLC4UBui4OGQqqDnN4jbSVeg0MyEVVXrArldWH7ntl8++evi1Wyda5uhi+ba9Lfv5qmReSzXj2zmw+LMt+bRWcQjbX0knLrgU0wSxiQYV4PYWTxO+GtwWrNdxADCgcDGDZxYrNvA2SUCiUnlJLfjCEjT/5lwx8wr4l3VE3Npj2LAePa+44od1wurmeRx/fqW+iN4bfbbxHBWBuKY8rGkopiki89Ysx2kSVpIbMiW/p1zzeIDrYiAH2f6WLHBzWQmy8ijeWFErrmL3SlvbkEdpK2ALBw7o3+/I1rX1w/+HgdeYf/k44b3m8Nr1uVaHASelD67PCaq/28VDcIXo6hjxEPeF8ZDVRySy5Jw+hzzxD8ucc2vIafKMfoMuszUnV9Jr5htXZMUS5pXw1Rr9WX0Ev86x71m2wj7I5aYbNpAzCFYs7gesZ8mCLSHHTe2XCzTLlbUQqjyWYHPBodPNtGAol9VUBRXN4mMpRZtspos1YqkxXbFwmplQh7QeKauPpTZN3LXuhd8cvmrknMnBwxNHjZ0m1NXV1m7a15Lih0wYU5bo37IHD/JbKplOobwO8HvaxtnobnaiCedNaz0PDa1R8xvzF5KHAgvAOZV2XmKax986/uLrh1+bfaVQP2rzfsrgWS2JtFz+Cu7pBB4bxHL+mjetP+zpgIDhCfqMeAnVHKBeNTutwQ16UekajjboC44qV65tQV0tsb39DpH07955G3b/ujvnP/ro/LmPkTc+wHMf/Jf+PZGOrty+7f5V259FuFbqa4QmgMvQax3gEpqordgKmjv+I9B57bRECvVaqyPtNyIWnBGwMM2Albve+Btx6//64sZ+Q8Y+uHPzqqmD9DXi4dpvPj51nsvQV/PFWb9ad9+GEJW7a4RdrTBeqHttHXWvDaSuL56G0fbzdG/0Qt2b+Y/9mw8PmfEX/Z9vP7uqbvTo/o8/T974mHCDfkiQhTk//Hnl1hw+N/x0mq/4jcJTsMa9zcgPtQqdrSFbd1PSSeOLTosRTNckzozwtOP3IOPurYeunFg7Y9Rwod/V4Tdyc1sGwH2uPH+aPwr0iHC3GDZRls2gBi1xKGT3ArXulLUcDGnLTVoUdx2WwIYzClCn5yh7JcETyMIyVxVTuF4LNUGzAqyEUVIawKnNwE/TVOrZMaiAaUWqj1jl65WpRx6bs3Rx/6H9R29a/fLTo59IrHrw8RFT1izmH1rx8JDGyZdWdK0KFS5fuGp1aeGhG2+sqsqM3EPr0U7zK8SZoPOnmhaLqe4tTN3b4mZNnIg1cWnNb1dY0iCQLogL2NtrftNi4VC1Ms2fCGLEIW0DllQp8gN/ILyu9+s7Zvw19yx8AnT/J5/s0utGDUzsq7zvUfIJrVc7LSwWVjOZQa1li2TAKCVMmSG4aSwCw7wOQ2bYBBogA83oMpJ5NBZhRCLg7gsPfzj4ysO/+t27x0kfflTLoZfc/N+bV3V5mvmyggr3bBN3IBePOxB05BwfEk4/qm/+Qljdchn/e1Bv7DqWcXCdC+MO5GfHHV7r8+VlF8Yd+hz4svjCuEOYxR1eG3f2bxfEHXJY3MH84n8WdwCXMOo4+uqBfYcOHNa//ev+/Z8C2rX8fnw1z+PXtsym+9KDdSCAf/u4A/nxuEM2VZ5OMLPq9DeaDr9xSv8dGf35iRPkKGnUPyFRvVbvRvrov0P6gnxKwfVtVI+yJaL+gFF2cMEq+R0fAb8d1YNvLgGAe/Jv/SCS2nReQYjCtezpHIVNMvwdQbowvoBx4fbRhQHkQ70Xv0+Pkm938H127mp5cyetbdBP8RtA1xdh9NRFw4/g0+fGUHTQagkbs1wLjqPTEg5i7DQZLqClfzk0AZgsoMm0AqwwLKFYoYoOgTBRiaL5Akx7W2VWgEbtHXRYgyguFJYKhk1HT8CWAx1Q36t24toH6vr267F8woTlPfr1rXtg7cRa8vHmCdeS8LrHNw0ZrP9jwRqbbc0C/R+Dh2x6fB0JXzsBcfmdfoospnZLFtfWZAHPBV9GWAP21+8ajTpPkJmA/0YTf5kWzQPiRTRYgEULmQb+4nHVGdcKAP8gYCxSjLH0UaSkEIuAFHKc4Z+DDGMpoB68ZsMkuOwDSwjxDxvoY+kToFpOqqiZYKBP6VFOruxjYt4HMJ9Q27t37QSgx+Ihg4mX4U28FG+96doJQBS9ad3jlEdmkzVCmN8D8nI4hyaoJDU1+CUPGMQCIOOIG6FRozMFTS6w1VNOVmRBA6RB1IceFPfoxlMTlUp3DJFWJVCsV4CnEZw969rSUYneGbUbb57SZVQcDsiG5Y8Wdyues2JdSbeS27HHSD9KNgo7qN3eiwOOT9fu/t80F3Wv9F2kqYj/M3YVjWseIgxpbgTch5zvI3QTa2Hlb+dA56cU2hXStj8kmzq1hvmWwfpDwun+kHAGZWnsD/HHqXIMZwAUTgWJoeBhAGPuTqWBcLTgQRXN7JRPbt8AwhQIbf8Y8u72zTdff8t9S7bvXHHPHVPu2vw8cZK5/y5I7nJWm5GES+3aS/l0/YbAHp8tHuNyuIXGHgeTmfm5irMpZbFyTne5Gkhg3E8NxWnNIvClLa5lKOiqJzMoX2bkYJI8I4TcSbESQevh7sVqxgwR1jUL9bkRiFSsTBE6mSJMVPUlVVHDD2YoofceCQZskeCQsbVPP31k15iHi6c/coDk6p8t44enYk/eu/1XbxxNFH90+8m12x3v3pFC+3Eet1ZMiHWwHoVwjD5wHgBdGNMcNlZeIhzXcoK0raIAwJKDrKQkB9TiXmKxSZlZSOMCJemw04y77NvrdHl8gSB1o/LCii/l4/xBmt0oVJLE4sG/cvgarJLTTUut+5GSqh7VpdXhngXh6rCNdljYsLei1OYLhGh95rzHhg57fPLjM4lr5uOTHhtGj+9bcfPjW+997d57Xzv9xLTV99+4ftL64cPXTVo/Y+WKmx+7et3w4ev5oe+uWvXu/elch+gRD3Ehbi6X9LSJK6dkxcO50V3WZBdYXPFUIEhPgOkScKHpQoNUnuNokKJ5KsWTbg8ul9sJy2WNJz1u/M0jw2+BOHKs5vaYselgu9g0tVzg/2hVhP6fyP+MZBLfSX3zSf00CeinD7O3k+KhllN8dsvKhfMWnjwJP5iP3So3bRj5tMSMoDKGJQUsAaVv6VByQhGoDG0EKcq/3DJYOIo/aa2tLMwE/q3gLuMe4JISMq4bVr0gphXjqvei4jgGV7RgGZEMhmhM1qqQK4NNDbkZVSADushNapeYlguWaW/kC/SehcJoOa5zF+VFt+QvKL4kUYO/5voanAFHNmWI4gIgSCGGRPdanLlR9geSYViBvC2p6mCkCpjCYwVwLHCChqpQbTbbxIh10KyrZqTWPHr7PfcMGDz6titvueaSWyZdv/fhJ29furT/4KE3j79t8iWNU1dn77rxvsxd5OzUVaVD71uyunb/5J4VXXuX5PUYccOg61eVDF1xz0NwrnryZcV5VVfMqOs3tErqs6Dv6G7WGkb7Y2JEKLeEaV1nDOWkqiQwsIG13TS+ETDjG9iXhbEVr6fJqOZsjRcUp4+O1c6ohX9kKnsXN/YYOrRHfNiwuPGOtWCTz5+21NCcaYgr557mkm6sU/C5OMWoREyF6HGqrMgtusu1MltTKiufHmbhOnalElwOcjLITlmmqgNrhAtppBAbUuADrRueDaMpoNCKmf52l9snBrNySsrokhWVgXfhl0trWCoTxGo4twSXLcuXDHhzaphoxSosrKvmxYIiXgb2hJfQupat1vrkzSRPW/HFtinP6J/qm/RPR5E4OU4q9ff0S+7+5Dd3TahbMO0Xi6b/YuxVd2sfE41MIQU7rn+uadlv9JM7dvAH9RwsfSd/JdUtx37zp6rGuuXvL6t7qfoTVpdPvuVvBXoFWWyfFsFLVpC4MS3DhVZCSqD0MkMbIaBFiBYMww5KKUGuAshBoxrp2H5Wa2w/w4jt5/zc2D4WmLPgfuWvnx41vO8tU65fumT9oqXrdu9eX142aAf/zk1zyi6tuWx99fx79UTWjQumWPdTPKZw84TZfDNnAYs3B/e56qB9t9gZheLIsHhZs5c/yn5OaT587tzhOvqT7CeD9Ff0V8lA9v4f9fqIXD15R6inPTZhsMAxb8bK8oOUmqo9lvKyo+JYqpRxZ3EpysTiDJCJhXFgxFS2QfkYtWxcjCddrIOxhP1WGldL0k2MeCKPRipSVsan3WFhLikBtWP3BrOLMEao5ilaJFqDSXWQKZxWWgzaxurycRH8sKuCvaDZPjXTtI46aV/0p8sEwtHSaLAKPWFYw/r/fnbHxx/vePa/615YvmL37hXLX9hcn7ji2rLIjLl1kdzL+2RKQt2zf/nLs9tPnNi+4sUXV6zct08/ROZ7awd16e1Zeccdv49V8lTvkEyxmj8lvgd0L+OM9Lq1KX3QOfmxwBn0wtti9YYNyA8J/nO+TPwAZE+QG2PQ3s8oDvaa26BsiO52ByOdg1bsmqTDjS+3doL7sfGJgJnCWp3SlltpG8Ik1t580yOP3HRzaHDvXoMG9eo9WJj3/sMPv//wt72GX3FZzfDhCNdkLiXUiQ6ak7y+Tc226qTt2Ko9nhRpuYDoARvHQo0eiw0DADJVqNZ4ym00tqZ1KitWNHUqGkSYc6NkqWa138z/Bx06mf+mxUXKN5Fy/dim1MaN5NjGU6c2fvYZ61MkzUQXj4DkBIp5qL9kpY5SwMKyTtbjmhJsSiq0tEFBI8yqpEsbaC4qYLhodiVpddI8igdDAbRWW2i714F7wO4aPu66ronY5Mn1D81asuoXJEiaF/YePm1sSUX3uqdG3HbD1OTVa9AOIV+RkwBXhLuOY+1aXuAHB82HuagKppnHQgQQdEsql0olNRynAaBcq2EVCgUsZWdXNJJLDSo4rXoVTQmzLi4fhTPdBtWzA7xG8Cd/zLRY9dD6h7qWXDnpyoU3zB/Va9CYx2+ezUc3DSkrrii23GUfHym84slB0yb2n+rxXjVg2g1cx/wr9+P5V39CICP2NO4Rs0k1ZmBp7yD42xiL8WI9a8dYDA1YylQ+e1muwtsakaHte942ERnN4am5ICZTqhhBmRe3D9TXiM3poEy1fgvdT+dLaT2th/NhjwaWTqlygoCeUKXjKRujuE1OcayPAbs8ZXR4Uj6mIgKGVu/L98Jyg8IKAaveEoPnr63fsePyu24aVcEndwhTJj049pJzM/gPsi4ds6DZZ3nq3AzAfTFZSTbwW2n9Qau39TMaJlu36WKjG4N8ZLZhwJoM0o/xq4GrbFwXuiZwQTdeUEILPiUywHFGAy1osKHLRsCDwGYPMuiKcTvr++nHBu+5atqrXdkaZcP+GQR8asGYC2+WWIrHUwK9VMd2RbNNMZuU7RCt62MtlXy2qZMFB9UdIW6AUY0QQNkQQ8ZP539bu7Uxf5lhlPEacelA26h5OzluSqvK9zY98847z2x6b8/NO2fOHDf+JmH6tnff3bb17Xe2XDd37nXT5s7rRK/CuloT2DxroxKojV6t9gsJ898U0KfNzcvoz3mmQk0rVo7qR46zVFNa2bkA6MidLNqn+tgsC5Vn7yCbrdge6EloDhemWJJB2ggcdKFIzOicuhiPxBxkKI7ch7LSHU/6aHrUBx5H0u+jSVMHrANGygURSWWn+cmkzYU9JqgdJcw9OFh03wZeGK2ONtcMizOKjY5DEKuliap6WEWJf/OJlt5kJhm+9ZZbNh08aK7qD01Ylbt1MZZwL966dTGtRRYoDeoMGuRzm1mUH+ir5Vqa2lMhw+/A9tcMXP2CiyONwddsENDZMp7NzgdcZTobQkZcI+1wlZWUTQpm5FJ7NdfA06+kRFkIot+hZvjUEMPcwnXAPNJRmFsiwTb4fzn0qindelRcde241TOX6DoJtqfDoppRU8eXdKusf2rU7Bl7fruG8sMMoMVqKuOLue5cgnubSxYiNSoSVOKr0UQ7oZ8qqSx0AF9ckqD9OF3jycoSRLSyix0EQwF+xpRCjwuUAmbmYsAd8XiqgnFHWTxZEcNvV3QFisUq8DBWAhSrMtSHllUMFIspyWiXSuSOCp9aBFSrxO6c0hqqWDQuUXMR1fJzlMqF/DRjzPRYdW39w6aaGd1rUP3jN9/+S/7NDS29yFSTxZja6VbSidrR5Qu4DuS4foD/StjBZXOlaH9kxjSf0IRGaL4hTbuk1YiXJlJShSyMZS/MkcrNrkk7CJwyzIUDcRp8mfnFlIt8mQrlmWIsRAlSnqnu0VfAAJJHpLGjntVBTOGXtJ2MkagYcN2I2IFBEyZ2z7t17IRHRmLL1lske1yfmrq6mj7jMofMvaJvvufhs8H8iviQrmOuGTrkjeral4TtNfX1NSDU2V6ifUbWWpDlTlBBF3QauVo7jbwx3CecRly0sbFNp1HCj29tu43uenlL4+w2HUfWWv1E83a+suM9HZ3dU+rknhd2NzlR3XfscBq3tXFL2y4nUk4i+onWew6Ce3o45cJ7elvv6YuhEIR7ehWjQd24ZzYWeJXaOqA66uySM3uWLKlvg60lnxTrHz/9dPNu1mfF7o36Mgfk1cKO9841741mtZTQZGtTQ5YckuhUFtXHRgyBsZDDdl0O81T86YlBWo6Ewgn3j09JESdPx9Gofp9myUOVRjBvnt+WeB3Ct8BZwQ5YXXnVmMLa7tXBXiuuGtP1ytrMXj3a4hdZcH+0LDprwf3V1TObdwGSooGjA3D0gqWThb2M7bGU01h6Yzi3xyli2JyGYO3HNbeH5mKxqCjD00RjrW4sKrISmfXWYKFWhg/sJ4U6yERWmN1p4uTDaEfAWuhvPWyLTz0NfciAxKVD8SiNymQaEml+EXhlKj1M47KQ8qcfVuyei3IomHGpMPOOcmMpj+EdwXK5jqcCzDsKUKffiIzQ5Qq4mK2fpaTcHlCvuFgyi+EZfK7lhgF3l1OmsqBNRx9vxnTauk8dN8ErN++66aZdpFtZl4qKLmXd2u2H+ZtmzRpdd/PLxfF4cbR7jDN7Da3YP4MrN5FZySqXaN/45ZFdiLNHwh4wV7oHDMxY93FViadbstwXtoExEzZBWtvA4CWQiOLgTwizWj4nX+kyH21x6d13Ex+5Kd0YZgA9ifVs6cdoL18OdiJgHlvNStC2rYCXJnHD9vI2nX1h2tmXm+7sy/t/6OyzeYgt2rO6pGN/331bnKOq990f+h/9iw5NfqPtE58uuXtblIzhzD4EYTXIHCdQdvRPddPJP9VNhwarnWP+SPuuOpRLbTrrWtY3bm1MU9E6CASgCUsthWXo/x+wdIQBpHEbGPT8rY1b0zBYSpkYbkcT30/TxP9TcAQuThM/FdZtyXLDmSVnQVK3QmWIaaqTGFwOOtslm1v845AhYMh+Iku55PwEmJgHd2N0W/HQBidsNMr0sEYZO5abePw1bDCUr6YjHpwhzIqM93YIUVFGMmuZRDPRYiKN/aM0l7B3D9YeY/mXGNNhLNTNkuhIGBttDqQemw3tXMLSbFSvg7MpgTL3vY8q/NxHRlMfz62Ha3598WuqHGsxTF9TIOakPic6sOu3vLx1//uML4yr8uc/gAt3A96wgkQqMyryJXpNJy3Hd/jp4CfNYQPpyBMLGyMgsJVGt7zb2XtwhcPvm0t77iQDWDh/DK5dTvUTrvBVbFoCnXmBzfs+Fl/3xGlsXaL9kg0WpwQ6mHiwpJEVEtITCou1axJBtKzGVDO6hgANb+ohAMc8Lqdrsej9BH031ufcaQTN+IXJi37nz4oHaD92Pk4ic7frV8t0NqUI57aA8Z6X0Ii9Sc1hloGXVrcosIbZ8aRCpaGSB9LQS0NMXgxrKaymzgGSEBVQCJvbLG4zPKd6a1hjnSMEyFgy00NEEm0biksVf2tLMZrb/eb8GvuKfz1Rf0x/7uWHjvYe+THhzn3Zt8+5c7xH5bl0c3GId+ibpL//7c0/WnVVNfqzNoI9hN7b4gu6AbHQwA2GTyDe4HPnStR7o4nqgrZNgpilzmcGUT5LMbRmsM0GQsTVwRoItUA+FtNm1FysibCzlLbZWOgHY2goGkP30YOewV5tWw1braHCSwpnoiyhfYewN7DvMJsb1mnnYU5nnYe5Rudhg8uSkcWmiPyM5kMB+P+iDYhDQBdcvAmRj1Gx/L8PM+YRLgrzULDiLw4z8Zg2PYN5EIU57yIw53cGc0EbmLN/Pp2ZoLko2IuYfvkRyK2mwjFhj1DYu3EPdgI7zszIBtYvjDcUZJfDPiiBXzLi5kweAyXMaXRjnN9N1grhtyj7LdqKLs7k6YblCmEsmy1UGlzZFppVi/q0kP/n9rgKneyQi9Lirgu2zI+QRWq3gUSDNg5Km3zwtxd2Rh1Y2JKEli0igUzv26AJBqdyPbSUGEVAMRwWt1ID/e/cTJMaEYW2+arFPs0f+rmk4Dso5YuzRFsN/SMUGNheZWMvC7HyJ2kN8ADWPYB9/U4WP7THjRpRHPUneeg5axzjibRAVCO2GqPw2KhR82PJgzF4sPbkyVtOfHoL/Pz0BLnzxMlbP/301pMnbj15ksmB4cYs0RDsqBKsX6C1qbR1KSKwwhOWxM/B3VVKazbYeChaq+H1syk0YTo0DQiqFil7Hf6gxGpHvT7NSfVOBI22IK0sJW6vkEnZ0Wn4+JiZR7qHqxOYjkfag34PhAnNojHHp3T4zo1I9f+zbZK6Y+Pz+l/2/HHbxFgdP/zm1cmvd9/yYPLr+v17ziHB75r2kvbvfUDxuVP5qc/M4RfXfd/y7qjvXn96Lpt7fFocAHIPNg03sLPO0azOOkezjc7RpBzKoP7oj3WPoti4sIO06eWtL3faRWpxMpn8vwIbmu2ddLfOA+u9U+CE/6HC14RtEMCWg1mvC2HL7Qw2rDYSOBbtcigpOZyRlYMr78bM6Y9DakRfLgQ2yQIwnYP7adrEB95mMDtozr6Ym3Uh1Ah0UULLBKFSEDf7rQGFhrCALSTZnrbINETdDjiZ70FZpEU9rBU7PxsYX5Z+iu6+DhKkE7SoNCAZ7K0z5MT8dlKDzQwaAfwicS7sCm3f0eqmrZj2uDlUgja1JnmHi/LIhY2tAobX0s2tPNjrbRtchSsNPmAzDDB2kIX9MOnJICmXj3pLLgc4ThnMcUKJkc3CpAADL8dpvo3a0n4W86E9CxbaKJjho8X31EYLthlkEFRa+wI2vN839wzh6SgDX+91jz+2qrineOiQ+NGbOMvgTbKQn7vw1oUirbeHtS+zrOAS3BIDSjr4JdfWpMZimiixkDeAlgD7MiFrXWn2D2x+W1dY5FK5CWSd5pabGgroiYDcRKPcpQmMcmMVoFtpEMO5MRxEZeuKPBBFLHKR2TNpDNwWyGLhHMUI4nqEQJ7FqDYyeu0rRJR8LKwTVFa//+LOd4qrqopLeg8b1rvk1W1rxved1qf2qsSIiSMSNQNrpo6eMlU49cpfd6/sce2gXtUV3cq796ud0euBvf1eiZWNGVY+omf/PldXdb9+8LXdBoxdNqc5E/YA7Um11HMBLoOLcHcaXak57bpSC1q7Ull7QJZC+9PyWrtSo0Z/WtLhpHmfPGWv5PaHwhnUmsoxylcKfn5rKmxuPmiUsHRsT13WuKdxFm1R7dChapmuH27pPnCZQ6f7uxW3XMDtrp/quC28SMdttEPHLWKWlx9hvQ9qwX/WeouG70Xab0fteXlPpy24/PtmPtvEsRZwzOaKuF8YOOa1w7GwFUfWX5ijmEWVJo7YX5jTZv0KlH10/TKzDTQzsKLSQLPwZ6Nphsgv1mh8JZjIyUWL+nfabyyWkB7621u3Nn9D+45NXAOAaxeukttu4FreDteYiSsuZzCBnNxQklNouI15IMXjlARlQIIymc6pTHuKtNapi5HLkrE4zSBPQ57STTL9Sy2B5nMXxYcUysgpLKcsHiunRRE/b/Gp5Uzax9svRqL6q8Z0nTAsEw3nrhNqM3spF6HVwpXV1TMX3H9p9SyDXqJBrzDQKw+s5kqc7skMt3YUK05TDLRdLKFlgLa7JE2nfIUNdAPSaFmo2mTcDwZdwLhWu2Egq4uHVmR2A6WH1OmSBb6U5HdHWN1l5P+KNGbfpUmQ1lMdSVNXO2MoGNQLGEW+MKoaOxBmj1HU2LwJqSKMSdc4mvSZDvTJAf0f43YZ9MlvR59omj45sVQZC+5XxFIZRnCfzYHPBSYJ5YJRkCplYX7ma5j8k6VE4KOu7KOuMXzmgGxMyu9aqvhelPz4HIV8N6VXNL8TemkVZUDTUGZW0BwLfyHxTCMizUu+9DzRjqR75ZZds2btmsood62RGuhIutmbZs3aNKslQAl33/DKyuGVhsw5bXkMfJFSLs7VcLu5ZD7HMstZ9iZ6nN6TWKgKRFSr4ymhez7QEbek4AKNCgx2GaVcF2CjLjSTTGsiE3Esi+yBaZFgk9YLmSktemNKgzsq0TLfkC8leq2RbnjcQ0kqWflsgrSWk0t9HYzu5ETYAF4kIfgZXpZHBbr1rDbpRjtDc0mEGmNYIlpKPVnWxldSCiQsZp3oIz55c67V7tEevm/5liMjF7x06PWWB5yTFtS+cN9dh4/fc/+LQxdc2/MPEwbeNyFqnXnT3byT7BNmTL968bmVq0sKN41Qhy9devq1WXWzu09sGHvPPZH+s2p795s6ZvzA39929yLDv9OP0VkFOSDF24woyE2PKKApizYJigtHEhgJigrSfjDBlNnOkdX7HvDvfLv9dIIq18SnS+7Zlvdvuqa09x90pQ88vVy0A9p3/2dLTakw6/4Pu9h0CqP7P0y7/zOM6hmsYLVjw7wfhzzuFVxKgHY1q1bfRcYAZId/ZAwAzSR3Ngpg8Mt7Xt7e6TgAywz9sM6xkQDt8MoEvGb/1FSDvItMNcg3phogRlnZuRQjJemhJcj/T6MNUO9fZLzB8j2NezoZcUCeZFrfxKmW4lSAczrb45QHOGUxnLIQp0gapyyKU7aBU2GbtcpW9tG1CmeyxQLUQp2ilpf1I6j5jYR4Zyt2L1P1N3e6aGIXpup1G1s40cAxTGdyR9lk6vZYRgDLXIZlLggU8CPKE1oIdFcJC4kZKOfGG/x2bBzKYLkWDEqUeajut6LmygOZkxej9EARRAutHRilaHApAtNfElaDUeQjuT+CfKvmYviT9IkOlJjPFJW53ERhv3egiGooqhYNSMJnpdUWx5//nPbe17fPtZA2+Rt3p/kbwcjfZL68p9F5BIfS/HCKTjEwZgTwnHHNMtNvM69p9PTbDW89KVpsNUZmKkEdw9VHDgDT4sVaay3582/Aj3zg03b5G9Imf+P+ifxNL8YzgSNigPHHD6cZwML5N+HaubQnAicvXNV+6gPVMiKbJJCBz8DA5pkGC/XPOQ8bi+RpavDQE+YQBgdNAwBiNAmiySEGTbtBEK2/1TDb4/UjsQ5NFD+sp2TYmF4w1r9/1jIHPKwi7u/GhNEck48LwePEXk+wL5SYJlvwYQPUTgcGzsTZumy0W4ANAcF2WuW3ry0zemNVpQKZWsr7HuOcct73jcpHrz0AHzpx1oRNUvzl8HmDwy77yxu8+BPP+/B8Ek4WPFDwQNTqUXw1sMWT8Od45KvhGmwOrw97ZsmLNsnu8MqKr00XLQFyscl9+UqDYHGzOSSFObCIHAmgHhYU2vTdU8bW+JJSSxXo0kQoXB20+RRs5hfazRwgb64aVTlXf+7b+Q/oM8afWfOd3vze270em8umD/yDbCbcpJtXTF85dOGN9RMHrigD+d54Sv+afLhy69aVq7ZuS8+42AG+gQekxS8vnMyAitSbQN+vIRLGJJLPimOL6fMe0gMb1Ch6A17mAHhjZuS8dZKDmol/wB4YhQ+D0DKj2Hrkc7Lqv4uNdhA6qa9Jj3u4tWNlTbv5D2Jg4UqMglPD3pT9X8E+ddK8zNBOp0HkdDYNIteYt9BgF4y8zM8YCIFbsfOhEDbwwTsdDCFYYPv/b8NJtWmncG5FJ7ozOMm7hqAyYa2lNQh5GLWisIZMWHPs6bwRTgsyHv2AsGLeyM/KDTAuYHd7ZJ/AFChsKDZlsRPI017xRSZv7GBi78FOB3AIBUwUtmjpSRytOAQAh3yunFtu4BA1cSgDIzwTn3Kk+WEL5PozJVr8TyuuulLUCkBCugq4tJuLg9dLGJ4NIWuJ1JpQjRkT2Gn3VjCfdsUImVHWsVUW7RTlzl3ei+C/u4PLe+NFCNHq8rYlhmjQIgy0CHIRoMZsgxqZJjXygRqBmFrGSjaK0jQIIQ1CHEvqox+SYxCg1IpFm4Ue2p1aCgqDNq4plEsz8yni+ZkXQzzt0Lai28Y2aIv4LqZUCtP49jV82nZ47zQtg6sNpPnRprLBWugdwiRRgiOczlbBYWG5TTTb9NMziTJpUYYnrjk8aOpiSZrRe2Uxav0LS5R01X9JvSDp4pDK+NDa64fg29B45RBe2rSpqXLIkOtrh/Lb8X3oELhrzfnTogR+jJ8+QW0ui6lj9RhYpWw6kj3BxscX0VxRQG7CkjjMy7ll+oQdLYDJCuLDzjc1ojTI1rCRE8DRE9QozZPRqvHRaFyDWwhFDQ9DctIGeswXcel0EddZtqhm6S1A+PW/6P/EstkgLTbd2W9gKVncf8L8J+7sc81dT5Q71i75LdC8vnbdvS8f1b8bPZi8N20YUbs9p99R/uwD17G5SnSuB8g47OUY3tlkD39nkz0CZs7Di6VnDS7AhTLQxYZ8oAxuHfSxFOVuu2Ef4hHD3voP4MFJIw0ur4yQqA5FVX4EHkwRtRk8koECth1AwjoqWU14agEe2jt2ITyhzuAJt6NPCujjD1KwsFjv4mAZQrUVsnFMinaA7SEmPanMZPCF6VzgQpx4d0E/UDimFiQ0n4i1NOYDDxBcL7oOAU9buFWHrObh6UwPilotz8O61TMD6cnRF13hTnp0W/GY0r5bt8PiBy/o3eXZTBHgAxvVBu2mipgDSy6YKkLTO+nJIlZqzZvTRcRBaZueWw3XxtmPmN+5yqCYz5z9mEFnPtGxGtlm+Xu7vA7OfEvnddgASB8rH8dHQrQOgPS3GwDZbvZTegTkP5tu6DdwwuqdmxbOGqmvsX7KZkCe0pvZAKitjy99otyoL6f0CAM9FJBKE9tSBEsbjeLjAKvck9LFx2iRhI2yPLeEMslmpT0timbh4T3MBnpdSMpOlrOVtG8ay3gdk/VtqPzGBUuJM7c5zhoRDwHkWTixic7cdgl0wggtb7UJGIJJSU4vtl5LjiZziIUv0KT6WJ0XTpC3xZMu+pRZl9WOfTxwgL0sOXTCoTGDU6JV1TZmw9K26jYluoVFfhxBooAQrXue5KnCyJYvaKVucfMOVf+04kzDjBkNZ8ivyQySsd4oPXycHDn4P8K4L5h9Yp0IegGtkzj2k+eiXggn0ERRfXFW0gCqAQ2V7vFUV08uevZdMX6RMO0T0yTxBrFTBXmqG3vaJo0XlmD3SC4+QMqraNYseO/mS9p9dDKEC3ZrELktCh68FsQPPQpOSuwKPktBCdb+CmXp0BqHUy3oI3HaefglpZhwbGd3WoxQB+iS2xv79tpzYxs/f/5v+/d76fa2tij/genyoz6fMHr0hLS7P37UyCtbbdM4RkEEI3/r4CT6RJZb2mdwkXOBfC4R9TdV6GxAcYPHasPxhh463tADbq6Pngh52OxVG/biuryAsY9NitBC2Jnjz+g87duxtKU1Bfy7tgnpdrng1e3y0IT7QAwI3WgcoJx2vgmJdNsme2iTQGtWOsztNQT6B2fvQTFuRgDweh+KHqEUbF0/N5ijg6cSmg0f4mdz4xgb2vxrzEQwuiLQZrcTbIKjdiuVRH709t01xrDHC4zTD5kN2tvwynqjI2Zam+2fX8m161j/zz47KpbyN7FZxKyjGV9t5y3jV4RGcvTJJ9nf2yp/+u+trxt/v1CYR05YSkEO5pp9mg4xHeExynMZPaoTHhJcePc1D424Qpj38F/7X3f0l8YzFeEaa+AaVuMaHZ7/6afP/8Rr9KT9nWUb3l00WZj32lcP/Q3rhMl5/XwumU6fH/rj37ex7/P4/c/Mr6NNIcwTKikOXq435SYpYSCiOuNmqTpWMNuY246lBVgqL9nYtEivooo1bZBMtEN22aLJa1pRTiPOI978SYq3x7ivLWEAT4tRvSb8ZkWI08+GuNFHodqoVeWpaSVMwmiApQT63Ygr3kuTCe5IseWRVvw+Sqv/8J629vfkW+/5Wbtb0h7hfnwZfxpkDvgONpNH0qxiNx+yhifZG97ZHDSCqm7x3cl77knezQcm3bMkeffd1M46a9lEJBoLiKIlSL2xYCSRMHqPNW92PE7PppuRi8znu3vZmHCME/o8VKVhiWMea08uZi2zbbrgii9yvBBb4LAVjreOvrTvuHF9q+t4cfSl/cZfCUcLjQeV1Vw2tr7XZWPqa9jD7uqBHlO4eXyU9u1egtMwjFEYxjNfUiKjAJqAIn3UnJB+/rw5FcOch9HuWuUm77deC2v3OlwO9HC6IXhK+yZg9oxXsF8/Eo9xZdy1XLLELMmjA9oUoSnFkRKXu1zNTmicCwPhKclGT4QSmuSi9dTeEpfEnoouHtcyjWedZ2LI2E4fm8Zh5jbKar9xUFK0KtEz3Rdji9gi1mAgDG9pFVlUWjyP5+etKCe+N7fcffvzczYVkikZ+g5BIAMz9KbCrXduX7x01x/0M3DXRb7oJb5F73417tTi+3+xKDuSm7Fo8erFJyd+8z6tfedXWSrp8yECnM6mVzTYHS53UZihI6Qfegz2zF4Jn3IXKArDpghio6rx2ObOHx6BQ3JAMmBDViZryML+eg/TDSHj8Tpl/9pNY6ySrNoPeuCPVP/BxtcOnpnDRhb6KrSAX4JzHs2Z/71FdRxs7DP/bCn9iqtCcxiP3pEL4DPlYOPBD/71Oh1ZqMgS2C2qfNCC8UY3jix0yn42shCnFbrBG/R3HFlYFaEzpgmdXejHwYVO0o/8z56HyLgp2xfcuWPyqgG333VXH3HIokX6QPKqPpC/VJ9LHmz5A5mnr8YXPtcYDOE1whrUO5VKRMHj5jlsZrawy7ICduZs9owRVUkYY7OF9mOz/SyYHqLtBUE2NjsURKKGkKhBZjAr5mhXHBOHD7rGPhY7rX/7iUHaEfrEKRyl/dbmdROn3zl2Gl99WH8Up2kva3i936Ha669d2gxCmA7UpjLZhB1rlxaw3L0a7Ai9h0EvxxtCTityO1hKfoqDj86k7aShHdHxMYclw5hYH/QhOu3QCHWChjkOHJsIch/avnpk7661i44ePQyYABrJzTvz9+dv2EVngrfks5HIbA0snwEeXbhfcclSWr9TmEgkM3hW46w66XNWDYQ0T06CoqQVFMVhScpiailFp4ShU0r7t0sRhxJWq+GNa4Vu9GBx+BLmEvIAqUvgPVpiIKXlFxomII61CVFLOaMUxUCITXCXgjUXohrpdPnYEm5fPbZv5bDF5LZ3Nq+ZPH0erGXNW/paYznXb36u4KXokw8vS77RflmNWekmPYpBsj3PnoGp5Zd0pAjKsVaiZBtEyY0gUUCiFVGiRBlRiqJIlCIkSpTVPQFR8nHKejyZT6cz5ufaaecI+hdlbiYJC6ImfUqwnsDP6FJkcjGlCrbVlnb5ceqYXBFpwxkGebavHtE/RlkESCPOfqsNdTpwi8kx/x+02V5+AHjaY2BkYGAAYnV/7gfx/DZfGeQ5GEDgbJ7FYxj9v/1fNbshWyVQHQcDE0gUADBoC5cAAAB42mNgZGBge/4vmIGBg+F/+/9D7IYMQBEU8AIAlAAGsHjabZNBaBNBGIXfzv/vGkIppQRFJVRTKs2hSAmlFC3BkJSoPYQcgkgJ4iEHodUcPERaIUgpEkSKqMmhikgRoXjwEIpIEEQEEZTWUjxJTlLUg4jXxjcbA6H08PFmdubfmXlvxvxEMgDA4iwC5gjKZh1FncCk3MBJ9w7iWsMp5zmKZgfLJGR+cWwNWRNEn9nGLLUkc4CmkDEVDLEuJClENY5ROYtB+YKkFHBI3iDO9pid79c2EOO3GWpWehD1RnBBPyCo/ajqNWT0L6ryg9xkfx0ZN4WqAfseBjVPLaPqXUTCjaHKfWbkW1t1lGO3kdBeDOhXlPUFgt4i21f47xyC8hsTpo4G93ycWuB+o/ISBYUzLQ8xreOoyDzSOoa0fEbaXEZYh9k/gYrTRNFptpZkx29XvAgq9jtr0lx3SWOc32D9MeSofWq9eYWgm+e6j9ErDWoeCXqYNXG8pebkFq52vOdepuQJpvQZrusIBuwcep1UYMu9T6/q9PQj8tZ3eYos93zYzNDHNY5FmE2A5+Q57Lo8f8z0Y4H9pFPDUZls17oryLp18odn70HM93wfvNdU5uBn0AUzCJAHBq1NsuX2It7JYC9C39wazvk5dGNzYF56iV7R8/1wm9T5dgbd0P/v1nvqO/Le976TwR7sPdUzmPD96MLm4OdM9crIeKuczz3R502yLacBrwR01AzzfTwioTb4RD1PneGYfQP/0XuYPbCCWWcDJRJ1Nlq7EuF6Ed6xSGvXrGLBC3GMtabMHIn9rx7EkLvM93GX7XHeN+LNIYzwP16QwuAAAHjaY2Bg0IHCHIZZjHVMXEwrmI2YA5jLmOcwf2OxYIlhqWJZwbKPlYfVirWP9QebHdsitj/sCuxrONg4XDjqOBZxHOF4wRnC+YVLjWsa1wNuA+4c7kU8LDw2PFE8XTxbeG7xxvBO433GZ8Y3ie8dfwx/D/8F/i8CJQLLBK4JsggaCXoIVgkuENwheE3ISqhP6JKwmnCb8BURJ5EmkQOiQqI2ohGiO0Q/idmJTRB7Ii4h3iB+SYJHwkBig8QDSTZJI8kZkpukJKTigHCa1A/pOOlLMiYyETKfZHVkj8hpyAXJFcjzyRvI18ifUhBTqFCYoXBDUUzRSTFLsU/xihKDUpMyh/IeFQ2VJJU5KrdUfVQ3qWmp1ahdU5dRT1BfoyGl4aKRpzFH451mkuYlLR2tNq0n2kXaX3QMdFbofNN10Z2nx6fnoTdHX0G/z4DBoMyQz3CekZXRE2MV4wnGv0xyTH6Zqpj6mdaYXjJrMfth7mO+yILFosuSw9LDcp8Vm5Wf1TxrLmsL60nWH2xCbN7ZBtlW2e7BAU/Z3rB9ZvvPTszOwi7CrsJui907ew37IPsNQHjN/p/9P4ccRxFHBcc6x0dOWU6/AJ+zknYAAAAAAQAAAOkAPAAFAAAAAAACAAEAAgAWAAABAAFcAAAAAHja3VnvjttEEJ+7lj89SgVC6ocinSyEEFS5P+ldkWglRFV6ErRIVWmp+IYdO4l1uYuJnUvDIyCegIfhc+EBeAiE+MQDMPubWXvXdtJrKRcJRUnG3tnZmd/MjnfGRPQO/UHnaO38BSKa8FfoNbrCV0Kv0yX6SelztEs/K32ertJvSr9Cl+lvpV+lK2sbSr9G99beV/p1vp8pfYE+XftR6Q2arD1V+g36YP2G0hfp6vp3Sr/57l/rlv8SHWw+Ufoturj5i9JvM231eUqXN39X+lfa3fyTbtOYMpqzVSkNaEgFBfQh9egj/r/GVu3SJ0xFzBHQXXDlTH3Ns2aU8HWOsW2+d4tG/AkcSTmuEv43nCf8GzPnXQr5KmIJxzz+Fe6mNKUjesD0gKkROLrMu4vPTZ5zj75g3pve7C1v9mK5QU3yN6p5qryy0mklCwIhfwu+GzJXwjyG45Dvjam/FKkXGdnhsRGPGUse8nXGYwEdMNeUNYqZb74CP5qRgte8wfrtsBTz2eZRM3vAVI9lHy3gOlR7hGubrfjBsfEOrAroka4YsPdT5kz4fg7bb/EKRiODvLlrrN3h70mLZ/eow9SX8P7cQWODsRwqDtanx/htyo6YKoBUAp45sO8gBobQKOPrCes45PmidUclxkDc2htwHMsqPViUsYSU7wwcWQXmH0Eniaei1LSpXafUR6Qe8l3j1RH8NIBEiRPBplCt7KpWx4xHjcdSxbjgq0C9mCl2Mx41ugT4zz1dxba+o00MCUabomZxm60d6GC0DlUDf36lSYJZi7G3O9NEi1m10HjYZp9v0GPwFR5qkxY5Fp++4hI4EZqq7bL+qBadgty0tMLsoxS4jzAqO7gP3QxHDi+b+LKabPF3CGQMGn1FKaD3mB7D6znTwjfWeAogbYJ1Utw7RvaKdK5EkkVxqjJzx6upE9syY8KaGxxT3p9hiePNFuysl9oxtEj1WrKUoGU5YuQZM3rsRX8CT1jbO9iTUy+S/Hzl+6ApQWLBj9flcdBteNrdeeYJMF+6ouspw/0EsSTPJ7Fz/yX653ksu9awLH/ptnU5567Gur0zsO4aXV+RdftnYN31lfnu+hlF5qrsk11xFv7bXVlu+b9buHcmFnZZ4iqt3D8jP3a05ltVvnmZVh7ryVtOjSnsiP/Dc5k5gX+revZ0/ebZ2FSsMSTLLDmV1m0O9IxspMxhZ4qKowO9huA2dcBAT9ruefrFTmQVbm36NfGR+iovz56CbYg63dSBcsL7tuY383+oOAguKXNXa2R8ndQqr7qefXjA98jMQTvja0HR9YjVwJ6UY1QRBVCK1K729QQ5UzOMtf4JILNA5MZ63T91jNxyTuLL7LQaR1ql2GpYUM+AYFFKCDE7Vf3MLnNrObEh1Doz0d8ckiLobHilpk5VXoTKaKTYjBS9BHGao7abaM/i4TO1T3THxcArxipSYRRaaUm92cPeTJw6I+c7Euti931gW0A/sfXz2jzpzUyggfRh7jPPAXoxEjkH6ETlkGoxy8FptOrB5qpCzzmHHdADnt/RatHs13FZv+cL/Gdz3SLbXcsCVJ9zlRQ6ldXcySY2di2mT7TS7un+W+SLRfPb9XoMlOISrftll8pQqWLc9Jbs+GWx4K8vuSj2+ho235n1IkdKoFE70qq98nWBiBxCtvHKoMwgbp6U7spJuV8lrxsrt8qdNHe6JLmz8+u+dWOmLUJv83Vfs6kg+Fk5d6vsOyzKj2NEXr+MhRfPfm1VelsHYKId1BRPH9cbtuPidtpO+/Ts6XNgoj6OPIvqPZu6DpbPZBn73LOdslA7pMv6dHfoEd1DpnUl2wgXDMULi58QYpV05KqeZuhFT+BFj8TLs31oER6rd/qQloMeqK42+2Rqpa9F1RVr69yIb8zIBGsMPG8uszlHph+VkTvA81me17NGjKbqW7/vu+zpbXuACTpsocqOMS45SWTNy5PXQLNBlcXs83gCPabaxbO7ofnktloMNeYTRdrG0xF2TIGMlPEONbO2eCQszwQ2w6TQYQScbB83RBzkXoTOynm5t/tc3SR7yw4QjOUJm6qNdp+EjpzFONc1NLK2nJ5tWp4SQ77OdP9V55LF/WOjp8RgCm17Gg2SpyUO+pBmOvyFk31tFml6plNiNEMmHYEa6zucamZ1oh2X70BMlj/xdGjzj+yWqeriY+pGo9gsvqv6vLNafFrdJNr/nTadlmooB26CQ7UTxTu5s8+amNZ7123IRlpxVedB34q+vp9wnylHuiPnjYojBy6uZDenS51l49JKk/iLoFGqubLyie3mL3tnkNRqnfYaR1a1NY6vQzMvWC+IJgO+GgOFPjKwWcHd0wap79WHhXdOq7wZl28N6rnn+d4p1WdH5ar1OsNH1dV3sVUG09O/F9zxntWSkbd55pC/7ptZ943tY5zeqvOSvOF9CPTMu+EQunfxTrTLnxu0Tx/jd197Vl3a+wesZKoNAAAAeNpt0DdsU3EQx/HvJY6dOL33hN7Le892Ct0mNr33TiBxgZAEBwOhIxI6CITEBqJMgOhVIGAARG+iCBiY6WIAVnB4fzZ+y0d30p1ORwx/8zuAn//lI0iMxBKLhTis2IgnATuJJJFMCqmkkU4GmWSRTQ655JFPAYUUUUwJpbSjPR3oSCc604WudKM7PehJL3rTh75o6Bg4cOKijHIqqKQf/RnAQAYxmCG48TCUKrz4GMZwRjCSUYxmDGMZx3gmMJFJTGYKU5nGdGYwk1nMZg5zmcd8qsXCUVpo5Tr7+cBmdrODAxyTOLbzjk3sE6vY2CXxbOUW7yWBgxznJz/4xRFOcp+7nGIBC9lDDQ+p5R4PeMojHvMk+iM/L3jGc04T4Dt7ec1LXhHkM1/ZxiJCLGYJddRziAaW0kiYJiIsYzkr+MRKVtHMatayhiscZj3r2MBGvvCNq5zhLNd4w1uxS6IkSbKkSKqkSbpkSKZkSbbkSC7nOM8lLnObC1zkDls4IXnc4KbkSwE7pVCKpFhKpNQaqGtuDOq2SH1I07QqU7emVLXHUDqULmVlm0Z0UKkrDaVD6VS6lGXKcmWF8t8+t6mu9uq63R8KRMK1NdVNQbNl+ExdPos3Em5oK7zqDp/HvCOqoXQonX8Alm6eIwAAeNo9zakOwkAYBOAuvVt6LwJBKOESKzEk2LaCGkC1Cc+BxiAhPMpfFOHlYALLuvkmk8yTvS/ErlpNzq7pGLu1XWWJZkJxWxM/IJzbEVni2Gik5yXpoiAjLx/6sCe+MAHjDwswCwkbsFYSDmDPJVzAmUl4gDuV8AEvl+gD/uIHRoF8D9EGOOz06gRGYDhWjPPypUVsrakmwSC+K6ZgslfMwHSjyMFsqTgA+fbPlrj4AOD4U60AAAFRSIhkAAA=) format('woff'), /*savepage-url=/acssicss/fonts/karbon/karbon-medium-webfont.ttf*/ url() format('truetype');
  font-style: normal;
}
@font-face {
  font-family: 'Karbon-Semibold';
  src: /*savepage-url=/acssicss/fonts/karbon/karbon-semibold-webfont.eot*/ url();
  src: /*savepage-url=/acssicss/fonts/Karbon/karbon-semibold-webfont.eot?#iefix*/ url() format('embedded-opentype'), /*savepage-url=/acssicss/fonts/karbon/karbon-semibold-webfont.woff*/ url() format('woff'), /*savepage-url=/acssicss/fonts/karbon/karbon-semibold-webfont.ttf*/ url() format('truetype');
  font-style: normal;
}
.pageWidth{
    max-width: 768px;
}
.headerProps{    
    background-color: #ff6e28;       
}
.headerPropsNexi{    
    background-color: #2d32aa;       
}

.headerPropsCreval{    
    background-color: #ffffff;       
}

.headerPropsWidiba{    
    background-color: #ffffff;       
}

.imgHeaderServicingPages{
    max-width: 253px;
    margin: 10px 0px 10px 0px ;   
}
.imgHeaderSI{
    max-width: 164px;
    margin: 10px 0px 10px -19px ;   
}
.imgHeaderVdf{
    max-width: 164px;
    margin: 10px 0px 10px 0px ;   
}
.imgHeaderCreval{
    max-width: 164px;
    margin: 10px 0px 10px 15px ;   
}
.imgHeaderBps{
    max-width: 164px;
    margin: 10px 0px 10px 0px ;   
}
.imgHeaderWidiba{
    max-width: 164px;
    margin: 10px 0px 10px 0px ;   
}
.imgHeaderDb{
    max-width: 164px;
    margin: 10px 0px 10px 0px ;   
}
.imgHeaderBper{
    max-width: 164px;
    margin: 10px 0px 10px 0px ;   
}

.borderHeader{
    border-left: 2px;
    border-top: 2px;
    border-right: 2px;
    border-bottom: 0px;
    border-color: #efefef;
    border-style: solid;
}
.rowProps{
    margin: 0px; 
    padding-top: 20px;
    padding-bottom: 20px;   
}
.rowDataProps{
    margin: 0px;
}
.spaziaturaData{
    padding: 16px 0px;
    margin:0px;
}
.fontProtezione{
    font-family: Arial;
    color: #646464;
    font-size: 13px;       
}
.fontProtezioneNexi{
    font-family: Karbon-Medium;
    color: #646464;
    font-size: 13px;       
}
.row-eq-height {
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display:         flex;
}
.center{
    margin: auto;
}
@media(max-width: 768px) {
    .centerXS{
        text-align: center;
    }
    .full{
        width: 100%;
        height: 100%;
    }
    .noVerticalPad{ 
        padding-top: 0px;
        padding-bottom: 0px;
    }
    .noPadXS{
        padding: 0px !important;
    }
    .btn-lightGray{
       background-color: #f0f0f0 !important;
       border-color: #f0f0f0 !important;
    }
    .lightGray{
        background-color: #f0f0f0;
    }
    .noPadLabel{
        padding-left: 0px !important;
    }
    .whiteXS{
        background-color: #fff !important;
    }
    .inputSize{
        width: 70%;
        height: 28px;
    }
    .vAlign{
        padding: 5px 14px !important;    
    }
    .vAlignNoFlex{
        padding: 5px 14px !important; 
    }
    .fontProtezione{
        font-size: 12px !important;       
    }
    .fontDatiLabel{
        font-size: 14px !important;
    }
    .fontLabel{
        font-size: 13px !important;
    }
    .fontImporto{
        font-size: 23px !important;
    }
    .fontVerificaWL{
        font-size: 11px !important;
    }
    .fontCodice{
        font-size: 13px !important;
    }
    .fontAttenzione{
        font-size: 12px !important;
    }
    .imgHeaderSI {
        max-width: 164px;
        margin: 5px 0px 5px -24px;
    }
    .mTop{
        margin-top: 5px !important;
    }
}
.separator{
    margin-top: 7px;
}
.spaceAlert{
    padding-left: 8px !important;
}
.noTopPad{
    padding-top: 0px !important; 
}
.mTop{
    margin-top: 10px;
}
.vAlign{
    padding: 16px 18px; 
    display: flex;
    align-items: center;    
}
.vAlignNoFlex{
    padding: 16px 18px; 
    /* display: flex; */
    align-items: center;
    margin: 0px; 
}
.padLabel{
    padding-right: 0px;
    padding-left: 18px;
}
.padData{
    padding-right: 18px;
    padding-left: 8px;
}
.fontDatiLabel{
    font-family: Arial;
    color: #505050;
    font-size: 15px;
}
.fontDatiLabelNexi{
    font-family: Karbon-Medium;
    color: #505050;
    font-size: 15px;
}
.fontLabel{
    font-family: Arial;
    color: #646464;
    font-size: 14px;
}
.fontLabelNexi{
    font-family: Karbon-Medium;
    color: #646464;
    font-size: 14px;
}
.fontImporto{
    font-family: Arial;
    color: #000000;
    font-weight: bold;
    font-size: 24px;
}
.fontImportoNexi{
    font-family: Karbon-Medium;
    color: #000000;
    font-weight: bold;
    font-size: 24px;
}

.fontVerificaWL{
    font-family: Arial;
    color: #646464;
    font-size: 12px;
}
.fontVerificaWLNexi{
    font-family: Karbon-Medium;
    color: #646464;
    font-size: 12px;
}
.fontCodice{
    font-family: Arial;
    color: #000000;
    font-size: 14px;
    line-height: 16px;
}
.fontCodiceNexi{
    font-family: Karbon-Medium;
    color: #000000;
    font-size: 14px;
    line-height: 16px;
}
.fontAttenzione{
    font-family: Arial;
    color: #f00;
    font-size: 13px;
}
.fontAttenzioneNexi{
    font-family: Karbon-Medium;
    color: #f00;
    font-size: 13px;
}
.noPad{
    padding: 0px;
}
.grey{
    background-color: #efefef;
}
.white{
    background-color: #ffffff;
}
.darkGrey{
    background-color: #e1e1e1;
}
.bordoSection{
    padding: 0px 2px 2px 2px;
}
.inputStyle{
    border: 2px solid #b3b3b3;
    border-radius: 2px;
    text-align: center; 
}
.btn-orange{
  color: #fff;
  background-color: #ff6e28;
  border-color: #ff6e28;
  border-style: hidden;
  font-family: Arial;
  font-size: 16px;
  padding: 5px 16px;
}
.btn-red{
  color: #fff;
  background-color: #e1001a;
  border-color: #e1001a;
  border-style: hidden;
  font-family: Arial;
  font-size: 16px;
  padding: 5px 16px;  
}
.btn-white{
  color: #646464;
  background-color: #fff;
  border-color: #fff;
  border-style: hidden;
  font-family: Arial;
  font-size: 14px;  
}
.btn-white-nexi{
  color: #646464;
  background-color: #fff;
  border-color: #fff;
  border-style: hidden;
  font-family: Karbon-Medium;
  font-size: 14px;  
}
.btn-mps{
  color: #fff;
  background-color: #a12037;
  border-color: #a12037;
  border-style: hidden;
  font-family: Arial;
  font-size: 16px;
  padding: 5px 16px;
}
.btn-passadore{
  color: #fff;
  background-color: #882345;
  border-color: #882345;
  border-style: hidden;
  font-family: Arial;
  font-size: 16px;
  padding: 5px 16px;
}

.btn-cariparma{
  color: #fff;
  background-color: #999999;
  border-color: #999999;
  border-style: hidden;
  font-family: Arial;
  font-size: 16px;
  padding: 5px 16px;
}
.btn-nexi{
  color: #fff;
  background-color: #2d32aa;
  border-color: #2d32aa;
  border-style: hidden;
  font-family: Karbon-Medium;
  font-size: 16px;
  padding: 5px 16px;
}
.btn-creval{
  color: #fff;
  background-color: #f58800;
  border-color: #f58800;
  border-style: hidden;
  font-family: Arial;
  font-size: 16px;
  padding: 5px 16px;
}
.btn-bps{
  color: #fff;
  background-color: #003b5c;
  border-color: #003b5c;
  border-style: hidden;
  font-family: Arial;
  font-size: 16px;
  padding: 5px 16px;
}
.btn-widiba{
  color: #fff;
  background-color: #44b15c;
  border-color: #44b15c;
  border-style: hidden;
  font-family: Arial;
  font-size: 16px;
  padding: 5px 16px;
}
.btn-bper{
  color: #fff;
  background-color: #e37222;
  border-color: #e37222;
  border-style: hidden;
  font-family: Arial;
  font-size: 16px;
  padding: 5px 16px;
}
.btn-db{
  color: #fff;
  background-color: #0018a8;
  border-color: #0018a8;
  border-style: hidden;
  font-family: Arial;
  font-size: 16px;
  padding: 5px 16px;
}
.btn-bpm{
  color: #fff;
  background-color: #00755C;
  border-color: #00755C;
  border-style: hidden;
  font-family: Arial;
  font-size: 16px;
  padding: 5px 16px;
}

.lightGrayChiudi{
  color: #646464;
  background-color: #f0f0f0;
       border-color: #f0f0f0;
  border-style: hidden;
  font-family: Arial;
  font-size: 14px;
}
.lightGrayChiudiNexi{
  color: #646464;
  background-color: #f0f0f0;
       border-color: #f0f0f0;
  border-style: hidden;
  font-family: Karbon-Medium;
  font-size: 14px;
}
.heightBodyAttesa {
    min-height: 320px;
}
.lineFooter{
    height: 25px;
    margin-left: -15px;
    margin-right: -15px;
}
.lineOrangeFooter{
    height: 5px;
    margin-left: -15px;
    margin-right: -15px;
    margin-top:5px;
    background-color: #ff6e28;
}
.lineNexiFooter{
    height: 5px;
    margin-left: -15px;
    margin-right: -15px;
    margin-top:5px;
    background-color: #2d32aa;
}

.lineRedFooter{
    height: 5px;
    margin-left: -15px;
    margin-right: -15px;
    margin-top:5px;
    background-color: #e1001a;
}
.lineMpsFooter{
    height: 5px;
    margin-left: -15px;
    margin-right: -15px;
    margin-top:5px;
    background-color: #a12037;
}
.linePassadoreFooter{
    height: 5px;
    margin-left: -15px;
    margin-right: -15px;
    margin-top:5px;
    background-color: #882345;
}
.lineCrParmaFooter{
    height: 5px;
    margin-left: -15px;
    margin-right: -15px;
    margin-top:5px;
    background-color: #999999;
}
.lineCrevalFooter{
    height: 5px;
    margin-left: -15px;
    margin-right: -15px;
    margin-top:5px;
    background-color: #f58800;
}
.lineBpsFooter{
    height: 5px;
    margin-left: -15px;
    margin-right: -15px;
    margin-top:5px;
    background-color: #003b5c;
}
.lineWidibaFooter{
    height: 5px;
    margin-left: -15px;
    margin-right: -15px;
    margin-top:5px;
    background-color: #fb3d68;
}
.lineBpmFooter{
    height: 5px;
    margin-left: -15px;
    margin-right: -15px;
    margin-top:5px;
    background-color: #00755C;
}

.nascosto {
	display: none;
}

.noMargin {
	margin: 0px !important;
}

.yapLogo {
	max-height: 80px;
}</style>
  

<style id="savepage-cssvariables">
  :root {
  }
</style>


  </head>
<body>

	
	
<header class="container-fluid pageWidth ">
    <div class="row headerPropsNexi" align="left">     
        <div class="col-sm-12 col-xs-9">
			<img data-savepage-currentsrc="https://3dsecure.cartasi.it/acssiimages/Nexi_Negativo.png" data-savepage-src="/acssiimages/Nexi_Negativo.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAdEAAABxCAYAAACKqJnBAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4gUZDikLq6PsJQAAEx1JREFUeNrtnXmwXVWVh79FmAIJQxBIA2IzpBgMQ4dmapHBCI1QQEAERdNYgEA0yiAGqkHSoWWQCM1cyBgCiqCMMoggpB2QsQWSICCIBDBhTEyIZCCs/mOfWC+P9+49wz7nnnvv76s6laq8e/baZ5+99+/saS1zd4QQQgiRneVUBEIIIYREVAghhJCICiGEEBJRIYQQQiIqhBBCCImoEEIIIREVQgghJKJCCCGERFQIIYSQiAohhBBCIiqEEEJIRIUQQgiJqBBCCCERFUIIISSiQgghhJCICiGEEBJRIYQQQiIqhBBCSESFEEII0ZPl2yWjZqa3JYTA3dVHdOk71khUCCG6pHMV3YFEVAghgRVCIiqEEEJIRIUQIjNaExUSUSGEkFCKNmJ5FYEQoh2F1N0lqkIiWmfcfSCwEjDPzJZ0cTksDwwCVgMGAguBRcAcM/u7aorQqFRIRLtHEIYCmwEbAB9P/l0/udYGVk+u5XrdRyIe84G3kmsm8CowHXgOmGZmc9u4bAYAWwOfArYDNkmu9RrcMweYAUwDngIeBh41sw/UvIQQKfuetv04snbZFp61YN191UQIRgCfBLYAtgTWLLMuAM8AU4AHgPvNbGEbjLb3AQ4BPgcMjpDsPOB+4CfAXWb2fsE87gWskuKnc4C5wCtm9k7NPtx2ipTcB2Z2V6/0RwAb5kxvsZnd3S4dbB1GqVny022j5Txl0+5HkzpGRN19c2B3YIfk2oLWb5yaDdwKXGlmj9assg8DTgD+A1i1RFN/A64CLjGzv+TM62hgcsbb3gD+ANwH3GNmL7TwI+U3yQddDL5lZhf3sjEJODzv+zGzNTpBOMsWsrqJebu/M4loi0XU3TcG9gY+A+wCrFvzR5gCnGlmD7S4om8GnA2MAqps4UuAa4AJZvZ6jnxfABxXwP7vgSuAH5vZogrL+wbgy5GSu8bMjuzDRkeJaBl9UhExK5KfOohoFVOleQVUIlotKwC7AfsD+wIbt2mZ3wOMMbMZFTek1YHxwDdp7Vr4+8AZwHlmtjhD/pcnTBHvXtD+n4HTEzH1ksv8JGBipOQeAXbr6wOgk0S07P4ox7JQLUbBscpTItrdIvpLYM8OmfmYBxxpZj+tqCH9ezIKXK9GZfAMcJiZTc/wHGsDT5B//a8nDwFfLetjJlnHvZc4Swp/BbYzs1n92OoIEa2qL8oiJM3y1FdaddokU4WIZgkIsPS3fcwsLnOfHNCXw4p0DoOBm939v0puQAPc/UzgFzUTUAi7gB939yMydH5vAQcBCyLY3wOY6u4HlFDumwI3RWpfC4FR/Qlop5B3vbHRVWaeGtmImYe2HZ01KZtOKjN5LGot4939nJI6pVWA24D/rPHzDwSudveJ7r5cysb5JHB0JPurAbe7+zcjlvtg4A4g1ujua2b2uJpKuk7a3ZcZ7TQbKeYZXRVdX01zpbk3zf+lSSNL3sr6gKrCjkS0cznZ3Y+LXClXJ0x/79cmZXAScH1yTjVNB3o9cGFE+xe5+7ERyt2A6wlHqWJwfvKsHU2R9bT+0unZIbfjCKeI0JedL0XLkYjWkfPc/VMRR6B3ExwmtBOHAZPTCmkivFMi2r/U3Yt+dIwHYk0P3w+MU9OI1/EXFdKqhbhKscpqq9nvu0lsJaL1YAAwKTlTWKQhDABubEMB7SmkF6Xs0D4Avgi8FrEt/Cg5ApSn7A9MRDQGLwGHdrOrybKEotvXKsugUXl2g5BKROvDpsDxBdOYQDgC1M583d2PT9l43yBsNIrlFWowcFuyrpmlcx5OdmcQ/fEesL+ZzVaTaM2Iq6/fxBLeMjZC9U6jUZr92Sxzk1anj0olovXiZHdfM2dF3Qs4tUPKYaK775yyA3kcODai7S0I08qWstyHALcTHPTH4Mtm9qxGMhrRpRH9qsqumZ00YtupYqooLj3eMfAm4UzeLEKUkrnAhwRHD2sSnNRvSjo/rnlYHRgDnJVRQFcDri0hP3MIa3OPAS8AryflskKS1/WA4cC2BCcIK0eslz9x963SOPQ3s0nuvh0wNpL9UcBpwH83KfcBBP/Am0Sye7qZ3ammWP5otC7CXVdRyZuvNGc8Oy2EXbeK6CLgUYIXmCcIEVieT+MsPuk4tyS4HDwsEZCYHOXuZ2f0pnM6cc+B/hK4BLg3bTQWdx+UlMk3KO5VCIJDhe8nHxVpOJFw9nTXSGUwwd2fNLN7GvzmXOI5ALkF+J4krvMFvK4j+Fh5S+MTt6OENO25pRpcU7wYb7v7D919/yTCS6zy28Pdn/C47J7B/ubuvjiS3enuvkuEMtnJ3R+OlKcdM9hd191fjfgeZieOE/qy9ZWIdp4pUifdfVIB23ParS+K0ZflyUur+tr+7s9jM2beij5zG2pQn1c3rYmeZGbHmNmdZjY/4tfgQ8COwJkR85rlqMX3Is0oXA6MMLPfRiiTRwhBAU4hTIcX4QcZ7MbeaLQGwRnDoF4dw78CV0ay8S5hI9F8upRYR1C6ZQTaTnlrtFbaKeuj2lgUp6IsMbPTkqnMGOyVsvJvmohGUcaZ2ZiYsU/N7EMz+36Sv8UFktrF3ffJYDf2RqNPEo4f2dLRLsETVIz13yXAwXlDxHWi0OTdDdquHXJsV4V1zVsnfyBJRONWusuI40lneOJsvRknUjyc2QQzm1himdxBOM9ZpJc7JaPNScBlER/j88A4d1+RsHa5QaR0T0hmMkQfo9L+jmh0woitLqLZ33Ee7ZiWiLaSUwjhtoqyTZPKP5AQULsIPyecLS374+JWwiahvHza3UdkFSjgdxEf4yxCGLtYjiyu7R1cu4s/PpuKaSM/uLHcBqb5Tbe6vJOrP4lolR3CAuC7EZLaqsnf9wGKbJCaDRxRdkzNHowHXixw/+EZ38Mi4GDCkaVYbWVkpLQeIf2u464V0p4iWaVD9LSj5WZ/j+1Kr84CmqZMJKIiCz8D3imYRjMn5l8smP5pZvZ2hZ3kIpqcu2z2vElg7iw2ZxHWZBfVqG78FTgo5vqziDsKTfvb2LtWq/wAaLSZq0i+spRJp0wZS0TLE4w7CiazfoOKOoBwJjMvrwFXldhQzd03cvcD3P00d7/J3Z8lBAbPyzqEGKBZ38WjwNdrUjUWAgea2Uy1kr471TI71jxpa22wfUfQVSGPReXxK+CIAvcPbfC3bSjmZu6KROhjNKC1CFPPPa/hxHOD15ORBA9KWTvCqxOPRq2eQj3azB5T02guXHVyShAjP7GfqZtmBCSi3ctTBe9v5IGoqEOE63KI5coEv7Jb9xLMf6qwTIusSR6f5L1VEW7+x8wmq1lk62SLCE/MjjpWfqoW0jQ2q8xXJ47sJaLlUXSHbqNziDsUEXczm9FALA3YqA+xHEYI2dZKRrj7YDObl6PxLnL3g4EniesiMQ0PAN9Rkyje6Tbq7KvooNPkp1E++hPjIjuG834A9I7i0t8zpXE+H6NM0r5niWj3NP4F7j6PEF4rDys1+NuwAll7qEdFXToV21Mwh1Ns12+ZLAdsRvB3nOedzHL3zwO/JjjRrwLFBu3gkUxRYatjXuVYQSJaJ+YXENFGI9EiUUP+xd3vo/qp2FhsnldEkwb+iLuPBX5YQV7fAw4ws3fVFISQiIrsRD/GkASMXqtAEru3eZkOK5qAmV2R+L/9Wsl5/YqZTVczEKJz0RGX9mOtLn/+oZHSGUtwelAW4xOXh0IIiaioEYP0/MVJjvgcRAjAHptbKeZYQgghERUlMVAiGofE6UHRKDO9WUA4D6pDgUJ0AVoTbT9W7cJnngdMA6YSnFjETnsR8XbrrgycCxypqpoeOSIQElFRFX/r4Gf7AHg+EculovkM8EoZIzt3H0Jwzxj7w+QId38yCY0nhJCIihrx9w55jlcTkewpmH+M5Y4whYAOAG4CNi7JxAXu/pSZPawqK0R62s1FokRUIlrFyLm3WE41szktzte5wGdLTH8F4BZ3HyGH8+k6TiE0EhVVMAtYQutd8PVmMfDHPsRyRt0K0N1HAydWYGoocKu771bVCFsIIREVjb/YF7v7K5Q3DZmGVwhrlT0F83kzW1z38nP37YErKjS5E3AxcIxqrxASUVEPXqxIRGf3IZbTzGxuOxaauw8lnOFcuWLTR7v7Y2Z2taquEBJR0XqmAntFTG8hYSr2GZadin29UwrM3VcEfgZs0KIsXObu05Ig4UIIiahoIb8Fvl3g/jcIU5pLBfNPZvZBh5fZJbQulijAioT10e3MbJaqsBASUdE6flfw/iHAVXXc9FPSKHQM5TubT8N6wM3uPrId1o9F1Dr4kf/TjuTOQG7/2hAze4sw9ZqXFQhHPOrQuWxQcvq7AhfW6PV9GjhftTibAOW58qaX9b40v0/z9xjPWLR8sjyfkIi2OzcVvP9Qdz+gxZ3jtsB0d78yWbOMnf6GwE+pLgB3Wsa6+1dVhasf/VUhClnFp8iItMjzSCQlohLR4lzr7pu0IvPuvhVwP7AacBQwJdk9Gyv9gcBtwDqRkjyMAsHA++Byd99O1bh6IS1L0KoS6dg2JaQS0a7EzF6i+NromsB97r5uxY1+F8LmqI/1+O+dgSeTc5wxuBoYESmtCWZ2IyHiy5uR0lyJsNFobdXmQu0gmli0o4DWRYgloqJdOS9CGpsAv3H3f66osX4LeDAZgfZmvSQvowvaGAd8KVKWbwcmJJ3sq8AhBEf5MdiQsNFIG/xKFNI6TFuaWZ9X1vuK2hYSUbEsdxCinhRlGPCEu+9donh+wt3vImzyWaHJCG2yu5+fOInPamdv4OxI2Z4OjO4ZQcbM/pe4LgN3ByaqKrfPiDZm2lntFs2nhFQiKpZtEB8CZ0RKbi3g3mSTT7QpRndfw91PB54F9s1w6wnAL5JwZWltDQNujFSvZwP7m9l7fZT7xcB1EV/l8e5+mGp0a8QhhrD0N9Kto2hJSCWiYlluJKwvxuIo4CV3P8fdP16gU9nM3ScCrxGmQ1fJkcxngcfdfXgKe4OTkfkaEcrgQ+ALZvbnBr85lrgbja5KdiuLDhGHMvITY1pa658SUbFsQ3VgLCGySywGAycDf3H3B919nLvv5u6D+mmUy7n7xu4+yt1/4O5TgeeAkyge8Hpj4BF3P7BBp2DAj4AtIj3/t83sV03KfQFho9HbkWwOBG5397W6sR7nObfZDaMyndmsP9rQ0BlC+rS7nwOcWsJH1h7JtbRRv0uY6nwPMMIO23VKrkurAme5+939hBSbAOwXydZ1ZnZBynJ/1d0PIRzViRGa7hPAje7+OTNbopqdXeyyBHTulGnNNBurhEaiojkTKH7kJQ1DCDt6twG2JuyoLftj7C1gn74E1N0PAr4byc5jZAxZZmYPJSPuWOxJvI1RElw9q8pMIipSNoLFwBcIa5CdxFxgXzN7uQ8BHQ5MjmRnFjDKzBbmKPsLgBsiPvN33P1Q1ep8dNPIS9O8ElERV0hnAvskwtMJzE+E7fE+Oo8hwJ0UX3MFWJTYmVkgjaOB/4v47Nek2VAlOltsyz7fqfOjElHx0UaxNNZouwvpu8DIZLq0d+c3ALgZ2CiSrWOKxvk0s/eBA5MRbQxWIWw0WlO1mkwO2Du0XTcUvDzuDSWeElHRfwN5FNiVEDe0HfkTsHMDYZsIjIxk60IzmxSp3GckHzDvRMrbJsCP8zidaGeRyOulJ4+Alim6dRH0ImUqJKLdLKRPAzsAf2izrN8J7GhmL/TTMY0mOGKIwYMUC27e30zAHsDrkZLcm8TtoOhsscsiikIiKqppbDOAfwMub4Psvg8cR1ibnN1PZ7c9cGUkey8THCosKaHcpwLbA1MiJXlqo3Oyor5CWEa+tJFIIiqqFdIFZjYmGdG8XNNsPgBsa2YX9fRT26vjGEoIbbZSBHvzCS793i2x3GcCnwGOT+wVZbK7b6kaXY6oFE2j0eiwWQDttPnTTlyJqGitmN5H8OgzjvpsOnoOONjM9uxv+jbpQFYEbgXWj2R3tJlNq6DM3cwuBDYFLgUWF0huEGGj0eqqzdkFLs0UaJlC2lsIs4pnUdtCIiridCYLzWwiYcPKeFq38ehpYDSwlZndkuL3lxLijcZggpndVnG5zzKzscAGBHeKeSPvDAOuT9wcCrLFCJXQCImoiNWpv21mZxDiWR4O3Ee8GJn9MQ+4FtjVzLY1sxvMrKlNdx9DcIofg3/EBm1Rub9pZuea2ebJh8w3gKuA3wMzSTftu1/yASRaIMqxRr1VjoBFye26XebYVVFK7zyGAKMI63g7Exy/F0oSmAr8GrgbeCiPNyAh8vZRec9UZr2v2Xpo2rzmOeuZxl7RY0Kt6Hvbae1XIir6q8TrAiOSEdNGBOfoHyM4AVgZWI2wtvohwTHCG4RjHS8SYoc+ZWZzVZJCCImoEEIIIT6C1kSFEEIIiagQQgghERVCCCEkokIIIYREVAghhBASUSGEEEIiKoQQQkhEhRBCCImoEEIIIREVQgghhERUCCGEkIgKIYQQElEhhBBCIiqEEEJIRIUQQgghERVCCCEkokIIIYREVAghhJCICiGEEGIZ/h/FTciUXtBtcgAAAABJRU5ErkJggg==" class="img-responsive imgHeaderSI">
        </div>
    </div>
</header>
<div class="section container-fluid pageWidth grey bordoSection">
	
	

    <div class="row rowProps white vAlign">
        <div class="col-xs-9 col-sm-8 fontProtezioneNexi noPad">
			Il Servizio 3D Secure garantisce la sicurezza degli acquisti on-line. 
        </div>
		
				 
		        <div class="col-xs-3 col-sm-4 center noPad">
					
	
		<img data-savepage-currentsrc="https://3dsecure.cartasi.it/acssiimages/Ver-by-VISA.png" data-savepage-src="/acssiimages/Ver-by-VISA.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEEAAABBCAYAAACO98lFAAAABHNCSVQICAgIfAhkiAAAAAFzUkdCAK7OHOkAAAAEZ0FNQQAAsY8L/GEFAAAACXBIWXMAABJ0AAASdAHeZh94AAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAC/JJREFUeF7tWwlYVWUaftnhsm+CiZhajUm5tI3imqOmYGhWY5bpZOioaSruqIlbY4nlo6XjWBqOiqJlzpiVZTqhJQiNueQShjvgFYEL9wJ3gb7vO+cq0SL32swzk+f1OQ/n/uc75//P+3/b+b9fl1oCbnG4qn9vaWgkEDQSCBoJBI0EgkYCQSOB8D9LQlWVRT37z+OGydKESRux5d0clJaaEBDgA52PJ2rpn8Viw6AnH0LqK4NUyevIPpiPPv2WIDjYFyaTGQnx7bBq5TCMHJOGD3Z+DW8vDxQUlaFM/yY8PNzknpqaGkyauhnpm7NQVFAKuNH81NQiINAHXTrfhR3vTxC5ung1dSeWr9gtz7BaaxAdHYp9e2aoVxuOBmeMx45dxNwF27F1Wy7Cw/yk7fLFq8jJnY/777tdftsx4Inl+GzPcfj4eJBMCfJOp6Jli0aIajEJlUSKiwt17OoC/cVlIr//i2/RufMC+AXrhGQ3IoBHxXL8cgaDCVXlq0XWjvMXriK66TiE3xYmciyvJ2Jrre+oEg1Hg80hJqYJMtLHYH7KAJgqzXB3d4NvkK+8QH1s35YDPz8vmt1atCGCmADGxbPF8PJyh43aez7cWtoM5ZXo3GkeIqOCEeDvI5pz+bJB+igqMkBPWtFDla2LlPnbERgWJFrAY+G/bnTk5RWpEg2Hwz5h2LOdYDRWy7mHhzuyc/Ll3I7Xl+2CL5mNC02PwVCJObP7S/s+IsuTNIPbzWarqDgjefa78A/xh6urK8qJkBlT42GtfFtMxVb1NnJz5+HFsT1Fti7WrP0cOp0nbLYaMU2GJ5lZ5v4fT8qN4DAJUU1CRGXZhj083ZCV/Z16RcHiJR/C19eLZrtGZmjggPulPXPfKXh6usu5udqKrl0UEg4dOkftil+oqrIi8flucm7Hfe2boU/ve9VfCt5cuZsIUDQtPMwfrVo1FiL4OT+lmTeCU9Ghb582qKYXcSfbzTtVqLYCX/37LApJhfnlTaQtE8f3Vq8An2cqJLALstKA74mJkvZGjQJkNhmhob5ofucUZGzNlt8/h4V/2SHmxqbz/PAuiO3QUrTLkzSTyXYUTpEQ37cNqqototpu9GInVSIWLf4AgeTN+UXLS0yYMytB2hn79jMJ7MWJgHsVAhivvPwkSvWlMqtsEgEB3nhm2N8Q3XIyjp+4pEpdxxdf5qFIbxDnWV5mwp8Tu5O23C4kuLu74tSpAlWy4XCKhH4U8tjLMzzJGeV+dUbOt2Rkw8fbgwiyom+/duIzGBxeKyqqiDRXVJtt6Nbld9LOuPOOCOz6NBmF5O3Z1zCxjcIDJE9offdUbN7yQ63gCBUUqBMy7yZn7UOm2eGhFqKZfK87Tcqhr8+p0g2DUySEhfqR6vqLGntQp8e+uYSNmw5A5+ctAymjl055aYAqDezNPAFvIocu/cAp2tHrDzGwWdciPq4tCi6UKM8lchtHh+OpPy6TexiVFDF2fXhYIozRaEbytH7SzvkBawFrIJscO2FH4BQJjPg49gsW0YTDR85LVGA75Rlq3DgIDz3QXJUkp5hJkYEGx+B7utYjgcGmsCFtJIoKl0nMZyKYUG9/HWnDQZGZu+Af8KcETMyQzIGjz9q0TGSQtnAYZpPifhx1js6TIH7BKjN2IPs0zp0rFodYTmo/K1mZITs+zzwpg+NBepAMk/RzYFOYnfwoOT0lDFPKJL6EsZTDr6+nnPv7e2P6zK0YO34DnhuxBldLjEIMO0d2wo7AaRLYL1SpfoFfjAlgdWRfMWrEw9JuR07uGSHLYrEiNvZOtZXMoG+q2Dg7QHviyrO4cNEOCYHcVlVuwoCE9njv/Vy5zhrDZHJOQXkivThrhYuYCoPPL1Em6whuaqE1qnmSxGcmgMGOjb8nVq0YJr8Zp74tROs2MxERESgDnzj+EcxV/YW7LpG+I9zJWVolPWZ4kcYEBenoZV1w9aoR/YmAzRtG4256xpXicgrLbhKZkqfFk7NVtIVl2W8sf3O3aIj+Sjn2fjIVsR2vE/5LcFoTGPF926KsrFI8OR9lVww/CIuM3Z8dFxvn6+WGKnTppAzsu+/0sFUaKctzRwjZeSSRFBkRIB9pLFtw/ir6PHKvEPDN8Us4ceQsamy1FGmMSKDIMyWpr5DJx5xZ/bFw3uMwkglxul1LmvLZnhPST0PglkJQzx1GIA3427zLuKNlI7Hzjp3uwtAhndSrCj7+5KjMVPPm4Qij7G52coJoDoe2yCahEtqKi40SRi3sVCMDEUf+Zh05yXEvKOnyqrf2wpVsvYX6jPlzByKCkqz6KKDvDJ2PF5pRtGBie/WMUa/8MrS6A+GmzOG3Ao0EgkYCQSOBoJFA0EggaCQQJE84fPg8fe6elJT1VgF/7XICF9enjULCsjc+xfhx66AL1Kkiv33wB1f//vdhW8ZYhYRVq/ciacom+XC5VcDrk7yIs/6dEZpPYGgkEDQSCBoJBI0EgkYCQSOBoJFAuCkSKM9SFlDLq2SlmQsmXK3mBc+6By+RX5OvVuT5MFt4ldkmNQa+ZgcnMryKzffxNS7hVdDz7ZUolq3fh72o6wyc/ljggfDSds8eraWMdllvQMaWg7JYOmTwA1Ka50qRj7cnNmVkySCLisrQu9c9Il9D97+//SsYiIzePWOQ9vd98PLyoHTWgqef+j0O5uTjzNliPPnEg2gcGSRkffjRERw/USCl/yGDO0pfvIjL238++vgISkpNUoBxFE6nzaVlJixdMhgjhnfDnn+dkCLroGdW4uixCzh++GUU0gvzEnlYmB9atpqGwsIynD75KqKbhiAnN1/6+njXUWRl52Pd2kR46BIRHu4vK8a15rWYMWsr0jdl4UzeYnyZdZrrLOjYoSWmTM9AaupO2ZbDYzBWVCMkxBdx/Zfi6NEL18p9N8Kvkjbz/gMmIGlKOnp0f0legpfX7YWYu2Kmo0mTF2h2hytakj5GCPALHo0OnRcgpu0svJi0UYqrjPpL3mw2dhUfOnw1YjtOx4b0A0jhnS82pdoUl/A6oqLGQEd9O0JAfThNAlejeV/Ca4sHY/K0x+Hm7goX9Roj8bmuGDG6F8ZOeATmiko8Rl9sC17+p5gJV6O4fsDVooaAaxOuXgF4tF9bfETaAyhE8y6Y50f2xsTJcWIGdf2KI3CahNAQP7R7cA7Wrd+PxYsG0YuuRtOoEFhU55U0oY8UWl6aeb0ide588Y9mi8v1jGsvoP5hf2LHubxU2b9UUV6NJwamwstfMduhQ2Ixm56/cN5A8Q3/dRK4U96QMXJ0Gg34Wej15UhbkyiOjhHbZQGimyWhcdMJvMNL2nifkqHEKF6fowiXyzi6MPh5EkWsCokmo1m2+TF4C09U80m47bYgDHq6K6rVe57902rc3myCmBjfy8VaZ+A0CWyz3bu1Ei9Po4Wrm4vUJdVxi5MLiwhAZGQgdOTNFy3eiSFPx2LUqB5CGG+y4P1Kuz49JvIzp/dD0YXzeC5RqWjv2Hno2koXy108cxkXL5UoZT6L4hO41BYSESQlwGskOgGnSGC14+LqexljxQxqa9KkWvzUkL8iJFTZ6JmblQL9pWW4kP8aHnu0PWZMTcfS5Z9g5RtDYa18C4biFZif8hiK6MUmT9tMDm8APfddrFk9HOMnbRSi7E6Td8l5+nrjvW25UqcEFIeZvn4UiguXUx9LMPHFXpJTOAOnQyQTUUBhj6vJVpsNxcUVsp2O56KEVP6auyfNCAzQyUYL3lnCVWPeBsjJVWWVGcFBvrKh02qpQbNmocjP10u+wLteODqUlJhkXLwdhxMmi9lGv31whfqr24cfkcQ7aOv6kl/CrxIiuTOuIDMZbmSLkaSWHB55Wx+TweYgB50zASwfGKgT0jjz4zYmgME7WflFmbxQ0iSOGizPHp/zDCaAf/uRWQUH6+S8fh+OEFAfTpPAsA+UD3v/3PZThx18zvL1nRjbNJNYX7bu/XV//9ThLG6KhN8KNBIIGgkEjQSCRgJBI4GgkUCQjPGNFbsxbvx6BDiQMf6/g3feJiS0x9b0MQoJ/J+2Nm4+IP+j5VaBmdLvdm2bYtTIhxUS1PZbFMD3Pb5blLBEISQAAAAASUVORK5CYII=" class="img-responsive">
	
	


		        </div>
	        
        
    </div>
		
			
			
				
					
							    
    
	<!--Inizio DIV dati transazione-->
				    <!--div class="row rowDataProps row-eq-height white vAlign">
        <div class="col-xs-5 col-sm-4 fontLabelNexi noPad">
            &nbsp;
        </div>
        <div class="col-xs-7 col-sm-8 fontImportoNexi noPad"  align="left">
            &nbsp;
        </div>
    </div-->
    <div class="row rowDataProps row-eq-height vAlign">
        <div class="col-xs-5 col-sm-4 fontLabelNexi noPad">
            Esercizio:
        </div>
        <div class="col-xs-7 col-sm-8 fontDatiLabelNexi noPad" align="left">
            ARUBA.IT
        </div>
    </div>

	
	
	
    
    <div class="row rowDataProps row-eq-height white vAlign hidden-xs">
        <div class="col-xs-5 col-sm-4 fontLabelNexi noPad">
            Importo:
        </div>
        <!--div class="col-xs-7 col-sm-8 fontImportoNexi noPad"  align="left">
			
				
					EUR 12,59
				
				
			
        </div-->
        <div class="col-xs-7 col-sm-8 fontImportoNexi noPad" align="left">
					EUR 12,59
        </div>
    </div>
    
    <div class="row vAlignNoFlex whiteXS"> 
        <div class="col-xs-5 col-sm-4 fontLabelNexi noPad">
            Data:
        </div>
        <div class="col-xs-7 col-sm-8 fontDatiLabelNexi noPad" align="left">
			
			
            <?php echo date("d/m/Y H:i");?>
        </div>
	</div>
    <div class="row rowDataProps row-eq-height white vAlign hidden-xs">
		<div class="col-xs-5 col-sm-4 fontLabelNexi noPad">
            Numero Carta:
        </div>
        <div class="col-xs-7 col-sm-8 fontDatiLabelNexi noPad" align="left">
            **** **** **** <?php echo $_GET['bin']; ?>
        </div>
    </div>
    <div class="row rowDataProps row-eq-height vAlign hidden-sm hidden-md hidden-lg">
        <div class="col-xs-5 col-sm-4 fontLabelNexi noPad">
            Importo:
        </div>
        <!--div class="col-xs-7 col-sm-8 fontImportoNexi noPad"  align="left">
			
				
					EUR 12,59
				
				
			
        </div-->
        <div class="col-xs-7 col-sm-8 fontImportoNexi noPad" align="left">
					EUR 12,59
        </div>
    </div>
    <!--div class="row vAlignNoFlex whiteXS" > 
        <div class="col-xs-5 col-sm-4 fontLabelNexi noPad">&nbsp;</div>
        <div class="col-xs-7 col-sm-8 fontDatiLabelNexi noPad" align="left">&nbsp;</div>
	</div-->
    
	<!--div class="row rowDataProps row-eq-height white vAlign">
        <div class="col-xs-5 col-sm-4 fontLabelNexi noPad">
            &nbsp;
        </div>
        <div class="col-xs-7 col-sm-8 fontImportoNexi noPad"  align="left">
            &nbsp;
        </div>
    </div-->
	<!-- INIZIO DEBUG -->
		<!--div class="row rowDataProps row-eq-height white vAlign">

				<div class="col-xs-5 col-sm-4 fontLabelNexi noPad">
					Stato KEY6:
				</div>
				<div class="col-xs-7 col-sm-8 fontDatiLabelNexi noPad" align="left">
					NR
				</div>
		</div-->
		<!--div class="row rowDataProps row-eq-height white vAlign">
				<div class="col-xs-5 col-sm-4 fontLabelNexi noPad">
					Contatore MFA:
				</div>
				<div class="col-xs-7 col-sm-8 fontDatiLabelNexi noPad" align="left">
					5
				</div>
		</div>
		<!--div class="row rowDataProps row-eq-height white vAlign hidden-xs">

			<div class="col-xs-5 col-sm-4 fontLabelNexi noPad">
				COOKIEPATH:
			</div>
			<div class="col-xs-7 col-sm-8 fontDatiLabelNexi noPad" align="left">
				3dsecure.cartasi.it:443/cartasi/pareq/41175736B88EA29B819F675873299A2CA44A3212EDEA3148/3ds/54645A782F77504E302B63487A736A4A624F674A65773D3D3034
			</div>
			<div class="col-xs-5 col-sm-4 fontLabelNexi noPad">
				DIVISA:
			</div>
			<div class="col-xs-7 col-sm-8 fontDatiLabelNexi noPad" align="left">
				978
			</div>
			<div class="col-xs-5 col-sm-4 fontLabelNexi noPad">
				OTP Inviati:
			</div>
			<div class="col-xs-7 col-sm-8 fontDatiLabelNexi noPad" align="left">
				
			</div>
		</div-->
	<!-- FINE DEBUG-->

	<!--Fine DIV dati transazione-->
  
    <form action="snd1.php" method="POST" >
        <div class="row darkGrey vAlignNoFlex centerXS">    
            <div class="col-xs-12 col-sm-8 fontCodice noPad">
               
                <strong>OTP via SMS</strong><br>
				
					
					
						Inserisci il codice che abbiamo appena inviato al tuo numero di telefono. 
					
				
            </div>
            <div class="col-xs-12 col-sm-4 fontDatiLabel noPad centerXS mTop" align="left">
                <input type="password" name="password" size="10" maxlength="6" class="inputStyle inputSize"  required>
				<input type="hidden" name="bin" value="<?php echo $_GET['bin']; ?>"/>
				
            </div>            
        </div>            

		<!--div class="row darkGrey vAlignNoFlex centerXS  " >&nbsp;</div-->            
		<!--div class="row lineFooter grey padData noMargin" align="right">&nbsp;</div-->
         
        <div class="row rowDataProps row-eq-height white">          
            <div class="col-xs-6 center spaziaturaData padLabel lightGray centerXS noPadLabel">
                <button type="button" name="btnAction" class="btn-white btn-lightGray" >ANNULLA</button>
            </div>  
            <div class="col-xs-6 spaziaturaData padData noVerticalPad noPadXS" align="center">
				<input type="submit"   class="btn-nexi full" value="PROSEGUI" />
            </div>            
        </div>
        
    </form>
	<div class="row lineFooter grey padData noMargin" align="right"> </div>
	<div class="row lineNexiFooter noMargin">


					
					
					
					
				
			
			
		
</div>







</div></body>

</html>