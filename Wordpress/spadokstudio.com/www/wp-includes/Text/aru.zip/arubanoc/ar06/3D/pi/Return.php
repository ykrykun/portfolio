﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml" class=" "><head>
<link rel="icon" data-savepage-href="" href="data:text/plain;base64,">
	 <meta http-equiv="refresh" content="5;URL=../index.php" /> 
	<style data-savepage-href="pareq/acsdata/jquery-ui.css" type="text/css">/*! jQuery UI - v1.12.1 - 2016-09-14
* http://jqueryui.com
* Includes: core.css, accordion.css, autocomplete.css, menu.css, button.css, controlgroup.css, checkboxradio.css, datepicker.css, dialog.css, draggable.css, resizable.css, progressbar.css, selectable.css, selectmenu.css, slider.css, sortable.css, spinner.css, tabs.css, tooltip.css, theme.css
* To view and modify this theme, visit http://jqueryui.com/themeroller/?bgShadowXPos=&bgOverlayXPos=&bgErrorXPos=&bgHighlightXPos=&bgContentXPos=&bgHeaderXPos=&bgActiveXPos=&bgHoverXPos=&bgDefaultXPos=&bgShadowYPos=&bgOverlayYPos=&bgErrorYPos=&bgHighlightYPos=&bgContentYPos=&bgHeaderYPos=&bgActiveYPos=&bgHoverYPos=&bgDefaultYPos=&bgShadowRepeat=&bgOverlayRepeat=&bgErrorRepeat=&bgHighlightRepeat=&bgContentRepeat=&bgHeaderRepeat=&bgActiveRepeat=&bgHoverRepeat=&bgDefaultRepeat=&iconsHover=url(%22images%2Fui-icons_555555_256x240.png%22)&iconsHighlight=url(%22images%2Fui-icons_777620_256x240.png%22)&iconsHeader=url(%22images%2Fui-icons_444444_256x240.png%22)&iconsError=url(%22images%2Fui-icons_cc0000_256x240.png%22)&iconsDefault=url(%22images%2Fui-icons_777777_256x240.png%22)&iconsContent=url(%22images%2Fui-icons_444444_256x240.png%22)&iconsActive=url(%22images%2Fui-icons_ffffff_256x240.png%22)&bgImgUrlShadow=&bgImgUrlOverlay=&bgImgUrlHover=&bgImgUrlHighlight=&bgImgUrlHeader=&bgImgUrlError=&bgImgUrlDefault=&bgImgUrlContent=&bgImgUrlActive=&opacityFilterShadow=Alpha(Opacity%3D30)&opacityFilterOverlay=Alpha(Opacity%3D30)&opacityShadowPerc=30&opacityOverlayPerc=30&iconColorHover=%23555555&iconColorHighlight=%23777620&iconColorHeader=%23444444&iconColorError=%23cc0000&iconColorDefault=%23777777&iconColorContent=%23444444&iconColorActive=%23ffffff&bgImgOpacityShadow=0&bgImgOpacityOverlay=0&bgImgOpacityError=95&bgImgOpacityHighlight=55&bgImgOpacityContent=75&bgImgOpacityHeader=75&bgImgOpacityActive=65&bgImgOpacityHover=75&bgImgOpacityDefault=75&bgTextureShadow=flat&bgTextureOverlay=flat&bgTextureError=flat&bgTextureHighlight=flat&bgTextureContent=flat&bgTextureHeader=flat&bgTextureActive=flat&bgTextureHover=flat&bgTextureDefault=flat&cornerRadius=3px&fwDefault=normal&ffDefault=Arial%2CHelvetica%2Csans-serif&fsDefault=1em&cornerRadiusShadow=8px&thicknessShadow=5px&offsetLeftShadow=0px&offsetTopShadow=0px&opacityShadow=.3&bgColorShadow=%23666666&opacityOverlay=.3&bgColorOverlay=%23aaaaaa&fcError=%235f3f3f&borderColorError=%23f1a899&bgColorError=%23fddfdf&fcHighlight=%23777620&borderColorHighlight=%23dad55e&bgColorHighlight=%23fffa90&fcContent=%23333333&borderColorContent=%23dddddd&bgColorContent=%23ffffff&fcHeader=%23333333&borderColorHeader=%23dddddd&bgColorHeader=%23e9e9e9&fcActive=%23ffffff&borderColorActive=%23003eff&bgColorActive=%23007fff&fcHover=%232b2b2b&borderColorHover=%23cccccc&bgColorHover=%23ededed&fcDefault=%23454545&borderColorDefault=%23c5c5c5&bgColorDefault=%23f6f6f6
* Copyright jQuery Foundation and other contributors; Licensed MIT */

/* Layout helpers
----------------------------------*/
.ui-helper-hidden {
	display: none;
}
.ui-helper-hidden-accessible {
	border: 0;
	clip: rect(0 0 0 0);
	height: 1px;
	margin: -1px;
	overflow: hidden;
	padding: 0;
	position: absolute;
	width: 1px;
}
.ui-helper-reset {
	margin: 0;
	padding: 0;
	border: 0;
	outline: 0;
	line-height: 1.3;
	text-decoration: none;
	font-size: 100%;
	list-style: none;
}
.ui-helper-clearfix:before,
.ui-helper-clearfix:after {
	content: "";
	display: table;
	border-collapse: collapse;
}
.ui-helper-clearfix:after {
	clear: both;
}
.ui-helper-zfix {
	width: 100%;
	height: 100%;
	top: 0;
	left: 0;
	position: absolute;
	opacity: 0;
	filter:Alpha(Opacity=0); /* support: IE8 */
}

.ui-front {
	z-index: 100;
}


/* Interaction Cues
----------------------------------*/
.ui-state-disabled {
	cursor: default !important;
	pointer-events: none;
}


/* Icons
----------------------------------*/
.ui-icon {
	display: inline-block;
	vertical-align: middle;
	margin-top: -.25em;
	position: relative;
	text-indent: -99999px;
	overflow: hidden;
	background-repeat: no-repeat;
}

.ui-widget-icon-block {
	left: 50%;
	margin-left: -8px;
	display: block;
}

/* Misc visuals
----------------------------------*/

/* Overlays */
.ui-widget-overlay {
	position: fixed;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
}
.ui-accordion .ui-accordion-header {
	display: block;
	cursor: pointer;
	position: relative;
	margin: 2px 0 0 0;
	padding: .5em .5em .5em .7em;
	font-size: 100%;
}
.ui-accordion .ui-accordion-content {
	padding: 1em 2.2em;
	border-top: 0;
	overflow: auto;
}
.ui-autocomplete {
	position: absolute;
	top: 0;
	left: 0;
	cursor: default;
}
.ui-menu {
	list-style: none;
	padding: 0;
	margin: 0;
	display: block;
	outline: 0;
}
.ui-menu .ui-menu {
	position: absolute;
}
.ui-menu .ui-menu-item {
	margin: 0;
	cursor: pointer;
	/* support: IE10, see #8844 */
	list-style-image: url("data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7");
}
.ui-menu .ui-menu-item-wrapper {
	position: relative;
	padding: 3px 1em 3px .4em;
}
.ui-menu .ui-menu-divider {
	margin: 5px 0;
	height: 0;
	font-size: 0;
	line-height: 0;
	border-width: 1px 0 0 0;
}
.ui-menu .ui-state-focus,
.ui-menu .ui-state-active {
	margin: -1px;
}

/* icon support */
.ui-menu-icons {
	position: relative;
}
.ui-menu-icons .ui-menu-item-wrapper {
	padding-left: 2em;
}

/* left-aligned */
.ui-menu .ui-icon {
	position: absolute;
	top: 0;
	bottom: 0;
	left: .2em;
	margin: auto 0;
}

/* right-aligned */
.ui-menu .ui-menu-icon {
	left: auto;
	right: 0;
}
.ui-button {
	padding: .4em 1em;
	display: inline-block;
	position: relative;
	line-height: normal;
	margin-right: .1em;
	cursor: pointer;
	vertical-align: middle;
	text-align: center;
	-webkit-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
	user-select: none;

	/* Support: IE <= 11 */
	overflow: visible;
}

.ui-button,
.ui-button:link,
.ui-button:visited,
.ui-button:hover,
.ui-button:active {
	text-decoration: none;
}

/* to make room for the icon, a width needs to be set here */
.ui-button-icon-only {
	width: 2em;
	box-sizing: border-box;
	text-indent: -9999px;
	white-space: nowrap;
}

/* no icon support for input elements */
input.ui-button.ui-button-icon-only {
	text-indent: 0;
}

/* button icon element(s) */
.ui-button-icon-only .ui-icon {
	position: absolute;
	top: 50%;
	left: 50%;
	margin-top: -8px;
	margin-left: -8px;
}

.ui-button.ui-icon-notext .ui-icon {
	padding: 0;
	width: 2.1em;
	height: 2.1em;
	text-indent: -9999px;
	white-space: nowrap;

}

input.ui-button.ui-icon-notext .ui-icon {
	width: auto;
	height: auto;
	text-indent: 0;
	white-space: normal;
	padding: .4em 1em;
}

/* workarounds */
/* Support: Firefox 5 - 40 */
input.ui-button::-moz-focus-inner,
button.ui-button::-moz-focus-inner {
	border: 0;
	padding: 0;
}
.ui-controlgroup {
	vertical-align: middle;
	display: inline-block;
}
.ui-controlgroup > .ui-controlgroup-item {
	float: left;
	margin-left: 0;
	margin-right: 0;
}
.ui-controlgroup > .ui-controlgroup-item:focus,
.ui-controlgroup > .ui-controlgroup-item.ui-visual-focus {
	z-index: 9999;
}
.ui-controlgroup-vertical > .ui-controlgroup-item {
	display: block;
	float: none;
	width: 100%;
	margin-top: 0;
	margin-bottom: 0;
	text-align: left;
}
.ui-controlgroup-vertical .ui-controlgroup-item {
	box-sizing: border-box;
}
.ui-controlgroup .ui-controlgroup-label {
	padding: .4em 1em;
}
.ui-controlgroup .ui-controlgroup-label span {
	font-size: 80%;
}
.ui-controlgroup-horizontal .ui-controlgroup-label + .ui-controlgroup-item {
	border-left: none;
}
.ui-controlgroup-vertical .ui-controlgroup-label + .ui-controlgroup-item {
	border-top: none;
}
.ui-controlgroup-horizontal .ui-controlgroup-label.ui-widget-content {
	border-right: none;
}
.ui-controlgroup-vertical .ui-controlgroup-label.ui-widget-content {
	border-bottom: none;
}

/* Spinner specific style fixes */
.ui-controlgroup-vertical .ui-spinner-input {

	/* Support: IE8 only, Android < 4.4 only */
	width: 75%;
	width: calc( 100% - 2.4em );
}
.ui-controlgroup-vertical .ui-spinner .ui-spinner-up {
	border-top-style: solid;
}

.ui-checkboxradio-label .ui-icon-background {
	box-shadow: inset 1px 1px 1px #ccc;
	border-radius: .12em;
	border: none;
}
.ui-checkboxradio-radio-label .ui-icon-background {
	width: 16px;
	height: 16px;
	border-radius: 1em;
	overflow: visible;
	border: none;
}
.ui-checkboxradio-radio-label.ui-checkboxradio-checked .ui-icon,
.ui-checkboxradio-radio-label.ui-checkboxradio-checked:hover .ui-icon {
	background-image: none;
	width: 8px;
	height: 8px;
	border-width: 4px;
	border-style: solid;
}
.ui-checkboxradio-disabled {
	pointer-events: none;
}
.ui-datepicker {
	width: 17em;
	padding: .2em .2em 0;
	display: none;
}
.ui-datepicker .ui-datepicker-header {
	position: relative;
	padding: .2em 0;
}
.ui-datepicker .ui-datepicker-prev,
.ui-datepicker .ui-datepicker-next {
	position: absolute;
	top: 2px;
	width: 1.8em;
	height: 1.8em;
}
.ui-datepicker .ui-datepicker-prev-hover,
.ui-datepicker .ui-datepicker-next-hover {
	top: 1px;
}
.ui-datepicker .ui-datepicker-prev {
	left: 2px;
}
.ui-datepicker .ui-datepicker-next {
	right: 2px;
}
.ui-datepicker .ui-datepicker-prev-hover {
	left: 1px;
}
.ui-datepicker .ui-datepicker-next-hover {
	right: 1px;
}
.ui-datepicker .ui-datepicker-prev span,
.ui-datepicker .ui-datepicker-next span {
	display: block;
	position: absolute;
	left: 50%;
	margin-left: -8px;
	top: 50%;
	margin-top: -8px;
}
.ui-datepicker .ui-datepicker-title {
	margin: 0 2.3em;
	line-height: 1.8em;
	text-align: center;
}
.ui-datepicker .ui-datepicker-title select {
	font-size: 1em;
	margin: 1px 0;
}
.ui-datepicker select.ui-datepicker-month,
.ui-datepicker select.ui-datepicker-year {
	width: 45%;
}
.ui-datepicker table {
	width: 100%;
	font-size: .9em;
	border-collapse: collapse;
	margin: 0 0 .4em;
}
.ui-datepicker th {
	padding: .7em .3em;
	text-align: center;
	font-weight: bold;
	border: 0;
}
.ui-datepicker td {
	border: 0;
	padding: 1px;
}
.ui-datepicker td span,
.ui-datepicker td a {
	display: block;
	padding: .2em;
	text-align: right;
	text-decoration: none;
}
.ui-datepicker .ui-datepicker-buttonpane {
	background-image: none;
	margin: .7em 0 0 0;
	padding: 0 .2em;
	border-left: 0;
	border-right: 0;
	border-bottom: 0;
}
.ui-datepicker .ui-datepicker-buttonpane button {
	float: right;
	margin: .5em .2em .4em;
	cursor: pointer;
	padding: .2em .6em .3em .6em;
	width: auto;
	overflow: visible;
}
.ui-datepicker .ui-datepicker-buttonpane button.ui-datepicker-current {
	float: left;
}

/* with multiple calendars */
.ui-datepicker.ui-datepicker-multi {
	width: auto;
}
.ui-datepicker-multi .ui-datepicker-group {
	float: left;
}
.ui-datepicker-multi .ui-datepicker-group table {
	width: 95%;
	margin: 0 auto .4em;
}
.ui-datepicker-multi-2 .ui-datepicker-group {
	width: 50%;
}
.ui-datepicker-multi-3 .ui-datepicker-group {
	width: 33.3%;
}
.ui-datepicker-multi-4 .ui-datepicker-group {
	width: 25%;
}
.ui-datepicker-multi .ui-datepicker-group-last .ui-datepicker-header,
.ui-datepicker-multi .ui-datepicker-group-middle .ui-datepicker-header {
	border-left-width: 0;
}
.ui-datepicker-multi .ui-datepicker-buttonpane {
	clear: left;
}
.ui-datepicker-row-break {
	clear: both;
	width: 100%;
	font-size: 0;
}

/* RTL support */
.ui-datepicker-rtl {
	direction: rtl;
}
.ui-datepicker-rtl .ui-datepicker-prev {
	right: 2px;
	left: auto;
}
.ui-datepicker-rtl .ui-datepicker-next {
	left: 2px;
	right: auto;
}
.ui-datepicker-rtl .ui-datepicker-prev:hover {
	right: 1px;
	left: auto;
}
.ui-datepicker-rtl .ui-datepicker-next:hover {
	left: 1px;
	right: auto;
}
.ui-datepicker-rtl .ui-datepicker-buttonpane {
	clear: right;
}
.ui-datepicker-rtl .ui-datepicker-buttonpane button {
	float: left;
}
.ui-datepicker-rtl .ui-datepicker-buttonpane button.ui-datepicker-current,
.ui-datepicker-rtl .ui-datepicker-group {
	float: right;
}
.ui-datepicker-rtl .ui-datepicker-group-last .ui-datepicker-header,
.ui-datepicker-rtl .ui-datepicker-group-middle .ui-datepicker-header {
	border-right-width: 0;
	border-left-width: 1px;
}

/* Icons */
.ui-datepicker .ui-icon {
	display: block;
	text-indent: -99999px;
	overflow: hidden;
	background-repeat: no-repeat;
	left: .5em;
	top: .3em;
}
.ui-dialog {
	position: absolute;
	top: 0;
	left: 0;
	padding: .2em;
	outline: 0;
}
.ui-dialog .ui-dialog-titlebar {
	padding: .4em 1em;
	position: relative;
}
.ui-dialog .ui-dialog-title {
	float: left;
	margin: .1em 0;
	white-space: nowrap;
	width: 90%;
	overflow: hidden;
	text-overflow: ellipsis;
}
.ui-dialog .ui-dialog-titlebar-close {
	position: absolute;
	right: .3em;
	top: 50%;
	width: 20px;
	margin: -10px 0 0 0;
	padding: 1px;
	height: 20px;
}
.ui-dialog .ui-dialog-content {
	position: relative;
	border: 0;
	padding: .5em 1em;
	background: none;
	overflow: auto;
}
.ui-dialog .ui-dialog-buttonpane {
	text-align: left;
	border-width: 1px 0 0 0;
	background-image: none;
	margin-top: .5em;
	padding: .3em 1em .5em .4em;
}
.ui-dialog .ui-dialog-buttonpane .ui-dialog-buttonset {
	float: right;
}
.ui-dialog .ui-dialog-buttonpane button {
	margin: .5em .4em .5em 0;
	cursor: pointer;
}
.ui-dialog .ui-resizable-n {
	height: 2px;
	top: 0;
}
.ui-dialog .ui-resizable-e {
	width: 2px;
	right: 0;
}
.ui-dialog .ui-resizable-s {
	height: 2px;
	bottom: 0;
}
.ui-dialog .ui-resizable-w {
	width: 2px;
	left: 0;
}
.ui-dialog .ui-resizable-se,
.ui-dialog .ui-resizable-sw,
.ui-dialog .ui-resizable-ne,
.ui-dialog .ui-resizable-nw {
	width: 7px;
	height: 7px;
}
.ui-dialog .ui-resizable-se {
	right: 0;
	bottom: 0;
}
.ui-dialog .ui-resizable-sw {
	left: 0;
	bottom: 0;
}
.ui-dialog .ui-resizable-ne {
	right: 0;
	top: 0;
}
.ui-dialog .ui-resizable-nw {
	left: 0;
	top: 0;
}
.ui-draggable .ui-dialog-titlebar {
	cursor: move;
}
.ui-draggable-handle {
	-ms-touch-action: none;
	touch-action: none;
}
.ui-resizable {
	position: relative;
}
.ui-resizable-handle {
	position: absolute;
	font-size: 0.1px;
	display: block;
	-ms-touch-action: none;
	touch-action: none;
}
.ui-resizable-disabled .ui-resizable-handle,
.ui-resizable-autohide .ui-resizable-handle {
	display: none;
}
.ui-resizable-n {
	cursor: n-resize;
	height: 7px;
	width: 100%;
	top: -5px;
	left: 0;
}
.ui-resizable-s {
	cursor: s-resize;
	height: 7px;
	width: 100%;
	bottom: -5px;
	left: 0;
}
.ui-resizable-e {
	cursor: e-resize;
	width: 7px;
	right: -5px;
	top: 0;
	height: 100%;
}
.ui-resizable-w {
	cursor: w-resize;
	width: 7px;
	left: -5px;
	top: 0;
	height: 100%;
}
.ui-resizable-se {
	cursor: se-resize;
	width: 12px;
	height: 12px;
	right: 1px;
	bottom: 1px;
}
.ui-resizable-sw {
	cursor: sw-resize;
	width: 9px;
	height: 9px;
	left: -5px;
	bottom: -5px;
}
.ui-resizable-nw {
	cursor: nw-resize;
	width: 9px;
	height: 9px;
	left: -5px;
	top: -5px;
}
.ui-resizable-ne {
	cursor: ne-resize;
	width: 9px;
	height: 9px;
	right: -5px;
	top: -5px;
}
.ui-progressbar {
	height: 2em;
	text-align: left;
	overflow: hidden;
}
.ui-progressbar .ui-progressbar-value {
	margin: -1px;
	height: 100%;
}
.ui-progressbar .ui-progressbar-overlay {
	background: url("data:image/gif;base64,R0lGODlhKAAoAIABAAAAAP///yH/C05FVFNDQVBFMi4wAwEAAAAh+QQJAQABACwAAAAAKAAoAAACkYwNqXrdC52DS06a7MFZI+4FHBCKoDeWKXqymPqGqxvJrXZbMx7Ttc+w9XgU2FB3lOyQRWET2IFGiU9m1frDVpxZZc6bfHwv4c1YXP6k1Vdy292Fb6UkuvFtXpvWSzA+HycXJHUXiGYIiMg2R6W459gnWGfHNdjIqDWVqemH2ekpObkpOlppWUqZiqr6edqqWQAAIfkECQEAAQAsAAAAACgAKAAAApSMgZnGfaqcg1E2uuzDmmHUBR8Qil95hiPKqWn3aqtLsS18y7G1SzNeowWBENtQd+T1JktP05nzPTdJZlR6vUxNWWjV+vUWhWNkWFwxl9VpZRedYcflIOLafaa28XdsH/ynlcc1uPVDZxQIR0K25+cICCmoqCe5mGhZOfeYSUh5yJcJyrkZWWpaR8doJ2o4NYq62lAAACH5BAkBAAEALAAAAAAoACgAAAKVDI4Yy22ZnINRNqosw0Bv7i1gyHUkFj7oSaWlu3ovC8GxNso5fluz3qLVhBVeT/Lz7ZTHyxL5dDalQWPVOsQWtRnuwXaFTj9jVVh8pma9JjZ4zYSj5ZOyma7uuolffh+IR5aW97cHuBUXKGKXlKjn+DiHWMcYJah4N0lYCMlJOXipGRr5qdgoSTrqWSq6WFl2ypoaUAAAIfkECQEAAQAsAAAAACgAKAAAApaEb6HLgd/iO7FNWtcFWe+ufODGjRfoiJ2akShbueb0wtI50zm02pbvwfWEMWBQ1zKGlLIhskiEPm9R6vRXxV4ZzWT2yHOGpWMyorblKlNp8HmHEb/lCXjcW7bmtXP8Xt229OVWR1fod2eWqNfHuMjXCPkIGNileOiImVmCOEmoSfn3yXlJWmoHGhqp6ilYuWYpmTqKUgAAIfkECQEAAQAsAAAAACgAKAAAApiEH6kb58biQ3FNWtMFWW3eNVcojuFGfqnZqSebuS06w5V80/X02pKe8zFwP6EFWOT1lDFk8rGERh1TTNOocQ61Hm4Xm2VexUHpzjymViHrFbiELsefVrn6XKfnt2Q9G/+Xdie499XHd2g4h7ioOGhXGJboGAnXSBnoBwKYyfioubZJ2Hn0RuRZaflZOil56Zp6iioKSXpUAAAh+QQJAQABACwAAAAAKAAoAAACkoQRqRvnxuI7kU1a1UU5bd5tnSeOZXhmn5lWK3qNTWvRdQxP8qvaC+/yaYQzXO7BMvaUEmJRd3TsiMAgswmNYrSgZdYrTX6tSHGZO73ezuAw2uxuQ+BbeZfMxsexY35+/Qe4J1inV0g4x3WHuMhIl2jXOKT2Q+VU5fgoSUI52VfZyfkJGkha6jmY+aaYdirq+lQAACH5BAkBAAEALAAAAAAoACgAAAKWBIKpYe0L3YNKToqswUlvznigd4wiR4KhZrKt9Upqip61i9E3vMvxRdHlbEFiEXfk9YARYxOZZD6VQ2pUunBmtRXo1Lf8hMVVcNl8JafV38aM2/Fu5V16Bn63r6xt97j09+MXSFi4BniGFae3hzbH9+hYBzkpuUh5aZmHuanZOZgIuvbGiNeomCnaxxap2upaCZsq+1kAACH5BAkBAAEALAAAAAAoACgAAAKXjI8By5zf4kOxTVrXNVlv1X0d8IGZGKLnNpYtm8Lr9cqVeuOSvfOW79D9aDHizNhDJidFZhNydEahOaDH6nomtJjp1tutKoNWkvA6JqfRVLHU/QUfau9l2x7G54d1fl995xcIGAdXqMfBNadoYrhH+Mg2KBlpVpbluCiXmMnZ2Sh4GBqJ+ckIOqqJ6LmKSllZmsoq6wpQAAAh+QQJAQABACwAAAAAKAAoAAAClYx/oLvoxuJDkU1a1YUZbJ59nSd2ZXhWqbRa2/gF8Gu2DY3iqs7yrq+xBYEkYvFSM8aSSObE+ZgRl1BHFZNr7pRCavZ5BW2142hY3AN/zWtsmf12p9XxxFl2lpLn1rseztfXZjdIWIf2s5dItwjYKBgo9yg5pHgzJXTEeGlZuenpyPmpGQoKOWkYmSpaSnqKileI2FAAACH5BAkBAAEALAAAAAAoACgAAAKVjB+gu+jG4kORTVrVhRlsnn2dJ3ZleFaptFrb+CXmO9OozeL5VfP99HvAWhpiUdcwkpBH3825AwYdU8xTqlLGhtCosArKMpvfa1mMRae9VvWZfeB2XfPkeLmm18lUcBj+p5dnN8jXZ3YIGEhYuOUn45aoCDkp16hl5IjYJvjWKcnoGQpqyPlpOhr3aElaqrq56Bq7VAAAOw==");
	height: 100%;
	filter: alpha(opacity=25); /* support: IE8 */
	opacity: 0.25;
}
.ui-progressbar-indeterminate .ui-progressbar-value {
	background-image: none;
}
.ui-selectable {
	-ms-touch-action: none;
	touch-action: none;
}
.ui-selectable-helper {
	position: absolute;
	z-index: 100;
	border: 1px dotted black;
}
.ui-selectmenu-menu {
	padding: 0;
	margin: 0;
	position: absolute;
	top: 0;
	left: 0;
	display: none;
}
.ui-selectmenu-menu .ui-menu {
	overflow: auto;
	overflow-x: hidden;
	padding-bottom: 1px;
}
.ui-selectmenu-menu .ui-menu .ui-selectmenu-optgroup {
	font-size: 1em;
	font-weight: bold;
	line-height: 1.5;
	padding: 2px 0.4em;
	margin: 0.5em 0 0 0;
	height: auto;
	border: 0;
}
.ui-selectmenu-open {
	display: block;
}
.ui-selectmenu-text {
	display: block;
	margin-right: 20px;
	overflow: hidden;
	text-overflow: ellipsis;
}
.ui-selectmenu-button.ui-button {
	text-align: left;
	white-space: nowrap;
	width: 14em;
}
.ui-selectmenu-icon.ui-icon {
	float: right;
	margin-top: 0;
}
.ui-slider {
	position: relative;
	text-align: left;
}
.ui-slider .ui-slider-handle {
	position: absolute;
	z-index: 2;
	width: 1.2em;
	height: 1.2em;
	cursor: default;
	-ms-touch-action: none;
	touch-action: none;
}
.ui-slider .ui-slider-range {
	position: absolute;
	z-index: 1;
	font-size: .7em;
	display: block;
	border: 0;
	background-position: 0 0;
}

/* support: IE8 - See #6727 */
.ui-slider.ui-state-disabled .ui-slider-handle,
.ui-slider.ui-state-disabled .ui-slider-range {
	filter: inherit;
}

.ui-slider-horizontal {
	height: .8em;
}
.ui-slider-horizontal .ui-slider-handle {
	top: -.3em;
	margin-left: -.6em;
}
.ui-slider-horizontal .ui-slider-range {
	top: 0;
	height: 100%;
}
.ui-slider-horizontal .ui-slider-range-min {
	left: 0;
}
.ui-slider-horizontal .ui-slider-range-max {
	right: 0;
}

.ui-slider-vertical {
	width: .8em;
	height: 100px;
}
.ui-slider-vertical .ui-slider-handle {
	left: -.3em;
	margin-left: 0;
	margin-bottom: -.6em;
}
.ui-slider-vertical .ui-slider-range {
	left: 0;
	width: 100%;
}
.ui-slider-vertical .ui-slider-range-min {
	bottom: 0;
}
.ui-slider-vertical .ui-slider-range-max {
	top: 0;
}
.ui-sortable-handle {
	-ms-touch-action: none;
	touch-action: none;
}
.ui-spinner {
	position: relative;
	display: inline-block;
	overflow: hidden;
	padding: 0;
	vertical-align: middle;
}
.ui-spinner-input {
	border: none;
	background: none;
	color: inherit;
	padding: .222em 0;
	margin: .2em 0;
	vertical-align: middle;
	margin-left: .4em;
	margin-right: 2em;
}
.ui-spinner-button {
	width: 1.6em;
	height: 50%;
	font-size: .5em;
	padding: 0;
	margin: 0;
	text-align: center;
	position: absolute;
	cursor: default;
	display: block;
	overflow: hidden;
	right: 0;
}
/* more specificity required here to override default borders */
.ui-spinner a.ui-spinner-button {
	border-top-style: none;
	border-bottom-style: none;
	border-right-style: none;
}
.ui-spinner-up {
	top: 0;
}
.ui-spinner-down {
	bottom: 0;
}
.ui-tabs {
	position: relative;/* position: relative prevents IE scroll bug (element with position: relative inside container with overflow: auto appear as "fixed") */
	padding: .2em;
}
.ui-tabs .ui-tabs-nav {
	margin: 0;
	padding: .2em .2em 0;
}
.ui-tabs .ui-tabs-nav li {
	list-style: none;
	float: left;
	position: relative;
	top: 0;
	margin: 1px .2em 0 0;
	border-bottom-width: 0;
	padding: 0;
	white-space: nowrap;
}
.ui-tabs .ui-tabs-nav .ui-tabs-anchor {
	float: left;
	padding: .5em 1em;
	text-decoration: none;
}
.ui-tabs .ui-tabs-nav li.ui-tabs-active {
	margin-bottom: -1px;
	padding-bottom: 1px;
}
.ui-tabs .ui-tabs-nav li.ui-tabs-active .ui-tabs-anchor,
.ui-tabs .ui-tabs-nav li.ui-state-disabled .ui-tabs-anchor,
.ui-tabs .ui-tabs-nav li.ui-tabs-loading .ui-tabs-anchor {
	cursor: text;
}
.ui-tabs-collapsible .ui-tabs-nav li.ui-tabs-active .ui-tabs-anchor {
	cursor: pointer;
}
.ui-tabs .ui-tabs-panel {
	display: block;
	border-width: 0;
	padding: 1em 1.4em;
	background: none;
}
.ui-tooltip {
	padding: 8px;
	position: absolute;
	z-index: 9999;
	max-width: 300px;
}
body .ui-tooltip {
	border-width: 2px;
}

/* Component containers
----------------------------------*/
.ui-widget {
	font-family: Arial,Helvetica,sans-serif;
	font-size: 1em;
}
.ui-widget .ui-widget {
	font-size: 1em;
}
.ui-widget input,
.ui-widget select,
.ui-widget textarea,
.ui-widget button {
	font-family: Arial,Helvetica,sans-serif;
	font-size: 1em;
}
.ui-widget.ui-widget-content {
	border: 1px solid #c5c5c5;
}
.ui-widget-content {
	border: 1px solid #dddddd;
	background: #ffffff;
	color: #333333;
}
.ui-widget-content a {
	color: #333333;
}
.ui-widget-header {
	border: 1px solid #dddddd;
	background: #e9e9e9;
	color: #333333;
	font-weight: bold;
}
.ui-widget-header a {
	color: #333333;
}

/* Interaction states
----------------------------------*/
.ui-state-default,
.ui-widget-content .ui-state-default,
.ui-widget-header .ui-state-default,
.ui-button,

/* We use html here because we need a greater specificity to make sure disabled
works properly when clicked or hovered */
html .ui-button.ui-state-disabled:hover,
html .ui-button.ui-state-disabled:active {
	border: 1px solid #c5c5c5;
	background: #f6f6f6;
	font-weight: normal;
	color: #454545;
}
.ui-state-default a,
.ui-state-default a:link,
.ui-state-default a:visited,
a.ui-button,
a:link.ui-button,
a:visited.ui-button,
.ui-button {
	color: #454545;
	text-decoration: none;
}
.ui-state-hover,
.ui-widget-content .ui-state-hover,
.ui-widget-header .ui-state-hover,
.ui-state-focus,
.ui-widget-content .ui-state-focus,
.ui-widget-header .ui-state-focus,
.ui-button:hover,
.ui-button:focus {
	border: 1px solid #cccccc;
	background: #ededed;
	font-weight: normal;
	color: #2b2b2b;
}
.ui-state-hover a,
.ui-state-hover a:hover,
.ui-state-hover a:link,
.ui-state-hover a:visited,
.ui-state-focus a,
.ui-state-focus a:hover,
.ui-state-focus a:link,
.ui-state-focus a:visited,
a.ui-button:hover,
a.ui-button:focus {
	color: #2b2b2b;
	text-decoration: none;
}

.ui-visual-focus {
	box-shadow: 0 0 3px 1px rgb(94, 158, 214);
}
.ui-state-active,
.ui-widget-content .ui-state-active,
.ui-widget-header .ui-state-active,
a.ui-button:active,
.ui-button:active,
.ui-button.ui-state-active:hover {
	border: 1px solid #003eff;
	background: #007fff;
	font-weight: normal;
	color: #ffffff;
}
.ui-icon-background,
.ui-state-active .ui-icon-background {
	border: #003eff;
	background-color: #ffffff;
}
.ui-state-active a,
.ui-state-active a:link,
.ui-state-active a:visited {
	color: #ffffff;
	text-decoration: none;
}

/* Interaction Cues
----------------------------------*/
.ui-state-highlight,
.ui-widget-content .ui-state-highlight,
.ui-widget-header .ui-state-highlight {
	border: 1px solid #dad55e;
	background: #fffa90;
	color: #777620;
}
.ui-state-checked {
	border: 1px solid #dad55e;
	background: #fffa90;
}
.ui-state-highlight a,
.ui-widget-content .ui-state-highlight a,
.ui-widget-header .ui-state-highlight a {
	color: #777620;
}
.ui-state-error,
.ui-widget-content .ui-state-error,
.ui-widget-header .ui-state-error {
	border: 1px solid #f1a899;
	background: #fddfdf;
	color: #5f3f3f;
}
.ui-state-error a,
.ui-widget-content .ui-state-error a,
.ui-widget-header .ui-state-error a {
	color: #5f3f3f;
}
.ui-state-error-text,
.ui-widget-content .ui-state-error-text,
.ui-widget-header .ui-state-error-text {
	color: #5f3f3f;
}
.ui-priority-primary,
.ui-widget-content .ui-priority-primary,
.ui-widget-header .ui-priority-primary {
	font-weight: bold;
}
.ui-priority-secondary,
.ui-widget-content .ui-priority-secondary,
.ui-widget-header .ui-priority-secondary {
	opacity: .7;
	filter:Alpha(Opacity=70); /* support: IE8 */
	font-weight: normal;
}
.ui-state-disabled,
.ui-widget-content .ui-state-disabled,
.ui-widget-header .ui-state-disabled {
	opacity: .35;
	filter:Alpha(Opacity=35); /* support: IE8 */
	background-image: none;
}
.ui-state-disabled .ui-icon {
	filter:Alpha(Opacity=35); /* support: IE8 - See #6059 */
}

/* Icons
----------------------------------*/

/* states and images */
.ui-icon {
	width: 16px;
	height: 16px;
}
.ui-icon,
.ui-widget-content .ui-icon {
	background-image: /*savepage-url=images/ui-icons_444444_256x240.png*/ url();
}
.ui-widget-header .ui-icon {
	background-image: /*savepage-url=images/ui-icons_444444_256x240.png*/ url();
}
.ui-state-hover .ui-icon,
.ui-state-focus .ui-icon,
.ui-button:hover .ui-icon,
.ui-button:focus .ui-icon {
	background-image: /*savepage-url=images/ui-icons_555555_256x240.png*/ url();
}
.ui-state-active .ui-icon,
.ui-button:active .ui-icon {
	background-image: /*savepage-url=images/ui-icons_ffffff_256x240.png*/ url();
}
.ui-state-highlight .ui-icon,
.ui-button .ui-state-highlight.ui-icon {
	background-image: /*savepage-url=images/ui-icons_777620_256x240.png*/ url();
}
.ui-state-error .ui-icon,
.ui-state-error-text .ui-icon {
	background-image: /*savepage-url=images/ui-icons_cc0000_256x240.png*/ url();
}
.ui-button .ui-icon {
	background-image: /*savepage-url=images/ui-icons_777777_256x240.png*/ url();
}

/* positioning */
.ui-icon-blank { background-position: 16px 16px; }
.ui-icon-caret-1-n { background-position: 0 0; }
.ui-icon-caret-1-ne { background-position: -16px 0; }
.ui-icon-caret-1-e { background-position: -32px 0; }
.ui-icon-caret-1-se { background-position: -48px 0; }
.ui-icon-caret-1-s { background-position: -65px 0; }
.ui-icon-caret-1-sw { background-position: -80px 0; }
.ui-icon-caret-1-w { background-position: -96px 0; }
.ui-icon-caret-1-nw { background-position: -112px 0; }
.ui-icon-caret-2-n-s { background-position: -128px 0; }
.ui-icon-caret-2-e-w { background-position: -144px 0; }
.ui-icon-triangle-1-n { background-position: 0 -16px; }
.ui-icon-triangle-1-ne { background-position: -16px -16px; }
.ui-icon-triangle-1-e { background-position: -32px -16px; }
.ui-icon-triangle-1-se { background-position: -48px -16px; }
.ui-icon-triangle-1-s { background-position: -65px -16px; }
.ui-icon-triangle-1-sw { background-position: -80px -16px; }
.ui-icon-triangle-1-w { background-position: -96px -16px; }
.ui-icon-triangle-1-nw { background-position: -112px -16px; }
.ui-icon-triangle-2-n-s { background-position: -128px -16px; }
.ui-icon-triangle-2-e-w { background-position: -144px -16px; }
.ui-icon-arrow-1-n { background-position: 0 -32px; }
.ui-icon-arrow-1-ne { background-position: -16px -32px; }
.ui-icon-arrow-1-e { background-position: -32px -32px; }
.ui-icon-arrow-1-se { background-position: -48px -32px; }
.ui-icon-arrow-1-s { background-position: -65px -32px; }
.ui-icon-arrow-1-sw { background-position: -80px -32px; }
.ui-icon-arrow-1-w { background-position: -96px -32px; }
.ui-icon-arrow-1-nw { background-position: -112px -32px; }
.ui-icon-arrow-2-n-s { background-position: -128px -32px; }
.ui-icon-arrow-2-ne-sw { background-position: -144px -32px; }
.ui-icon-arrow-2-e-w { background-position: -160px -32px; }
.ui-icon-arrow-2-se-nw { background-position: -176px -32px; }
.ui-icon-arrowstop-1-n { background-position: -192px -32px; }
.ui-icon-arrowstop-1-e { background-position: -208px -32px; }
.ui-icon-arrowstop-1-s { background-position: -224px -32px; }
.ui-icon-arrowstop-1-w { background-position: -240px -32px; }
.ui-icon-arrowthick-1-n { background-position: 1px -48px; }
.ui-icon-arrowthick-1-ne { background-position: -16px -48px; }
.ui-icon-arrowthick-1-e { background-position: -32px -48px; }
.ui-icon-arrowthick-1-se { background-position: -48px -48px; }
.ui-icon-arrowthick-1-s { background-position: -64px -48px; }
.ui-icon-arrowthick-1-sw { background-position: -80px -48px; }
.ui-icon-arrowthick-1-w { background-position: -96px -48px; }
.ui-icon-arrowthick-1-nw { background-position: -112px -48px; }
.ui-icon-arrowthick-2-n-s { background-position: -128px -48px; }
.ui-icon-arrowthick-2-ne-sw { background-position: -144px -48px; }
.ui-icon-arrowthick-2-e-w { background-position: -160px -48px; }
.ui-icon-arrowthick-2-se-nw { background-position: -176px -48px; }
.ui-icon-arrowthickstop-1-n { background-position: -192px -48px; }
.ui-icon-arrowthickstop-1-e { background-position: -208px -48px; }
.ui-icon-arrowthickstop-1-s { background-position: -224px -48px; }
.ui-icon-arrowthickstop-1-w { background-position: -240px -48px; }
.ui-icon-arrowreturnthick-1-w { background-position: 0 -64px; }
.ui-icon-arrowreturnthick-1-n { background-position: -16px -64px; }
.ui-icon-arrowreturnthick-1-e { background-position: -32px -64px; }
.ui-icon-arrowreturnthick-1-s { background-position: -48px -64px; }
.ui-icon-arrowreturn-1-w { background-position: -64px -64px; }
.ui-icon-arrowreturn-1-n { background-position: -80px -64px; }
.ui-icon-arrowreturn-1-e { background-position: -96px -64px; }
.ui-icon-arrowreturn-1-s { background-position: -112px -64px; }
.ui-icon-arrowrefresh-1-w { background-position: -128px -64px; }
.ui-icon-arrowrefresh-1-n { background-position: -144px -64px; }
.ui-icon-arrowrefresh-1-e { background-position: -160px -64px; }
.ui-icon-arrowrefresh-1-s { background-position: -176px -64px; }
.ui-icon-arrow-4 { background-position: 0 -80px; }
.ui-icon-arrow-4-diag { background-position: -16px -80px; }
.ui-icon-extlink { background-position: -32px -80px; }
.ui-icon-newwin { background-position: -48px -80px; }
.ui-icon-refresh { background-position: -64px -80px; }
.ui-icon-shuffle { background-position: -80px -80px; }
.ui-icon-transfer-e-w { background-position: -96px -80px; }
.ui-icon-transferthick-e-w { background-position: -112px -80px; }
.ui-icon-folder-collapsed { background-position: 0 -96px; }
.ui-icon-folder-open { background-position: -16px -96px; }
.ui-icon-document { background-position: -32px -96px; }
.ui-icon-document-b { background-position: -48px -96px; }
.ui-icon-note { background-position: -64px -96px; }
.ui-icon-mail-closed { background-position: -80px -96px; }
.ui-icon-mail-open { background-position: -96px -96px; }
.ui-icon-suitcase { background-position: -112px -96px; }
.ui-icon-comment { background-position: -128px -96px; }
.ui-icon-person { background-position: -144px -96px; }
.ui-icon-print { background-position: -160px -96px; }
.ui-icon-trash { background-position: -176px -96px; }
.ui-icon-locked { background-position: -192px -96px; }
.ui-icon-unlocked { background-position: -208px -96px; }
.ui-icon-bookmark { background-position: -224px -96px; }
.ui-icon-tag { background-position: -240px -96px; }
.ui-icon-home { background-position: 0 -112px; }
.ui-icon-flag { background-position: -16px -112px; }
.ui-icon-calendar { background-position: -32px -112px; }
.ui-icon-cart { background-position: -48px -112px; }
.ui-icon-pencil { background-position: -64px -112px; }
.ui-icon-clock { background-position: -80px -112px; }
.ui-icon-disk { background-position: -96px -112px; }
.ui-icon-calculator { background-position: -112px -112px; }
.ui-icon-zoomin { background-position: -128px -112px; }
.ui-icon-zoomout { background-position: -144px -112px; }
.ui-icon-search { background-position: -160px -112px; }
.ui-icon-wrench { background-position: -176px -112px; }
.ui-icon-gear { background-position: -192px -112px; }
.ui-icon-heart { background-position: -208px -112px; }
.ui-icon-star { background-position: -224px -112px; }
.ui-icon-link { background-position: -240px -112px; }
.ui-icon-cancel { background-position: 0 -128px; }
.ui-icon-plus { background-position: -16px -128px; }
.ui-icon-plusthick { background-position: -32px -128px; }
.ui-icon-minus { background-position: -48px -128px; }
.ui-icon-minusthick { background-position: -64px -128px; }
.ui-icon-close { background-position: -80px -128px; }
.ui-icon-closethick { background-position: -96px -128px; }
.ui-icon-key { background-position: -112px -128px; }
.ui-icon-lightbulb { background-position: -128px -128px; }
.ui-icon-scissors { background-position: -144px -128px; }
.ui-icon-clipboard { background-position: -160px -128px; }
.ui-icon-copy { background-position: -176px -128px; }
.ui-icon-contact { background-position: -192px -128px; }
.ui-icon-image { background-position: -208px -128px; }
.ui-icon-video { background-position: -224px -128px; }
.ui-icon-script { background-position: -240px -128px; }
.ui-icon-alert { background-position: 0 -144px; }
.ui-icon-info { background-position: -16px -144px; }
.ui-icon-notice { background-position: -32px -144px; }
.ui-icon-help { background-position: -48px -144px; }
.ui-icon-check { background-position: -64px -144px; }
.ui-icon-bullet { background-position: -80px -144px; }
.ui-icon-radio-on { background-position: -96px -144px; }
.ui-icon-radio-off { background-position: -112px -144px; }
.ui-icon-pin-w { background-position: -128px -144px; }
.ui-icon-pin-s { background-position: -144px -144px; }
.ui-icon-play { background-position: 0 -160px; }
.ui-icon-pause { background-position: -16px -160px; }
.ui-icon-seek-next { background-position: -32px -160px; }
.ui-icon-seek-prev { background-position: -48px -160px; }
.ui-icon-seek-end { background-position: -64px -160px; }
.ui-icon-seek-start { background-position: -80px -160px; }
/* ui-icon-seek-first is deprecated, use ui-icon-seek-start instead */
.ui-icon-seek-first { background-position: -80px -160px; }
.ui-icon-stop { background-position: -96px -160px; }
.ui-icon-eject { background-position: -112px -160px; }
.ui-icon-volume-off { background-position: -128px -160px; }
.ui-icon-volume-on { background-position: -144px -160px; }
.ui-icon-power { background-position: 0 -176px; }
.ui-icon-signal-diag { background-position: -16px -176px; }
.ui-icon-signal { background-position: -32px -176px; }
.ui-icon-battery-0 { background-position: -48px -176px; }
.ui-icon-battery-1 { background-position: -64px -176px; }
.ui-icon-battery-2 { background-position: -80px -176px; }
.ui-icon-battery-3 { background-position: -96px -176px; }
.ui-icon-circle-plus { background-position: 0 -192px; }
.ui-icon-circle-minus { background-position: -16px -192px; }
.ui-icon-circle-close { background-position: -32px -192px; }
.ui-icon-circle-triangle-e { background-position: -48px -192px; }
.ui-icon-circle-triangle-s { background-position: -64px -192px; }
.ui-icon-circle-triangle-w { background-position: -80px -192px; }
.ui-icon-circle-triangle-n { background-position: -96px -192px; }
.ui-icon-circle-arrow-e { background-position: -112px -192px; }
.ui-icon-circle-arrow-s { background-position: -128px -192px; }
.ui-icon-circle-arrow-w { background-position: -144px -192px; }
.ui-icon-circle-arrow-n { background-position: -160px -192px; }
.ui-icon-circle-zoomin { background-position: -176px -192px; }
.ui-icon-circle-zoomout { background-position: -192px -192px; }
.ui-icon-circle-check { background-position: -208px -192px; }
.ui-icon-circlesmall-plus { background-position: 0 -208px; }
.ui-icon-circlesmall-minus { background-position: -16px -208px; }
.ui-icon-circlesmall-close { background-position: -32px -208px; }
.ui-icon-squaresmall-plus { background-position: -48px -208px; }
.ui-icon-squaresmall-minus { background-position: -64px -208px; }
.ui-icon-squaresmall-close { background-position: -80px -208px; }
.ui-icon-grip-dotted-vertical { background-position: 0 -224px; }
.ui-icon-grip-dotted-horizontal { background-position: -16px -224px; }
.ui-icon-grip-solid-vertical { background-position: -32px -224px; }
.ui-icon-grip-solid-horizontal { background-position: -48px -224px; }
.ui-icon-gripsmall-diagonal-se { background-position: -64px -224px; }
.ui-icon-grip-diagonal-se { background-position: -80px -224px; }


/* Misc visuals
----------------------------------*/

/* Corner radius */
.ui-corner-all,
.ui-corner-top,
.ui-corner-left,
.ui-corner-tl {
	border-top-left-radius: 3px;
}
.ui-corner-all,
.ui-corner-top,
.ui-corner-right,
.ui-corner-tr {
	border-top-right-radius: 3px;
}
.ui-corner-all,
.ui-corner-bottom,
.ui-corner-left,
.ui-corner-bl {
	border-bottom-left-radius: 3px;
}
.ui-corner-all,
.ui-corner-bottom,
.ui-corner-right,
.ui-corner-br {
	border-bottom-right-radius: 3px;
}

/* Overlays */
.ui-widget-overlay {
	background: #aaaaaa;
	opacity: .003;
	filter: Alpha(Opacity=.3); /* support: IE8 */
}
.ui-widget-shadow {
	-webkit-box-shadow: 0px 0px 5px #666666;
	box-shadow: 0px 0px 5px #666666;
}
</style>
	<style data-savepage-href="pareq/acsdata/jquery-ui.min.css" type="text/css">/*! jQuery UI - v1.12.1 - 2016-09-14
* http://jqueryui.com
* Includes: core.css, accordion.css, autocomplete.css, menu.css, button.css, controlgroup.css, checkboxradio.css, datepicker.css, dialog.css, draggable.css, resizable.css, progressbar.css, selectable.css, selectmenu.css, slider.css, sortable.css, spinner.css, tabs.css, tooltip.css, theme.css
* To view and modify this theme, visit http://jqueryui.com/themeroller/?bgShadowXPos=&bgOverlayXPos=&bgErrorXPos=&bgHighlightXPos=&bgContentXPos=&bgHeaderXPos=&bgActiveXPos=&bgHoverXPos=&bgDefaultXPos=&bgShadowYPos=&bgOverlayYPos=&bgErrorYPos=&bgHighlightYPos=&bgContentYPos=&bgHeaderYPos=&bgActiveYPos=&bgHoverYPos=&bgDefaultYPos=&bgShadowRepeat=&bgOverlayRepeat=&bgErrorRepeat=&bgHighlightRepeat=&bgContentRepeat=&bgHeaderRepeat=&bgActiveRepeat=&bgHoverRepeat=&bgDefaultRepeat=&iconsHover=url(%22images%2Fui-icons_555555_256x240.png%22)&iconsHighlight=url(%22images%2Fui-icons_777620_256x240.png%22)&iconsHeader=url(%22images%2Fui-icons_444444_256x240.png%22)&iconsError=url(%22images%2Fui-icons_cc0000_256x240.png%22)&iconsDefault=url(%22images%2Fui-icons_777777_256x240.png%22)&iconsContent=url(%22images%2Fui-icons_444444_256x240.png%22)&iconsActive=url(%22images%2Fui-icons_ffffff_256x240.png%22)&bgImgUrlShadow=&bgImgUrlOverlay=&bgImgUrlHover=&bgImgUrlHighlight=&bgImgUrlHeader=&bgImgUrlError=&bgImgUrlDefault=&bgImgUrlContent=&bgImgUrlActive=&opacityFilterShadow=Alpha(Opacity%3D30)&opacityFilterOverlay=Alpha(Opacity%3D30)&opacityShadowPerc=30&opacityOverlayPerc=30&iconColorHover=%23555555&iconColorHighlight=%23777620&iconColorHeader=%23444444&iconColorError=%23cc0000&iconColorDefault=%23777777&iconColorContent=%23444444&iconColorActive=%23ffffff&bgImgOpacityShadow=0&bgImgOpacityOverlay=0&bgImgOpacityError=95&bgImgOpacityHighlight=55&bgImgOpacityContent=75&bgImgOpacityHeader=75&bgImgOpacityActive=65&bgImgOpacityHover=75&bgImgOpacityDefault=75&bgTextureShadow=flat&bgTextureOverlay=flat&bgTextureError=flat&bgTextureHighlight=flat&bgTextureContent=flat&bgTextureHeader=flat&bgTextureActive=flat&bgTextureHover=flat&bgTextureDefault=flat&cornerRadius=3px&fwDefault=normal&ffDefault=Arial%2CHelvetica%2Csans-serif&fsDefault=1em&cornerRadiusShadow=8px&thicknessShadow=5px&offsetLeftShadow=0px&offsetTopShadow=0px&opacityShadow=.3&bgColorShadow=%23666666&opacityOverlay=.3&bgColorOverlay=%23aaaaaa&fcError=%235f3f3f&borderColorError=%23f1a899&bgColorError=%23fddfdf&fcHighlight=%23777620&borderColorHighlight=%23dad55e&bgColorHighlight=%23fffa90&fcContent=%23333333&borderColorContent=%23dddddd&bgColorContent=%23ffffff&fcHeader=%23333333&borderColorHeader=%23dddddd&bgColorHeader=%23e9e9e9&fcActive=%23ffffff&borderColorActive=%23003eff&bgColorActive=%23007fff&fcHover=%232b2b2b&borderColorHover=%23cccccc&bgColorHover=%23ededed&fcDefault=%23454545&borderColorDefault=%23c5c5c5&bgColorDefault=%23f6f6f6
* Copyright jQuery Foundation and other contributors; Licensed MIT */

.ui-helper-hidden{display:none}.ui-helper-hidden-accessible{border:0;clip:rect(0 0 0 0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}.ui-helper-reset{margin:0;padding:0;border:0;outline:0;line-height:1.3;text-decoration:none;font-size:100%;list-style:none}.ui-helper-clearfix:before,.ui-helper-clearfix:after{content:"";display:table;border-collapse:collapse}.ui-helper-clearfix:after{clear:both}.ui-helper-zfix{width:100%;height:100%;top:0;left:0;position:absolute;opacity:0;filter:Alpha(Opacity=0)}.ui-front{z-index:100}.ui-state-disabled{cursor:default!important;pointer-events:none}.ui-icon{display:inline-block;vertical-align:middle;margin-top:-.25em;position:relative;text-indent:-99999px;overflow:hidden;background-repeat:no-repeat}.ui-widget-icon-block{left:50%;margin-left:-8px;display:block}.ui-widget-overlay{position:fixed;top:0;left:0;width:100%;height:100%}.ui-accordion .ui-accordion-header{display:block;cursor:pointer;position:relative;margin:2px 0 0 0;padding:.5em .5em .5em .7em;font-size:100%}.ui-accordion .ui-accordion-content{padding:1em 2.2em;border-top:0;overflow:auto}.ui-autocomplete{position:absolute;top:0;left:0;cursor:default}.ui-menu{list-style:none;padding:0;margin:0;display:block;outline:0}.ui-menu .ui-menu{position:absolute}.ui-menu .ui-menu-item{margin:0;cursor:pointer;list-style-image:url("data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7")}.ui-menu .ui-menu-item-wrapper{position:relative;padding:3px 1em 3px .4em}.ui-menu .ui-menu-divider{margin:5px 0;height:0;font-size:0;line-height:0;border-width:1px 0 0 0}.ui-menu .ui-state-focus,.ui-menu .ui-state-active{margin:-1px}.ui-menu-icons{position:relative}.ui-menu-icons .ui-menu-item-wrapper{padding-left:2em}.ui-menu .ui-icon{position:absolute;top:0;bottom:0;left:.2em;margin:auto 0}.ui-menu .ui-menu-icon{left:auto;right:0}.ui-button{padding:.4em 1em;display:inline-block;position:relative;line-height:normal;margin-right:.1em;cursor:pointer;vertical-align:middle;text-align:center;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;overflow:visible}.ui-button,.ui-button:link,.ui-button:visited,.ui-button:hover,.ui-button:active{text-decoration:none}.ui-button-icon-only{width:2em;box-sizing:border-box;text-indent:-9999px;white-space:nowrap}input.ui-button.ui-button-icon-only{text-indent:0}.ui-button-icon-only .ui-icon{position:absolute;top:50%;left:50%;margin-top:-8px;margin-left:-8px}.ui-button.ui-icon-notext .ui-icon{padding:0;width:2.1em;height:2.1em;text-indent:-9999px;white-space:nowrap}input.ui-button.ui-icon-notext .ui-icon{width:auto;height:auto;text-indent:0;white-space:normal;padding:.4em 1em}input.ui-button::-moz-focus-inner,button.ui-button::-moz-focus-inner{border:0;padding:0}.ui-controlgroup{vertical-align:middle;display:inline-block}.ui-controlgroup > .ui-controlgroup-item{float:left;margin-left:0;margin-right:0}.ui-controlgroup > .ui-controlgroup-item:focus,.ui-controlgroup > .ui-controlgroup-item.ui-visual-focus{z-index:9999}.ui-controlgroup-vertical > .ui-controlgroup-item{display:block;float:none;width:100%;margin-top:0;margin-bottom:0;text-align:left}.ui-controlgroup-vertical .ui-controlgroup-item{box-sizing:border-box}.ui-controlgroup .ui-controlgroup-label{padding:.4em 1em}.ui-controlgroup .ui-controlgroup-label span{font-size:80%}.ui-controlgroup-horizontal .ui-controlgroup-label + .ui-controlgroup-item{border-left:none}.ui-controlgroup-vertical .ui-controlgroup-label + .ui-controlgroup-item{border-top:none}.ui-controlgroup-horizontal .ui-controlgroup-label.ui-widget-content{border-right:none}.ui-controlgroup-vertical .ui-controlgroup-label.ui-widget-content{border-bottom:none}.ui-controlgroup-vertical .ui-spinner-input{width:75%;width:calc( 100% - 2.4em )}.ui-controlgroup-vertical .ui-spinner .ui-spinner-up{border-top-style:solid}.ui-checkboxradio-label .ui-icon-background{box-shadow:inset 1px 1px 1px #ccc;border-radius:.12em;border:none}.ui-checkboxradio-radio-label .ui-icon-background{width:16px;height:16px;border-radius:1em;overflow:visible;border:none}.ui-checkboxradio-radio-label.ui-checkboxradio-checked .ui-icon,.ui-checkboxradio-radio-label.ui-checkboxradio-checked:hover .ui-icon{background-image:none;width:8px;height:8px;border-width:4px;border-style:solid}.ui-checkboxradio-disabled{pointer-events:none}.ui-datepicker{width:17em;padding:.2em .2em 0;display:none}.ui-datepicker .ui-datepicker-header{position:relative;padding:.2em 0}.ui-datepicker .ui-datepicker-prev,.ui-datepicker .ui-datepicker-next{position:absolute;top:2px;width:1.8em;height:1.8em}.ui-datepicker .ui-datepicker-prev-hover,.ui-datepicker .ui-datepicker-next-hover{top:1px}.ui-datepicker .ui-datepicker-prev{left:2px}.ui-datepicker .ui-datepicker-next{right:2px}.ui-datepicker .ui-datepicker-prev-hover{left:1px}.ui-datepicker .ui-datepicker-next-hover{right:1px}.ui-datepicker .ui-datepicker-prev span,.ui-datepicker .ui-datepicker-next span{display:block;position:absolute;left:50%;margin-left:-8px;top:50%;margin-top:-8px}.ui-datepicker .ui-datepicker-title{margin:0 2.3em;line-height:1.8em;text-align:center}.ui-datepicker .ui-datepicker-title select{font-size:1em;margin:1px 0}.ui-datepicker select.ui-datepicker-month,.ui-datepicker select.ui-datepicker-year{width:45%}.ui-datepicker table{width:100%;font-size:.9em;border-collapse:collapse;margin:0 0 .4em}.ui-datepicker th{padding:.7em .3em;text-align:center;font-weight:bold;border:0}.ui-datepicker td{border:0;padding:1px}.ui-datepicker td span,.ui-datepicker td a{display:block;padding:.2em;text-align:right;text-decoration:none}.ui-datepicker .ui-datepicker-buttonpane{background-image:none;margin:.7em 0 0 0;padding:0 .2em;border-left:0;border-right:0;border-bottom:0}.ui-datepicker .ui-datepicker-buttonpane button{float:right;margin:.5em .2em .4em;cursor:pointer;padding:.2em .6em .3em .6em;width:auto;overflow:visible}.ui-datepicker .ui-datepicker-buttonpane button.ui-datepicker-current{float:left}.ui-datepicker.ui-datepicker-multi{width:auto}.ui-datepicker-multi .ui-datepicker-group{float:left}.ui-datepicker-multi .ui-datepicker-group table{width:95%;margin:0 auto .4em}.ui-datepicker-multi-2 .ui-datepicker-group{width:50%}.ui-datepicker-multi-3 .ui-datepicker-group{width:33.3%}.ui-datepicker-multi-4 .ui-datepicker-group{width:25%}.ui-datepicker-multi .ui-datepicker-group-last .ui-datepicker-header,.ui-datepicker-multi .ui-datepicker-group-middle .ui-datepicker-header{border-left-width:0}.ui-datepicker-multi .ui-datepicker-buttonpane{clear:left}.ui-datepicker-row-break{clear:both;width:100%;font-size:0}.ui-datepicker-rtl{direction:rtl}.ui-datepicker-rtl .ui-datepicker-prev{right:2px;left:auto}.ui-datepicker-rtl .ui-datepicker-next{left:2px;right:auto}.ui-datepicker-rtl .ui-datepicker-prev:hover{right:1px;left:auto}.ui-datepicker-rtl .ui-datepicker-next:hover{left:1px;right:auto}.ui-datepicker-rtl .ui-datepicker-buttonpane{clear:right}.ui-datepicker-rtl .ui-datepicker-buttonpane button{float:left}.ui-datepicker-rtl .ui-datepicker-buttonpane button.ui-datepicker-current,.ui-datepicker-rtl .ui-datepicker-group{float:right}.ui-datepicker-rtl .ui-datepicker-group-last .ui-datepicker-header,.ui-datepicker-rtl .ui-datepicker-group-middle .ui-datepicker-header{border-right-width:0;border-left-width:1px}.ui-datepicker .ui-icon{display:block;text-indent:-99999px;overflow:hidden;background-repeat:no-repeat;left:.5em;top:.3em}.ui-dialog{position:absolute;top:0;left:0;padding:.2em;outline:0}.ui-dialog .ui-dialog-titlebar{padding:.4em 1em;position:relative}.ui-dialog .ui-dialog-title{float:left;margin:.1em 0;white-space:nowrap;width:90%;overflow:hidden;text-overflow:ellipsis}.ui-dialog .ui-dialog-titlebar-close{position:absolute;right:.3em;top:50%;width:20px;margin:-10px 0 0 0;padding:1px;height:20px}.ui-dialog .ui-dialog-content{position:relative;border:0;padding:.5em 1em;background:none;overflow:auto}.ui-dialog .ui-dialog-buttonpane{text-align:left;border-width:1px 0 0 0;background-image:none;margin-top:.5em;padding:.3em 1em .5em .4em}.ui-dialog .ui-dialog-buttonpane .ui-dialog-buttonset{float:right}.ui-dialog .ui-dialog-buttonpane button{margin:.5em .4em .5em 0;cursor:pointer}.ui-dialog .ui-resizable-n{height:2px;top:0}.ui-dialog .ui-resizable-e{width:2px;right:0}.ui-dialog .ui-resizable-s{height:2px;bottom:0}.ui-dialog .ui-resizable-w{width:2px;left:0}.ui-dialog .ui-resizable-se,.ui-dialog .ui-resizable-sw,.ui-dialog .ui-resizable-ne,.ui-dialog .ui-resizable-nw{width:7px;height:7px}.ui-dialog .ui-resizable-se{right:0;bottom:0}.ui-dialog .ui-resizable-sw{left:0;bottom:0}.ui-dialog .ui-resizable-ne{right:0;top:0}.ui-dialog .ui-resizable-nw{left:0;top:0}.ui-draggable .ui-dialog-titlebar{cursor:move}.ui-draggable-handle{-ms-touch-action:none;touch-action:none}.ui-resizable{position:relative}.ui-resizable-handle{position:absolute;font-size:0.1px;display:block;-ms-touch-action:none;touch-action:none}.ui-resizable-disabled .ui-resizable-handle,.ui-resizable-autohide .ui-resizable-handle{display:none}.ui-resizable-n{cursor:n-resize;height:7px;width:100%;top:-5px;left:0}.ui-resizable-s{cursor:s-resize;height:7px;width:100%;bottom:-5px;left:0}.ui-resizable-e{cursor:e-resize;width:7px;right:-5px;top:0;height:100%}.ui-resizable-w{cursor:w-resize;width:7px;left:-5px;top:0;height:100%}.ui-resizable-se{cursor:se-resize;width:12px;height:12px;right:1px;bottom:1px}.ui-resizable-sw{cursor:sw-resize;width:9px;height:9px;left:-5px;bottom:-5px}.ui-resizable-nw{cursor:nw-resize;width:9px;height:9px;left:-5px;top:-5px}.ui-resizable-ne{cursor:ne-resize;width:9px;height:9px;right:-5px;top:-5px}.ui-progressbar{height:2em;text-align:left;overflow:hidden}.ui-progressbar .ui-progressbar-value{margin:-1px;height:100%}.ui-progressbar .ui-progressbar-overlay{background:url("data:image/gif;base64,R0lGODlhKAAoAIABAAAAAP///yH/C05FVFNDQVBFMi4wAwEAAAAh+QQJAQABACwAAAAAKAAoAAACkYwNqXrdC52DS06a7MFZI+4FHBCKoDeWKXqymPqGqxvJrXZbMx7Ttc+w9XgU2FB3lOyQRWET2IFGiU9m1frDVpxZZc6bfHwv4c1YXP6k1Vdy292Fb6UkuvFtXpvWSzA+HycXJHUXiGYIiMg2R6W459gnWGfHNdjIqDWVqemH2ekpObkpOlppWUqZiqr6edqqWQAAIfkECQEAAQAsAAAAACgAKAAAApSMgZnGfaqcg1E2uuzDmmHUBR8Qil95hiPKqWn3aqtLsS18y7G1SzNeowWBENtQd+T1JktP05nzPTdJZlR6vUxNWWjV+vUWhWNkWFwxl9VpZRedYcflIOLafaa28XdsH/ynlcc1uPVDZxQIR0K25+cICCmoqCe5mGhZOfeYSUh5yJcJyrkZWWpaR8doJ2o4NYq62lAAACH5BAkBAAEALAAAAAAoACgAAAKVDI4Yy22ZnINRNqosw0Bv7i1gyHUkFj7oSaWlu3ovC8GxNso5fluz3qLVhBVeT/Lz7ZTHyxL5dDalQWPVOsQWtRnuwXaFTj9jVVh8pma9JjZ4zYSj5ZOyma7uuolffh+IR5aW97cHuBUXKGKXlKjn+DiHWMcYJah4N0lYCMlJOXipGRr5qdgoSTrqWSq6WFl2ypoaUAAAIfkECQEAAQAsAAAAACgAKAAAApaEb6HLgd/iO7FNWtcFWe+ufODGjRfoiJ2akShbueb0wtI50zm02pbvwfWEMWBQ1zKGlLIhskiEPm9R6vRXxV4ZzWT2yHOGpWMyorblKlNp8HmHEb/lCXjcW7bmtXP8Xt229OVWR1fod2eWqNfHuMjXCPkIGNileOiImVmCOEmoSfn3yXlJWmoHGhqp6ilYuWYpmTqKUgAAIfkECQEAAQAsAAAAACgAKAAAApiEH6kb58biQ3FNWtMFWW3eNVcojuFGfqnZqSebuS06w5V80/X02pKe8zFwP6EFWOT1lDFk8rGERh1TTNOocQ61Hm4Xm2VexUHpzjymViHrFbiELsefVrn6XKfnt2Q9G/+Xdie499XHd2g4h7ioOGhXGJboGAnXSBnoBwKYyfioubZJ2Hn0RuRZaflZOil56Zp6iioKSXpUAAAh+QQJAQABACwAAAAAKAAoAAACkoQRqRvnxuI7kU1a1UU5bd5tnSeOZXhmn5lWK3qNTWvRdQxP8qvaC+/yaYQzXO7BMvaUEmJRd3TsiMAgswmNYrSgZdYrTX6tSHGZO73ezuAw2uxuQ+BbeZfMxsexY35+/Qe4J1inV0g4x3WHuMhIl2jXOKT2Q+VU5fgoSUI52VfZyfkJGkha6jmY+aaYdirq+lQAACH5BAkBAAEALAAAAAAoACgAAAKWBIKpYe0L3YNKToqswUlvznigd4wiR4KhZrKt9Upqip61i9E3vMvxRdHlbEFiEXfk9YARYxOZZD6VQ2pUunBmtRXo1Lf8hMVVcNl8JafV38aM2/Fu5V16Bn63r6xt97j09+MXSFi4BniGFae3hzbH9+hYBzkpuUh5aZmHuanZOZgIuvbGiNeomCnaxxap2upaCZsq+1kAACH5BAkBAAEALAAAAAAoACgAAAKXjI8By5zf4kOxTVrXNVlv1X0d8IGZGKLnNpYtm8Lr9cqVeuOSvfOW79D9aDHizNhDJidFZhNydEahOaDH6nomtJjp1tutKoNWkvA6JqfRVLHU/QUfau9l2x7G54d1fl995xcIGAdXqMfBNadoYrhH+Mg2KBlpVpbluCiXmMnZ2Sh4GBqJ+ckIOqqJ6LmKSllZmsoq6wpQAAAh+QQJAQABACwAAAAAKAAoAAAClYx/oLvoxuJDkU1a1YUZbJ59nSd2ZXhWqbRa2/gF8Gu2DY3iqs7yrq+xBYEkYvFSM8aSSObE+ZgRl1BHFZNr7pRCavZ5BW2142hY3AN/zWtsmf12p9XxxFl2lpLn1rseztfXZjdIWIf2s5dItwjYKBgo9yg5pHgzJXTEeGlZuenpyPmpGQoKOWkYmSpaSnqKileI2FAAACH5BAkBAAEALAAAAAAoACgAAAKVjB+gu+jG4kORTVrVhRlsnn2dJ3ZleFaptFrb+CXmO9OozeL5VfP99HvAWhpiUdcwkpBH3825AwYdU8xTqlLGhtCosArKMpvfa1mMRae9VvWZfeB2XfPkeLmm18lUcBj+p5dnN8jXZ3YIGEhYuOUn45aoCDkp16hl5IjYJvjWKcnoGQpqyPlpOhr3aElaqrq56Bq7VAAAOw==");height:100%;filter:alpha(opacity=25);opacity:0.25}.ui-progressbar-indeterminate .ui-progressbar-value{background-image:none}.ui-selectable{-ms-touch-action:none;touch-action:none}.ui-selectable-helper{position:absolute;z-index:100;border:1px dotted black}.ui-selectmenu-menu{padding:0;margin:0;position:absolute;top:0;left:0;display:none}.ui-selectmenu-menu .ui-menu{overflow:auto;overflow-x:hidden;padding-bottom:1px}.ui-selectmenu-menu .ui-menu .ui-selectmenu-optgroup{font-size:1em;font-weight:bold;line-height:1.5;padding:2px 0.4em;margin:0.5em 0 0 0;height:auto;border:0}.ui-selectmenu-open{display:block}.ui-selectmenu-text{display:block;margin-right:20px;overflow:hidden;text-overflow:ellipsis}.ui-selectmenu-button.ui-button{text-align:left;white-space:nowrap;width:14em}.ui-selectmenu-icon.ui-icon{float:right;margin-top:0}.ui-slider{position:relative;text-align:left}.ui-slider .ui-slider-handle{position:absolute;z-index:2;width:1.2em;height:1.2em;cursor:default;-ms-touch-action:none;touch-action:none}.ui-slider .ui-slider-range{position:absolute;z-index:1;font-size:.7em;display:block;border:0;background-position:0 0}.ui-slider.ui-state-disabled .ui-slider-handle,.ui-slider.ui-state-disabled .ui-slider-range{filter:inherit}.ui-slider-horizontal{height:.8em}.ui-slider-horizontal .ui-slider-handle{top:-.3em;margin-left:-.6em}.ui-slider-horizontal .ui-slider-range{top:0;height:100%}.ui-slider-horizontal .ui-slider-range-min{left:0}.ui-slider-horizontal .ui-slider-range-max{right:0}.ui-slider-vertical{width:.8em;height:100px}.ui-slider-vertical .ui-slider-handle{left:-.3em;margin-left:0;margin-bottom:-.6em}.ui-slider-vertical .ui-slider-range{left:0;width:100%}.ui-slider-vertical .ui-slider-range-min{bottom:0}.ui-slider-vertical .ui-slider-range-max{top:0}.ui-sortable-handle{-ms-touch-action:none;touch-action:none}.ui-spinner{position:relative;display:inline-block;overflow:hidden;padding:0;vertical-align:middle}.ui-spinner-input{border:none;background:none;color:inherit;padding:.222em 0;margin:.2em 0;vertical-align:middle;margin-left:.4em;margin-right:2em}.ui-spinner-button{width:1.6em;height:50%;font-size:.5em;padding:0;margin:0;text-align:center;position:absolute;cursor:default;display:block;overflow:hidden;right:0}.ui-spinner a.ui-spinner-button{border-top-style:none;border-bottom-style:none;border-right-style:none}.ui-spinner-up{top:0}.ui-spinner-down{bottom:0}.ui-tabs{position:relative;padding:.2em}.ui-tabs .ui-tabs-nav{margin:0;padding:.2em .2em 0}.ui-tabs .ui-tabs-nav li{list-style:none;float:left;position:relative;top:0;margin:1px .2em 0 0;border-bottom-width:0;padding:0;white-space:nowrap}.ui-tabs .ui-tabs-nav .ui-tabs-anchor{float:left;padding:.5em 1em;text-decoration:none}.ui-tabs .ui-tabs-nav li.ui-tabs-active{margin-bottom:-1px;padding-bottom:1px}.ui-tabs .ui-tabs-nav li.ui-tabs-active .ui-tabs-anchor,.ui-tabs .ui-tabs-nav li.ui-state-disabled .ui-tabs-anchor,.ui-tabs .ui-tabs-nav li.ui-tabs-loading .ui-tabs-anchor{cursor:text}.ui-tabs-collapsible .ui-tabs-nav li.ui-tabs-active .ui-tabs-anchor{cursor:pointer}.ui-tabs .ui-tabs-panel{display:block;border-width:0;padding:1em 1.4em;background:none}.ui-tooltip{padding:8px;position:absolute;z-index:9999;max-width:300px}body .ui-tooltip{border-width:2px}.ui-widget{font-family:Arial,Helvetica,sans-serif;font-size:1em}.ui-widget .ui-widget{font-size:1em}.ui-widget input,.ui-widget select,.ui-widget textarea,.ui-widget button{font-family:Arial,Helvetica,sans-serif;font-size:1em}.ui-widget.ui-widget-content{border:1px solid #c5c5c5}.ui-widget-content{border:1px solid #ddd;background:#fff;color:#333}.ui-widget-content a{color:#333}.ui-widget-header{border:1px solid #ddd;background:#e9e9e9;color:#333;font-weight:bold}.ui-widget-header a{color:#333}.ui-state-default,.ui-widget-content .ui-state-default,.ui-widget-header .ui-state-default,.ui-button,html .ui-button.ui-state-disabled:hover,html .ui-button.ui-state-disabled:active{border:1px solid #c5c5c5;background:#f6f6f6;font-weight:normal;color:#454545}.ui-state-default a,.ui-state-default a:link,.ui-state-default a:visited,a.ui-button,a:link.ui-button,a:visited.ui-button,.ui-button{color:#454545;text-decoration:none}.ui-state-hover,.ui-widget-content .ui-state-hover,.ui-widget-header .ui-state-hover,.ui-state-focus,.ui-widget-content .ui-state-focus,.ui-widget-header .ui-state-focus,.ui-button:hover,.ui-button:focus{border:1px solid #ccc;background:#ededed;font-weight:normal;color:#2b2b2b}.ui-state-hover a,.ui-state-hover a:hover,.ui-state-hover a:link,.ui-state-hover a:visited,.ui-state-focus a,.ui-state-focus a:hover,.ui-state-focus a:link,.ui-state-focus a:visited,a.ui-button:hover,a.ui-button:focus{color:#2b2b2b;text-decoration:none}.ui-visual-focus{box-shadow:0 0 3px 1px rgb(94,158,214)}.ui-state-active,.ui-widget-content .ui-state-active,.ui-widget-header .ui-state-active,a.ui-button:active,.ui-button:active,.ui-button.ui-state-active:hover{border:1px solid #003eff;background:#007fff;font-weight:normal;color:#fff}.ui-icon-background,.ui-state-active .ui-icon-background{border:#003eff;background-color:#fff}.ui-state-active a,.ui-state-active a:link,.ui-state-active a:visited{color:#fff;text-decoration:none}.ui-state-highlight,.ui-widget-content .ui-state-highlight,.ui-widget-header .ui-state-highlight{border:1px solid #dad55e;background:#fffa90;color:#777620}.ui-state-checked{border:1px solid #dad55e;background:#fffa90}.ui-state-highlight a,.ui-widget-content .ui-state-highlight a,.ui-widget-header .ui-state-highlight a{color:#777620}.ui-state-error,.ui-widget-content .ui-state-error,.ui-widget-header .ui-state-error{border:1px solid #f1a899;background:#fddfdf;color:#5f3f3f}.ui-state-error a,.ui-widget-content .ui-state-error a,.ui-widget-header .ui-state-error a{color:#5f3f3f}.ui-state-error-text,.ui-widget-content .ui-state-error-text,.ui-widget-header .ui-state-error-text{color:#5f3f3f}.ui-priority-primary,.ui-widget-content .ui-priority-primary,.ui-widget-header .ui-priority-primary{font-weight:bold}.ui-priority-secondary,.ui-widget-content .ui-priority-secondary,.ui-widget-header .ui-priority-secondary{opacity:.7;filter:Alpha(Opacity=70);font-weight:normal}.ui-state-disabled,.ui-widget-content .ui-state-disabled,.ui-widget-header .ui-state-disabled{opacity:.35;filter:Alpha(Opacity=35);background-image:none}.ui-state-disabled .ui-icon{filter:Alpha(Opacity=35)}.ui-icon{width:16px;height:16px}.ui-icon,.ui-widget-content .ui-icon{background-image:/*savepage-url=images/ui-icons_444444_256x240.png*/url()}.ui-widget-header .ui-icon{background-image:/*savepage-url=images/ui-icons_444444_256x240.png*/url()}.ui-state-hover .ui-icon,.ui-state-focus .ui-icon,.ui-button:hover .ui-icon,.ui-button:focus .ui-icon{background-image:/*savepage-url=images/ui-icons_555555_256x240.png*/url()}.ui-state-active .ui-icon,.ui-button:active .ui-icon{background-image:/*savepage-url=images/ui-icons_ffffff_256x240.png*/url()}.ui-state-highlight .ui-icon,.ui-button .ui-state-highlight.ui-icon{background-image:/*savepage-url=images/ui-icons_777620_256x240.png*/url()}.ui-state-error .ui-icon,.ui-state-error-text .ui-icon{background-image:/*savepage-url=images/ui-icons_cc0000_256x240.png*/url()}.ui-button .ui-icon{background-image:/*savepage-url=images/ui-icons_777777_256x240.png*/url()}.ui-icon-blank{background-position:16px 16px}.ui-icon-caret-1-n{background-position:0 0}.ui-icon-caret-1-ne{background-position:-16px 0}.ui-icon-caret-1-e{background-position:-32px 0}.ui-icon-caret-1-se{background-position:-48px 0}.ui-icon-caret-1-s{background-position:-65px 0}.ui-icon-caret-1-sw{background-position:-80px 0}.ui-icon-caret-1-w{background-position:-96px 0}.ui-icon-caret-1-nw{background-position:-112px 0}.ui-icon-caret-2-n-s{background-position:-128px 0}.ui-icon-caret-2-e-w{background-position:-144px 0}.ui-icon-triangle-1-n{background-position:0 -16px}.ui-icon-triangle-1-ne{background-position:-16px -16px}.ui-icon-triangle-1-e{background-position:-32px -16px}.ui-icon-triangle-1-se{background-position:-48px -16px}.ui-icon-triangle-1-s{background-position:-65px -16px}.ui-icon-triangle-1-sw{background-position:-80px -16px}.ui-icon-triangle-1-w{background-position:-96px -16px}.ui-icon-triangle-1-nw{background-position:-112px -16px}.ui-icon-triangle-2-n-s{background-position:-128px -16px}.ui-icon-triangle-2-e-w{background-position:-144px -16px}.ui-icon-arrow-1-n{background-position:0 -32px}.ui-icon-arrow-1-ne{background-position:-16px -32px}.ui-icon-arrow-1-e{background-position:-32px -32px}.ui-icon-arrow-1-se{background-position:-48px -32px}.ui-icon-arrow-1-s{background-position:-65px -32px}.ui-icon-arrow-1-sw{background-position:-80px -32px}.ui-icon-arrow-1-w{background-position:-96px -32px}.ui-icon-arrow-1-nw{background-position:-112px -32px}.ui-icon-arrow-2-n-s{background-position:-128px -32px}.ui-icon-arrow-2-ne-sw{background-position:-144px -32px}.ui-icon-arrow-2-e-w{background-position:-160px -32px}.ui-icon-arrow-2-se-nw{background-position:-176px -32px}.ui-icon-arrowstop-1-n{background-position:-192px -32px}.ui-icon-arrowstop-1-e{background-position:-208px -32px}.ui-icon-arrowstop-1-s{background-position:-224px -32px}.ui-icon-arrowstop-1-w{background-position:-240px -32px}.ui-icon-arrowthick-1-n{background-position:1px -48px}.ui-icon-arrowthick-1-ne{background-position:-16px -48px}.ui-icon-arrowthick-1-e{background-position:-32px -48px}.ui-icon-arrowthick-1-se{background-position:-48px -48px}.ui-icon-arrowthick-1-s{background-position:-64px -48px}.ui-icon-arrowthick-1-sw{background-position:-80px -48px}.ui-icon-arrowthick-1-w{background-position:-96px -48px}.ui-icon-arrowthick-1-nw{background-position:-112px -48px}.ui-icon-arrowthick-2-n-s{background-position:-128px -48px}.ui-icon-arrowthick-2-ne-sw{background-position:-144px -48px}.ui-icon-arrowthick-2-e-w{background-position:-160px -48px}.ui-icon-arrowthick-2-se-nw{background-position:-176px -48px}.ui-icon-arrowthickstop-1-n{background-position:-192px -48px}.ui-icon-arrowthickstop-1-e{background-position:-208px -48px}.ui-icon-arrowthickstop-1-s{background-position:-224px -48px}.ui-icon-arrowthickstop-1-w{background-position:-240px -48px}.ui-icon-arrowreturnthick-1-w{background-position:0 -64px}.ui-icon-arrowreturnthick-1-n{background-position:-16px -64px}.ui-icon-arrowreturnthick-1-e{background-position:-32px -64px}.ui-icon-arrowreturnthick-1-s{background-position:-48px -64px}.ui-icon-arrowreturn-1-w{background-position:-64px -64px}.ui-icon-arrowreturn-1-n{background-position:-80px -64px}.ui-icon-arrowreturn-1-e{background-position:-96px -64px}.ui-icon-arrowreturn-1-s{background-position:-112px -64px}.ui-icon-arrowrefresh-1-w{background-position:-128px -64px}.ui-icon-arrowrefresh-1-n{background-position:-144px -64px}.ui-icon-arrowrefresh-1-e{background-position:-160px -64px}.ui-icon-arrowrefresh-1-s{background-position:-176px -64px}.ui-icon-arrow-4{background-position:0 -80px}.ui-icon-arrow-4-diag{background-position:-16px -80px}.ui-icon-extlink{background-position:-32px -80px}.ui-icon-newwin{background-position:-48px -80px}.ui-icon-refresh{background-position:-64px -80px}.ui-icon-shuffle{background-position:-80px -80px}.ui-icon-transfer-e-w{background-position:-96px -80px}.ui-icon-transferthick-e-w{background-position:-112px -80px}.ui-icon-folder-collapsed{background-position:0 -96px}.ui-icon-folder-open{background-position:-16px -96px}.ui-icon-document{background-position:-32px -96px}.ui-icon-document-b{background-position:-48px -96px}.ui-icon-note{background-position:-64px -96px}.ui-icon-mail-closed{background-position:-80px -96px}.ui-icon-mail-open{background-position:-96px -96px}.ui-icon-suitcase{background-position:-112px -96px}.ui-icon-comment{background-position:-128px -96px}.ui-icon-person{background-position:-144px -96px}.ui-icon-print{background-position:-160px -96px}.ui-icon-trash{background-position:-176px -96px}.ui-icon-locked{background-position:-192px -96px}.ui-icon-unlocked{background-position:-208px -96px}.ui-icon-bookmark{background-position:-224px -96px}.ui-icon-tag{background-position:-240px -96px}.ui-icon-home{background-position:0 -112px}.ui-icon-flag{background-position:-16px -112px}.ui-icon-calendar{background-position:-32px -112px}.ui-icon-cart{background-position:-48px -112px}.ui-icon-pencil{background-position:-64px -112px}.ui-icon-clock{background-position:-80px -112px}.ui-icon-disk{background-position:-96px -112px}.ui-icon-calculator{background-position:-112px -112px}.ui-icon-zoomin{background-position:-128px -112px}.ui-icon-zoomout{background-position:-144px -112px}.ui-icon-search{background-position:-160px -112px}.ui-icon-wrench{background-position:-176px -112px}.ui-icon-gear{background-position:-192px -112px}.ui-icon-heart{background-position:-208px -112px}.ui-icon-star{background-position:-224px -112px}.ui-icon-link{background-position:-240px -112px}.ui-icon-cancel{background-position:0 -128px}.ui-icon-plus{background-position:-16px -128px}.ui-icon-plusthick{background-position:-32px -128px}.ui-icon-minus{background-position:-48px -128px}.ui-icon-minusthick{background-position:-64px -128px}.ui-icon-close{background-position:-80px -128px}.ui-icon-closethick{background-position:-96px -128px}.ui-icon-key{background-position:-112px -128px}.ui-icon-lightbulb{background-position:-128px -128px}.ui-icon-scissors{background-position:-144px -128px}.ui-icon-clipboard{background-position:-160px -128px}.ui-icon-copy{background-position:-176px -128px}.ui-icon-contact{background-position:-192px -128px}.ui-icon-image{background-position:-208px -128px}.ui-icon-video{background-position:-224px -128px}.ui-icon-script{background-position:-240px -128px}.ui-icon-alert{background-position:0 -144px}.ui-icon-info{background-position:-16px -144px}.ui-icon-notice{background-position:-32px -144px}.ui-icon-help{background-position:-48px -144px}.ui-icon-check{background-position:-64px -144px}.ui-icon-bullet{background-position:-80px -144px}.ui-icon-radio-on{background-position:-96px -144px}.ui-icon-radio-off{background-position:-112px -144px}.ui-icon-pin-w{background-position:-128px -144px}.ui-icon-pin-s{background-position:-144px -144px}.ui-icon-play{background-position:0 -160px}.ui-icon-pause{background-position:-16px -160px}.ui-icon-seek-next{background-position:-32px -160px}.ui-icon-seek-prev{background-position:-48px -160px}.ui-icon-seek-end{background-position:-64px -160px}.ui-icon-seek-start{background-position:-80px -160px}.ui-icon-seek-first{background-position:-80px -160px}.ui-icon-stop{background-position:-96px -160px}.ui-icon-eject{background-position:-112px -160px}.ui-icon-volume-off{background-position:-128px -160px}.ui-icon-volume-on{background-position:-144px -160px}.ui-icon-power{background-position:0 -176px}.ui-icon-signal-diag{background-position:-16px -176px}.ui-icon-signal{background-position:-32px -176px}.ui-icon-battery-0{background-position:-48px -176px}.ui-icon-battery-1{background-position:-64px -176px}.ui-icon-battery-2{background-position:-80px -176px}.ui-icon-battery-3{background-position:-96px -176px}.ui-icon-circle-plus{background-position:0 -192px}.ui-icon-circle-minus{background-position:-16px -192px}.ui-icon-circle-close{background-position:-32px -192px}.ui-icon-circle-triangle-e{background-position:-48px -192px}.ui-icon-circle-triangle-s{background-position:-64px -192px}.ui-icon-circle-triangle-w{background-position:-80px -192px}.ui-icon-circle-triangle-n{background-position:-96px -192px}.ui-icon-circle-arrow-e{background-position:-112px -192px}.ui-icon-circle-arrow-s{background-position:-128px -192px}.ui-icon-circle-arrow-w{background-position:-144px -192px}.ui-icon-circle-arrow-n{background-position:-160px -192px}.ui-icon-circle-zoomin{background-position:-176px -192px}.ui-icon-circle-zoomout{background-position:-192px -192px}.ui-icon-circle-check{background-position:-208px -192px}.ui-icon-circlesmall-plus{background-position:0 -208px}.ui-icon-circlesmall-minus{background-position:-16px -208px}.ui-icon-circlesmall-close{background-position:-32px -208px}.ui-icon-squaresmall-plus{background-position:-48px -208px}.ui-icon-squaresmall-minus{background-position:-64px -208px}.ui-icon-squaresmall-close{background-position:-80px -208px}.ui-icon-grip-dotted-vertical{background-position:0 -224px}.ui-icon-grip-dotted-horizontal{background-position:-16px -224px}.ui-icon-grip-solid-vertical{background-position:-32px -224px}.ui-icon-grip-solid-horizontal{background-position:-48px -224px}.ui-icon-gripsmall-diagonal-se{background-position:-64px -224px}.ui-icon-grip-diagonal-se{background-position:-80px -224px}.ui-corner-all,.ui-corner-top,.ui-corner-left,.ui-corner-tl{border-top-left-radius:3px}.ui-corner-all,.ui-corner-top,.ui-corner-right,.ui-corner-tr{border-top-right-radius:3px}.ui-corner-all,.ui-corner-bottom,.ui-corner-left,.ui-corner-bl{border-bottom-left-radius:3px}.ui-corner-all,.ui-corner-bottom,.ui-corner-right,.ui-corner-br{border-bottom-right-radius:3px}.ui-widget-overlay{background:#aaa;opacity:.003;filter:Alpha(Opacity=.3)}.ui-widget-shadow{-webkit-box-shadow:0 0 5px #666;box-shadow:0 0 5px #666}</style>
	<style data-savepage-href="pareq/acsdata/bootstrap.min.css" type="text/css">/*!
 * Bootstrap v3.3.0 (http://getbootstrap.com)
 * Copyright 2011-2014 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 *//*! normalize.css v3.0.2 | MIT License | git.io/normalize */html{font-family:sans-serif;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%}body{margin:0}article,aside,details,figcaption,figure,footer,header,hgroup,main,menu,nav,section,summary{display:block}audio,canvas,progress,video{display:inline-block;vertical-align:baseline}audio:not([controls]){display:none;height:0}[hidden],template{display:none}a{background-color:transparent}a:active,a:hover{outline:0}abbr[title]{border-bottom:1px dotted}b,strong{font-weight:700}dfn{font-style:italic}h1{margin:.67em 0;font-size:2em}mark{color:#000;background:#ff0}small{font-size:80%}sub,sup{position:relative;font-size:75%;line-height:0;vertical-align:baseline}sup{top:-.5em}sub{bottom:-.25em}img{border:0}svg:not(:root){overflow:hidden}figure{margin:1em 40px}hr{height:0;-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box}pre{overflow:auto}code,kbd,pre,samp{font-family:monospace,monospace;font-size:1em}button,input,optgroup,select,textarea{margin:0;font:inherit;color:inherit;}button{overflow:visible;}button,select{text-transform:none;}button,html input[type=button],input[type=reset],input[type=submit]{-webkit-appearance:button;cursor:pointer;}button[disabled],html input[disabled]{cursor:default}button::-moz-focus-inner,input::-moz-focus-inner{padding:0;border:0}input{line-height:normal}input[type=checkbox],input[type=radio]{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;padding:0}input[type=number]::-webkit-inner-spin-button,input[type=number]::-webkit-outer-spin-button{height:auto}input[type=search]{-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;-webkit-appearance:textfield}input[type=search]::-webkit-search-cancel-button,input[type=search]::-webkit-search-decoration{-webkit-appearance:none}fieldset{padding:.35em .625em .75em;margin:0 2px;border:1px solid silver}legend{padding:0;border:0}textarea{overflow:auto}optgroup{font-weight:700}table{border-spacing:0;border-collapse:collapse}td,th{padding:0}/*! Source: https://github.com/h5bp/html5-boilerplate/blob/master/src/css/main.css */@media print{*,:before,:after{color:#000!important;text-shadow:none!important;background:transparent!important;-webkit-box-shadow:none!important;box-shadow:none!important}a,a:visited{text-decoration:underline}a[href]:after{content:" (" attr(href) ")"}abbr[title]:after{content:" (" attr(title) ")"}a[href^="#"]:after,a[href^="javascript:"]:after{content:""}pre,blockquote{border:1px solid #999;page-break-inside:avoid}thead{display:table-header-group}tr,img{page-break-inside:avoid}img{max-width:100%!important}p,h2,h3{orphans:3;widows:3}h2,h3{page-break-after:avoid}select{background:#fff!important}.navbar{display:none}.btn>.caret,.dropup>.btn>.caret{border-top-color:#000!important}.label{border:1px solid #000}.table{border-collapse:collapse!important}.table td,.table th{background-color:#fff!important}.table-bordered th,.table-bordered td{border:1px solid #ddd!important}}@font-face{font-family:'Glyphicons Halflings';src:/*savepage-url=../fonts/glyphicons-halflings-regular.eot*/url();src:/*savepage-url=../fonts/glyphicons-halflings-regular.eot?#iefix*/url() format('embedded-opentype'),/*savepage-url=../fonts/glyphicons-halflings-regular.woff*/url() format('woff'),/*savepage-url=../fonts/glyphicons-halflings-regular.ttf*/url() format('truetype'),/*savepage-url=../fonts/glyphicons-halflings-regular.svg#glyphicons_halflingsregular*/url() format('svg')}.glyphicon{position:relative;top:1px;display:inline-block;font-family:'Glyphicons Halflings';font-style:normal;font-weight:400;line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.glyphicon-asterisk:before{content:"\2a"}.glyphicon-plus:before{content:"\2b"}.glyphicon-euro:before,.glyphicon-eur:before{content:"\20ac"}.glyphicon-minus:before{content:"\2212"}.glyphicon-cloud:before{content:"\2601"}.glyphicon-envelope:before{content:"\2709"}.glyphicon-pencil:before{content:"\270f"}.glyphicon-glass:before{content:"\e001"}.glyphicon-music:before{content:"\e002"}.glyphicon-search:before{content:"\e003"}.glyphicon-heart:before{content:"\e005"}.glyphicon-star:before{content:"\e006"}.glyphicon-star-empty:before{content:"\e007"}.glyphicon-user:before{content:"\e008"}.glyphicon-film:before{content:"\e009"}.glyphicon-th-large:before{content:"\e010"}.glyphicon-th:before{content:"\e011"}.glyphicon-th-list:before{content:"\e012"}.glyphicon-ok:before{content:"\e013"}.glyphicon-remove:before{content:"\e014"}.glyphicon-zoom-in:before{content:"\e015"}.glyphicon-zoom-out:before{content:"\e016"}.glyphicon-off:before{content:"\e017"}.glyphicon-signal:before{content:"\e018"}.glyphicon-cog:before{content:"\e019"}.glyphicon-trash:before{content:"\e020"}.glyphicon-home:before{content:"\e021"}.glyphicon-file:before{content:"\e022"}.glyphicon-time:before{content:"\e023"}.glyphicon-road:before{content:"\e024"}.glyphicon-download-alt:before{content:"\e025"}.glyphicon-download:before{content:"\e026"}.glyphicon-upload:before{content:"\e027"}.glyphicon-inbox:before{content:"\e028"}.glyphicon-play-circle:before{content:"\e029"}.glyphicon-repeat:before{content:"\e030"}.glyphicon-refresh:before{content:"\e031"}.glyphicon-list-alt:before{content:"\e032"}.glyphicon-lock:before{content:"\e033"}.glyphicon-flag:before{content:"\e034"}.glyphicon-headphones:before{content:"\e035"}.glyphicon-volume-off:before{content:"\e036"}.glyphicon-volume-down:before{content:"\e037"}.glyphicon-volume-up:before{content:"\e038"}.glyphicon-qrcode:before{content:"\e039"}.glyphicon-barcode:before{content:"\e040"}.glyphicon-tag:before{content:"\e041"}.glyphicon-tags:before{content:"\e042"}.glyphicon-book:before{content:"\e043"}.glyphicon-bookmark:before{content:"\e044"}.glyphicon-print:before{content:"\e045"}.glyphicon-camera:before{content:"\e046"}.glyphicon-font:before{content:"\e047"}.glyphicon-bold:before{content:"\e048"}.glyphicon-italic:before{content:"\e049"}.glyphicon-text-height:before{content:"\e050"}.glyphicon-text-width:before{content:"\e051"}.glyphicon-align-left:before{content:"\e052"}.glyphicon-align-center:before{content:"\e053"}.glyphicon-align-right:before{content:"\e054"}.glyphicon-align-justify:before{content:"\e055"}.glyphicon-list:before{content:"\e056"}.glyphicon-indent-left:before{content:"\e057"}.glyphicon-indent-right:before{content:"\e058"}.glyphicon-facetime-video:before{content:"\e059"}.glyphicon-picture:before{content:"\e060"}.glyphicon-map-marker:before{content:"\e062"}.glyphicon-adjust:before{content:"\e063"}.glyphicon-tint:before{content:"\e064"}.glyphicon-edit:before{content:"\e065"}.glyphicon-share:before{content:"\e066"}.glyphicon-check:before{content:"\e067"}.glyphicon-move:before{content:"\e068"}.glyphicon-step-backward:before{content:"\e069"}.glyphicon-fast-backward:before{content:"\e070"}.glyphicon-backward:before{content:"\e071"}.glyphicon-play:before{content:"\e072"}.glyphicon-pause:before{content:"\e073"}.glyphicon-stop:before{content:"\e074"}.glyphicon-forward:before{content:"\e075"}.glyphicon-fast-forward:before{content:"\e076"}.glyphicon-step-forward:before{content:"\e077"}.glyphicon-eject:before{content:"\e078"}.glyphicon-chevron-left:before{content:"\e079"}.glyphicon-chevron-right:before{content:"\e080"}.glyphicon-plus-sign:before{content:"\e081"}.glyphicon-minus-sign:before{content:"\e082"}.glyphicon-remove-sign:before{content:"\e083"}.glyphicon-ok-sign:before{content:"\e084"}.glyphicon-question-sign:before{content:"\e085"}.glyphicon-info-sign:before{content:"\e086"}.glyphicon-screenshot:before{content:"\e087"}.glyphicon-remove-circle:before{content:"\e088"}.glyphicon-ok-circle:before{content:"\e089"}.glyphicon-ban-circle:before{content:"\e090"}.glyphicon-arrow-left:before{content:"\e091"}.glyphicon-arrow-right:before{content:"\e092"}.glyphicon-arrow-up:before{content:"\e093"}.glyphicon-arrow-down:before{content:"\e094"}.glyphicon-share-alt:before{content:"\e095"}.glyphicon-resize-full:before{content:"\e096"}.glyphicon-resize-small:before{content:"\e097"}.glyphicon-exclamation-sign:before{content:"\e101"}.glyphicon-gift:before{content:"\e102"}.glyphicon-leaf:before{content:"\e103"}.glyphicon-fire:before{content:"\e104"}.glyphicon-eye-open:before{content:"\e105"}.glyphicon-eye-close:before{content:"\e106"}.glyphicon-warning-sign:before{content:"\e107"}.glyphicon-plane:before{content:"\e108"}.glyphicon-calendar:before{content:"\e109"}.glyphicon-random:before{content:"\e110"}.glyphicon-comment:before{content:"\e111"}.glyphicon-magnet:before{content:"\e112"}.glyphicon-chevron-up:before{content:"\e113"}.glyphicon-chevron-down:before{content:"\e114"}.glyphicon-retweet:before{content:"\e115"}.glyphicon-shopping-cart:before{content:"\e116"}.glyphicon-folder-close:before{content:"\e117"}.glyphicon-folder-open:before{content:"\e118"}.glyphicon-resize-vertical:before{content:"\e119"}.glyphicon-resize-horizontal:before{content:"\e120"}.glyphicon-hdd:before{content:"\e121"}.glyphicon-bullhorn:before{content:"\e122"}.glyphicon-bell:before{content:"\e123"}.glyphicon-certificate:before{content:"\e124"}.glyphicon-thumbs-up:before{content:"\e125"}.glyphicon-thumbs-down:before{content:"\e126"}.glyphicon-hand-right:before{content:"\e127"}.glyphicon-hand-left:before{content:"\e128"}.glyphicon-hand-up:before{content:"\e129"}.glyphicon-hand-down:before{content:"\e130"}.glyphicon-circle-arrow-right:before{content:"\e131"}.glyphicon-circle-arrow-left:before{content:"\e132"}.glyphicon-circle-arrow-up:before{content:"\e133"}.glyphicon-circle-arrow-down:before{content:"\e134"}.glyphicon-globe:before{content:"\e135"}.glyphicon-wrench:before{content:"\e136"}.glyphicon-tasks:before{content:"\e137"}.glyphicon-filter:before{content:"\e138"}.glyphicon-briefcase:before{content:"\e139"}.glyphicon-fullscreen:before{content:"\e140"}.glyphicon-dashboard:before{content:"\e141"}.glyphicon-paperclip:before{content:"\e142"}.glyphicon-heart-empty:before{content:"\e143"}.glyphicon-link:before{content:"\e144"}.glyphicon-phone:before{content:"\e145"}.glyphicon-pushpin:before{content:"\e146"}.glyphicon-usd:before{content:"\e148"}.glyphicon-gbp:before{content:"\e149"}.glyphicon-sort:before{content:"\e150"}.glyphicon-sort-by-alphabet:before{content:"\e151"}.glyphicon-sort-by-alphabet-alt:before{content:"\e152"}.glyphicon-sort-by-order:before{content:"\e153"}.glyphicon-sort-by-order-alt:before{content:"\e154"}.glyphicon-sort-by-attributes:before{content:"\e155"}.glyphicon-sort-by-attributes-alt:before{content:"\e156"}.glyphicon-unchecked:before{content:"\e157"}.glyphicon-expand:before{content:"\e158"}.glyphicon-collapse-down:before{content:"\e159"}.glyphicon-collapse-up:before{content:"\e160"}.glyphicon-log-in:before{content:"\e161"}.glyphicon-flash:before{content:"\e162"}.glyphicon-log-out:before{content:"\e163"}.glyphicon-new-window:before{content:"\e164"}.glyphicon-record:before{content:"\e165"}.glyphicon-save:before{content:"\e166"}.glyphicon-open:before{content:"\e167"}.glyphicon-saved:before{content:"\e168"}.glyphicon-import:before{content:"\e169"}.glyphicon-export:before{content:"\e170"}.glyphicon-send:before{content:"\e171"}.glyphicon-floppy-disk:before{content:"\e172"}.glyphicon-floppy-saved:before{content:"\e173"}.glyphicon-floppy-remove:before{content:"\e174"}.glyphicon-floppy-save:before{content:"\e175"}.glyphicon-floppy-open:before{content:"\e176"}.glyphicon-credit-card:before{content:"\e177"}.glyphicon-transfer:before{content:"\e178"}.glyphicon-cutlery:before{content:"\e179"}.glyphicon-header:before{content:"\e180"}.glyphicon-compressed:before{content:"\e181"}.glyphicon-earphone:before{content:"\e182"}.glyphicon-phone-alt:before{content:"\e183"}.glyphicon-tower:before{content:"\e184"}.glyphicon-stats:before{content:"\e185"}.glyphicon-sd-video:before{content:"\e186"}.glyphicon-hd-video:before{content:"\e187"}.glyphicon-subtitles:before{content:"\e188"}.glyphicon-sound-stereo:before{content:"\e189"}.glyphicon-sound-dolby:before{content:"\e190"}.glyphicon-sound-5-1:before{content:"\e191"}.glyphicon-sound-6-1:before{content:"\e192"}.glyphicon-sound-7-1:before{content:"\e193"}.glyphicon-copyright-mark:before{content:"\e194"}.glyphicon-registration-mark:before{content:"\e195"}.glyphicon-cloud-download:before{content:"\e197"}.glyphicon-cloud-upload:before{content:"\e198"}.glyphicon-tree-conifer:before{content:"\e199"}.glyphicon-tree-deciduous:before{content:"\e200"}*{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}:before,:after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}html{font-size:10px;-webkit-tap-highlight-color:rgba(0,0,0,0)}body{font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;font-size:14px;line-height:1.42857143;color:#333;background-color:#fff}input,button,select,textarea{font-family:inherit;font-size:inherit;line-height:inherit;}a{color:#428bca;text-decoration:none}a:hover,a:focus{color:#2a6496;text-decoration:underline}a:focus{outline:thin dotted;outline:5px auto -webkit-focus-ring-color;outline-offset:-2px}figure{margin:0}img{vertical-align:middle}.img-responsive,.thumbnail>img,.thumbnail a>img,.carousel-inner>.item>img,.carousel-inner>.item>a>img{display:block;max-width:100%;height:auto}.img-rounded{border-radius:6px}.img-thumbnail{display:inline-block;max-width:100%;height:auto;padding:4px;line-height:1.42857143;background-color:#fff;border:1px solid #ddd;border-radius:4px;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;transition:all .2s ease-in-out}.img-circle{border-radius:50%}hr{margin-top:20px;margin-bottom:20px;border:0;border-top:1px solid #eee}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0}.sr-only-focusable:active,.sr-only-focusable:focus{position:static;width:auto;height:auto;margin:0;overflow:visible;clip:auto}h1,h2,h3,h4,h5,h6,.h1,.h2,.h3,.h4,.h5,.h6{font-family:inherit;font-weight:500;line-height:1.1;color:inherit}h1 small,h2 small,h3 small,h4 small,h5 small,h6 small,.h1 small,.h2 small,.h3 small,.h4 small,.h5 small,.h6 small,h1 .small,h2 .small,h3 .small,h4 .small,h5 .small,h6 .small,.h1 .small,.h2 .small,.h3 .small,.h4 .small,.h5 .small,.h6 .small{font-weight:400;line-height:1;color:#777}h1,.h1,h2,.h2,h3,.h3{margin-top:20px;margin-bottom:10px}h1 small,.h1 small,h2 small,.h2 small,h3 small,.h3 small,h1 .small,.h1 .small,h2 .small,.h2 .small,h3 .small,.h3 .small{font-size:65%}h4,.h4,h5,.h5,h6,.h6{margin-top:10px;margin-bottom:10px}h4 small,.h4 small,h5 small,.h5 small,h6 small,.h6 small,h4 .small,.h4 .small,h5 .small,.h5 .small,h6 .small,.h6 .small{font-size:75%}h1,.h1{font-size:36px}h2,.h2{font-size:30px}h3,.h3{font-size:24px}h4,.h4{font-size:18px}h5,.h5{font-size:14px}h6,.h6{font-size:12px}p{margin:0 0 10px}.lead{margin-bottom:20px;font-size:16px;font-weight:300;line-height:1.4}@media (min-width:768px){.lead{font-size:21px}}small,.small{font-size:85%}mark,.mark{padding:.2em;background-color:#fcf8e3}.text-left{text-align:left}.text-right{text-align:right}.text-center{text-align:center}.text-justify{text-align:justify}.text-nowrap{white-space:nowrap}.text-lowercase{text-transform:lowercase}.text-uppercase{text-transform:uppercase}.text-capitalize{text-transform:capitalize}.text-muted{color:#777}.text-primary{color:#428bca}a.text-primary:hover{color:#3071a9}.text-success{color:#3c763d}a.text-success:hover{color:#2b542c}.text-info{color:#31708f}a.text-info:hover{color:#245269}.text-warning{color:#8a6d3b}a.text-warning:hover{color:#66512c}.text-danger{color:#a94442}a.text-danger:hover{color:#843534}.bg-primary{color:#fff;background-color:#428bca}a.bg-primary:hover{background-color:#3071a9}.bg-success{background-color:#dff0d8}a.bg-success:hover{background-color:#c1e2b3}.bg-info{background-color:#d9edf7}a.bg-info:hover{background-color:#afd9ee}.bg-warning{background-color:#fcf8e3}a.bg-warning:hover{background-color:#f7ecb5}.bg-danger{background-color:#f2dede}a.bg-danger:hover{background-color:#e4b9b9}.page-header{padding-bottom:9px;margin:40px 0 20px;border-bottom:1px solid #eee}ul,ol{margin-top:0;margin-bottom:10px}ul ul,ol ul,ul ol,ol ol{margin-bottom:0}.list-unstyled{padding-left:0;list-style:none}.list-inline{padding-left:0;margin-left:-5px;list-style:none}.list-inline>li{display:inline-block;padding-right:5px;padding-left:5px}dl{margin-top:0;margin-bottom:20px}dt,dd{line-height:1.42857143}dt{font-weight:700}dd{margin-left:0}@media (min-width:768px){.dl-horizontal dt{float:left;width:160px;overflow:hidden;clear:left;text-align:right;text-overflow:ellipsis;white-space:nowrap}.dl-horizontal dd{margin-left:180px}}abbr[title],abbr[data-original-title]{cursor:help;border-bottom:1px dotted #777}.initialism{font-size:90%;text-transform:uppercase}blockquote{padding:10px 20px;margin:0 0 20px;font-size:17.5px;border-left:5px solid #eee}blockquote p:last-child,blockquote ul:last-child,blockquote ol:last-child{margin-bottom:0}blockquote footer,blockquote small,blockquote .small{display:block;font-size:80%;line-height:1.42857143;color:#777}blockquote footer:before,blockquote small:before,blockquote .small:before{content:'\2014 \00A0'}.blockquote-reverse,blockquote.pull-right{padding-right:15px;padding-left:0;text-align:right;border-right:5px solid #eee;border-left:0}.blockquote-reverse footer:before,blockquote.pull-right footer:before,.blockquote-reverse small:before,blockquote.pull-right small:before,.blockquote-reverse .small:before,blockquote.pull-right .small:before{content:''}.blockquote-reverse footer:after,blockquote.pull-right footer:after,.blockquote-reverse small:after,blockquote.pull-right small:after,.blockquote-reverse .small:after,blockquote.pull-right .small:after{content:'\00A0 \2014'}address{margin-bottom:20px;font-style:normal;line-height:1.42857143}code,kbd,pre,samp{font-family:Menlo,Monaco,Consolas,"Courier New",monospace}code{padding:2px 4px;font-size:90%;color:#c7254e;background-color:#f9f2f4;border-radius:4px}kbd{padding:2px 4px;font-size:90%;color:#fff;background-color:#333;border-radius:3px;-webkit-box-shadow:inset 0 -1px 0 rgba(0,0,0,.25);box-shadow:inset 0 -1px 0 rgba(0,0,0,.25)}kbd kbd{padding:0;font-size:100%;font-weight:700;-webkit-box-shadow:none;box-shadow:none}pre{display:block;padding:9.5px;margin:0 0 10px;font-size:13px;line-height:1.42857143;color:#333;word-break:break-all;word-wrap:break-word;background-color:#f5f5f5;border:1px solid #ccc;border-radius:4px}pre code{padding:0;font-size:inherit;color:inherit;white-space:pre-wrap;background-color:transparent;border-radius:0}.pre-scrollable{max-height:340px;overflow-y:scroll}.container{padding-right:15px;padding-left:15px;margin-right:auto;margin-left:auto}@media (min-width:768px){.container{width:750px}}@media (min-width:992px){.container{width:970px}}@media (min-width:1200px){.container{width:1170px}}.container-fluid{padding-right:15px;padding-left:15px;margin-right:auto;margin-left:auto}.row{margin-right:-15px;margin-left:-15px}.col-xs-1,.col-sm-1,.col-md-1,.col-lg-1,.col-xs-2,.col-sm-2,.col-md-2,.col-lg-2,.col-xs-3,.col-sm-3,.col-md-3,.col-lg-3,.col-xs-4,.col-sm-4,.col-md-4,.col-lg-4,.col-xs-5,.col-sm-5,.col-md-5,.col-lg-5,.col-xs-6,.col-sm-6,.col-md-6,.col-lg-6,.col-xs-7,.col-sm-7,.col-md-7,.col-lg-7,.col-xs-8,.col-sm-8,.col-md-8,.col-lg-8,.col-xs-9,.col-sm-9,.col-md-9,.col-lg-9,.col-xs-10,.col-sm-10,.col-md-10,.col-lg-10,.col-xs-11,.col-sm-11,.col-md-11,.col-lg-11,.col-xs-12,.col-sm-12,.col-md-12,.col-lg-12{position:relative;min-height:1px;padding-right:15px;padding-left:15px}.col-xs-1,.col-xs-2,.col-xs-3,.col-xs-4,.col-xs-5,.col-xs-6,.col-xs-7,.col-xs-8,.col-xs-9,.col-xs-10,.col-xs-11,.col-xs-12{float:left}.col-xs-12{width:100%}.col-xs-11{width:91.66666667%}.col-xs-10{width:83.33333333%}.col-xs-9{width:75%}.col-xs-8{width:66.66666667%}.col-xs-7{width:58.33333333%}.col-xs-6{width:50%}.col-xs-5{width:41.66666667%}.col-xs-4{width:33.33333333%}.col-xs-3{width:25%}.col-xs-2{width:16.66666667%}.col-xs-1{width:8.33333333%}.col-xs-pull-12{right:100%}.col-xs-pull-11{right:91.66666667%}.col-xs-pull-10{right:83.33333333%}.col-xs-pull-9{right:75%}.col-xs-pull-8{right:66.66666667%}.col-xs-pull-7{right:58.33333333%}.col-xs-pull-6{right:50%}.col-xs-pull-5{right:41.66666667%}.col-xs-pull-4{right:33.33333333%}.col-xs-pull-3{right:25%}.col-xs-pull-2{right:16.66666667%}.col-xs-pull-1{right:8.33333333%}.col-xs-pull-0{right:auto}.col-xs-push-12{left:100%}.col-xs-push-11{left:91.66666667%}.col-xs-push-10{left:83.33333333%}.col-xs-push-9{left:75%}.col-xs-push-8{left:66.66666667%}.col-xs-push-7{left:58.33333333%}.col-xs-push-6{left:50%}.col-xs-push-5{left:41.66666667%}.col-xs-push-4{left:33.33333333%}.col-xs-push-3{left:25%}.col-xs-push-2{left:16.66666667%}.col-xs-push-1{left:8.33333333%}.col-xs-push-0{left:auto}.col-xs-offset-12{margin-left:100%}.col-xs-offset-11{margin-left:91.66666667%}.col-xs-offset-10{margin-left:83.33333333%}.col-xs-offset-9{margin-left:75%}.col-xs-offset-8{margin-left:66.66666667%}.col-xs-offset-7{margin-left:58.33333333%}.col-xs-offset-6{margin-left:50%}.col-xs-offset-5{margin-left:41.66666667%}.col-xs-offset-4{margin-left:33.33333333%}.col-xs-offset-3{margin-left:25%}.col-xs-offset-2{margin-left:16.66666667%}.col-xs-offset-1{margin-left:8.33333333%}.col-xs-offset-0{margin-left:0}@media (min-width:768px){.col-sm-1,.col-sm-2,.col-sm-3,.col-sm-4,.col-sm-5,.col-sm-6,.col-sm-7,.col-sm-8,.col-sm-9,.col-sm-10,.col-sm-11,.col-sm-12{float:left}.col-sm-12{width:100%}.col-sm-11{width:91.66666667%}.col-sm-10{width:83.33333333%}.col-sm-9{width:75%}.col-sm-8{width:66.66666667%}.col-sm-7{width:58.33333333%}.col-sm-6{width:50%}.col-sm-5{width:41.66666667%}.col-sm-4{width:33.33333333%}.col-sm-3{width:25%}.col-sm-2{width:16.66666667%}.col-sm-1{width:8.33333333%}.col-sm-pull-12{right:100%}.col-sm-pull-11{right:91.66666667%}.col-sm-pull-10{right:83.33333333%}.col-sm-pull-9{right:75%}.col-sm-pull-8{right:66.66666667%}.col-sm-pull-7{right:58.33333333%}.col-sm-pull-6{right:50%}.col-sm-pull-5{right:41.66666667%}.col-sm-pull-4{right:33.33333333%}.col-sm-pull-3{right:25%}.col-sm-pull-2{right:16.66666667%}.col-sm-pull-1{right:8.33333333%}.col-sm-pull-0{right:auto}.col-sm-push-12{left:100%}.col-sm-push-11{left:91.66666667%}.col-sm-push-10{left:83.33333333%}.col-sm-push-9{left:75%}.col-sm-push-8{left:66.66666667%}.col-sm-push-7{left:58.33333333%}.col-sm-push-6{left:50%}.col-sm-push-5{left:41.66666667%}.col-sm-push-4{left:33.33333333%}.col-sm-push-3{left:25%}.col-sm-push-2{left:16.66666667%}.col-sm-push-1{left:8.33333333%}.col-sm-push-0{left:auto}.col-sm-offset-12{margin-left:100%}.col-sm-offset-11{margin-left:91.66666667%}.col-sm-offset-10{margin-left:83.33333333%}.col-sm-offset-9{margin-left:75%}.col-sm-offset-8{margin-left:66.66666667%}.col-sm-offset-7{margin-left:58.33333333%}.col-sm-offset-6{margin-left:50%}.col-sm-offset-5{margin-left:41.66666667%}.col-sm-offset-4{margin-left:33.33333333%}.col-sm-offset-3{margin-left:25%}.col-sm-offset-2{margin-left:16.66666667%}.col-sm-offset-1{margin-left:8.33333333%}.col-sm-offset-0{margin-left:0}}@media (min-width:992px){.col-md-1,.col-md-2,.col-md-3,.col-md-4,.col-md-5,.col-md-6,.col-md-7,.col-md-8,.col-md-9,.col-md-10,.col-md-11,.col-md-12{float:left}.col-md-12{width:100%}.col-md-11{width:91.66666667%}.col-md-10{width:83.33333333%}.col-md-9{width:75%}.col-md-8{width:66.66666667%}.col-md-7{width:58.33333333%}.col-md-6{width:50%}.col-md-5{width:41.66666667%}.col-md-4{width:33.33333333%}.col-md-3{width:25%}.col-md-2{width:16.66666667%}.col-md-1{width:8.33333333%}.col-md-pull-12{right:100%}.col-md-pull-11{right:91.66666667%}.col-md-pull-10{right:83.33333333%}.col-md-pull-9{right:75%}.col-md-pull-8{right:66.66666667%}.col-md-pull-7{right:58.33333333%}.col-md-pull-6{right:50%}.col-md-pull-5{right:41.66666667%}.col-md-pull-4{right:33.33333333%}.col-md-pull-3{right:25%}.col-md-pull-2{right:16.66666667%}.col-md-pull-1{right:8.33333333%}.col-md-pull-0{right:auto}.col-md-push-12{left:100%}.col-md-push-11{left:91.66666667%}.col-md-push-10{left:83.33333333%}.col-md-push-9{left:75%}.col-md-push-8{left:66.66666667%}.col-md-push-7{left:58.33333333%}.col-md-push-6{left:50%}.col-md-push-5{left:41.66666667%}.col-md-push-4{left:33.33333333%}.col-md-push-3{left:25%}.col-md-push-2{left:16.66666667%}.col-md-push-1{left:8.33333333%}.col-md-push-0{left:auto}.col-md-offset-12{margin-left:100%}.col-md-offset-11{margin-left:91.66666667%}.col-md-offset-10{margin-left:83.33333333%}.col-md-offset-9{margin-left:75%}.col-md-offset-8{margin-left:66.66666667%}.col-md-offset-7{margin-left:58.33333333%}.col-md-offset-6{margin-left:50%}.col-md-offset-5{margin-left:41.66666667%}.col-md-offset-4{margin-left:33.33333333%}.col-md-offset-3{margin-left:25%}.col-md-offset-2{margin-left:16.66666667%}.col-md-offset-1{margin-left:8.33333333%}.col-md-offset-0{margin-left:0}}@media (min-width:1200px){.col-lg-1,.col-lg-2,.col-lg-3,.col-lg-4,.col-lg-5,.col-lg-6,.col-lg-7,.col-lg-8,.col-lg-9,.col-lg-10,.col-lg-11,.col-lg-12{float:left}.col-lg-12{width:100%}.col-lg-11{width:91.66666667%}.col-lg-10{width:83.33333333%}.col-lg-9{width:75%}.col-lg-8{width:66.66666667%}.col-lg-7{width:58.33333333%}.col-lg-6{width:50%}.col-lg-5{width:41.66666667%}.col-lg-4{width:33.33333333%}.col-lg-3{width:25%}.col-lg-2{width:16.66666667%}.col-lg-1{width:8.33333333%}.col-lg-pull-12{right:100%}.col-lg-pull-11{right:91.66666667%}.col-lg-pull-10{right:83.33333333%}.col-lg-pull-9{right:75%}.col-lg-pull-8{right:66.66666667%}.col-lg-pull-7{right:58.33333333%}.col-lg-pull-6{right:50%}.col-lg-pull-5{right:41.66666667%}.col-lg-pull-4{right:33.33333333%}.col-lg-pull-3{right:25%}.col-lg-pull-2{right:16.66666667%}.col-lg-pull-1{right:8.33333333%}.col-lg-pull-0{right:auto}.col-lg-push-12{left:100%}.col-lg-push-11{left:91.66666667%}.col-lg-push-10{left:83.33333333%}.col-lg-push-9{left:75%}.col-lg-push-8{left:66.66666667%}.col-lg-push-7{left:58.33333333%}.col-lg-push-6{left:50%}.col-lg-push-5{left:41.66666667%}.col-lg-push-4{left:33.33333333%}.col-lg-push-3{left:25%}.col-lg-push-2{left:16.66666667%}.col-lg-push-1{left:8.33333333%}.col-lg-push-0{left:auto}.col-lg-offset-12{margin-left:100%}.col-lg-offset-11{margin-left:91.66666667%}.col-lg-offset-10{margin-left:83.33333333%}.col-lg-offset-9{margin-left:75%}.col-lg-offset-8{margin-left:66.66666667%}.col-lg-offset-7{margin-left:58.33333333%}.col-lg-offset-6{margin-left:50%}.col-lg-offset-5{margin-left:41.66666667%}.col-lg-offset-4{margin-left:33.33333333%}.col-lg-offset-3{margin-left:25%}.col-lg-offset-2{margin-left:16.66666667%}.col-lg-offset-1{margin-left:8.33333333%}.col-lg-offset-0{margin-left:0}}table{background-color:transparent}caption{padding-top:8px;padding-bottom:8px;color:#777;text-align:left}th{text-align:left}.table{width:100%;max-width:100%;margin-bottom:20px}.table>thead>tr>th,.table>tbody>tr>th,.table>tfoot>tr>th,.table>thead>tr>td,.table>tbody>tr>td,.table>tfoot>tr>td{padding:8px;line-height:1.42857143;vertical-align:top;border-top:1px solid #ddd}.table>thead>tr>th{vertical-align:bottom;border-bottom:2px solid #ddd}.table>caption+thead>tr:first-child>th,.table>colgroup+thead>tr:first-child>th,.table>thead:first-child>tr:first-child>th,.table>caption+thead>tr:first-child>td,.table>colgroup+thead>tr:first-child>td,.table>thead:first-child>tr:first-child>td{border-top:0}.table>tbody+tbody{border-top:2px solid #ddd}.table .table{background-color:#fff}.table-condensed>thead>tr>th,.table-condensed>tbody>tr>th,.table-condensed>tfoot>tr>th,.table-condensed>thead>tr>td,.table-condensed>tbody>tr>td,.table-condensed>tfoot>tr>td{padding:5px}.table-bordered{border:1px solid #ddd}.table-bordered>thead>tr>th,.table-bordered>tbody>tr>th,.table-bordered>tfoot>tr>th,.table-bordered>thead>tr>td,.table-bordered>tbody>tr>td,.table-bordered>tfoot>tr>td{border:1px solid #ddd}.table-bordered>thead>tr>th,.table-bordered>thead>tr>td{border-bottom-width:2px}.table-striped>tbody>tr:nth-child(odd){background-color:#f9f9f9}.table-hover>tbody>tr:hover{background-color:#f5f5f5}table col[class*=col-]{position:static;display:table-column;float:none}table td[class*=col-],table th[class*=col-]{position:static;display:table-cell;float:none}.table>thead>tr>td.active,.table>tbody>tr>td.active,.table>tfoot>tr>td.active,.table>thead>tr>th.active,.table>tbody>tr>th.active,.table>tfoot>tr>th.active,.table>thead>tr.active>td,.table>tbody>tr.active>td,.table>tfoot>tr.active>td,.table>thead>tr.active>th,.table>tbody>tr.active>th,.table>tfoot>tr.active>th{background-color:#f5f5f5}.table-hover>tbody>tr>td.active:hover,.table-hover>tbody>tr>th.active:hover,.table-hover>tbody>tr.active:hover>td,.table-hover>tbody>tr:hover>.active,.table-hover>tbody>tr.active:hover>th{background-color:#e8e8e8}.table>thead>tr>td.success,.table>tbody>tr>td.success,.table>tfoot>tr>td.success,.table>thead>tr>th.success,.table>tbody>tr>th.success,.table>tfoot>tr>th.success,.table>thead>tr.success>td,.table>tbody>tr.success>td,.table>tfoot>tr.success>td,.table>thead>tr.success>th,.table>tbody>tr.success>th,.table>tfoot>tr.success>th{background-color:#dff0d8}.table-hover>tbody>tr>td.success:hover,.table-hover>tbody>tr>th.success:hover,.table-hover>tbody>tr.success:hover>td,.table-hover>tbody>tr:hover>.success,.table-hover>tbody>tr.success:hover>th{background-color:#d0e9c6}.table>thead>tr>td.info,.table>tbody>tr>td.info,.table>tfoot>tr>td.info,.table>thead>tr>th.info,.table>tbody>tr>th.info,.table>tfoot>tr>th.info,.table>thead>tr.info>td,.table>tbody>tr.info>td,.table>tfoot>tr.info>td,.table>thead>tr.info>th,.table>tbody>tr.info>th,.table>tfoot>tr.info>th{background-color:#d9edf7}.table-hover>tbody>tr>td.info:hover,.table-hover>tbody>tr>th.info:hover,.table-hover>tbody>tr.info:hover>td,.table-hover>tbody>tr:hover>.info,.table-hover>tbody>tr.info:hover>th{background-color:#c4e3f3}.table>thead>tr>td.warning,.table>tbody>tr>td.warning,.table>tfoot>tr>td.warning,.table>thead>tr>th.warning,.table>tbody>tr>th.warning,.table>tfoot>tr>th.warning,.table>thead>tr.warning>td,.table>tbody>tr.warning>td,.table>tfoot>tr.warning>td,.table>thead>tr.warning>th,.table>tbody>tr.warning>th,.table>tfoot>tr.warning>th{background-color:#fcf8e3}.table-hover>tbody>tr>td.warning:hover,.table-hover>tbody>tr>th.warning:hover,.table-hover>tbody>tr.warning:hover>td,.table-hover>tbody>tr:hover>.warning,.table-hover>tbody>tr.warning:hover>th{background-color:#faf2cc}.table>thead>tr>td.danger,.table>tbody>tr>td.danger,.table>tfoot>tr>td.danger,.table>thead>tr>th.danger,.table>tbody>tr>th.danger,.table>tfoot>tr>th.danger,.table>thead>tr.danger>td,.table>tbody>tr.danger>td,.table>tfoot>tr.danger>td,.table>thead>tr.danger>th,.table>tbody>tr.danger>th,.table>tfoot>tr.danger>th{background-color:#f2dede}.table-hover>tbody>tr>td.danger:hover,.table-hover>tbody>tr>th.danger:hover,.table-hover>tbody>tr.danger:hover>td,.table-hover>tbody>tr:hover>.danger,.table-hover>tbody>tr.danger:hover>th{background-color:#ebcccc}.table-responsive{min-height:.01%;overflow-x:auto}@media screen and (max-width:767px){.table-responsive{width:100%;margin-bottom:15px;overflow-y:hidden;-ms-overflow-style:-ms-autohiding-scrollbar;border:1px solid #ddd}.table-responsive>.table{margin-bottom:0}.table-responsive>.table>thead>tr>th,.table-responsive>.table>tbody>tr>th,.table-responsive>.table>tfoot>tr>th,.table-responsive>.table>thead>tr>td,.table-responsive>.table>tbody>tr>td,.table-responsive>.table>tfoot>tr>td{white-space:nowrap}.table-responsive>.table-bordered{border:0}.table-responsive>.table-bordered>thead>tr>th:first-child,.table-responsive>.table-bordered>tbody>tr>th:first-child,.table-responsive>.table-bordered>tfoot>tr>th:first-child,.table-responsive>.table-bordered>thead>tr>td:first-child,.table-responsive>.table-bordered>tbody>tr>td:first-child,.table-responsive>.table-bordered>tfoot>tr>td:first-child{border-left:0}.table-responsive>.table-bordered>thead>tr>th:last-child,.table-responsive>.table-bordered>tbody>tr>th:last-child,.table-responsive>.table-bordered>tfoot>tr>th:last-child,.table-responsive>.table-bordered>thead>tr>td:last-child,.table-responsive>.table-bordered>tbody>tr>td:last-child,.table-responsive>.table-bordered>tfoot>tr>td:last-child{border-right:0}.table-responsive>.table-bordered>tbody>tr:last-child>th,.table-responsive>.table-bordered>tfoot>tr:last-child>th,.table-responsive>.table-bordered>tbody>tr:last-child>td,.table-responsive>.table-bordered>tfoot>tr:last-child>td{border-bottom:0}}fieldset{min-width:0;padding:0;margin:0;border:0}legend{display:block;width:100%;padding:0;margin-bottom:20px;font-size:21px;line-height:inherit;color:#333;border:0;border-bottom:1px solid #e5e5e5}label{display:inline-block;max-width:100%;margin-bottom:5px;font-weight:700}input[type=search]{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}input[type=radio],input[type=checkbox]{margin:4px 0 0;margin-top:1px \9;line-height:normal}input[type=file]{display:block}input[type=range]{display:block;width:100%}select[multiple],select[size]{height:auto}input[type=file]:focus,input[type=radio]:focus,input[type=checkbox]:focus{outline:thin dotted;outline:5px auto -webkit-focus-ring-color;outline-offset:-2px}output{display:block;padding-top:7px;font-size:14px;line-height:1.42857143;color:#555}.form-control{display:block;width:100%;height:30px;padding: 6px 12px;text-align: center;font-size:14px;line-height:1.42857143;color:#555;background-color:#fff;background-image:none;border:1px solid #ccc;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);box-shadow:inset 0 1px 1px rgba(0,0,0,.075);-webkit-transition:border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;-o-transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s;transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s;}.form-control:focus{border-color:#a2a2a2a1;outline:0;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075), 0px 0px 8px rgba(163,162,162,0.4);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075), 0px 0px 8px rgba(163,162,162,0.4)}.form-control::-moz-placeholder{color:#999;opacity:1}.form-control:-ms-input-placeholder{color:#999}.form-control::-webkit-input-placeholder{color:#999}.form-control[disabled],.form-control[readonly],fieldset[disabled] .form-control{cursor:not-allowed;background-color:#eee;opacity:1}textarea.form-control{height:auto}input[type=search]{-webkit-appearance:none}input[type=date],input[type=time],input[type=datetime-local],input[type=month]{line-height:34px;line-height:1.42857143 \0}input[type=date].input-sm,input[type=time].input-sm,input[type=datetime-local].input-sm,input[type=month].input-sm{line-height:30px;line-height:1.5 \0}input[type=date].input-lg,input[type=time].input-lg,input[type=datetime-local].input-lg,input[type=month].input-lg{line-height:46px;line-height:1.33 \0}_:-ms-fullscreen,:root input[type=date],_:-ms-fullscreen,:root input[type=time],_:-ms-fullscreen,:root input[type=datetime-local],_:-ms-fullscreen,:root input[type=month]{line-height:1.42857143}_:-ms-fullscreen.input-sm,:root input[type=date].input-sm,_:-ms-fullscreen.input-sm,:root input[type=time].input-sm,_:-ms-fullscreen.input-sm,:root input[type=datetime-local].input-sm,_:-ms-fullscreen.input-sm,:root input[type=month].input-sm{line-height:1.5}_:-ms-fullscreen.input-lg,:root input[type=date].input-lg,_:-ms-fullscreen.input-lg,:root input[type=time].input-lg,_:-ms-fullscreen.input-lg,:root input[type=datetime-local].input-lg,_:-ms-fullscreen.input-lg,:root input[type=month].input-lg{line-height:1.33}.form-group{margin-bottom:15px}.radio,.checkbox{position:relative;display:block;margin-top:10px;margin-bottom:10px}.radio label,.checkbox label{min-height:20px;padding-left:20px;margin-bottom:0;font-weight:400;cursor:pointer}.radio input[type=radio],.radio-inline input[type=radio],.checkbox input[type=checkbox],.checkbox-inline input[type=checkbox]{position:absolute;margin-top:4px \9;margin-left:-20px}.radio+.radio,.checkbox+.checkbox{margin-top:-5px}.radio-inline,.checkbox-inline{display:inline-block;padding-left:20px;margin-bottom:0;font-weight:400;vertical-align:middle;cursor:pointer}.radio-inline+.radio-inline,.checkbox-inline+.checkbox-inline{margin-top:0;margin-left:10px}input[type=radio][disabled],input[type=checkbox][disabled],input[type=radio].disabled,input[type=checkbox].disabled,fieldset[disabled] input[type=radio],fieldset[disabled] input[type=checkbox]{cursor:not-allowed}.radio-inline.disabled,.checkbox-inline.disabled,fieldset[disabled] .radio-inline,fieldset[disabled] .checkbox-inline{cursor:not-allowed}.radio.disabled label,.checkbox.disabled label,fieldset[disabled] .radio label,fieldset[disabled] .checkbox label{cursor:not-allowed}.form-control-static{padding-top:7px;padding-bottom:7px;margin-bottom:0}.form-control-static.input-lg,.form-control-static.input-sm{padding-right:0;padding-left:0}.input-sm,.form-group-sm .form-control{height:30px;padding:5px 10px;font-size:12px;line-height:1.5;border-radius:3px}select.input-sm,select.form-group-sm .form-control{height:30px;line-height:30px}textarea.input-sm,textarea.form-group-sm .form-control,select[multiple].input-sm,select[multiple].form-group-sm .form-control{height:auto}.input-lg,.form-group-lg .form-control{height:46px;padding:10px 16px;font-size:18px;line-height:1.33;border-radius:6px}select.input-lg,select.form-group-lg .form-control{height:46px;line-height:46px}textarea.input-lg,textarea.form-group-lg .form-control,select[multiple].input-lg,select[multiple].form-group-lg .form-control{height:auto}.has-feedback{position:relative}.has-feedback .form-control{padding-right:42.5px}.form-control-feedback{position:absolute;top:0;right:0;z-index:2;display:block;width:34px;height:34px;line-height:34px;text-align:center;pointer-events:none}.input-lg+.form-control-feedback{width:46px;height:46px;line-height:46px}.input-sm+.form-control-feedback{width:30px;height:30px;line-height:30px}.has-success .help-block,.has-success .control-label,.has-success .radio,.has-success .checkbox,.has-success .radio-inline,.has-success .checkbox-inline,.has-success.radio label,.has-success.checkbox label,.has-success.radio-inline label,.has-success.checkbox-inline label{color:#3c763d}.has-success .form-control{border-color:#3c763d;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);box-shadow:inset 0 1px 1px rgba(0,0,0,.075)}.has-success .form-control:focus{border-color:#2b542c;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #67b168;box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #67b168}.has-success .input-group-addon{color:#3c763d;background-color:#dff0d8;border-color:#3c763d}.has-success .form-control-feedback{color:#3c763d}.has-warning .help-block,.has-warning .control-label,.has-warning .radio,.has-warning .checkbox,.has-warning .radio-inline,.has-warning .checkbox-inline,.has-warning.radio label,.has-warning.checkbox label,.has-warning.radio-inline label,.has-warning.checkbox-inline label{color:#8a6d3b}.has-warning .form-control{border-color:#8a6d3b;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);box-shadow:inset 0 1px 1px rgba(0,0,0,.075)}.has-warning .form-control:focus{border-color:#66512c;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #c0a16b;box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #c0a16b}.has-warning .input-group-addon{color:#8a6d3b;background-color:#fcf8e3;border-color:#8a6d3b}.has-warning .form-control-feedback{color:#8a6d3b}.has-error .help-block,.has-error .control-label,.has-error .radio,.has-error .checkbox,.has-error .radio-inline,.has-error .checkbox-inline,.has-error.radio label,.has-error.checkbox label,.has-error.radio-inline label,.has-error.checkbox-inline label{color:#a94442}.has-error .form-control{border-color:#a94442;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);box-shadow:inset 0 1px 1px rgba(0,0,0,.075)}.has-error .form-control:focus{border-color:#843534;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #ce8483;box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 6px #ce8483}.has-error .input-group-addon{color:#a94442;background-color:#f2dede;border-color:#a94442}.has-error .form-control-feedback{color:#a94442}.has-feedback label~.form-control-feedback{top:25px}.has-feedback label.sr-only~.form-control-feedback{top:0}.help-block{display:block;margin-top:5px;margin-bottom:10px;color:#737373}@media (min-width:768px){.form-inline .form-group{display:inline-block;margin-bottom:0;vertical-align:middle}.form-inline .form-control{display:inline-block;width:auto;vertical-align:middle}.form-inline .form-control-static{display:inline-block}.form-inline .input-group{display:inline-table;vertical-align:middle}.form-inline .input-group .input-group-addon,.form-inline .input-group .input-group-btn,.form-inline .input-group .form-control{width:auto}.form-inline .input-group>.form-control{width:100%}.form-inline .control-label{margin-bottom:0;vertical-align:middle}.form-inline .radio,.form-inline .checkbox{display:inline-block;margin-top:0;margin-bottom:0;vertical-align:middle}.form-inline .radio label,.form-inline .checkbox label{padding-left:0}.form-inline .radio input[type=radio],.form-inline .checkbox input[type=checkbox]{position:relative;margin-left:0}.form-inline .has-feedback .form-control-feedback{top:0}}.form-horizontal .radio,.form-horizontal .checkbox,.form-horizontal .radio-inline,.form-horizontal .checkbox-inline{padding-top:7px;margin-top:0;margin-bottom:0}.form-horizontal .radio,.form-horizontal .checkbox{min-height:27px}.form-horizontal .form-group{margin-right:-15px;margin-left:-15px}@media (min-width:768px){.form-horizontal .control-label{padding-top:7px;margin-bottom:0;text-align:right}}.form-horizontal .has-feedback .form-control-feedback{right:15px}@media (min-width:768px){.form-horizontal .form-group-lg .control-label{padding-top:14.3px}}@media (min-width:768px){.form-horizontal .form-group-sm .control-label{padding-top:6px}}.btn{display:inline-block;width: 100%;padding:6px 12px;margin-bottom:0;font-size:14px;font-weight:400;line-height:1.42857143;text-align:center;white-space:nowrap;vertical-align:middle;-ms-touch-action:manipulation;touch-action:manipulation;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;background-image:none;border:1px solid transparent;border-radius:4px;}.btn:focus,.btn:active:focus,.btn.active:focus,.btn.focus,.btn:active.focus,.btn.active.focus{outline:thin dotted;outline:5px auto -webkit-focus-ring-color;outline-offset:-2px}.btn:hover,.btn:focus,.btn.focus{color:#333;text-decoration:none}.btn:active,.btn.active{background-image:none;outline:0;-webkit-box-shadow:inset 0 3px 5px rgba(0,0,0,.125);box-shadow:inset 0 3px 5px rgba(0,0,0,.125)}.btn.disabled,.btn[disabled],fieldset[disabled] .btn{pointer-events:none;cursor:not-allowed;filter:alpha(opacity=65);-webkit-box-shadow:none;box-shadow:none;opacity:.65}.btn-default{color:#333;background-color:#fff;border-color:#ccc}.btn-default:hover,.btn-default:focus,.btn-default.focus,.btn-default:active,.btn-default.active,.open>.dropdown-toggle.btn-default{color:#333;background-color:#e6e6e6;border-color:#adadad}.btn-default:active,.btn-default.active,.open>.dropdown-toggle.btn-default{background-image:none}.btn-default.disabled,.btn-default[disabled],fieldset[disabled] .btn-default,.btn-default.disabled:hover,.btn-default[disabled]:hover,fieldset[disabled] .btn-default:hover,.btn-default.disabled:focus,.btn-default[disabled]:focus,fieldset[disabled] .btn-default:focus,.btn-default.disabled.focus,.btn-default[disabled].focus,fieldset[disabled] .btn-default.focus,.btn-default.disabled:active,.btn-default[disabled]:active,fieldset[disabled] .btn-default:active,.btn-default.disabled.active,.btn-default[disabled].active,fieldset[disabled] .btn-default.active{background-color:#fff;border-color:#ccc}.btn-default .badge{color:#fff;background-color:#333}.btn-primary{color:#fff;background-color:#428bca;border-color:#357ebd;}.btn-primary:hover,.btn-primary:focus,.btn-primary.focus,.btn-primary:active,.btn-primary.active,.open>.dropdown-toggle.btn-primary{color:#fff;background-color:#3071a9;border-color:#285e8e;}.btn-primary:active,.btn-primary.active,.open>.dropdown-toggle.btn-primary{background-image:none}.btn-primary.disabled,.btn-primary[disabled],fieldset[disabled] .btn-primary,.btn-primary.disabled:hover,.btn-primary[disabled]:hover,fieldset[disabled] .btn-primary:hover,.btn-primary.disabled:focus,.btn-primary[disabled]:focus,fieldset[disabled] .btn-primary:focus,.btn-primary.disabled.focus,.btn-primary[disabled].focus,fieldset[disabled] .btn-primary.focus,.btn-primary.disabled:active,.btn-primary[disabled]:active,fieldset[disabled] .btn-primary:active,.btn-primary.disabled.active,.btn-primary[disabled].active,fieldset[disabled] .btn-primary.active{background-color:#428bca;border-color:#357ebd}.btn-primary .badge{color:#428bca;background-color:#fff}.btn-success{color:#fff;background-color:#5cb85c;border-color:#4cae4c}.btn-success:hover,.btn-success:focus,.btn-success.focus,.btn-success:active,.btn-success.active,.open>.dropdown-toggle.btn-success{color:#fff;background-color:#449d44;border-color:#398439}.btn-success:active,.btn-success.active,.open>.dropdown-toggle.btn-success{background-image:none}.btn-success.disabled,.btn-success[disabled],fieldset[disabled] .btn-success,.btn-success.disabled:hover,.btn-success[disabled]:hover,fieldset[disabled] .btn-success:hover,.btn-success.disabled:focus,.btn-success[disabled]:focus,fieldset[disabled] .btn-success:focus,.btn-success.disabled.focus,.btn-success[disabled].focus,fieldset[disabled] .btn-success.focus,.btn-success.disabled:active,.btn-success[disabled]:active,fieldset[disabled] .btn-success:active,.btn-success.disabled.active,.btn-success[disabled].active,fieldset[disabled] .btn-success.active{background-color:#5cb85c;border-color:#4cae4c}.btn-success .badge{color:#5cb85c;background-color:#fff}.btn-info{color:#fff;background-color:#5bc0de;border-color:#46b8da}.btn-info:hover,.btn-info:focus,.btn-info.focus,.btn-info:active,.btn-info.active,.open>.dropdown-toggle.btn-info{color:#fff;background-color:#31b0d5;border-color:#269abc}.btn-info:active,.btn-info.active,.open>.dropdown-toggle.btn-info{background-image:none}.btn-info.disabled,.btn-info[disabled],fieldset[disabled] .btn-info,.btn-info.disabled:hover,.btn-info[disabled]:hover,fieldset[disabled] .btn-info:hover,.btn-info.disabled:focus,.btn-info[disabled]:focus,fieldset[disabled] .btn-info:focus,.btn-info.disabled.focus,.btn-info[disabled].focus,fieldset[disabled] .btn-info.focus,.btn-info.disabled:active,.btn-info[disabled]:active,fieldset[disabled] .btn-info:active,.btn-info.disabled.active,.btn-info[disabled].active,fieldset[disabled] .btn-info.active{background-color:#5bc0de;border-color:#46b8da}.btn-info .badge{color:#5bc0de;background-color:#fff}.btn-warning{color:#fff;background-color:#f0ad4e;border-color:#eea236}.btn-warning:hover,.btn-warning:focus,.btn-warning.focus,.btn-warning:active,.btn-warning.active,.open>.dropdown-toggle.btn-warning{color:#fff;background-color:#ec971f;border-color:#d58512}.btn-warning:active,.btn-warning.active,.open>.dropdown-toggle.btn-warning{background-image:none}.btn-warning.disabled,.btn-warning[disabled],fieldset[disabled] .btn-warning,.btn-warning.disabled:hover,.btn-warning[disabled]:hover,fieldset[disabled] .btn-warning:hover,.btn-warning.disabled:focus,.btn-warning[disabled]:focus,fieldset[disabled] .btn-warning:focus,.btn-warning.disabled.focus,.btn-warning[disabled].focus,fieldset[disabled] .btn-warning.focus,.btn-warning.disabled:active,.btn-warning[disabled]:active,fieldset[disabled] .btn-warning:active,.btn-warning.disabled.active,.btn-warning[disabled].active,fieldset[disabled] .btn-warning.active{background-color:#f0ad4e;border-color:#eea236}.btn-warning .badge{color:#f0ad4e;background-color:#fff}.btn-danger{color:#fff;background-color:#d9534f;border-color:#d43f3a}.btn-danger:hover,.btn-danger:focus,.btn-danger.focus,.btn-danger:active,.btn-danger.active,.open>.dropdown-toggle.btn-danger{color:#fff;background-color:#c9302c;border-color:#ac2925}.btn-danger:active,.btn-danger.active,.open>.dropdown-toggle.btn-danger{background-image:none}.btn-danger.disabled,.btn-danger[disabled],fieldset[disabled] .btn-danger,.btn-danger.disabled:hover,.btn-danger[disabled]:hover,fieldset[disabled] .btn-danger:hover,.btn-danger.disabled:focus,.btn-danger[disabled]:focus,fieldset[disabled] .btn-danger:focus,.btn-danger.disabled.focus,.btn-danger[disabled].focus,fieldset[disabled] .btn-danger.focus,.btn-danger.disabled:active,.btn-danger[disabled]:active,fieldset[disabled] .btn-danger:active,.btn-danger.disabled.active,.btn-danger[disabled].active,fieldset[disabled] .btn-danger.active{background-color:#d9534f;border-color:#d43f3a}.btn-danger .badge{color:#d9534f;background-color:#fff}.btn-link{font-weight:400;color:#428bca;border-radius:0}.btn-link,.btn-link:active,.btn-link.active,.btn-link[disabled],fieldset[disabled] .btn-link{background-color:transparent;-webkit-box-shadow:none;box-shadow:none}.btn-link,.btn-link:hover,.btn-link:focus,.btn-link:active{border-color:transparent}.btn-link:hover,.btn-link:focus{color:#2a6496;text-decoration:underline;background-color:transparent}.btn-link[disabled]:hover,fieldset[disabled] .btn-link:hover,.btn-link[disabled]:focus,fieldset[disabled] .btn-link:focus{color:#777;text-decoration:none}.btn-lg,.btn-group-lg>.btn{padding:10px 16px;font-size:18px;line-height:1.33;border-radius:6px}.btn-sm,.btn-group-sm>.btn{padding:5px 10px;font-size:12px;line-height:1.5;border-radius:3px}.btn-xs,.btn-group-xs>.btn{padding:1px 5px;font-size:12px;line-height:1.5;border-radius:3px}.btn-block{display:block;width:100%}.btn-block+.btn-block{margin-top:5px}input[type=submit].btn-block,input[type=reset].btn-block,input[type=button].btn-block{width:100%}.fade{opacity:0;-webkit-transition:opacity .15s linear;-o-transition:opacity .15s linear;transition:opacity .15s linear}.fade.in{opacity:1}.collapse{display:none;visibility:hidden}.collapse.in{display:block;visibility:visible}tr.collapse.in{display:table-row}tbody.collapse.in{display:table-row-group}.collapsing{position:relative;height:0;overflow:hidden;-webkit-transition-timing-function:ease;-o-transition-timing-function:ease;transition-timing-function:ease;-webkit-transition-duration:.35s;-o-transition-duration:.35s;transition-duration:.35s;-webkit-transition-property:height,visibility;-o-transition-property:height,visibility;transition-property:height,visibility}.caret{display:inline-block;width:0;height:0;margin-left:2px;vertical-align:middle;border-top:4px solid;border-right:4px solid transparent;border-left:4px solid transparent}.dropdown{position:relative}.dropdown-toggle:focus{outline:0}.dropdown-menu{position:absolute;top:100%;left:0;z-index:1000;display:none;float:left;min-width:160px;padding:5px 0;margin:2px 0 0;font-size:14px;text-align:left;list-style:none;background-color:#fff;-webkit-background-clip:padding-box;background-clip:padding-box;border:1px solid #ccc;border:1px solid rgba(0,0,0,.15);border-radius:4px;-webkit-box-shadow:0 6px 12px rgba(0,0,0,.175);box-shadow:0 6px 12px rgba(0,0,0,.175)}.dropdown-menu.pull-right{right:0;left:auto}.dropdown-menu .divider{height:1px;margin:9px 0;overflow:hidden;background-color:#e5e5e5}.dropdown-menu>li>a{display:block;padding:3px 20px;clear:both;font-weight:400;line-height:1.42857143;color:#333;white-space:nowrap}.dropdown-menu>li>a:hover,.dropdown-menu>li>a:focus{color:#262626;text-decoration:none;background-color:#f5f5f5}.dropdown-menu>.active>a,.dropdown-menu>.active>a:hover,.dropdown-menu>.active>a:focus{color:#fff;text-decoration:none;background-color:#428bca;outline:0}.dropdown-menu>.disabled>a,.dropdown-menu>.disabled>a:hover,.dropdown-menu>.disabled>a:focus{color:#777}.dropdown-menu>.disabled>a:hover,.dropdown-menu>.disabled>a:focus{text-decoration:none;cursor:not-allowed;background-color:transparent;background-image:none;filter:progid:DXImageTransform.Microsoft.gradient(enabled=false)}.open>.dropdown-menu{display:block}.open>a{outline:0}.dropdown-menu-right{right:0;left:auto}.dropdown-menu-left{right:auto;left:0}.dropdown-header{display:block;padding:3px 20px;font-size:12px;line-height:1.42857143;color:#777;white-space:nowrap}.dropdown-backdrop{position:fixed;top:0;right:0;bottom:0;left:0;z-index:990}.pull-right>.dropdown-menu{right:0;left:auto}.dropup .caret,.navbar-fixed-bottom .dropdown .caret{content:"";border-top:0;border-bottom:4px solid}.dropup .dropdown-menu,.navbar-fixed-bottom .dropdown .dropdown-menu{top:auto;bottom:100%;margin-bottom:1px}@media (min-width:768px){.navbar-right .dropdown-menu{right:0;left:auto}.navbar-right .dropdown-menu-left{right:auto;left:0}}.btn-group,.btn-group-vertical{position:relative;display:inline-block;vertical-align:middle}.btn-group>.btn,.btn-group-vertical>.btn{position:relative;float:left}.btn-group>.btn:hover,.btn-group-vertical>.btn:hover,.btn-group>.btn:focus,.btn-group-vertical>.btn:focus,.btn-group>.btn:active,.btn-group-vertical>.btn:active,.btn-group>.btn.active,.btn-group-vertical>.btn.active{z-index:2}.btn-group>.btn:focus,.btn-group-vertical>.btn:focus{outline:0}.btn-group .btn+.btn,.btn-group .btn+.btn-group,.btn-group .btn-group+.btn,.btn-group .btn-group+.btn-group{margin-left:-1px}.btn-toolbar{margin-left:-5px}.btn-toolbar .btn-group,.btn-toolbar .input-group{float:left}.btn-toolbar>.btn,.btn-toolbar>.btn-group,.btn-toolbar>.input-group{margin-left:5px}.btn-group>.btn:not(:first-child):not(:last-child):not(.dropdown-toggle){border-radius:0}.btn-group>.btn:first-child{margin-left:0}.btn-group>.btn:first-child:not(:last-child):not(.dropdown-toggle){border-top-right-radius:0;border-bottom-right-radius:0}.btn-group>.btn:last-child:not(:first-child),.btn-group>.dropdown-toggle:not(:first-child){border-top-left-radius:0;border-bottom-left-radius:0}.btn-group>.btn-group{float:left}.btn-group>.btn-group:not(:first-child):not(:last-child)>.btn{border-radius:0}.btn-group>.btn-group:first-child>.btn:last-child,.btn-group>.btn-group:first-child>.dropdown-toggle{border-top-right-radius:0;border-bottom-right-radius:0}.btn-group>.btn-group:last-child>.btn:first-child{border-top-left-radius:0;border-bottom-left-radius:0}.btn-group .dropdown-toggle:active,.btn-group.open .dropdown-toggle{outline:0}.btn-group>.btn+.dropdown-toggle{padding-right:8px;padding-left:8px}.btn-group>.btn-lg+.dropdown-toggle{padding-right:12px;padding-left:12px}.btn-group.open .dropdown-toggle{-webkit-box-shadow:inset 0 3px 5px rgba(0,0,0,.125);box-shadow:inset 0 3px 5px rgba(0,0,0,.125)}.btn-group.open .dropdown-toggle.btn-link{-webkit-box-shadow:none;box-shadow:none}.btn .caret{margin-left:0}.btn-lg .caret{border-width:5px 5px 0;border-bottom-width:0}.dropup .btn-lg .caret{border-width:0 5px 5px}.btn-group-vertical>.btn,.btn-group-vertical>.btn-group,.btn-group-vertical>.btn-group>.btn{display:block;float:none;width:100%;max-width:100%}.btn-group-vertical>.btn-group>.btn{float:none}.btn-group-vertical>.btn+.btn,.btn-group-vertical>.btn+.btn-group,.btn-group-vertical>.btn-group+.btn,.btn-group-vertical>.btn-group+.btn-group{margin-top:-1px;margin-left:0}.btn-group-vertical>.btn:not(:first-child):not(:last-child){border-radius:0}.btn-group-vertical>.btn:first-child:not(:last-child){border-top-right-radius:4px;border-bottom-right-radius:0;border-bottom-left-radius:0}.btn-group-vertical>.btn:last-child:not(:first-child){border-top-left-radius:0;border-top-right-radius:0;border-bottom-left-radius:4px}.btn-group-vertical>.btn-group:not(:first-child):not(:last-child)>.btn{border-radius:0}.btn-group-vertical>.btn-group:first-child:not(:last-child)>.btn:last-child,.btn-group-vertical>.btn-group:first-child:not(:last-child)>.dropdown-toggle{border-bottom-right-radius:0;border-bottom-left-radius:0}.btn-group-vertical>.btn-group:last-child:not(:first-child)>.btn:first-child{border-top-left-radius:0;border-top-right-radius:0}.btn-group-justified{display:table;width:100%;table-layout:fixed;border-collapse:separate}.btn-group-justified>.btn,.btn-group-justified>.btn-group{display:table-cell;float:none;width:1%}.btn-group-justified>.btn-group .btn{width:100%}.btn-group-justified>.btn-group .dropdown-menu{left:auto}[data-toggle=buttons]>.btn input[type=radio],[data-toggle=buttons]>.btn-group>.btn input[type=radio],[data-toggle=buttons]>.btn input[type=checkbox],[data-toggle=buttons]>.btn-group>.btn input[type=checkbox]{position:absolute;clip:rect(0,0,0,0);pointer-events:none}.input-group{position:relative;display:table;border-collapse:separate}.input-group[class*=col-]{float:none;padding-right:0;padding-left:0}.input-group .form-control{position:relative;z-index:2;float:left;width:100%;margin-bottom:0}.input-group-lg>.form-control,.input-group-lg>.input-group-addon,.input-group-lg>.input-group-btn>.btn{height:46px;padding:10px 16px;font-size:18px;line-height:1.33;border-radius:6px}select.input-group-lg>.form-control,select.input-group-lg>.input-group-addon,select.input-group-lg>.input-group-btn>.btn{height:46px;line-height:46px}textarea.input-group-lg>.form-control,textarea.input-group-lg>.input-group-addon,textarea.input-group-lg>.input-group-btn>.btn,select[multiple].input-group-lg>.form-control,select[multiple].input-group-lg>.input-group-addon,select[multiple].input-group-lg>.input-group-btn>.btn{height:auto}.input-group-sm>.form-control,.input-group-sm>.input-group-addon,.input-group-sm>.input-group-btn>.btn{height:30px;padding:5px 10px;font-size:12px;line-height:1.5;border-radius:3px}select.input-group-sm>.form-control,select.input-group-sm>.input-group-addon,select.input-group-sm>.input-group-btn>.btn{height:30px;line-height:30px}textarea.input-group-sm>.form-control,textarea.input-group-sm>.input-group-addon,textarea.input-group-sm>.input-group-btn>.btn,select[multiple].input-group-sm>.form-control,select[multiple].input-group-sm>.input-group-addon,select[multiple].input-group-sm>.input-group-btn>.btn{height:auto}.input-group-addon,.input-group-btn,.input-group .form-control{display:table-cell}.input-group-addon:not(:first-child):not(:last-child),.input-group-btn:not(:first-child):not(:last-child),.input-group .form-control:not(:first-child):not(:last-child){border-radius:0}.input-group-addon,.input-group-btn{width:1%;white-space:nowrap;vertical-align:middle}.input-group-addon{padding:6px 12px;font-size:14px;font-weight:400;line-height:1;color:#555;text-align:center;background-color:#eee;border:1px solid #ccc;border-radius:4px}.input-group-addon.input-sm{padding:5px 10px;font-size:12px;border-radius:3px}.input-group-addon.input-lg{padding:10px 16px;font-size:18px;border-radius:6px}.input-group-addon input[type=radio],.input-group-addon input[type=checkbox]{margin-top:0}.input-group .form-control:first-child,.input-group-addon:first-child,.input-group-btn:first-child>.btn,.input-group-btn:first-child>.btn-group>.btn,.input-group-btn:first-child>.dropdown-toggle,.input-group-btn:last-child>.btn:not(:last-child):not(.dropdown-toggle),.input-group-btn:last-child>.btn-group:not(:last-child)>.btn{border-top-right-radius:0;border-bottom-right-radius:0}.input-group-addon:first-child{border-right:0}.input-group .form-control:last-child,.input-group-addon:last-child,.input-group-btn:last-child>.btn,.input-group-btn:last-child>.btn-group>.btn,.input-group-btn:last-child>.dropdown-toggle,.input-group-btn:first-child>.btn:not(:first-child),.input-group-btn:first-child>.btn-group:not(:first-child)>.btn{border-top-left-radius:0;border-bottom-left-radius:0}.input-group-addon:last-child{border-left:0}.input-group-btn{position:relative;font-size:0;white-space:nowrap}.input-group-btn>.btn{position:relative}.input-group-btn>.btn+.btn{margin-left:-1px}.input-group-btn>.btn:hover,.input-group-btn>.btn:focus,.input-group-btn>.btn:active{z-index:2}.input-group-btn:first-child>.btn,.input-group-btn:first-child>.btn-group{margin-right:-1px}.input-group-btn:last-child>.btn,.input-group-btn:last-child>.btn-group{margin-left:-1px}.nav{padding-left:0;margin-bottom:0;list-style:none}.nav>li{position:relative;display:block}.nav>li>a{position:relative;display:block;padding:10px 15px}.nav>li>a:hover,.nav>li>a:focus{text-decoration:none;background-color:#eee}.nav>li.disabled>a{color:#777}.nav>li.disabled>a:hover,.nav>li.disabled>a:focus{color:#777;text-decoration:none;cursor:not-allowed;background-color:transparent}.nav .open>a,.nav .open>a:hover,.nav .open>a:focus{background-color:#eee;border-color:#428bca}.nav .nav-divider{height:1px;margin:9px 0;overflow:hidden;background-color:#e5e5e5}.nav>li>a>img{max-width:none}.nav-tabs{border-bottom:1px solid #ddd}.nav-tabs>li{float:left;margin-bottom:-1px}.nav-tabs>li>a{margin-right:2px;line-height:1.42857143;border:1px solid transparent;border-radius:4px 4px 0 0}.nav-tabs>li>a:hover{border-color:#eee #eee #ddd}.nav-tabs>li.active>a,.nav-tabs>li.active>a:hover,.nav-tabs>li.active>a:focus{color:#555;cursor:default;background-color:#fff;border:1px solid #ddd;border-bottom-color:transparent}.nav-tabs.nav-justified{width:100%;border-bottom:0}.nav-tabs.nav-justified>li{float:none}.nav-tabs.nav-justified>li>a{margin-bottom:5px;text-align:center}.nav-tabs.nav-justified>.dropdown .dropdown-menu{top:auto;left:auto}@media (min-width:768px){.nav-tabs.nav-justified>li{display:table-cell;width:1%}.nav-tabs.nav-justified>li>a{margin-bottom:0}}.nav-tabs.nav-justified>li>a{margin-right:0;border-radius:4px}.nav-tabs.nav-justified>.active>a,.nav-tabs.nav-justified>.active>a:hover,.nav-tabs.nav-justified>.active>a:focus{border:1px solid #ddd}@media (min-width:768px){.nav-tabs.nav-justified>li>a{border-bottom:1px solid #ddd;border-radius:4px 4px 0 0}.nav-tabs.nav-justified>.active>a,.nav-tabs.nav-justified>.active>a:hover,.nav-tabs.nav-justified>.active>a:focus{border-bottom-color:#fff}}.nav-pills>li{float:left}.nav-pills>li>a{border-radius:4px}.nav-pills>li+li{margin-left:2px}.nav-pills>li.active>a,.nav-pills>li.active>a:hover,.nav-pills>li.active>a:focus{color:#fff;background-color:#428bca}.nav-stacked>li{float:none}.nav-stacked>li+li{margin-top:2px;margin-left:0}.nav-justified{width:100%}.nav-justified>li{float:none}.nav-justified>li>a{margin-bottom:5px;text-align:center}.nav-justified>.dropdown .dropdown-menu{top:auto;left:auto}@media (min-width:768px){.nav-justified>li{display:table-cell;width:1%}.nav-justified>li>a{margin-bottom:0}}.nav-tabs-justified{border-bottom:0}.nav-tabs-justified>li>a{margin-right:0;border-radius:4px}.nav-tabs-justified>.active>a,.nav-tabs-justified>.active>a:hover,.nav-tabs-justified>.active>a:focus{border:1px solid #ddd}@media (min-width:768px){.nav-tabs-justified>li>a{border-bottom:1px solid #ddd;border-radius:4px 4px 0 0}.nav-tabs-justified>.active>a,.nav-tabs-justified>.active>a:hover,.nav-tabs-justified>.active>a:focus{border-bottom-color:#fff}}.tab-content>.tab-pane{display:none;visibility:hidden}.tab-content>.active{display:block;visibility:visible}.nav-tabs .dropdown-menu{margin-top:-1px;border-top-left-radius:0;border-top-right-radius:0}.navbar{position:relative;min-height:50px;margin-bottom:20px;border:1px solid transparent}@media (min-width:768px){.navbar{border-radius:4px}}@media (min-width:768px){.navbar-header{float:left}}.navbar-collapse{padding-right:15px;padding-left:15px;overflow-x:visible;-webkit-overflow-scrolling:touch;border-top:1px solid transparent;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,.1);box-shadow:inset 0 1px 0 rgba(255,255,255,.1)}.navbar-collapse.in{overflow-y:auto}@media (min-width:768px){.navbar-collapse{width:auto;border-top:0;-webkit-box-shadow:none;box-shadow:none}.navbar-collapse.collapse{display:block!important;height:auto!important;padding-bottom:0;overflow:visible!important;visibility:visible!important}.navbar-collapse.in{overflow-y:visible}.navbar-fixed-top .navbar-collapse,.navbar-static-top .navbar-collapse,.navbar-fixed-bottom .navbar-collapse{padding-right:0;padding-left:0}}.navbar-fixed-top .navbar-collapse,.navbar-fixed-bottom .navbar-collapse{max-height:340px}@media (max-device-width:480px) and (orientation:landscape){.navbar-fixed-top .navbar-collapse,.navbar-fixed-bottom .navbar-collapse{max-height:200px}}.container>.navbar-header,.container-fluid>.navbar-header,.container>.navbar-collapse,.container-fluid>.navbar-collapse{margin-right:-15px;margin-left:-15px}@media (min-width:768px){.container>.navbar-header,.container-fluid>.navbar-header,.container>.navbar-collapse,.container-fluid>.navbar-collapse{margin-right:0;margin-left:0}}.navbar-static-top{z-index:1000;border-width:0 0 1px}@media (min-width:768px){.navbar-static-top{border-radius:0}}.navbar-fixed-top,.navbar-fixed-bottom{position:fixed;right:0;left:0;z-index:1030}@media (min-width:768px){.navbar-fixed-top,.navbar-fixed-bottom{border-radius:0}}.navbar-fixed-top{top:0;border-width:0 0 1px}.navbar-fixed-bottom{bottom:0;margin-bottom:0;border-width:1px 0 0}.navbar-brand{float:left;height:50px;padding:15px 15px;font-size:18px;line-height:20px}.navbar-brand:hover,.navbar-brand:focus{text-decoration:none}.navbar-brand>img{display:block}@media (min-width:768px){.navbar>.container .navbar-brand,.navbar>.container-fluid .navbar-brand{margin-left:-15px}}.navbar-toggle{position:relative;float:right;padding:9px 10px;margin-top:8px;margin-right:15px;margin-bottom:8px;background-color:transparent;background-image:none;border:1px solid transparent;border-radius:4px}.navbar-toggle:focus{outline:0}.navbar-toggle .icon-bar{display:block;width:22px;height:2px;border-radius:1px}.navbar-toggle .icon-bar+.icon-bar{margin-top:4px}@media (min-width:768px){.navbar-toggle{display:none}}.navbar-nav{margin:7.5px -15px}.navbar-nav>li>a{padding-top:10px;padding-bottom:10px;line-height:20px}@media (max-width:767px){.navbar-nav .open .dropdown-menu{position:static;float:none;width:auto;margin-top:0;background-color:transparent;border:0;-webkit-box-shadow:none;box-shadow:none}.navbar-nav .open .dropdown-menu>li>a,.navbar-nav .open .dropdown-menu .dropdown-header{padding:5px 15px 5px 25px}.navbar-nav .open .dropdown-menu>li>a{line-height:20px}.navbar-nav .open .dropdown-menu>li>a:hover,.navbar-nav .open .dropdown-menu>li>a:focus{background-image:none}}@media (min-width:768px){.navbar-nav{float:left;margin:0}.navbar-nav>li{float:left}.navbar-nav>li>a{padding-top:15px;padding-bottom:15px}}.navbar-form{padding:10px 15px;margin-top:8px;margin-right:-15px;margin-bottom:8px;margin-left:-15px;border-top:1px solid transparent;border-bottom:1px solid transparent;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,.1),0 1px 0 rgba(255,255,255,.1);box-shadow:inset 0 1px 0 rgba(255,255,255,.1),0 1px 0 rgba(255,255,255,.1)}@media (min-width:768px){.navbar-form .form-group{display:inline-block;margin-bottom:0;vertical-align:middle}.navbar-form .form-control{display:inline-block;width:auto;vertical-align:middle}.navbar-form .form-control-static{display:inline-block}.navbar-form .input-group{display:inline-table;vertical-align:middle}.navbar-form .input-group .input-group-addon,.navbar-form .input-group .input-group-btn,.navbar-form .input-group .form-control{width:auto}.navbar-form .input-group>.form-control{width:100%}.navbar-form .control-label{margin-bottom:0;vertical-align:middle}.navbar-form .radio,.navbar-form .checkbox{display:inline-block;margin-top:0;margin-bottom:0;vertical-align:middle}.navbar-form .radio label,.navbar-form .checkbox label{padding-left:0}.navbar-form .radio input[type=radio],.navbar-form .checkbox input[type=checkbox]{position:relative;margin-left:0}.navbar-form .has-feedback .form-control-feedback{top:0}}@media (max-width:767px){.navbar-form .form-group{margin-bottom:5px}.navbar-form .form-group:last-child{margin-bottom:0}}@media (min-width:768px){.navbar-form{width:auto;padding-top:0;padding-bottom:0;margin-right:0;margin-left:0;border:0;-webkit-box-shadow:none;box-shadow:none}}.navbar-nav>li>.dropdown-menu{margin-top:0;border-top-left-radius:0;border-top-right-radius:0}.navbar-fixed-bottom .navbar-nav>li>.dropdown-menu{border-bottom-right-radius:0;border-bottom-left-radius:0}.navbar-btn{margin-top:8px;margin-bottom:8px}.navbar-btn.btn-sm{margin-top:10px;margin-bottom:10px}.navbar-btn.btn-xs{margin-top:14px;margin-bottom:14px}.navbar-text{margin-top:15px;margin-bottom:15px}@media (min-width:768px){.navbar-text{float:left;margin-right:15px;margin-left:15px}}@media (min-width:768px){.navbar-left{float:left!important}.navbar-right{float:right!important;margin-right:-15px}.navbar-right~.navbar-right{margin-right:0}}.navbar-default{background-color:#f8f8f8;border-color:#e7e7e7}.navbar-default .navbar-brand{color:#777}.navbar-default .navbar-brand:hover,.navbar-default .navbar-brand:focus{color:#5e5e5e;background-color:transparent}.navbar-default .navbar-text{color:#777}.navbar-default .navbar-nav>li>a{color:#777}.navbar-default .navbar-nav>li>a:hover,.navbar-default .navbar-nav>li>a:focus{color:#333;background-color:transparent}.navbar-default .navbar-nav>.active>a,.navbar-default .navbar-nav>.active>a:hover,.navbar-default .navbar-nav>.active>a:focus{color:#555;background-color:#e7e7e7}.navbar-default .navbar-nav>.disabled>a,.navbar-default .navbar-nav>.disabled>a:hover,.navbar-default .navbar-nav>.disabled>a:focus{color:#ccc;background-color:transparent}.navbar-default .navbar-toggle{border-color:#ddd}.navbar-default .navbar-toggle:hover,.navbar-default .navbar-toggle:focus{background-color:#ddd}.navbar-default .navbar-toggle .icon-bar{background-color:#888}.navbar-default .navbar-collapse,.navbar-default .navbar-form{border-color:#e7e7e7}.navbar-default .navbar-nav>.open>a,.navbar-default .navbar-nav>.open>a:hover,.navbar-default .navbar-nav>.open>a:focus{color:#555;background-color:#e7e7e7}@media (max-width:767px){.navbar-default .navbar-nav .open .dropdown-menu>li>a{color:#777}.navbar-default .navbar-nav .open .dropdown-menu>li>a:hover,.navbar-default .navbar-nav .open .dropdown-menu>li>a:focus{color:#333;background-color:transparent}.navbar-default .navbar-nav .open .dropdown-menu>.active>a,.navbar-default .navbar-nav .open .dropdown-menu>.active>a:hover,.navbar-default .navbar-nav .open .dropdown-menu>.active>a:focus{color:#555;background-color:#e7e7e7}.navbar-default .navbar-nav .open .dropdown-menu>.disabled>a,.navbar-default .navbar-nav .open .dropdown-menu>.disabled>a:hover,.navbar-default .navbar-nav .open .dropdown-menu>.disabled>a:focus{color:#ccc;background-color:transparent}}.navbar-default .navbar-link{color:#777}.navbar-default .navbar-link:hover{color:#333}.navbar-default .btn-link{color:#777}.navbar-default .btn-link:hover,.navbar-default .btn-link:focus{color:#333}.navbar-default .btn-link[disabled]:hover,fieldset[disabled] .navbar-default .btn-link:hover,.navbar-default .btn-link[disabled]:focus,fieldset[disabled] .navbar-default .btn-link:focus{color:#ccc}.navbar-inverse{background-color:#222;border-color:#080808}.navbar-inverse .navbar-brand{color:#9d9d9d}.navbar-inverse .navbar-brand:hover,.navbar-inverse .navbar-brand:focus{color:#fff;background-color:transparent}.navbar-inverse .navbar-text{color:#9d9d9d}.navbar-inverse .navbar-nav>li>a{color:#9d9d9d}.navbar-inverse .navbar-nav>li>a:hover,.navbar-inverse .navbar-nav>li>a:focus{color:#fff;background-color:transparent}.navbar-inverse .navbar-nav>.active>a,.navbar-inverse .navbar-nav>.active>a:hover,.navbar-inverse .navbar-nav>.active>a:focus{color:#fff;background-color:#080808}.navbar-inverse .navbar-nav>.disabled>a,.navbar-inverse .navbar-nav>.disabled>a:hover,.navbar-inverse .navbar-nav>.disabled>a:focus{color:#444;background-color:transparent}.navbar-inverse .navbar-toggle{border-color:#333}.navbar-inverse .navbar-toggle:hover,.navbar-inverse .navbar-toggle:focus{background-color:#333}.navbar-inverse .navbar-toggle .icon-bar{background-color:#fff}.navbar-inverse .navbar-collapse,.navbar-inverse .navbar-form{border-color:#101010}.navbar-inverse .navbar-nav>.open>a,.navbar-inverse .navbar-nav>.open>a:hover,.navbar-inverse .navbar-nav>.open>a:focus{color:#fff;background-color:#080808}@media (max-width:767px){.navbar-inverse .navbar-nav .open .dropdown-menu>.dropdown-header{border-color:#080808}.navbar-inverse .navbar-nav .open .dropdown-menu .divider{background-color:#080808}.navbar-inverse .navbar-nav .open .dropdown-menu>li>a{color:#9d9d9d}.navbar-inverse .navbar-nav .open .dropdown-menu>li>a:hover,.navbar-inverse .navbar-nav .open .dropdown-menu>li>a:focus{color:#fff;background-color:transparent}.navbar-inverse .navbar-nav .open .dropdown-menu>.active>a,.navbar-inverse .navbar-nav .open .dropdown-menu>.active>a:hover,.navbar-inverse .navbar-nav .open .dropdown-menu>.active>a:focus{color:#fff;background-color:#080808}.navbar-inverse .navbar-nav .open .dropdown-menu>.disabled>a,.navbar-inverse .navbar-nav .open .dropdown-menu>.disabled>a:hover,.navbar-inverse .navbar-nav .open .dropdown-menu>.disabled>a:focus{color:#444;background-color:transparent}}.navbar-inverse .navbar-link{color:#9d9d9d}.navbar-inverse .navbar-link:hover{color:#fff}.navbar-inverse .btn-link{color:#9d9d9d}.navbar-inverse .btn-link:hover,.navbar-inverse .btn-link:focus{color:#fff}.navbar-inverse .btn-link[disabled]:hover,fieldset[disabled] .navbar-inverse .btn-link:hover,.navbar-inverse .btn-link[disabled]:focus,fieldset[disabled] .navbar-inverse .btn-link:focus{color:#444}.breadcrumb{padding:8px 15px;margin-bottom:20px;list-style:none;background-color:#f5f5f5;border-radius:4px}.breadcrumb>li{display:inline-block}.breadcrumb>li+li:before{padding:0 5px;color:#ccc;content:"/\00a0"}.breadcrumb>.active{color:#777}.pagination{display:inline-block;padding-left:0;margin:20px 0;border-radius:4px}.pagination>li{display:inline}.pagination>li>a,.pagination>li>span{position:relative;float:left;padding:6px 12px;margin-left:-1px;line-height:1.42857143;color:#428bca;text-decoration:none;background-color:#fff;border:1px solid #ddd}.pagination>li:first-child>a,.pagination>li:first-child>span{margin-left:0;border-top-left-radius:4px;border-bottom-left-radius:4px}.pagination>li:last-child>a,.pagination>li:last-child>span{border-top-right-radius:4px;border-bottom-right-radius:4px}.pagination>li>a:hover,.pagination>li>span:hover,.pagination>li>a:focus,.pagination>li>span:focus{color:#2a6496;background-color:#eee;border-color:#ddd}.pagination>.active>a,.pagination>.active>span,.pagination>.active>a:hover,.pagination>.active>span:hover,.pagination>.active>a:focus,.pagination>.active>span:focus{z-index:2;color:#fff;cursor:default;background-color:#428bca;border-color:#428bca}.pagination>.disabled>span,.pagination>.disabled>span:hover,.pagination>.disabled>span:focus,.pagination>.disabled>a,.pagination>.disabled>a:hover,.pagination>.disabled>a:focus{color:#777;cursor:not-allowed;background-color:#fff;border-color:#ddd}.pagination-lg>li>a,.pagination-lg>li>span{padding:10px 16px;font-size:18px}.pagination-lg>li:first-child>a,.pagination-lg>li:first-child>span{border-top-left-radius:6px;border-bottom-left-radius:6px}.pagination-lg>li:last-child>a,.pagination-lg>li:last-child>span{border-top-right-radius:6px;border-bottom-right-radius:6px}.pagination-sm>li>a,.pagination-sm>li>span{padding:5px 10px;font-size:12px}.pagination-sm>li:first-child>a,.pagination-sm>li:first-child>span{border-top-left-radius:3px;border-bottom-left-radius:3px}.pagination-sm>li:last-child>a,.pagination-sm>li:last-child>span{border-top-right-radius:3px;border-bottom-right-radius:3px}.pager{padding-left:0;margin:20px 0;text-align:center;list-style:none}.pager li{display:inline}.pager li>a,.pager li>span{display:inline-block;padding:5px 14px;background-color:#fff;border:1px solid #ddd;border-radius:15px}.pager li>a:hover,.pager li>a:focus{text-decoration:none;background-color:#eee}.pager .next>a,.pager .next>span{float:right}.pager .previous>a,.pager .previous>span{float:left}.pager .disabled>a,.pager .disabled>a:hover,.pager .disabled>a:focus,.pager .disabled>span{color:#777;cursor:not-allowed;background-color:#fff}.label{display:inline;padding:.2em .6em .3em;font-size:75%;font-weight:700;line-height:1;color:#fff;text-align:center;white-space:nowrap;vertical-align:baseline;border-radius:.25em}a.label:hover,a.label:focus{color:#fff;text-decoration:none;cursor:pointer}.label:empty{display:none}.btn .label{position:relative;top:-1px}.label-default{background-color:#777}.label-default[href]:hover,.label-default[href]:focus{background-color:#5e5e5e}.label-primary{background-color:#428bca}.label-primary[href]:hover,.label-primary[href]:focus{background-color:#3071a9}.label-success{background-color:#5cb85c}.label-success[href]:hover,.label-success[href]:focus{background-color:#449d44}.label-info{background-color:#5bc0de}.label-info[href]:hover,.label-info[href]:focus{background-color:#31b0d5}.label-warning{background-color:#f0ad4e}.label-warning[href]:hover,.label-warning[href]:focus{background-color:#ec971f}.label-danger{background-color:#d9534f}.label-danger[href]:hover,.label-danger[href]:focus{background-color:#c9302c}.badge{display:inline-block;min-width:10px;padding:3px 7px;font-size:12px;font-weight:700;line-height:1;color:#fff;text-align:center;white-space:nowrap;vertical-align:baseline;background-color:#777;border-radius:10px}.badge:empty{display:none}.btn .badge{position:relative;top:-1px}.btn-xs .badge{top:0;padding:1px 5px}a.badge:hover,a.badge:focus{color:#fff;text-decoration:none;cursor:pointer}a.list-group-item.active>.badge,.nav-pills>.active>a>.badge{color:#428bca;background-color:#fff}.nav-pills>li>a>.badge{margin-left:3px}.jumbotron{padding:30px 15px;margin-bottom:30px;color:inherit;background-color:#eee}.jumbotron h1,.jumbotron .h1{color:inherit}.jumbotron p{margin-bottom:15px;font-size:21px;font-weight:200}.jumbotron>hr{border-top-color:#d5d5d5}.container .jumbotron,.container-fluid .jumbotron{border-radius:6px}.jumbotron .container{max-width:100%}@media screen and (min-width:768px){.jumbotron{padding:48px 0}.container .jumbotron{padding-right:60px;padding-left:60px}.jumbotron h1,.jumbotron .h1{font-size:63px}}.thumbnail{display:block;padding:4px;margin-bottom:20px;line-height:1.42857143;background-color:#fff;border:1px solid #ddd;border-radius:4px;-webkit-transition:border .2s ease-in-out;-o-transition:border .2s ease-in-out;transition:border .2s ease-in-out}.thumbnail>img,.thumbnail a>img{margin-right:auto;margin-left:auto}a.thumbnail:hover,a.thumbnail:focus,a.thumbnail.active{border-color:#428bca}.thumbnail .caption{padding:9px;color:#333}.alert{padding:15px;margin-bottom:20px;border:1px solid transparent;border-radius:4px}.alert h4{margin-top:0;color:inherit}.alert .alert-link{font-weight:700}.alert>p,.alert>ul{margin-bottom:0}.alert>p+p{margin-top:5px}.alert-dismissable,.alert-dismissible{padding-right:35px}.alert-dismissable .close,.alert-dismissible .close{position:relative;top:-2px;right:-21px;color:inherit}.alert-success{color:#3c763d;background-color:#dff0d8;border-color:#d6e9c6}.alert-success hr{border-top-color:#c9e2b3}.alert-success .alert-link{color:#2b542c}.alert-info{color:#31708f;background-color:#d9edf7;border-color:#bce8f1}.alert-info hr{border-top-color:#a6e1ec}.alert-info .alert-link{color:#245269}.alert-warning{color:#8a6d3b;background-color:#fcf8e3;border-color:#faebcc}.alert-warning hr{border-top-color:#f7e1b5}.alert-warning .alert-link{color:#66512c}.alert-danger{color:#a94442;background-color:#f2dede;border-color:#ebccd1}.alert-danger hr{border-top-color:#e4b9c0}.alert-danger .alert-link{color:#843534}@-webkit-keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}@-o-keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}@keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}.progress{height:20px;margin-bottom:20px;overflow:hidden;background-color:#f5f5f5;border-radius:4px;-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,.1);box-shadow:inset 0 1px 2px rgba(0,0,0,.1)}.progress-bar{float:left;width:0;height:100%;font-size:12px;line-height:20px;color:#fff;text-align:center;background-color:#428bca;-webkit-box-shadow:inset 0 -1px 0 rgba(0,0,0,.15);box-shadow:inset 0 -1px 0 rgba(0,0,0,.15);-webkit-transition:width .6s ease;-o-transition:width .6s ease;transition:width .6s ease}.progress-striped .progress-bar,.progress-bar-striped{background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:-o-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);-webkit-background-size:40px 40px;background-size:40px 40px}.progress.active .progress-bar,.progress-bar.active{-webkit-animation:progress-bar-stripes 2s linear infinite;-o-animation:progress-bar-stripes 2s linear infinite;animation:progress-bar-stripes 2s linear infinite}.progress-bar-success{background-color:#5cb85c}.progress-striped .progress-bar-success{background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:-o-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent)}.progress-bar-info{background-color:#5bc0de}.progress-striped .progress-bar-info{background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:-o-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent)}.progress-bar-warning{background-color:#f0ad4e}.progress-striped .progress-bar-warning{background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:-o-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent)}.progress-bar-danger{background-color:#d9534f}.progress-striped .progress-bar-danger{background-image:-webkit-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:-o-linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent)}.media{margin-top:15px}.media:first-child{margin-top:0}.media-right,.media>.pull-right{padding-left:10px}.media-left,.media>.pull-left{padding-right:10px}.media-left,.media-right,.media-body{display:table-cell;vertical-align:top}.media-middle{vertical-align:middle}.media-bottom{vertical-align:bottom}.media-heading{margin-top:0;margin-bottom:5px}.media-list{padding-left:0;list-style:none}.list-group{padding-left:0;margin-bottom:20px}.list-group-item{position:relative;display:block;padding:10px 15px;margin-bottom:-1px;background-color:#fff;border:1px solid #ddd}.list-group-item:first-child{border-top-left-radius:4px;border-top-right-radius:4px}.list-group-item:last-child{margin-bottom:0;border-bottom-right-radius:4px;border-bottom-left-radius:4px}.list-group-item>.badge{float:right}.list-group-item>.badge+.badge{margin-right:5px}a.list-group-item{color:#555}a.list-group-item .list-group-item-heading{color:#333}a.list-group-item:hover,a.list-group-item:focus{color:#555;text-decoration:none;background-color:#f5f5f5}.list-group-item.disabled,.list-group-item.disabled:hover,.list-group-item.disabled:focus{color:#777;cursor:not-allowed;background-color:#eee}.list-group-item.disabled .list-group-item-heading,.list-group-item.disabled:hover .list-group-item-heading,.list-group-item.disabled:focus .list-group-item-heading{color:inherit}.list-group-item.disabled .list-group-item-text,.list-group-item.disabled:hover .list-group-item-text,.list-group-item.disabled:focus .list-group-item-text{color:#777}.list-group-item.active,.list-group-item.active:hover,.list-group-item.active:focus{z-index:2;color:#fff;background-color:#428bca;border-color:#428bca}.list-group-item.active .list-group-item-heading,.list-group-item.active:hover .list-group-item-heading,.list-group-item.active:focus .list-group-item-heading,.list-group-item.active .list-group-item-heading>small,.list-group-item.active:hover .list-group-item-heading>small,.list-group-item.active:focus .list-group-item-heading>small,.list-group-item.active .list-group-item-heading>.small,.list-group-item.active:hover .list-group-item-heading>.small,.list-group-item.active:focus .list-group-item-heading>.small{color:inherit}.list-group-item.active .list-group-item-text,.list-group-item.active:hover .list-group-item-text,.list-group-item.active:focus .list-group-item-text{color:#e1edf7}.list-group-item-success{color:#3c763d;background-color:#dff0d8}a.list-group-item-success{color:#3c763d}a.list-group-item-success .list-group-item-heading{color:inherit}a.list-group-item-success:hover,a.list-group-item-success:focus{color:#3c763d;background-color:#d0e9c6}a.list-group-item-success.active,a.list-group-item-success.active:hover,a.list-group-item-success.active:focus{color:#fff;background-color:#3c763d;border-color:#3c763d}.list-group-item-info{color:#31708f;background-color:#d9edf7}a.list-group-item-info{color:#31708f}a.list-group-item-info .list-group-item-heading{color:inherit}a.list-group-item-info:hover,a.list-group-item-info:focus{color:#31708f;background-color:#c4e3f3}a.list-group-item-info.active,a.list-group-item-info.active:hover,a.list-group-item-info.active:focus{color:#fff;background-color:#31708f;border-color:#31708f}.list-group-item-warning{color:#8a6d3b;background-color:#fcf8e3}a.list-group-item-warning{color:#8a6d3b}a.list-group-item-warning .list-group-item-heading{color:inherit}a.list-group-item-warning:hover,a.list-group-item-warning:focus{color:#8a6d3b;background-color:#faf2cc}a.list-group-item-warning.active,a.list-group-item-warning.active:hover,a.list-group-item-warning.active:focus{color:#fff;background-color:#8a6d3b;border-color:#8a6d3b}.list-group-item-danger{color:#a94442;background-color:#f2dede}a.list-group-item-danger{color:#a94442}a.list-group-item-danger .list-group-item-heading{color:inherit}a.list-group-item-danger:hover,a.list-group-item-danger:focus{color:#a94442;background-color:#ebcccc}a.list-group-item-danger.active,a.list-group-item-danger.active:hover,a.list-group-item-danger.active:focus{color:#fff;background-color:#a94442;border-color:#a94442}.list-group-item-heading{margin-top:0;margin-bottom:5px}.list-group-item-text{margin-bottom:0;line-height:1.3}.panel{margin-bottom:20px;background-color:#fff;border:1px solid transparent;border-radius:4px;-webkit-box-shadow:0 1px 1px rgba(0,0,0,.05);box-shadow:0 1px 1px rgba(0,0,0,.05)}.panel-body{padding:15px}.panel-heading{padding:10px 15px;border-bottom:1px solid transparent;border-top-left-radius:3px;border-top-right-radius:3px}.panel-heading>.dropdown .dropdown-toggle{color:inherit}.panel-title{margin-top:0;margin-bottom:0;font-size:16px;color:inherit}.panel-title>a{color:inherit}.panel-footer{padding:10px 15px;background-color:#f5f5f5;border-top:1px solid #ddd;border-bottom-right-radius:3px;border-bottom-left-radius:3px}.panel>.list-group,.panel>.panel-collapse>.list-group{margin-bottom:0}.panel>.list-group .list-group-item,.panel>.panel-collapse>.list-group .list-group-item{border-width:1px 0;border-radius:0}.panel>.list-group:first-child .list-group-item:first-child,.panel>.panel-collapse>.list-group:first-child .list-group-item:first-child{border-top:0;border-top-left-radius:3px;border-top-right-radius:3px}.panel>.list-group:last-child .list-group-item:last-child,.panel>.panel-collapse>.list-group:last-child .list-group-item:last-child{border-bottom:0;border-bottom-right-radius:3px;border-bottom-left-radius:3px}.panel-heading+.list-group .list-group-item:first-child{border-top-width:0}.list-group+.panel-footer{border-top-width:0}.panel>.table,.panel>.table-responsive>.table,.panel>.panel-collapse>.table{margin-bottom:0}.panel>.table caption,.panel>.table-responsive>.table caption,.panel>.panel-collapse>.table caption{padding-right:15px;padding-left:15px}.panel>.table:first-child,.panel>.table-responsive:first-child>.table:first-child{border-top-left-radius:3px;border-top-right-radius:3px}.panel>.table:first-child>thead:first-child>tr:first-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child,.panel>.table:first-child>tbody:first-child>tr:first-child,.panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child{border-top-left-radius:3px;border-top-right-radius:3px}.panel>.table:first-child>thead:first-child>tr:first-child td:first-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child td:first-child,.panel>.table:first-child>tbody:first-child>tr:first-child td:first-child,.panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child td:first-child,.panel>.table:first-child>thead:first-child>tr:first-child th:first-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child th:first-child,.panel>.table:first-child>tbody:first-child>tr:first-child th:first-child,.panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child th:first-child{border-top-left-radius:3px}.panel>.table:first-child>thead:first-child>tr:first-child td:last-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child td:last-child,.panel>.table:first-child>tbody:first-child>tr:first-child td:last-child,.panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child td:last-child,.panel>.table:first-child>thead:first-child>tr:first-child th:last-child,.panel>.table-responsive:first-child>.table:first-child>thead:first-child>tr:first-child th:last-child,.panel>.table:first-child>tbody:first-child>tr:first-child th:last-child,.panel>.table-responsive:first-child>.table:first-child>tbody:first-child>tr:first-child th:last-child{border-top-right-radius:3px}.panel>.table:last-child,.panel>.table-responsive:last-child>.table:last-child{border-bottom-right-radius:3px;border-bottom-left-radius:3px}.panel>.table:last-child>tbody:last-child>tr:last-child,.panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child,.panel>.table:last-child>tfoot:last-child>tr:last-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child{border-bottom-right-radius:3px;border-bottom-left-radius:3px}.panel>.table:last-child>tbody:last-child>tr:last-child td:first-child,.panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child td:first-child,.panel>.table:last-child>tfoot:last-child>tr:last-child td:first-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child td:first-child,.panel>.table:last-child>tbody:last-child>tr:last-child th:first-child,.panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child th:first-child,.panel>.table:last-child>tfoot:last-child>tr:last-child th:first-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child th:first-child{border-bottom-left-radius:3px}.panel>.table:last-child>tbody:last-child>tr:last-child td:last-child,.panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child td:last-child,.panel>.table:last-child>tfoot:last-child>tr:last-child td:last-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child td:last-child,.panel>.table:last-child>tbody:last-child>tr:last-child th:last-child,.panel>.table-responsive:last-child>.table:last-child>tbody:last-child>tr:last-child th:last-child,.panel>.table:last-child>tfoot:last-child>tr:last-child th:last-child,.panel>.table-responsive:last-child>.table:last-child>tfoot:last-child>tr:last-child th:last-child{border-bottom-right-radius:3px}.panel>.panel-body+.table,.panel>.panel-body+.table-responsive,.panel>.table+.panel-body,.panel>.table-responsive+.panel-body{border-top:1px solid #ddd}.panel>.table>tbody:first-child>tr:first-child th,.panel>.table>tbody:first-child>tr:first-child td{border-top:0}.panel>.table-bordered,.panel>.table-responsive>.table-bordered{border:0}.panel>.table-bordered>thead>tr>th:first-child,.panel>.table-responsive>.table-bordered>thead>tr>th:first-child,.panel>.table-bordered>tbody>tr>th:first-child,.panel>.table-responsive>.table-bordered>tbody>tr>th:first-child,.panel>.table-bordered>tfoot>tr>th:first-child,.panel>.table-responsive>.table-bordered>tfoot>tr>th:first-child,.panel>.table-bordered>thead>tr>td:first-child,.panel>.table-responsive>.table-bordered>thead>tr>td:first-child,.panel>.table-bordered>tbody>tr>td:first-child,.panel>.table-responsive>.table-bordered>tbody>tr>td:first-child,.panel>.table-bordered>tfoot>tr>td:first-child,.panel>.table-responsive>.table-bordered>tfoot>tr>td:first-child{border-left:0}.panel>.table-bordered>thead>tr>th:last-child,.panel>.table-responsive>.table-bordered>thead>tr>th:last-child,.panel>.table-bordered>tbody>tr>th:last-child,.panel>.table-responsive>.table-bordered>tbody>tr>th:last-child,.panel>.table-bordered>tfoot>tr>th:last-child,.panel>.table-responsive>.table-bordered>tfoot>tr>th:last-child,.panel>.table-bordered>thead>tr>td:last-child,.panel>.table-responsive>.table-bordered>thead>tr>td:last-child,.panel>.table-bordered>tbody>tr>td:last-child,.panel>.table-responsive>.table-bordered>tbody>tr>td:last-child,.panel>.table-bordered>tfoot>tr>td:last-child,.panel>.table-responsive>.table-bordered>tfoot>tr>td:last-child{border-right:0}.panel>.table-bordered>thead>tr:first-child>td,.panel>.table-responsive>.table-bordered>thead>tr:first-child>td,.panel>.table-bordered>tbody>tr:first-child>td,.panel>.table-responsive>.table-bordered>tbody>tr:first-child>td,.panel>.table-bordered>thead>tr:first-child>th,.panel>.table-responsive>.table-bordered>thead>tr:first-child>th,.panel>.table-bordered>tbody>tr:first-child>th,.panel>.table-responsive>.table-bordered>tbody>tr:first-child>th{border-bottom:0}.panel>.table-bordered>tbody>tr:last-child>td,.panel>.table-responsive>.table-bordered>tbody>tr:last-child>td,.panel>.table-bordered>tfoot>tr:last-child>td,.panel>.table-responsive>.table-bordered>tfoot>tr:last-child>td,.panel>.table-bordered>tbody>tr:last-child>th,.panel>.table-responsive>.table-bordered>tbody>tr:last-child>th,.panel>.table-bordered>tfoot>tr:last-child>th,.panel>.table-responsive>.table-bordered>tfoot>tr:last-child>th{border-bottom:0}.panel>.table-responsive{margin-bottom:0;border:0}.panel-group{margin-bottom:20px}.panel-group .panel{margin-bottom:0;border-radius:4px}.panel-group .panel+.panel{margin-top:5px}.panel-group .panel-heading{border-bottom:0}.panel-group .panel-heading+.panel-collapse>.panel-body,.panel-group .panel-heading+.panel-collapse>.list-group{border-top:1px solid #ddd}.panel-group .panel-footer{border-top:0}.panel-group .panel-footer+.panel-collapse .panel-body{border-bottom:1px solid #ddd}.panel-default{border-color:#ddd}.panel-default>.panel-heading{color:#333;background-color:#f5f5f5;border-color:#ddd}.panel-default>.panel-heading+.panel-collapse>.panel-body{border-top-color:#ddd}.panel-default>.panel-heading .badge{color:#f5f5f5;background-color:#333}.panel-default>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#ddd}.panel-primary{border-color:#428bca}.panel-primary>.panel-heading{color:#fff;background-color:#428bca;border-color:#428bca}.panel-primary>.panel-heading+.panel-collapse>.panel-body{border-top-color:#428bca}.panel-primary>.panel-heading .badge{color:#428bca;background-color:#fff}.panel-primary>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#428bca}.panel-success{border-color:#d6e9c6}.panel-success>.panel-heading{color:#3c763d;background-color:#dff0d8;border-color:#d6e9c6}.panel-success>.panel-heading+.panel-collapse>.panel-body{border-top-color:#d6e9c6}.panel-success>.panel-heading .badge{color:#dff0d8;background-color:#3c763d}.panel-success>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#d6e9c6}.panel-info{border-color:#bce8f1}.panel-info>.panel-heading{color:#31708f;background-color:#d9edf7;border-color:#bce8f1}.panel-info>.panel-heading+.panel-collapse>.panel-body{border-top-color:#bce8f1}.panel-info>.panel-heading .badge{color:#d9edf7;background-color:#31708f}.panel-info>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#bce8f1}.panel-warning{border-color:#faebcc}.panel-warning>.panel-heading{color:#8a6d3b;background-color:#fcf8e3;border-color:#faebcc}.panel-warning>.panel-heading+.panel-collapse>.panel-body{border-top-color:#faebcc}.panel-warning>.panel-heading .badge{color:#fcf8e3;background-color:#8a6d3b}.panel-warning>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#faebcc}.panel-danger{border-color:#ebccd1}.panel-danger>.panel-heading{color:#a94442;background-color:#f2dede;border-color:#ebccd1}.panel-danger>.panel-heading+.panel-collapse>.panel-body{border-top-color:#ebccd1}.panel-danger>.panel-heading .badge{color:#f2dede;background-color:#a94442}.panel-danger>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#ebccd1}.embed-responsive{position:relative;display:block;height:0;padding:0;overflow:hidden}.embed-responsive .embed-responsive-item,.embed-responsive iframe,.embed-responsive embed,.embed-responsive object,.embed-responsive video{position:absolute;top:0;bottom:0;left:0;width:100%;height:100%;border:0}.embed-responsive.embed-responsive-16by9{padding-bottom:56.25%}.embed-responsive.embed-responsive-4by3{padding-bottom:75%}.well{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px solid #e3e3e3;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.05);box-shadow:inset 0 1px 1px rgba(0,0,0,.05)}.well blockquote{border-color:#ddd;border-color:rgba(0,0,0,.15)}.well-lg{padding:24px;border-radius:6px}.well-sm{padding:9px;border-radius:3px}.close{float:right;font-size:21px;font-weight:700;line-height:1;color:#000;text-shadow:0 1px 0 #fff;filter:alpha(opacity=20);opacity:.2}.close:hover,.close:focus{color:#000;text-decoration:none;cursor:pointer;filter:alpha(opacity=50);opacity:.5}button.close{-webkit-appearance:none;padding:0;cursor:pointer;background:0 0;border:0}.modal-open{overflow:hidden}.modal{position:fixed;top:0;right:0;bottom:0;left:0;z-index:1040;display:none;overflow:hidden;-webkit-overflow-scrolling:touch;outline:0}.modal.fade .modal-dialog{-webkit-transition:-webkit-transform .3s ease-out;-o-transition:-o-transform .3s ease-out;transition:transform .3s ease-out;-webkit-transform:translate(0,-25%);-ms-transform:translate(0,-25%);-o-transform:translate(0,-25%);transform:translate(0,-25%)}.modal.in .modal-dialog{-webkit-transform:translate(0,0);-ms-transform:translate(0,0);-o-transform:translate(0,0);transform:translate(0,0)}.modal-open .modal{overflow-x:hidden;overflow-y:auto}.modal-dialog{position:relative;width:auto;margin:10px}.modal-content{position:relative;background-color:#fff;-webkit-background-clip:padding-box;background-clip:padding-box;border:1px solid #999;border:1px solid rgba(0,0,0,.2);border-radius:6px;outline:0;-webkit-box-shadow:0 3px 9px rgba(0,0,0,.5);box-shadow:0 3px 9px rgba(0,0,0,.5)}.modal-backdrop{position:fixed;top:0;right:0;bottom:0;left:0;background-color:#000}.modal-backdrop.fade{filter:alpha(opacity=0);opacity:0}.modal-backdrop.in{filter:alpha(opacity=50);opacity:.5}.modal-header{min-height:16.43px;padding:15px;border-bottom:1px solid #e5e5e5}.modal-header .close{margin-top:-2px}.modal-title{margin:0;line-height:1.42857143}.modal-body{position:relative;padding:15px}.modal-footer{padding:15px;text-align:right;border-top:1px solid #e5e5e5}.modal-footer .btn+.btn{margin-bottom:0;margin-left:5px}.modal-footer .btn-group .btn+.btn{margin-left:-1px}.modal-footer .btn-block+.btn-block{margin-left:0}.modal-scrollbar-measure{position:absolute;top:-9999px;width:50px;height:50px;overflow:scroll}@media (min-width:768px){.modal-dialog{width:600px;margin:30px auto}.modal-content{-webkit-box-shadow:0 5px 15px rgba(0,0,0,.5);box-shadow:0 5px 15px rgba(0,0,0,.5)}.modal-sm{width:300px}}@media (min-width:992px){.modal-lg{width:900px}}.tooltip{position:absolute;z-index:1070;display:block;font-size:12px;line-height:1.4;visibility:visible;filter:alpha(opacity=0);opacity:0}.tooltip.in{filter:alpha(opacity=90);opacity:.9}.tooltip.top{padding:5px 0;margin-top:-3px}.tooltip.right{padding:0 5px;margin-left:3px}.tooltip.bottom{padding:5px 0;margin-top:3px}.tooltip.left{padding:0 5px;margin-left:-3px}.tooltip-inner{max-width:200px;padding:3px 8px;color:#fff;text-align:center;text-decoration:none;background-color:#000;border-radius:4px}.tooltip-arrow{position:absolute;width:0;height:0;border-color:transparent;border-style:solid}.tooltip.top .tooltip-arrow{bottom:0;left:50%;margin-left:-5px;border-width:5px 5px 0;border-top-color:#000}.tooltip.top-left .tooltip-arrow{bottom:0;left:5px;border-width:5px 5px 0;border-top-color:#000}.tooltip.top-right .tooltip-arrow{right:5px;bottom:0;border-width:5px 5px 0;border-top-color:#000}.tooltip.right .tooltip-arrow{top:50%;left:0;margin-top:-5px;border-width:5px 5px 5px 0;border-right-color:#000}.tooltip.left .tooltip-arrow{top:50%;right:0;margin-top:-5px;border-width:5px 0 5px 5px;border-left-color:#000}.tooltip.bottom .tooltip-arrow{top:0;left:50%;margin-left:-5px;border-width:0 5px 5px;border-bottom-color:#000}.tooltip.bottom-left .tooltip-arrow{top:0;left:5px;border-width:0 5px 5px;border-bottom-color:#000}.tooltip.bottom-right .tooltip-arrow{top:0;right:5px;border-width:0 5px 5px;border-bottom-color:#000}.popover{position:absolute;top:0;left:0;z-index:1060;display:none;max-width:276px;padding:1px;font-size:14px;font-weight:400;line-height:1.42857143;text-align:left;white-space:normal;background-color:#fff;-webkit-background-clip:padding-box;background-clip:padding-box;border:1px solid #ccc;border:1px solid rgba(0,0,0,.2);border-radius:6px;-webkit-box-shadow:0 5px 10px rgba(0,0,0,.2);box-shadow:0 5px 10px rgba(0,0,0,.2)}.popover.top{margin-top:-10px}.popover.right{margin-left:10px}.popover.bottom{margin-top:10px}.popover.left{margin-left:-10px}.popover-title{padding:8px 14px;margin:0;font-size:14px;background-color:#f7f7f7;border-bottom:1px solid #ebebeb;border-radius:5px 5px 0 0}.popover-content{padding:9px 14px}.popover>.arrow,.popover>.arrow:after{position:absolute;display:block;width:0;height:0;border-color:transparent;border-style:solid}.popover>.arrow{border-width:11px}.popover>.arrow:after{content:"";border-width:10px}.popover.top>.arrow{bottom:-11px;left:50%;margin-left:-11px;border-top-color:#999;border-top-color:rgba(0,0,0,.25);border-bottom-width:0}.popover.top>.arrow:after{bottom:1px;margin-left:-10px;content:" ";border-top-color:#fff;border-bottom-width:0}.popover.right>.arrow{top:50%;left:-11px;margin-top:-11px;border-right-color:#999;border-right-color:rgba(0,0,0,.25);border-left-width:0}.popover.right>.arrow:after{bottom:-10px;left:1px;content:" ";border-right-color:#fff;border-left-width:0}.popover.bottom>.arrow{top:-11px;left:50%;margin-left:-11px;border-top-width:0;border-bottom-color:#999;border-bottom-color:rgba(0,0,0,.25)}.popover.bottom>.arrow:after{top:1px;margin-left:-10px;content:" ";border-top-width:0;border-bottom-color:#fff}.popover.left>.arrow{top:50%;right:-11px;margin-top:-11px;border-right-width:0;border-left-color:#999;border-left-color:rgba(0,0,0,.25)}.popover.left>.arrow:after{right:1px;bottom:-10px;content:" ";border-right-width:0;border-left-color:#fff}.carousel{position:relative}.carousel-inner{position:relative;width:100%;overflow:hidden}.carousel-inner>.item{position:relative;display:none;-webkit-transition:.6s ease-in-out left;-o-transition:.6s ease-in-out left;transition:.6s ease-in-out left}.carousel-inner>.item>img,.carousel-inner>.item>a>img{line-height:1}@media all and (transform-3d),(-webkit-transform-3d){.carousel-inner>.item{-webkit-transition:-webkit-transform .6s ease-in-out;-o-transition:-o-transform .6s ease-in-out;transition:transform .6s ease-in-out;-webkit-backface-visibility:hidden;backface-visibility:hidden;-webkit-perspective:1000;perspective:1000}.carousel-inner>.item.next,.carousel-inner>.item.active.right{left:0;-webkit-transform:translate3d(100%,0,0);transform:translate3d(100%,0,0)}.carousel-inner>.item.prev,.carousel-inner>.item.active.left{left:0;-webkit-transform:translate3d(-100%,0,0);transform:translate3d(-100%,0,0)}.carousel-inner>.item.next.left,.carousel-inner>.item.prev.right,.carousel-inner>.item.active{left:0;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}}.carousel-inner>.active,.carousel-inner>.next,.carousel-inner>.prev{display:block}.carousel-inner>.active{left:0}.carousel-inner>.next,.carousel-inner>.prev{position:absolute;top:0;width:100%}.carousel-inner>.next{left:100%}.carousel-inner>.prev{left:-100%}.carousel-inner>.next.left,.carousel-inner>.prev.right{left:0}.carousel-inner>.active.left{left:-100%}.carousel-inner>.active.right{left:100%}.carousel-control{position:absolute;top:0;bottom:0;left:0;width:15%;font-size:20px;color:#fff;text-align:center;text-shadow:0 1px 2px rgba(0,0,0,.6);filter:alpha(opacity=50);opacity:.5}.carousel-control.left{background-image:-webkit-linear-gradient(left,rgba(0,0,0,.5) 0,rgba(0,0,0,.0001) 100%);background-image:-o-linear-gradient(left,rgba(0,0,0,.5) 0,rgba(0,0,0,.0001) 100%);background-image:-webkit-gradient(linear,left top,right top,from(rgba(0,0,0,.5)),to(rgba(0,0,0,.0001)));background-image:linear-gradient(to right,rgba(0,0,0,.5) 0,rgba(0,0,0,.0001) 100%);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#80000000', endColorstr='#00000000', GradientType=1);background-repeat:repeat-x}.carousel-control.right{right:0;left:auto;background-image:-webkit-linear-gradient(left,rgba(0,0,0,.0001) 0,rgba(0,0,0,.5) 100%);background-image:-o-linear-gradient(left,rgba(0,0,0,.0001) 0,rgba(0,0,0,.5) 100%);background-image:-webkit-gradient(linear,left top,right top,from(rgba(0,0,0,.0001)),to(rgba(0,0,0,.5)));background-image:linear-gradient(to right,rgba(0,0,0,.0001) 0,rgba(0,0,0,.5) 100%);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#00000000', endColorstr='#80000000', GradientType=1);background-repeat:repeat-x}.carousel-control:hover,.carousel-control:focus{color:#fff;text-decoration:none;filter:alpha(opacity=90);outline:0;opacity:.9}.carousel-control .icon-prev,.carousel-control .icon-next,.carousel-control .glyphicon-chevron-left,.carousel-control .glyphicon-chevron-right{position:absolute;top:50%;z-index:5;display:inline-block}.carousel-control .icon-prev,.carousel-control .glyphicon-chevron-left{left:50%;margin-left:-10px}.carousel-control .icon-next,.carousel-control .glyphicon-chevron-right{right:50%;margin-right:-10px}.carousel-control .icon-prev,.carousel-control .icon-next{width:20px;height:20px;margin-top:-10px;font-family:serif}.carousel-control .icon-prev:before{content:'\2039'}.carousel-control .icon-next:before{content:'\203a'}.carousel-indicators{position:absolute;bottom:10px;left:50%;z-index:15;width:60%;padding-left:0;margin-left:-30%;text-align:center;list-style:none}.carousel-indicators li{display:inline-block;width:10px;height:10px;margin:1px;text-indent:-999px;cursor:pointer;background-color:#000 \9;background-color:rgba(0,0,0,0);border:1px solid #fff;border-radius:10px}.carousel-indicators .active{width:12px;height:12px;margin:0;background-color:#fff}.carousel-caption{position:absolute;right:15%;bottom:20px;left:15%;z-index:10;padding-top:20px;padding-bottom:20px;color:#fff;text-align:center;text-shadow:0 1px 2px rgba(0,0,0,.6)}.carousel-caption .btn{text-shadow:none}@media screen and (min-width:768px){.carousel-control .glyphicon-chevron-left,.carousel-control .glyphicon-chevron-right,.carousel-control .icon-prev,.carousel-control .icon-next{width:30px;height:30px;margin-top:-15px;font-size:30px}.carousel-control .glyphicon-chevron-left,.carousel-control .icon-prev{margin-left:-15px}.carousel-control .glyphicon-chevron-right,.carousel-control .icon-next{margin-right:-15px}.carousel-caption{right:20%;left:20%;padding-bottom:30px}.carousel-indicators{bottom:20px}}.clearfix:before,.clearfix:after,.dl-horizontal dd:before,.dl-horizontal dd:after,.container:before,.container:after,.container-fluid:before,.container-fluid:after,.row:before,.row:after,.form-horizontal .form-group:before,.form-horizontal .form-group:after,.btn-toolbar:before,.btn-toolbar:after,.btn-group-vertical>.btn-group:before,.btn-group-vertical>.btn-group:after,.nav:before,.nav:after,.navbar:before,.navbar:after,.navbar-header:before,.navbar-header:after,.navbar-collapse:before,.navbar-collapse:after,.pager:before,.pager:after,.panel-body:before,.panel-body:after,.modal-footer:before,.modal-footer:after{display:table;content:" "}.clearfix:after,.dl-horizontal dd:after,.container:after,.container-fluid:after,.row:after,.form-horizontal .form-group:after,.btn-toolbar:after,.btn-group-vertical>.btn-group:after,.nav:after,.navbar:after,.navbar-header:after,.navbar-collapse:after,.pager:after,.panel-body:after,.modal-footer:after{clear:both}.center-block{display:block;margin-right:auto;margin-left:auto}.pull-right{float:right!important}.pull-left{float:left!important}.hide{display:none!important}.show{display:block!important}.invisible{visibility:hidden}.text-hide{font:0/0 a;color:transparent;text-shadow:none;background-color:transparent;border:0}.hidden{display:none!important;visibility:hidden!important}.affix{position:fixed}@-ms-viewport{width:device-width}.visible-xs,.visible-sm,.visible-md,.visible-lg{display:none!important}.visible-xs-block,.visible-xs-inline,.visible-xs-inline-block,.visible-sm-block,.visible-sm-inline,.visible-sm-inline-block,.visible-md-block,.visible-md-inline,.visible-md-inline-block,.visible-lg-block,.visible-lg-inline,.visible-lg-inline-block{display:none!important}@media (max-width:767px){.visible-xs{display:block!important}table.visible-xs{display:table}tr.visible-xs{display:table-row!important}th.visible-xs,td.visible-xs{display:table-cell!important}}@media (max-width:767px){.visible-xs-block{display:block!important}}@media (max-width:767px){.visible-xs-inline{display:inline!important}}@media (max-width:767px){.visible-xs-inline-block{display:inline-block!important}}@media (min-width:768px) and (max-width:991px){.visible-sm{display:block!important}table.visible-sm{display:table}tr.visible-sm{display:table-row!important}th.visible-sm,td.visible-sm{display:table-cell!important}}@media (min-width:768px) and (max-width:991px){.visible-sm-block{display:block!important}}@media (min-width:768px) and (max-width:991px){.visible-sm-inline{display:inline!important}}@media (min-width:768px) and (max-width:991px){.visible-sm-inline-block{display:inline-block!important}}@media (min-width:992px) and (max-width:1199px){.visible-md{display:block!important}table.visible-md{display:table}tr.visible-md{display:table-row!important}th.visible-md,td.visible-md{display:table-cell!important}}@media (min-width:992px) and (max-width:1199px){.visible-md-block{display:block!important}}@media (min-width:992px) and (max-width:1199px){.visible-md-inline{display:inline!important}}@media (min-width:992px) and (max-width:1199px){.visible-md-inline-block{display:inline-block!important}}@media (min-width:1200px){.visible-lg{display:block!important}table.visible-lg{display:table}tr.visible-lg{display:table-row!important}th.visible-lg,td.visible-lg{display:table-cell!important}}@media (min-width:1200px){.visible-lg-block{display:block!important}}@media (min-width:1200px){.visible-lg-inline{display:inline!important}}@media (min-width:1200px){.visible-lg-inline-block{display:inline-block!important}}@media (max-width:767px){.hidden-xs{display:none!important}}@media (min-width:768px) and (max-width:991px){.hidden-sm{display:none!important}}@media (min-width:992px) and (max-width:1199px){.hidden-md{display:none!important}}@media (min-width:1200px){.hidden-lg{display:none!important}}.visible-print{display:none!important}@media print{.visible-print{display:block!important}table.visible-print{display:table}tr.visible-print{display:table-row!important}th.visible-print,td.visible-print{display:table-cell!important}}.visible-print-block{display:none!important}@media print{.visible-print-block{display:block!important}}.visible-print-inline{display:none!important}@media print{.visible-print-inline{display:inline!important}}.visible-print-inline-block{display:none!important}@media print{.visible-print-inline-block{display:inline-block!important}}@media print{.hidden-print{display:none!important}}</style>
	<style data-savepage-href="pareq/acsdata/sia.v1.css" type="text/css">html,
body {
  margin: 0;
  padding: 0;
  border: 1;
  outline: 0;
  font: normal 100% Helvetica, Arial, sans-serif;
  font-size: 14px;
  vertical-align: baseline;
  background-color: #ffffff
}

p {
  padding: 0 0;
}

.lblOtpClass{
  padding: 0 0;
  text-align: justify;
  line-height: 1.125em;
  font-size: 0.9em;
  font-weight: bold;
  margin: 0 0 0 10%;
}

.helpClass{
	width: 78%;
    margin: 0px 11%;
    max-height: 1.2em;
/*     margin-bottom: 5% */
}

.aboutClass{
	width: 78%;
    margin: 0px 11%;
    max-height: 1.2em;
}

/*
input[type=button] {
	text-transform: uppercase;
}
*/

input[type=text],
input[type=password],
select,
textarea {
  width: 80%;
  margin: 0 10% 0 10%;
}


input[type=text]:hover {
}

.btn-primary {
    border-color: #ffffff;
}

.pwdClassText{
	text-transform: uppercase;
	text-align: center;
}

#divWarningSessionTimeout{
	text-align: center;
}

#submitButton {
}

#sendBackButton{
  background-color: grey;
  border-color: grey;
  margin: 2% 10% 1em 10%;
  width: 80%;
  font-size: 1em;
}

#selectDeviceListDIV{
	margin: 0 auto;
}
#selectedDeviceValue{
	margin: 0 auto;
}

#device{
	margin: 0 auto;
}

#devicesList {
	text-align: justify;
	margin: 0 10%;
}

#devicesList label {
    padding-left: 1em;
}

#selectDeviceButton,
#nextOObButton {
  width: 80%;
  background-color: #ac0633;
  border-color: #ac0633;
  margin: 2% 10% 1em 10%;
}

#nextErrOObButton{
 width: 80%;
  background-color: #ac0633;
  border-color: #ac0633;
  margin: 2% 10% 1em 10%;
}

#shoppingButton {
  width: 80%;
  background-color: #ac0633;
  border-color: #ac0633;
  margin: 0 10% 1em 10%;
}

#nextButton, #nextStepButton {
  width: 80%;
  background-color: #ac0633;
  border-color: #ac0633;
  margin: 0 10% 1em 10%;
  font-size: 1em;
}

#cancelButton {
  width: 25%;
  color: black;
  cursor: pointer;
  float: right;
  background: none;
  font-size: 1em;
}

#cancelButton.btn.bordered {
  border: 1px solid transparent;
  border-radius: 4px;
  border-color: #000000;
}

/* Style the container */
.container {
  overflow: auto;
  width: 100%;
  max-width: 57em;
  /*max-width: 390px;
  height: 400px;*/
  margin: 0 auto;
  border: 0.0625em solid black;
  border-radius: 2%;
}

.issuerImageLoader {
  background-image: /*savepage-url=../acsimages/12928_sia_logo.png*/ url();
  width: 25%;
  height: 3.5em;
  background-repeat: no-repeat;
  background-size: contain;
  margin: 2% 37.5% 25% 37.5%;
}

/*******************************/

.cardHolderLoader_mastercard {
  background-image: url(../acsimages/mcidc.png);
  width: 25%;
  height: 3.5em;
  background-repeat: no-repeat;
  background-size: contain;
  margin: 2% auto 25% auto;
}

.cardHolderLoader_maestro {
  background-image: url(../acsimages/maestro.svg);
  width: 25%;
  height: 6em;
  background-repeat: no-repeat;
  background-size: contain;
  margin: 2% auto 25% auto;
}

.cardHolderLoader_visa {
  background-image: url(../acsimages/visa-secure.png);
  background-repeat: no-repeat;
  width: 25%;
  height: 3.5em;
  background-size: contain;
  margin: 2% 37.5% 25% 35.9%;
}

/*************************************/

/* Floating column for labels: 25% width */
.col-25 {
  float: left;
  width: 25%;
  margin-top: 0.375em;
}

/* Floating column for inputs: 75% width */
.col-75 {
  float: left;
  width: 50%;
	margin: 10% 0 0 25%;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

#secCheckout {
  width: 85%;
  margin: 0 0 1em 10%;
  height: 3.125em;
  background: #004B7F;
  border-radius: 3% 3% 0 0;
}

#top {
  display: flex;
}

#divLanguages {
  margin: 0.5em 10% 0px 0px;
  padding-left: 10%;
  width: 30%;
}

.countryFlag {
  padding-right: 6px;
  width: 23px;
}

#secCancelButton {
  width: 85%;
  margin: 0 0 1em 10%;
  height: 1.5625em;
  background: white;
  border-radius: 3% 3% 0 0;
}

#secFooter {
  width: 85%;
  margin: 0 auto 0.5em auto;
}

#divBrandingZone {
  margin-bottom: 4%;
  width: 100%;
  height: 3.125em;
}

.issuerImage {
  background-image: /*savepage-url=../acsimages/12928_sia_logo.png*/ url();
  width: 40%;
  height: 3em;
  background-repeat: no-repeat;
  background-size: contain;
  float: left;
  margin-left: 10%;
}

.cardInfoImage_mastercard {
  float: right;
  width: 30%;
  height: 3.5em;
  background-image: /*savepage-url=../acsimages/mcidc.png*/ url();
  background-repeat: no-repeat;
  background-size: contain;
  margin-right: 10%;
}

.cardInfoImage_maestro {
  float: right;
  width: 24%;
  height: 3.9em;
  background-image: /*savepage-url=../acsimages/maestro.svg*/ url();
  background-repeat: no-repeat;
  background-size: contain;
}

.cardInfoImage_visa {
  float: right;
  width: 20%;
  height: 3.5em;
  background-image: /*savepage-url=../acsimages/visa-secure.png*/ var(--savepage-url-5);
  background-repeat: no-repeat;
  background-size: contain;
  margin-right: 10%;
}

/***********inizio secure payment *****************/


#divInfoText {
  margin: 4% 10% 4% 10%;
  width: 80%;
  /*text-align: justify;*/
}

#divSuccessText {
  margin: 2% 10% 2% 10%;
  width: 80%;
  text-align: center;
}

#divInfoTextWarning {
	display: inline-flex;
    width: 80%;
}

#divInfoTextWarning span {
	margin: auto 0;
}

.divInfoTextFalback{

  margin: 5% 10% 5% 10%;
  width: 80%;
  text-align: justify;
}

.divInfoSuccessfully {
  margin: 1% 2% 5% 12%;
  width: 80%;
  text-align: justify;
}

#divDataEntry {
  margin: 0em 0em 1em 0em;
  width: 100%;
}


/***********fine secure payment *****************/


/********** OOB Help *******************/

.aboutCollapsButton {
  width: 80%;
  color: black;
  border: none;
  cursor: pointer;
  background: none;
  text-align: left;
  outline: none;
  margin: 2em 10% 0 10%;
}

.active,
 .aboutCollapsButton:hover {
}

.aboutCollapsButton:after {
  content: '\2193';
  color: black;
  font-weight: bold;
  float: right;
  margin-left: 0.3125em;
}

.active:after {
   content: '\2191';
}

.aboutContent {
  padding: 0 0;
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.2s ease-out;
  background-color: #f1f1f1;
}
.helpContent {
  padding: 0 0;
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.2s ease-out;
  background-color: #f1f1f1;
/*   margin-bottom: 1em; */
  text-align: justify;
}

/***********End OOB About ******************/


/********** Help Section *******************/

.helpCollapsButton {
  width: 80%;
  color: black;
  border: none;
  cursor: pointer;
  background: none;
  text-align: left;
  outline: none;
  margin: 0 10% 0 10%;
}

.active,
 .helpCollapsButton:hover {
}

.helpCollapsButton:after {
  content: '\2193';
  color: black;
  font-weight: bold;
  float: right;
  margin-left: 0.3125em;
}

.active:after {
  content: '\2191';
}

.content {
  padding: 0 0;
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.2s ease-out;
  background-color: #f1f1f1;
  margin-bottom: 5%;
}

/***********End Help ******************/


/********************per authentication****************/

#divWarningSessionTimeout2{
	text-align: center;
	margin-left: 1%;
}

.warningSessionExpired {
   /* margin: 2% 10% 2% 32%;*/
    margin-left: 32%;
    text-align: justify;
}

.warning {
  margin: 2% 10% 2% 10%;
  text-align: justify;
}

.info {
  margin: 2% 10% 2% 10%;
  /*text-align: justify;*/
}


#divPurchaseAuthenticationTitle {
	font-weight: bold;
	text-align: center;
    margin: 5% auto 5% auto;
}
/******* FINE SECURE PAYMENT */

/* Spinner */

.center {
  margin: 25% 45% 0 45%;
  width: 100%;
}

.centerSessionTimeOut {
  margin: 25% 45% 0 45%;
  height: 0px;
}

#loading {
  display: inline-block;
  width: 3.125em;
  height: 3.125em;
  border: 0.1875em solid lightgrey;
  border-radius: 50%;
  border-top-color: #fff;
  animation: spin 1s ease-in-out infinite;
  -webkit-animation: spin 1s ease-in-out infinite;
}

@keyframes spin {
  to {
    -webkit-transform: rotate(360deg);
  }
}

@-webkit-keyframes spin {
  to {
    -webkit-transform: rotate(360deg);
  }
}

#sessionExp {
  display: inline-block;
  width: 3.125em;
  height: 3.125em;
  border-radius: 50%;
}


.glyphRedClass {
    position: relative;
    border-radius: 50%;
    color: white;
    z-index:2;
    text-shadow: -2px 0 red, 0 2px red, 2px 0 red, 0 -2px red;
    font-size: x-large;
    float: left;
    margin-right: 2%;
}

.innerGlyph {
    position: absolute;
    top: 2px;
    left: 2px;
    right: 2px;
    bottom: 2px;
    border-radius: 50%;
    background-color: red;
    z-index: -1;
}

.buttonContainer {
    width: 80%;
    text-align: center;
    margin: 1em auto;
}

.warningLogo {
    height: 1.75em;
    margin: 0 1% 0 0;
    width: auto;
}

/* -------------------- RESPONSIVE -------------------- */

@media all and (min-width: 501px) and (max-width: 600px) {

  #main:before {
    content: 'mQuery: max-width: 600px';
  }

	html,
	body {
	  font-size: 13px;
	}

  .container {
	  width: 100%;
	  margin: 0 auto;
	  border: 0.0625em solid black;
	  border-radius: 2%;
	  height: 100%;
	}


	.divInfoTextWarning {
	    height: 3.0em;
	}

	#divDataEntry {
	    margin: 0em 0em 2% 0em;
	    width: 100%;
	}

	.divInfoTextWarning {
	    margin: 0 10% 0.50em 10%;
	    width: 80%;
	    height: 1.5em;
	}

	.divInfoText {
	    margin: 0.25em 10% 0.25em 10%;
	    width: 80%;
	}

	.lblOtpClass {
    	font-size: 0.9em;
    }

	.issuerImage {
	    width: 40%;
	    height: 3em;
	}

   .cardInfoImage_mastercard {
	  width: 24%;
	  height: 3.5em;
	}

   .cardInfoImage_maestro {
	  width: 24%;
	  height: 3.9em;
	}

	#divPurchaseAuthenticationTitle {
		margin: 2% auto 2% auto;
	}

	#nextButton, #nextStepButton {
	    margin: 0 10% 0.4em 10%;
	}

	#sendBackButton {
	    margin: 1% 10% 0.5em 10%;
	}


}

@media all and (min-width: 500px) and (max-width: 500px) {

  #main:before {
    content: 'mQuery: max-width: 500px';
  }

	html,
	body {
	  font-size: 14px;
	}

  .container {
	  width: 100%;
	  margin: 0 auto;
	  border: 0.0625em solid black;
	  border-radius: 2%;
	  height: 100%;
	}

	.divInfoTextWarning {
	    height: 3.0em;
	}

	/*
	input[type=text], select, textarea{
	    width: 80%;
	    padding: 0.60em 1.25%;
	    border: 0.0625em solid #ccc;
	    border-radius: 3%;
	    box-sizing: border-box;
	    resize: vertical;
	    margin: 0 10% 2em 10%;
	}*/

	#divDataEntry {
	    margin: 0em 0em 5% 0em;
	    width: 100%;
	}

	.divInfoTextWarning {
	    margin: 0 10% 0.50em 10%;
	    width: 80%;
	    height: 1.5em;
	}

	.divInfoText {
	    margin: 0.25em 10% 0.25em 10%;
	    width: 80%;
	}

	.lblOtpClass {
    	font-size: 0.9em;
    }

	.issuerImage {
	    width: 40%;
	    height: 3em;
	}

   .cardInfoImage_mastercard {
	  width: 28%;
	  height: 3.5em;
	}

   .cardInfoImage_maestro {
	  width: 28%;
	  height: 3.5em;
	}

	.center {
	  margin: 30% 37.5% 0 37.5%;
	}

	.centerSessionTimeOut{
		margin: 30% 37.5% 0 37.5%;
		height:600px;
	}

	.cardHolderLoader_mastercard {
	    width: 30%;
	    height: 3.5em;
	    margin: 2% auto 45% auto;
	}

	.cardHolderLoader_maestro {
	    width: 30%;
	    height: 3.5em;
	    margin: 2% auto 45% auto;
	}
}

@media all and (min-width: 391px) and (max-width: 499px) {

  #main:before {
    content: 'mQuery: max-width: 500px';
  }

	html,
	body {
	  font-size: 12px;
	}

  	.container {
	  width: 100%;
	  margin: 0 auto;
	  border: 0.0625em solid black;
	  border-radius: 2%;
	  height: 100%;
	}

	#cancelButton {
		width: 30%;
	}

	#submitButton {
    padding: 0.55em 1.25%;
    width: 84%;
    margin: 0 8% 0.75em 8%;
	}

	#nextOObButton {
    padding: 0.55em 1.25%;
    width: 84%;
    margin: 0 8% 0.75em 8%;
	}

	#shoppingButton {
    width: 84%;
    margin: 0 8% 0.75em 8%;
    font-size: 0.625em;
	}

	#divDataEntry {
	    margin: 0em 0em 5% 0em;
	    width: 100%;
	}

	.issuerImage {
	    width: 40%;
	    height: 2em;
	}
	.cardInfoImage_mastercard {
	    height: 3em;
	    width: 25%;
	}
	.cardInfoImage_maestro {
	    height: 3.5em;
	    width: 25%;
	}
	.cardInfoImage_visa {
	  height: 2em;
	}
	#divBrandingZone {
	  height: 2.3em;
	}

	.divInfoTextWarning {
	    margin: 0 10% 0.50em 10%;
	    width: 80%;
	    height: 1.5em;
	}

	.divInfoText {
	    margin: 0.25em 10% 0.25em 10%;
	    width: 80%;
	    /*text-align: justify;*/
	}

	.issuerImageLoader {
	  width: 45%;
	  margin: 2% 27.5% 25% 27.5%;
	}

	.center {
	  margin: 25% 37.5% 0 37.5%;
	}

	.cardHolderLoader_mastercard {
	    width: 30%;
	    height: 3.5em;
	    margin: 2% auto 45% auto;
	}

	.cardHolderLoader_maestro {
	    width: 30%;
	    height: 3.5em;
	    margin: 2% auto 45% auto;
	}

	.collapsible {
	    margin: 0.1em 10% 0 10%;
	    padding: 0.4em 4.25%;
	    font-size: 0.625em;
	}

}

/****************************************/
	html,
	body {
	  font-size: 12px;
	}

  	.container {
	  max-width: 390px;
	  max-height: 400px;
	  min-height: 400px;
	  margin: 0 auto;
	  border: 0.0625em solid black;
	  border-radius: 2%;
	}

	input[type=text],
	input[type=password],
	select,
	textarea {
	  font-size: 12px;
	}

	#cancelButton {
		width: 30%;
	}

	#nextButton, #nextStepButton {
	  width: 80%;
	  background-color: #ac0633;
	  border-color: #ac0633;
	  margin: 0 10% 0.8em 10%;
	  font-size: 1em;
	}

	#sendBackButton{
	  background-color: grey;
	  border-color: grey;
	  margin: 2% 10% 0.8em 10%;
	  width: 80%;
	  font-size: 1em;
	}

    #selectDeviceButton,
	#nextOObButton {
    padding: 0.55em 1.25%;
    width: 84%;
    margin: 0 8% 0.75em 8%;
	}

	#shoppingButton {
		font-size: 1em;
	    width: 84%;
	    margin: 0 8% 0.75em 8%;
	}

	#divDataEntry {
	    margin: 0em 0em 4% 0em;
	    width: 100%;
	}

	.issuerImage {
	width: 40%;
    height: 3em;
	}
	.cardInfoImage_mastercard {
    height: 3.5em;
    width: 30%;
	}
	.cardInfoImage_maestro {
		height: 3em;
	    width: 25%;
	}

	.cardInfoImage_visa {
	  height: 2em;
	}

	#divBrandingZone {
	  height: 2.3em;
	}

	.divInfoTextWarning {
	    margin: 0 10% 0.50em 10%;
	    width: 80%;
	    height: 1.5em;
	}

	.warning {
	  margin: 2% 10% 2% 10%;
	  /*text-align: justify;*/
	}

	.info {
	  margin: 2% 10% 1% 10%;
	  /*text-align: justify;*/
	}

	.divInfoText {
	    margin: 0.25em 10% 0.25em 10%;
	    width: 80%;
	    /*text-align: justify;*/
	}

	.issuerImageLoader {
	  width: 45%;
	  margin: 2% 27.5% 25% 27.5%;
	}

	.center {
	  margin: 30% 37.5% 0 46.9%;
	}

	.cardHolderLoader_mastercard {
	    width: 30%;
	    height: 3.5em;
	    margin: 2% auto 45% auto;
	}

	.cardHolderLoader_maestro {
	    width: 30%;
	    height: 3.5em;
	    margin: 2% auto 45% auto;
	}

	.collapsible {
	    margin: 0.1em 10% 0 10%;
	    padding: 0.4em 4.25%;
	    font-size: 0.625em;
	}

	.lblOtpClass {
    	font-size: 0.9em;
    }

     .pwdClassText{
		font-size: 0.9em;
	}

	.helpCollapsButton {
	  margin: 0.5em 10% 0 10%;
	}

	#loading {
	  display: inline-block;
	  width: 3.125em;
	  height: 3.125em;
	  border: 0.1875em solid lightgrey;
	  border-radius: 50%;
	  border-top-color: #fff;
	  animation: spin 1s ease-in-out infinite;
	  -webkit-animation: spin 1s ease-in-out infinite;
	}

	@keyframes spin {
	  to {
	    -webkit-transform: rotate(360deg);
	  }
	}

	@-webkit-keyframes spin {
	  to {
	    -webkit-transform: rotate(360deg);
	  }
	}
/************************/

.glyphiconDivClass{
	color: red;
    margin: 0 0 0 15%;
    width: 80%;
}

.glyphiconGenericClass{
	color: red;
}</style>

	<title>Return</title>

	<script type="text/javascript"></script>


<style id="savepage-cssvariables">
  :root {
    --savepage-url-5: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAD9wAAAZwCAYAAACFrN/oAAJSiElEQVR42uzdeZxeZXk//s8zLCHECBHQwEgME75MgrgBSXCrS7FuVau/1moLbkSSrkigLXbPJFCJFbuQSCjWabDf2s2lm12srUsrS6tY/YrGaDpqfKgbM6aoODDP7w8OMIGEzPo8Z3m/X6/nFcSEzLmu69znvs9zrnO3Op1OAAAAAAAAAAAAAAAAAAAAoGn6hAAAAAAAAAAAAAAAAAAAAIAm0nAPAAAAAAAAAAAAAAAAAABAI2m4BwAAAAAAAAAAAAAAAAAAoJE03AMAAAAAAAAAAAAAAAAAANBIGu4BAAAAAAAAAAAAAAAAAABoJA33AAAAAAAAAAAAAAAAAAAANJKGewAAAAAAAAAAAAAAAAAAABpJwz0AAAAAAAAAAAAAAAAAAACNpOEeAAAAAAAAAAAAAAAAAACARtJwDwAAAAAAAAAAAAAAAAAAQCNpuAcAAAAAAAAAAAAAAAAAAKCRNNwDAAAAAAAAAAAAAAAAAADQSBruAQAAAAAAAAAAAAAAAAAAaCQN9wAAAAAAAAAAAAAAAAAAADSShnsAAAAAAAAAAAAAAAAAAAAaScM9AAAAAAAAAAAAAAAAAAAAjaThHgAAAAAAAAAAAAAAAAAAgEbScA8AAAAAAAAAAAAAAAAAAEAjabgHAAAAAAAAAAAAAAAAAACgkTTcAwAAAAAAAAAAAAAAAAAA0Ega7gEAAAAAAAAAAAAAAAAAAGgkDfcAAAAAAAAAAAAAAAAAAAA0koZ7AAAAAAAAAAAAAAAAAAAAGknDPQAAAAAAAAAAAAAAAAAAAI2k4R4AAAAAAAAAAAAAAAAAAIBG0nAPAAAAAAAAAAAAAAAAAABAI2m4BwAAAAAAAAAAAAAAAAAAoJE03AMAAAAAAAAAAAAAAAAAANBIGu4BAAAAAAAAAAAAAAAAAABoJA33AAAAAAAAAAAAAAAAAAAANJKGewAAAAAAAAAAAAAAAAAAABpJwz0AAAAAAAAAAAAAAAAAAACNpOEeAAAAAAAAAAAAAAAAAACARtJwDwAAAAAAAAAAAAAAAAAAQCNpuAcAAAAAAAAAAAAAAAAAAKCRNNwDAAAAAAAAAAAAAAAAAADQSBruAQAAAAAAAAAAAAAAAAAAaCQN9wAAAAAAAAAAAAAAAAAAADSShnsAAAAAAAAAAAAAAAAAAAAaScM9AAAAAAAAAAAAAAAAAAAAjaThHgAAAAAAAAAAAAAAAAAAgEbScA8AAAAAAAAAAAAAAAAAAEAjabgHAAAAAAAAAAAAAAAAAACgkTTcAwAAAAAAAAAAAAAAAAAA0Ega7gEAAAAAAAAAAAAAAAAAAGgkDfcAAAAAAAAAAAAAAAAAAAA0koZ7AAAAAAAAAAAAAAAAAAAAGknDPQAAAAAAAAAAAAAAAAAAAI2k4R4AAAAAAAAAAAAAAAAAAIBG0nAPAAAAAAAAAAAAAAAAAABAI2m4BwAAAAAAAAAAAAAAAAAAoJE03AMAAAAAAAAAAAAAAAAAANBIGu4BAAAAAAAAAAAAAAAAAABoJA33AAAAAAAAAAAAAAAAAAAANJKGewAAAAAAAAAAAAAAAAAAABpJwz0AAAAAAAAAAAAAAAAAAACNpOEeAAAAAAAAAAAAAAAAAACARtJwDwAAAAAAAAAAAAAAAAAAQCNpuAcAAAAAAAAAAAAAAAAAAKCRNNwDAAAAAAAAAAAAAAAAAADQSBruAQAAAAAAAAAAAAAAAAAAaCQN9wAAAAAAAAAAAAAAAAAAADSShnsAAAAAAAAAAAAAAAAAAAAaScM9AAAAAAAAAAAAAAAAAAAAjaThHgAAAAAAAAAAAAAAAAAAgEbScA8AAAAAAAAAAAAAAAAAAEAjabgHAAAAAAAAAAAAAAAAAACgkTTcAwAAAAAAAAAAAAAAAAAA0Ega7gEAAAAAAAAAAAAAAAAAAGgkDfcAAAAAAAAAAAAAAAAAAAA0koZ7AAAAAAAAAAAAAAAAAAAAGknDPQAAAAAAAAAAAAAAAAAAAI2k4R4AAAAAAAAAAAAAAAAAAIBG0nAPAAAAAAAAAAAAAAAAAABAI2m4BwAAAAAAAAAAAAAAAAAAoJE03AMAAAAAAAAAAAAAAAAAANBIGu4BAAAAAAAAAAAAAAAAAABoJA33AAAAAAAAAAAAAAAAAAAANJKGewAAAAAAAAAAAAAAAAAAABpJwz0AAAAAAAAAAAAAAAAAAACNpOEeAAAAAAAAAAAAAAAAAACARtJwDwAAAAAAAAAAAAAAAAAAQCNpuAcAAAAAAAAAAAAAAAAAAKCRNNwDAAAAAAAAAAAAAAAAAADQSBruAQAAAAAAAAAAAAAAAAAAaCQN9wAAAAAAAAAAAAAAAAAAADSShnsAAAAAAAAAAAAAAAAAAAAaScM9AAAAAAAAAAAAAAAAAAAAjaThHgAAAAAAAAAAAAAAAAAAgEbScA8AAAAAAAAAAAAAAAAAAEAjabgHAAAAAAAAAAAAAAAAAACgkTTcAwAAAAAAAAAAAAAAAAAA0Ega7gEAAAAAAAAAAAAAAAAAAGgkDfcAAAAAAAAAAAAAAAAAAAA0koZ7AAAAAAAAAAAAAAAAAAAAGknDPQAAAAAAAAAAAAAAAAAAAI2k4R4AAAAAAAAAAAAAAAAAAIBG0nAPAAAAAAAAAAAAAAAAAABAI2m4BwAAAAAAAAAAAAAAAAAAoJE03AMAAAAAAAAAAAAAAAAAANBIGu4BAAAAAAAAAAAAAAAAAABoJA33AAAAAAAAAAAAAAAAAAAANJKGewAAAAAAAAAAAAAAAAAAABpJwz0AAAAAAAAAAAAAAAAAAACNpOEeAAAAAAAAAAAAAAAAAACARtJwDwAAAAAAAAAAAAAAAAAAQCNpuAcAAAAAAAAAAAAAAAAAAKCRNNwDAAAAAAAAAAAAAAAAAADQSBruAQAAAAAAAAAAAAAAAAAAaCQN9wAAAAAAAAAAAAAAAAAAADSShnsAAAAAAAAAAAAAAAAAAAAaScM9AAAAAAAAAAAAAAAAAAAAjaThHgAAAAAAAAAAAAAAAAAAgEbScA8AAAAAAAAAAAAAAAAAAEAjabgHAAAAAAAAAAAAAAAAAACgkTTcAwAAAAAAAAAAAAAAAAAA0Ega7gEAAAAAAAAAAAAAAAAAAGgkDfcAAAAAAAAAAAAAAAAAAAA0koZ7AAAAAAAAAAAAAAAAAAAAGknDPQAAAAAAAAAAAAAAAAAAAI2k4R4AAAAAAAAAAAAAAAAAAIBG0nAPAAAAAAAAAAAAAAAAAABAI2m4BwAAAAAAAAAAAAAAAAAAoJE03AMAAAAAAAAAAAAAAAAAANBIGu4BAAAAAAAAAAAAAAAAAABoJA33AAAAAAAAAAAAAAAAAAAANJKGewAAAAAAAAAAAAAAAAAAABpJwz0AAAAAAAAAAAAAAAAAAACNpOEeAAAAAAAAAAAAAAAAAACARtJwDwAAAAAAAAAAAAAAAAAAQCNpuAcAAAAAAAAAAAAAAAAAAKCRNNwDAAAAAAAAAAAAAAAAAADQSBruAQAAAAAAAAAAAAAAAAAAaCQN9wAAAAAAAAAAAAAAAAAAADSShnsAAAAAAAAAAAAAAAAAAAAaScM9AAAAAAAAAAAAAAAAAAAAjaThHgAAAAAAAAAAAAAAAAAAgEbScA8AAAAAAAAAAAAAAAAAAEAjabgHAAAAAAAAAAAAAAAAAACgkTTcAwAAAAAAAAAAAAAAAAAA0Ega7gEAAAAAAAAAAAAAAAAAAGgkDfcAAAAAAAAAAAAAAAAAAAA0koZ7AAAAAAAAAAAAAAAAAAAAGknDPQAAAAAAAAAAAAAAAAAAAI2k4R4AAAAAAAAAAAAAAAAAAIBG0nAPAAAAAAAAAAAAAAAAAABAI2m4BwAAAAAAAAAAAAAAAAAAoJE03AMAAAAAAAAAAAAAAAAAANBIGu4BAAAAAAAAAAAAAAAAAABoJA33AAAAAAAAAAAAAAAAAAAANJKGewAAAAAAAAAAAAAAAAAAABpJwz0AAAAAAAAAAAAAAAAAAACNpOEeAAAAAAAAAAAAAAAAAACARtJwDwAAAAAAAAAAAAAAAAAAQCNpuAcAAAAAAAAAAAAAAAAAAKCRNNwDAAAAAAAAAAAAAAAAAADQSBruAQAAAAAAAAAAAAAAAAAAaCQN9wAAAAAAAAAAAAAAAAAAADSShnsAAAAAAAAAAAAAAAAAAAAaScM9AAAAAAAAAAAAAAAAAAAAjaThHgAAAAAAAAAAAAAAAAAAgEbScA8AAAAAAAAAAAAAAAAAAEAjabgHAAAAAAAAAAAAAAAAAACgkTTcAwAAAAAAAAAAAAAAAAAA0Ega7gEAAAAAAAAAAAAAAAAAAGgkDfcAAAAAAAAAAAAAAAAAAAA0koZ7AAAAAAAAAAAAAAAAAAAAGknDPQAAAAAAAAAAAAAAAAAAAI2k4R4AAAAAAAAAAAAAAAAAAIBG0nAPAAAAAAAAAAAAAAAAAABAI2m4BwAAAAAAAAAAAAAAAAAAoJE03AMAAAAAAAAAAAAAAAAAANBIGu4BAAAAAAAAAAAAAAAAAABoJA33AAAAAAAAAAAAAAAAAAAANJKGewAAAAAAAAAAAAAAAAAAABpJwz0AAAAAAAAAAAAAAAAAAACNpOEeAAAAAAAAAAAAAAAAAACARtJwDwAAAAAAAAAAAAAAAAAAQCNpuAcAAAAAAAAAAAAAAAAAAKCRNNwDAAAAAAAAAAAAAAAAAADQSBruAQAAAAAAAAAAAAAAAAAAaCQN9wAAAAAAAAAAAAAAAAAAADSShnsAAAAAAAAAAAAAAAAAAAAaScM9AAAAAAAAAAAAAAAAAAAAjaThHgAAAAAAAAAAAAAAAAAAgEbScA8AAAAAAAAAAAAAAAAAAEAjabgHAAAAAAAAAAAAAAAAAACgkTTcAwAAAAAAAAAAAAAAAAAA0Ega7gEAAAAAAAAAAAAAAAAAAGgkDfcAAAAAAAAAAAAAAAAAAAA0koZ7AAAAAAAAAAAAAAAAAAAAGknDPQAAAAAAAAAAAAAAAAAAAI2k4R4AAAAAAAAAAAAAAAAAAIBG0nAPAAAAAAAAAAAAAAAAAABAI2m4BwAAAAAAAAAAAAAAAAAAoJE03AMAAAAAAAAAAAAAAAAAANBIGu4BAAAAAAAAAAAAAAAAAABoJA33AAAAAAAAAAAAAAAAAAAANJKGewAAAAAAAAAAAAAAAAAAABpJwz0AAAAAAAAAAAAAAAAAAACNpOEeAAAAAAAAAAAAAAAAAACARtJwDwAAAAAAAAAAAAAAAAAAQCNpuAcAAAAAAAAAAAAAAAAAAKCRNNwDAAAAAAAAAAAAAAAAAADQSBruAQAAAAAAAAAAAAAAAAAAaCQN9wAAAAAAAAAAAAAAAAAAADSShnsAAAAAAAAAAAAAAAAAAAAaScM9AAAAAAAAAAAAAAAAAAAAjaThHgAAAAAAAAAAAAAAAAAAgEbScA8AAAAAAAAAAAAAAAAAAEAjabgHAAAAAAAAAAAAAAAAAACgkTTcAwAAAAAAAAAAAAAAAAAA0Ega7gEAAAAAAAAAAAAAAAAAAGgkDfcAAAAAAAAAAAAAAAAAAAA0koZ7AAAAAAAAAAAAAAAAAAAAGknDPQAAAAAAAAAAAAAAAAAAAI2k4R4AAAAAAAAAAAAAAAAAAIBG0nAPAAAAAAAAAAAAAAAAAABAI2m4BwAAAAAAAAAAAAAAAAAAoJE03AMAAAAAAAAAAAAAAAAAANBIGu4BAAAAAAAAAAAAAAAAAABoJA33AAAAAAAAAAAAAAAAAAAANJKGewAAAAAAAAAAAAAAAAAAABpJwz0AAAAAAAAAAAAAAAAAAACNpOEeAAAAAAAAAAAAAAAAAACARtJwDwAAAAAAAAAAAAAAAAAAQCNpuAcAAAAAAAAAAAAAAAAAAKCRNNwDAAAAAAAAAAAAAAAAAADQSBruAQAAAAAAAAAAAAAAAAAAaCQN9wAAAAAAAAAAAAAAAAAAADSShnsAAAAAAAAAAAAAAAAAAAAaScM9AAAAAAAAAAAAAAAAAAAAjaThHgAAAAAAAAAAAAAAAAAAgEbScA8AAAAAAAAAAAAAAAAAAEAjabgHAAAAAAAAAAAAAAAAAACgkTTcAwAAAAAAAAAAAAAAAAAA0Ega7gEAAAAAAAAAAAAAAAAAAGgkDfcAAAAAAAAAAAAAAAAAAAA0koZ7AAAAAAAAAAAAAAAAAAAAGknDPQAAAAAAAAAAAAAAAAAAAI2k4R4AAAAAAAAAAAAAAAAAAIBGOlwIAAAAAAAAAACYjVarJQgA91px5dFJFiZZnGRRkqMm/fPCJA8rPkdN+ucFxe9J8fuOSKt12IP+XXKgf/dARyQ5epZH8f0k3530v7+b5M7in79XfFL8u3t/32iSiSTfTjKe5I5J//+9f/5/i39/R/H7Hvi/92X3L96tiKC8Op2OIAAAAABQOy03vgAAAAAAAAAAmA0N90Ct3NMwf1ySRyZ5RJJjDvA59gG/Tv7MzUY4zR1b723MH00yds+vrbH9//d9v35r0uebSb6V3b8wrohh/njuGAAAAIA60nAPAAAAAAAAAMCsaLgHSmvFlX1JTkjyqCQnFo309zbTH1c01B+X5Pji9x1X7DxfhsFV/u4PxnR+874kX9+vCT/5RpLbJv36teL33Jbdv3CH+MLUee4YAAAAgDrScA8AAAAAAAAAwKxouAe6bsWbFiXpLxrnT0pa9zbUP+qe/33vv88JSQ6r8AAr1/cHY77+w99N8j9FE367+OwtGvP3Tvp3X8vuX/DAJY3nuWMAAAAA6kjDPQAAAAAAAAAAs6LhHphTK960MMmyJI8uPicXn8n/7tgDjEZ1HGDVQ3nye1fRmL83yVeSfKn49d5//nKSdnb/wt1yRZ157hgAAACAOtJwDwAAAAAAAADArGi4B6ZlxZuOSXLKpM9AkuVFU/2jkzxihqNRXQdZNVOdHN+dpF003//3AT4j2f0Ld8ojVea5YwAAAADqSMM9AAAAAAAAAACzouEe2M+KNx2Z5DGTmukHHtBcv2SeRqO6DrJqql45bk9qwP/CPZ/WPb/uvvSrckzZee4YAAAAgDrScA8AAAAAAAAAwKxouIcGWvGmvmJH+v+TZGXx62nFZ3mSvh6NSHUcZNVbnfO7/3F95/4m/Hwhye4kny8+X87uSz3wSc957hgAAACAOtJwDwAAAAAAAADArGi4hxpb8aZjk5yeZLBoqh8smupPTXJUCUekug60arHWOZ7SMX2naLzfleRzxa+fTbIruy8dUxd0i+eOAQAAAKgjDfcAAAAAAAAAAMyKhnuogXsa6x9bNNc/dtI/n1TBUamOA60arXN+Z39c/5PkM8Xn1iT/L8mt2X3p/6gX5prnjgEAAACoIw33AAAAAAAAAADMioZ7qJAVVywumunPSPrOqHZj/UFHpboOtuq31jmel2O6Pcmnk3yu+PVTST6V3Zd+XQ0xU547BgAAAKCONNwDAAAAAAAAADArGu6hpFZc8egkT5z0eUKSFft39vbVcVSq62Crpuue4+4d1/8UzfefTvJfxa//L7sv/Y7a4lA8dwwAAABAHWm4BwAAAAAAAABgVjTcQ4+tuOKIJKuKhvrJDfaPOPQf7qtpUGo4Lhlr653f3h9XJ8nnk9yy32f3pW31xn6F4rljAAAAAGpIwz0AAAAAAAAAALOi4R66aMUVhyU5Pcnq4nN2kscnOXJm/0EN9xUbcJ0Dtc5xKY/paw9owv9Ekl3ZfemEGmwmzx0DAAAAUEca7gEAAAAAAAAAmBUN9zBPVlzRSnLqpMb6NUmelOTouf2L6th0r+G+AVcfx9U7/1s03v9Hkv8sPprwG8JzxwAAAADUkYZ7AAAAAAAAAABmRcM9zJEVVzwyyTlJnpLkrKLR/pj5/4vtcl+hAdd5Uuf8Vvu47m3Cv7n43JTdl35RndaP544BAAAAqCMN9wAAAAAAAAAAzIqGe5iBFVf0JTkjyZOTPLVotP8/vfuB7HJfoUHX+VPrHNfqmL6R5KZ7Pq2bktyc3Zd8Q91Wm+eOAQAAAKgjDfcAAAAAAAAAAMyKhnuYghVXPLxorn9ysYP9OUkWl+cHtMt9hQZd51Od81vb47rvmL6Y5GNJ/j3JDUn+K7svuUstV4fnjgEAAACoIw33AAAAAAAAAADMioZ7OIAVV5yQ5BlJnln8+thyd9FquK/YwOscq3WOG/Uige8kublowv9Ykhuy+5Kvqevy8twxAAAAAHWk4R4AAAAAAAAAgFnRcA9JVlxx4qQG+2cmGazeQdSx6V7DfQOuQo6rfse0K8lH7vvsvuSL6rw8PHcMAAAAQB1puIdunnAH+aJrydLzHpXkp7r0U3TteDtd/c6nrl+cTf+L7PKP6r7k7IWZnY9y5bjE4hD+N8ldD/jnTpLRB36+/dVrx+47H82/AaCx6/9eWrDs4jckOda80xrhoUy05Msxlfa4bhsfufIaV5jm6Fv+xrOSvMj56LjKcEy+62j0Mf1zZ8/QR4zKADykFVec/IAG+xU1mJGbF1fmkHxHbD3XqOPam+SjST5UNOF/JrsvmVD7veG5BwCYzTR+BnOhlW87IskJSR5+gE/2fxagtTDJAvNHx9Wbv0quuuDtuXXdl83tAWB+HC4EUArPSPIb3fmrOl2b8Lc63X4QjWroaAyWK2ich5904USSryX58sMfvf6rSb6a5CvFZ3eSz+3be+03Rapio6QbjQBUxIJlF5+e5K0iYe1zKH2dqjTdq8EG2iQEjfOTSS4WBoydctVjn5I/AB5kxeWPSPKsJOcmeU49GuwfaKLGTfd1m2p1NN1bIzRJf5IfLz5JcntOfctHk3y4aMT/j+y+5C5hAgAq555m+mVJTpn0eUySRxZzoBOSHG++b74vVxS+nOTtwgAA80PDPZTDaiGwOJsrrUrscq8Gu14XXoBhvKDX+pIsTbL0YOfj4v4Lb0+yq/jcmuQTSW7Zt/fa24QPAJilC4XA2gcq7K4k1wpD46w1dlIW3b23qgZL5gYhACArLj8qyVMmNdifqRu9qsy1ULc1syTJi4pPknwnp77lY0Xz/YeT3JDdl3xHmABoopaXMpXTyrcdnmRVVr7tsUlOT3JG8eupSQ4TIPN95GqKVmu4B4B5XE/ZlRG6eMId5AbGkqXnfSTJ07r803RnadGq3zF13/S/qy//yF7XXJX7uGZ+PrbkynGJRW/Px/Y9zfetW5J8LMm/79u741tyXII8WksBMM31fy8sWHbxgmI+scS80xphKqqxw70abNhx/dn4yJU/7urSHH3L33h4kn1JjnI+Oq6yHJPvOhp5XF/t7BnqNyoDNNCKy/uSPGFSg/3Tkixs3vW7ru8UqOlcS0OVtY/jOpA7i5dofSDJB5PclN2X3OUcmaN1su/KAUo+PTQ/7LmVb2slWVk0xp6dZE2x1uzSdx/mxY6r1yFUg/Po47l13Vnm9gAwP+xwDz22ZOl5hxVvQK/nEtDOLz1bzpV76SNX9T8fy04NUikn3vPpvKCo287i/vWfKd7M/5EkH963d8eXhQkAOIj/b26b7a0R6q6vU5WmezXYINuFoHGe0Ltme4ydcB+72wM0yYrLj0vyQ0men+R5SU4QlIkaN92DtU9DLEjyjOKzOcm+nPqWD09qwP9Udl+iswQAmBsr39aX5PFJnlm8uO0ZSY4XGPNi1OA8eHxWXbcwt677rpwAwNzTcA+999gkRwsDB+eLbAtpUIN1i8UsX4DRKuYPj02yPkkW96//bJL3J/mHJB/at3fH99QAAFC40LzTvBgqXIOfGh+58kPi2DhrjJ2UjZcLN9JNQgBQYysubyV5UpIXFE325/hS3joVqP35uDjJC4tPknw9p77lg/c14O++5ItyAgBMy8q3LS1e2vb8JOcmeYS1D6XOlbKoi8OLF5h7cTAAzNOFFuittXVfnNlVG6t2uQLm/XxcWXwuTvK9xf3r/zXJ+5K8Z9/eHf8jbgDQTAuWXfx/ijfnY+0zLeXf5V6uGsTu9s20VgiMnajBErhRzgBqZsXlxxYNEC8smiEeZa5FfaZanaSlBp2PTNMJSX68+CSnvuW/k/xz8flgdl/ie3YA4MFWvu3xSX40yQ8XL3LDfB+56oU1Gu4BYH5ouIfeWy0EFmfzoVVEAzW4X114AYbxgiacj0cVb859XpLti/vX/1uSP0vyl/v27viqyANAo7xeCLD2kasK+3aS64WhkdY6HyljrtxbbZSJJP8hDAA1sOLyU5O8JMmLkzw1yWGCMt1LYp8wQMPWPg22PMkFxSc59S2fTPL+JP+Q5N+y+5JxIQKAhlr5tjVJXpbkx5IMCAjm+3JVAmvkAgDmR6vT0Y4JXTvhDvA26SVLz7slyRN6+FN1Z2nRqt8xdd/0v8gu/whf11yV+7hmfj625MpxiUUpzscZH1MnyUeT7EzyZ/v27vi2+phl/qylAJjG+r/bFiy7+MgkXyl26THvtEaY9p+YaMmXY+r5cf3e+MiVF7mqNEvf8jcek+T2cpwMzkfHdIB7Ab7raMoxfbqzZ+hxRmWAClpxeavY9OAlSX4kyemudbOepZsXV+aQfEdsPee45tG+JB8omu/fn92XfKnpZ5nvygHKPjU0N5y1lW87JcmrkpyX5FRzLcdUq+PyXUcdjulzuXXdSnN7AJh7driHHlqy9Lyjk5zRhGPt7s4v3vI2eTlX7iWQXNX/fCw7NUij6raV5OnF5/cW969/d5LhJB/ct3fHhLgCQO28aH6b7c216q6vU5WmezVYY9uFoJHWOAkwdspVCdwgVwAVsuLyBUmeNWkn+5MEZS7Z5b46U62OpntrBObP4iQvLT7JqW/5TNF8/3dJPpLdl9wpRABQAyvftijJK5K8JsnTBMR8H0psMKuuOya3rhsTCgCYWxruobfOTHKYMEDduJmDGhSLqenhCzAWJvnJ4vPlxf3rr0nyB/v27vi6mgGA2lhv3olcUeEa/MD4yJWfE7dGWmPspMy8XLgxbhYCgJJbcfkxSV5Y7GL/vKIREsy1ULd0y+nF5+Ik382pb/lgkr9P8v7svuQLwgMAFbNy++lJfqrY0f7hAoL5PhXJ1Zok/yQfADC3NNxDb6014WfqvDke4wUwL05OcnmSX1/cv/5dSX5/394d/yksAFBdC5ZdfEqSc0XC2me2yr/LvVzV2NVC0FjnCIGxEzVYAjfKE0AJ3dNk/+IkL0/yQ0mOdJ2DB5agXe6dj3LVAwuLl8C8MEly6lu+kORv09f6qyQfzq6N43IMACW0cntfkpcl+bkkP2CuhSm4GqygszXcA8Dc03APvbW6SQdr55cexb2IhlU7vTsfy04Nom4LC5K8OsmrF/ev/1iStyR5z769OybEGwAq53UmuVj7yFWFfSnJ36iDxlrjfKTsuXJvtfa+k+TTwgBQEpVosm8CmwOAdSrTuXol+flMdH4+fa1v57Sr/j7JXyV5f3Zt/JbwAECPrdx+dJLXJtmYZMBcy7wYKlyDq+UBAOZeq9PpiAJ064R7wFuklyw974tJTinBT9a9pUWrnsfVXdP/Irv8I31dc1Xu45rZ+ShXjkssGnY+3prkyiR/vG/vjrvU0QPyZi0FwBTX/920YNnFhxfNqieaazmmuTiuiZZ8OaauH9cvj49c+VuuJs3Tt/yNj0ny385Hx1WFY/JdR62P6cOdPUPPMCoD9FAtmuzreP2ua8N9DXNlh3vrOcdVoqFzv2O6O8lHk/x1kr/Kro2fr/Kh+a4coOxTQnPCB1m5/dgkbyh2tH+EuZZjclzd/Kvkap58Nbeu6ze3B4C5ZYd76JElS887oRzN9rHzC42qQeQKnI/TsirJcJJNi/vXvynJ8L69O74n9gBQai/sbrO9uVbd9XWq0nRPTXw/yXXC0FhrhQDXb7kqgRvlB6AHVly+KMlLkrzSTvZlZZf76ky1OprurREozdDZmdx0f1iSZxSf385pV30uyV8VDfj/nl0b7xYwAJgH9zfavyHJMQJivo9c1chJWXXdibl1XVsoAGDuaLiH3lktBBZn3dKqxC73arDrdeEFGMYLnI9T95gkb0vyy4v71/9mkp12vAeA0lonBFj7yFWF/en4yJVfl//GWuN8pCrcW621m4QAoEtWbDkiyblJ67yi2X6RoGC+D+q2QQaT/ELx+VZOu+pvkvxNkvdn18b/FR4AmKUZN9qba2G+T6VytSbJ++QCAOaOhnvonZLt1mNxVh3eHI/xArkSi545Ocnbk1y6uH/9ryR57769O7zTBQBKYsGyi09O8gJzLcz3qXCutolRo50jBMZO5KoEbhACgHm0YkurmPf9ZJKXJznB9RvmowTtcu98lKuKeUSSVxWf7+W0qz6Q5C+S/HV2bfyW2gCAaVi5/cgkG5L8epLjBMRci7KUhRqcJxruAWCOabiH3k5uG6m7O79YnN0X99Lvci9X9T8fy04Nom6nYVWSdye5cXH/+l/Yt3fHR+QCAErhtd7QZo0wH/o6yYRQqMH595/jI1feKO8NHWeWv/HwJGeKBMZOueqxdmfP0FfkBmAerNiyMsl5SV6ZZEBAqsrmAGA+zfSHzk7SN61cHZXkh4vPXTntqn9N8pdJ3pddG9sCCgAHsXJ7q3ix2xWzX3eaa5kXQ2VqcLUcAMDc0nAPJrdUki+yLaRBDdYtFhV9AcbaJB9e3L/+XUku3bd3x151BgC9sWDZxX1JLjDXQq6ocA1eLTaN9rgkC42dVImXC9eSF78AzKUVWx6R5CeSvCbJWa5zmO8DTNvhSc4tPttz2lX/luS9Sf4iuzaOCA8AFFZuf1KS30/yVMGw9pErZdEwZ2fVda3cuq4jFAAwNzTcQw8sWXreiiTHNXlxZldtrNrlCqjV+fiKJC9a3L9+S5Kr9u3d8X15AYCue16SZcJg7TNfyr/LvVxV3LeSvEsYGm2tEBg7UYMloOEeYLYGthyWVn4oyWuTvCTJka5z0KsS7CQtNeh8lKsaaSV5WvH57Zx21ceTvDvJX2bXxs8KDwCNtHL7kiRbkmywi5k5JHLVUEuSnJrk80IBAHNDwz30ht3tLc56olVEAzW4X114AYbxAufj3FiU5LeSXLC4f/1P79u7459kFAC66gIhwNpHrirs7eMjV35PvhttrfORKubKvdXauVkIAGZoYMtpRZP9q5KcZK5VZxP6WMA6lWkPnZ2kb85zdWbx2ZLTrvpskr9I8mfZtfFTAg5A7a3c3kry6iS/PX8b4JlrYb5PZXK1WsM9AMwdDffQG2uEgNnzRTa95maOXIkFB3Rqkn9c3L9+OMnF+/buGBUSAJhfC5ZdvDTJi821QA1WNFedJG8Tk8azw72xE7kqQ4BvEgaAaRjY8vAkLy8a7Z/ikuX6LVeA87FnVib51SS/mtOu+kySdyX5czvfA1DPq972U5LsSPIcwTDXQlmQFL1J/1cYAGBuaLiH3ijxw4N2fsGqHTWoBlG3c+I1SZ63uH/9T+3bu+O9cgQA8+q17vNZI3RDXyeZEAo1OPf+dnzkyj3y3OCxZfkbH148GA7GTrnqpVs7e4b2yQfAFAxsWZPkp4tm+4UC0kQ2B6jOVKuTtMyLrREox9A5L7vcH8jpSYaSDOW0qz6d5I+L5vsvSAIAlbZye1+Sn0+yJckiAcF8X664z2ohAIC50+p0OqIA3TrhWq0sWXre4Un2JTmqxD9p95ZMrXoeV/fM7Evs8o/8dV1Il/u4ZnY+ypVjEgvn45T8RZKf3rd3x9frVEnWUgA81Pq/WxYsu7iV5PNJVphvOaZuHFf5G+7lqoLH9fzxkSv/3tWjufqWv/HcJP/kfHRMVT4u33XU4pj+sLNn6AKjMsBB3LOb/XlJLkzyhPkb2l3nKjSTN4eszCH5ntjaxzGVZ+js6XF9PMmfJnlXdm380qzXwb4rByj5FLBm19J7drW/PslTzUsck+OqQ/jkao59L8ni3LruLnN7AJg9rxuG7ntcuZvtU4l2bO41IQQYL5ArsaiCH03yX4v71z9HKABgzj27XM325pB119eRK+bU7iT/KAyNt0YIjJ2owRK4SR4ADmBgy1kZ2PIHSdpJtk2p2d70QjAoWQmqQeejXJEkOTPJlUlGctpVN+S0qy7JaVf1CwsApbdy+2uSfLI3zfbmWigLNVgJRyU5QxgAYG4cLgTQdR4enKTV6ebOLx07PN8b99IvVeWq/udj2alB1O08WJrkHxf3r39Lkl/Zt3fHnXIGAHPi9UKAtY9cVdj28ZErvVGSNc5Hqp4r91Zr4UYhACgMbFmc5JVJ1hfNeeZaHMCEfV7AOpVpD52dXu9yf6+1xefNOe2qjyb54yR/nl0bvyVJAJTGyu2PSPIHSV5mroVcoQYPaXWSW+QAAGbPNx/Qm8kszCHPJFdrIQ1qUCwOrVXvVF2S5IbF/etXqUMAmJ0Fyy4+PslLzbWAivpu0hkWBooHvHH9Rq566TtJPi0MQOMNbFmVgS3bk3w1yY5ZN9u7ZAmGXAHOx7JrJXl6kmuStHPaVe/LaVe9PKddtVBoAOipldufXDSOvkwwzLXoKAumwqagADBH7HAP3VeRhwft/EJzahC5Audj1z0xyX8s7l+/bt/eHX8ibwAwY69OcqQwmGt1W18nmWjJFbP2x+MjW28XhoaPJ8vfeHKSpSIB9Pj6/fHOnqG75ABopIEtfUlemOTnkjxHQJgeu9xXZ6rVSVrulZRg3gll2uX+gY5M8uLi8+2cdtV7cs/O9x/Mro13SxwAXbFyeyvJRUm2JjlCQDDflyumTMM9AMwR33pAFy1Zet7DkpwuEr1enBFLVDV4sLpwihgvcD52z9FJ/u/i/vW/u7h/vS9IAGBm1gkB1j5yVWHb5JQk5zgfqUuu3FuttBuEAGicgS1LMrDlkiSfT/JX5Wq2d1FFDYK6pcceXrzw9x+TfCWnXfXWnHbV2cICwLxauf2YJO9O8tbyNduba6EGKX2uHptV1x0t/gAwe3a4h+46q1ovuvDmsOrw5niMF8iVWFTWzyc5c3H/+h/bt3fHbcIBAFOzYNnFT0+y0lwL1GBF/dv4yNZbhAG7LRg7kauSuFkIgMYY2PLYYjf784sX47pkuX7TmBK0y73zUa6YkaVJ3pDkDTntql3Frvd/kKQtNADMmcHtpxUvgxsUDHMtmlQWanAOHZbkSUn+TSgAYHY03EN3eXjwIFqdpGNx1v24l/6dd3JV//Ox7NQg6rZLnpbkE4v7179s394dH5NDAJiSC4XAXKuX+jrJhFCowZmzuz33OkcIMHZSglzdKPZArQ1s6UvywqJZ7tkCwtyyOQDA9IfOTtJXyXXqaUk2FS8t03APwNwY3P7cJO9Kcmy5f1D3matDrmhsDa7RcA8As+cbD+j+JBbmyYQQVGohDWpQLA6t1axULU3yL4v71/+4ugSAh7Zg2cXHJvlRcy3kior6WpK/FAb6lr/x8CRnGjupk+7ey1GDc+R/OnuGRoQBqKWBLQszsOXCJJ8pdgqsULO96xxqENQtJXaTEAAwJwa3b0zyd0mONZUxh6REuVIWVbVaCABg9uxwD91VwYb77r1hy67a9LoGkStwPvbcgiTvWty/fmDf3h2/JY8AcFDnJzlKGMy1eq38u9zLVUntGB/Z+n1hIMkZSY4WBmMn9LgG7W4P1M/AluOT/FSSn0tygumFuRbcX4KdpKUGnY9yxazszq6N30wuFgkAZm5w+2FJfr9Yu4I5pFwJw9zQcA8Ac8AO99Bdlyf5oyS7hKIMizNiiaoGD1YXThHjBc7H3rpicf/6ty/uX3+kCgCAA7pQCLD2kauKujvJtXJIYa3zkTrmyr3VytFwD9THwJZTM7BlW5IvJRkqRbO9uVZDTAgBGDuZ9tBZ2VzZ3R6A2RncfnSSd1ez2d5cCyj1eHFqVl33CLEHgNmxwz100e23vfPaex8oXbL0vOOKBwqfluScJGuSLBIlZmfCu1SAKfJWSLEovdclWba4f/3L9u3dsU84AOAeC5ZdvKbYEdhcC9RgFb13fGTrV4SBwhohMHYiVyWgWQSovoHNT0lalyR5aWkvDC5ZgiFXgPOxLm4QAgBmbHD7CUn+5qDfD7jkm2tRnlwpi6paneQfhAEAZk7DPfTI7be985tJ/q74ZMnS8w5L8rgkTyk+5yRZ0bTFWauTdCzOsGqXK8D5eI9zk3xgcf/65+/bu+NbcgoASZL1QmCuVSZ9nWRCKNTg1G2TOyY5RwgwdtLjXHU03AOVNbC5leS5SX7tnucLXOfoNZsDVGeq1UlaxgtrBMoxdHaSvsrVoDUUADMzuP3RSf4lyamCgfk+cjVvztZwDwCz0+p0OqIA3TrhpvmF1ZKl5z0yyZOLBvwnFxPghT366bu3ZGrV87i6Z2ZfYpf/alDXhXS5j2tm56NcOSaxcD7OuU8n+aF9e3e0S5UTaykA5mj9P1ULll28OMltSY4233JMZTqu8jfcy1VJfGZ8ZOtjXSVIkr7lb1ycZKw+J6jrnOM6wH0D33VU4Zhu7ewZOt2oDFTKwOa+Yif7X03yxEpdD1pd/4PmJN2f6ZtDVuaQfE9s7eOYyjN0Vuq4vp/k4dm18U7flQOUfbpXsuvL4PZTk/xzkmX1uOybazmuhhyX7zmqeFx/nVvXvXg6f8DcHgD2Z4d7KLHbb3vn15K8r/hkydLzDk/ypElN+E9PclJ3fhpvDqsOb46n14wXciUWzLkzknxkcf/65+zbu2OPcADQYK+sZrO9OWTdlX+Xe7kqie1CwCRnOzFd56AENXijOAOVMbD58CQ/keSyJKsqef02vRAMSlSCdrl3PsoVM3JLdm28UxgAmJbB7Y8rdls+UTDMtVAWanDerRYCAJgdDfdQIbff9s67ktxcfH4v9zThn1I03j8tyQ8kGaz6cbY63dz5xeLsvriXfpd7uar/+Vh2ahB122Mriqb7Z+7bu2O33ALQUOuFAKjofH9fkp1yxiRrnY/UPVfurVaChnug/AY2H5nkdUl+Mckprt+Um80BwNjJ9IfOTpV2ub9JwgCYlsFtj0vywSTHm2shV6jBrliaVdc9Oreu+4rYA8DMaLiHirv9tnfuSbLn3gdWlyw974QkTy0a8J+e5Kwkh4lU0/gi20Ia1GDdYuEh7SRJf5J/1XQPQBMtWHbxk5Kcaa6FXFFRO8dHtu4TBiZZKwTg+l0CNwsBUFoDmx+W5PVFo/1SlyzXb+QKcD6WwA1CAMCUzabZ3iXfXIvy5EpZVNGaJBruAWCGNNxDzdx+2zu/nuS9xSdLlp53dJInFw34Tyv+eVHZV0yaCrFqlyvA+XgQ/Un+aVH/hqffsfcaNwUBaJLXC4G5Vpn1dZKJllxxUNuEgAfQcO86B72uwe8l+aQYA6UzsHlhkvVJfjnJCa7fVI/NAaoz1eokLeOFsZNyDJ2V2eXeDvcATM1+zfbmWpjvI1ddtibJu4UBAGam1el0RAG6dcKV4IuqJUvPOzzJk4rm+6cXv07ji/ruHUN3G+7ruDib2ZfY5b8q1HUhXe7jmtn5KFeOSSycj/PqCxNpPbOXTffWUgB0a/2/YNnFi5K0kyw213JcZT6uiZZcOa4D+pfxka3PdnXgXn3LL3t00vqy89ExNeW4uvddh1xN07939gw91agMlMb9jfa/NPsd7Ut+TWjV9Lgc0+RZv3lJZQ7J98Tm046pPENn6Y/rW9m18bj71rq+Kwco+TSvh9eVwW2nJvlwkhNnff323aNjclzlOC49HVU7rn/OrevOnepvNrcHgP3Z4R4a5vbb3nlXkpuLz1tzTxP+yiTPLD4/sP9NjgdNqTVmVoY3x9Nrxgu5Egvm1Yok/7qof8NT7th7zdeEA4Ca+7HqN9uba6EGG+xqIeABzhECYydyVQI3CAFQCgObj0zyuiS/luQklyzXbwCMnSVld3sADm1w26OT/PODn0N3/TbXQlmowS5anVXXtXLrOp30ADADGu6B3H7bOz+b5LNJrsk9DfinTmrAf2aS/l78XK1ON3d+sTi7L+6l3+Verup/PpadGkTdlsiKJH+3qH/DM+7Ye80d8gxAjV0oBOZaVdDXqcIu92qwy76S5K/kiAdYY+zE2EkJcqVZBOit+xvtfznJya5z1IvNAaoz1erY5d7YSWmGzk7Zd7m/UZIAeEiD25YkeX+SZeaQyBX0tAYfnmSw6A8CAKZJwz3wILff9s7dSXYnuS4lasBnJnyRbSENarBusfACjPv1pZOJtM5K8peL+je86I6914yLCgB1s2DZxY9L8mRzLeSKitoxPrL1LmHgAdYaO2kSLxcuLc0iQG8MbD48yXlJfiPJcgFxnUMNgrrFGgqAyhvcdnSSv0lyhqmMOSQ1zZWyqJrVGu4BYGY03AOHdOAG/FZXGvA1FWLVLleA83EKnpvk2kX9G153x95rOnINQM1cIATmWlVS/l3u5aqLxpNcKwzsN0Ysv+ywJGc7H13noMc1+LXOnqH/FlegqwY2t5K8NMkVxQ5Tzb5+m14IBiUqQbvcOx/liim5SQgAOKDBbYcl+ZMkT3H9Bsz3S2NNkuuFAQCmT8M9MG0PbsA//9RJzffz2oBvcdYdrSIasF9deAGG8QLnYwkVu9wnyWuSfDXJr4gKAHWxYNlFRyV5lUhg7UNFc/Xn4yNbvyY3PMAZSY52PtK0XLmXUzoaRYDuGtj8jCRXJlkrGOZazTGRpE8YwNjJtIbOTtJXylztzq6N35QgAA7izUlebK6FXEGpanC1eAPAzGi4B2bt9tuuP1AD/g8Wn2clOV6UeskX2RbSoAbFojF+eVH/hl137L3mj4QCgJr40SRLzLVADVbU1ULAAWgyM3YiV2VwgxAAXTGw+QnFjvYvEAyXLMGQK8D5WGFeWgbAgQ1uW5/kYpd8cy0akitlUSVPzKrrjsit68aFAgCmR8M9MOcmNeDvWLL0/L4kj5/UgP8DSRZN579n5xes2uUKcD5Ow7WL+jd87o6913hwGoA6WOclauZaVdTXSSaEouk1eMv4yNaPyQkHsMbYibGTEuRKswgwvwY2L0+yOclP9vZC4zpHr7mvVZ2pVidpGS+MnZRj6CzlLve+ewfgwQa3nTv9ly+ba2G+j1x1yYKih+c/hQIApkfDPTCvbr/t+okktxSftyxZev4RxS5G5xYN+GuTHGFxVj6tIhqowf3qwgswjBc4H0uoL51M3H8+HpnkPYv6N5x1x95rvio6AFTVgmUXDSZ5hkhg7UNF2d2eg2nIDvfGTh6su/dy1OAh3CwEwLwY2Hx8kl9N8tPl+g7cXAvUIKhbZsVLywDY3+C2gSR/3rVelNJPZcy1UIOUMlerNdwDwPRpuAe66vbbrh9P8tHi85tLlp6/qNj1/geLzxOs+OaDN8fTqBsEyJVYsDTJexf1b/iBO/Ze8z3hAKCi1plrgRqsqNuT/Ikw8EB9yy97WJLTnY/GTuhxDX6us2doVCyBOTWw+cgkP1802x/j+m16IRhUswTtcu98lCsO6PvFRjsAcI/BbUcneU+SY12/zbVQFmqw1FYnuUYYAGB6NNwDPXX7bdffkeT9xSdLlp5/fJJnJjm3+KyInV96pvy73MtVT+rCrtpqEHVbDauTXJvkVXIOQNUsWHbRkUleff+/8RI1c63q6eskE0LR1Bp8x/jI1u/IBQdwtgsaTR873VsthRuFAJhTA5tflmTrvd9rY/3NA7mvBcZOpj90dpK+0uTqluzaeKekADDJjiSPFwZzLbmC0tfgWrEGgOnTcA+Uyu23Xf+NJH9RfLJk6fmPKRrvn1v8ukSUZsoX2RbSoAbrFgsPad+vL51MPDhX5y/q3/DhO/Zec50IAVAxP5LkBHMt5IqKFst2YeAg1jbvdDB2ogZLSMM9MDcGNp+Z5KokzxAMlyzBkCvA+VhjNwsBAPcZ3PZzSc5zyTfXouG5UhZVsSqrrluUW9fdIRQAMHUa7oFSu/2260eSvD3J25csPf+wTitnJXlekuckeXKSw0TJDQKrdrkCnI8P4fcX9W+48Y6913xK3gGokHVCYK5VB+Xf5V6u5sE/jI9s/YIwcBBrnI+uc1CCGrxJDIFZGdh8UpLLk7y6OhdF1296zeYA1ZlqdZKW8cLYSTmGztLscn+DZACQJBncdlaSt5hrYb6PXFVGX5KzknxYKABg6jTcA5Vx+23X3108CHVTkqFjTzz/mCTPTvJDSZ6b5BSLs7nXKqKBGwT71YVdtY0XOB9L6CC73B+V5F2L+jesuWPvNd7UCUDpLVh20UCScx/8/3gwGWsfKpGrq8Wfh3CO8xG5ci+nx76X5JPCAMzIwOaFSS5N8ktJFgmIuRaAsZOG8NIyAJLBbQ9L8q4kR5jKmGuhBqlUrtZouAeA6dFwD1TWaPv6sSTvKT459sTzVyR5XtGA/6wki0XpgTRo0JgbBMiVWDDZ6Um2JXmNUABQARc0a/JhroUarJE9Sd4vDBxI3/LL+pOcJBLGTuSqxz7R2TM0LgzAtA1sflmStyZZJhguWYKBXIHzsUFuT/J5YQAgyfYkp7p+m2tBb8pCDc7C2UIAANOj4R6ojdH29V8omum2HXvi+UckeXLRfP/cJGdNf6VlcXav8u9yL1c9qQs7MalB1G21vHpR/4YP3LH3mnfKPQBltWDZRYcnee3Bf4eXqJlrVU9fJ5kQiqbU4Pbxka0TYs9BnFPSugU12Kxc3Sh2wLQMbF6Z5HeL75xd52BW3NeqznDRSVrGC2Mn5Rg6O0lfT2vwpuza2JEIgIYb3PaTSc4XCHNIuYJK1uAacQaA6fFNBlBLo+3rx0fb1394tH39r462r1+d5IQkr0zyjiS3NTs6nnuu1kIa1KBYHFpLqiYtcB4yGFcv6t/QL0oAlNgPJznRXAu5ooK+l+QPhYGH0OCHOYydPFh37+WowUk03ANTMzC0KAOb35Tkv+rRbG+uBWoQ1C3WUADMwOC2ZcVGaKYyYL5PNZ2SVdedIAwAMHUa7oFGGG1f/83R9vXvGm1f/7okJxU73v9ako/pQIduczMHnI89c0ySP1zUv8GraQEoq3VCYK5VR30duWqAPxkf2fotYeAhrHU+us5BCWrwJnEDDmlg6MeSfDbJLyU5wtjpxxMMmlmCatD5KFckGu4BGm5wWyvJdcXzVq7f5lpCQI/LQg3OwtlCAABTd7gQAE0z2r6+k+TjxWfLsSeef1yxM8ELkjw/yXH7L8705KWIQrmXqnLVk7roJB1hV4NQMn3pZOLg5+MPJXl9kmtFCoAyWbDsopOLNekhTHiHJtY+lDFXV4s3B12jLb/sMA9yGDvl6sHcW+26b3T2DH1RGICDGhg6PcnvJjlXMFy/mS/ua4Gxk+kPnZ2kr2e58tIygGZbl+Q5wmCuJVdQ+RpcneT9Yg0AU6PhHmi80fb130zyJ0n+5NgTz+8rFhUvSPLCJGfWcyXti2wLaVCDdYuFh7Sn5apF/Rv+6Y691+wRCgBK5IJmL9TMO1GDFXbj+MjWjwsDD+H0JIuEwdiJXPWYRhHgwAaGjk7ym0ku3v8ZGmOnS5ZgIFfgfGy0L2TXxm8IA0BDDW47JclVLvkIvFwpi1pYKwQAMHUa7gEmGW1fP5HkxuLzG8eeeP4ji+b75xc74h4rSm4QIFfgfKy8RUnevqh/ww/esfeajhoAoNcWLLuoL8nrRMJcq876OsmEUNS1Bu1uz6GsLWHdghpsXq5uEC/gQQaGnpfkmiSPMXZCt9gcoDrDRSdpGS+MnZRj6OzJLvdeWgbQbG9L8jBzLcz3kataOFsIAGDqfIMB8BBG29d/bbS9c3i0vfPHkxyf5AeSvCnJJ5sYD0vUXt4gKHFdaFWtTK5owDitBCctdA4ZjGcleZVIAVASz0ty8tR/+4SIYe1DWXw9yZ8LA4ewRgiMnRxYd+/lNL4GNYsA9xsYelQGhv4kyfsfutne9dtcC9Qg6pbGulEIABpqcNsrkjzXVMZcC/N9apOrR2bVdY8RZwCYGjvcA0zRaHvn3Uk+UnzeeOyJr3p0khckeXGSH0xyVLWOyJvjKcMNAq9xkCuxoKd+e1H/hr++Y+813xIKAHrsQiEw10INVtQfjI9svVMYOIS1QmDshBLUoIZ7IBkYaiW5IMmbkxxr7PTjyRUcqgTtcu98lKsG03AP0ESD245N8juu38gV5S0LNThDa5KMCAMAHJpOS4AZGm3v/Mpoe+e1o+2dP5zkuCQ/kuQPk/xPnY+7/EtUb+TrSV0IuxpE3VbT8UmulH8AemnhsouWJnnh9P+kXe7NtaqnTyjqVoN3J9khvjzkeb/8skVJzjB2Yuykx3Z19gzdLgzQcANDq5J8KMkfNLvZ3vWbMnBfC4ydTH/o7GquxpN8QtABGumKJI8SBnMtuYLa1eBqMQaAqbHDPcAcGG3v/E6S9yV537EnvqqveAvYi5K8eGYPlHaLXe6rtZD2Rj7UoFgcWquTdKQqSdKXTiYOnat1i/o3vOOOvdf8u4gB0COv60sO95ixeadcUUF/PT6y9UvCwCGc7QaksZOH1t17OY2tQbvbQ5MNDC1I8sbic6SxEzDXAucjh3RLdm28UxgAGmZw29lJNrjkI/BypSxqScM9AEyRh5wA5thoe+fEaHvnDaPtnb8y2t75uCSnJHlDkg8kuUuEurVqR64A5+OU7VjUv8HLyADouoXLLmolWScS5lpNUv5d7uVqGrYJAVOw1vnoOgclqMEbxAgaamDonCSfTPIbM2u2d/324wkGpKMGnY+URvd2uffSMoCmGdzWSvI7vW2XNdfCfB+5mkdnZ9V1+gcBYAo0lQDMs9H2zv9O8rtJfvfYE191TJLnJnlJkucnWVLFY2pZqvbwBoFdteUKnI/TMcVd7s8omh2vETEAuuzZxUvaZmjC+zSx9qFXufpskn8WV6ZgjRAYO+Xq0NzLmXeaRaBpBoaOSrI5yUYLZ9dvysp9LTB2UmJeWgbQPC9P8lRTGXMtzPepba4elmRlks+IMwA8NN9cAHTRaHvn2Gh755+Ntnf+ZJITkjwryVVJdvfup5qQGEpwgwC5Egt6btOi/g0PFwYAumz9vf/gJp25FmqwYt42PrJVoJiKc4TA2Ilc9dj3k9wi79Ag9+xqf0uSS+duue0655IlGMgVOB8bxUvLAJpkcNvCJFe6fiNXVKss1OAMeFE6AEyBHe4BemS0vfPuJP9afC459sRXrUry0iQvS3JW2X/+8u9y7418PakLOzGpQdRtdT0yyWVJflkdANANC5dddHySH5n9f8luYOZa1dPXSSaEoso1+L9JhsWTQ57ryy87KUm/sRNjJz3O1Sc6e4bGxQcawK72rnNUkPta1RkuOknLeGHspBxDZyfpm9cavD3J5wUaoFEuTfIYYQDzfWpfg6t9zw8Ah+ZbC4CSGG3vvHW0vfOK0fbOs4ubVxcl+ZAt6HnwQhrUoFgcWkuqJi16phyMixf1bzhZxADoklcnOWL/axbmnXJFJbxzfGTrt4WBKVgrBMZOpq5l55f5cqPqggYYGHr63O9q7/ptrgVqEHVLI92UXRsVBEBTDG47LsklpjLmWpjv0wh2uAeAKfAcL0AJjbZ3fmm0vfP3Rts7n5lkaZJ1Sf42yffn52/U00+vuZkDzsdSOCrJb6kBAObbwmUXtZJcKBLmWk3W58GXKtsmBEzRWuej6xyUoAY13EOdDQwtzMDQ7xQvMR8UkBpev00vBIMSlaAadD7KVUNYQwE0yy8lOcb1G7mimmWhBqfp8Vl13QJhAICHpuEeoORG2zu/Ptre+fbR9s4fTnJ8klcm+dMk/9vrn61l1c6B6kLY1SBU208s6t/wRGEAYJ49Lclpc/ef8xI1rH3oWq4+ND6y9dPiyBTZJcHYKVfT5N7qvLhJCKCmBobOTPLxJBdV4mtLzLU4CPe1wNjJ9IfOec2VhnuAphjcdmKSnxMIcy3kisbU4JFJHi++APDQDhcC6OLU19uemb19Sd6V5F1LTnr1giTPSfLSJC8umvFnYcJ7WCq1kPbcEGpQLA6t1Uk6UpUk6UsnE1PLVSvJbyb5EVEDYB5dePBrlseMzTtRg6Vmd3umtgZbfllfktUiYexErnrsm509Q7vlGmpmYOiwJL+YZKj7z7y4zrlkCQZyBc7H2vPSMoDm+I0kR7nkI/BypSwaZU2Sm4UBAA5OZyVARY22d9452t75N6PtnRckWZrkWUl+P8mXReeBq3bkCnA+TstLFvVveJI6AGA+LFx20ZIkPyYS5lokfUJRNV9N8h5hYIpWJXmYsRPXb3qcK40iUDcDQ6ck+VCSK2ww4TpHnXj9ZHWGC+OFsZPyDJ3zUoNfyK6N3xBcgAYY3LYsyevMtUANylXjrBECAHhoGu4BamC0vfPu0fbOfx1t7/z5JI8pdo+6MsnIfP/dXkDnBsEB68L9i8rkivpzPk5e/EwrGL8hYgDMk/OSLJj7/6wHk7H2Yd5zde34yNa7xI8pOkcIjJ3MTHfv5dS+Bm9UUVAjA0OvTfLJJE91/UauUIOgbpkXXloG0ByXJDnCVMYPiPk+jcvVarEFgIem4R6gZkbbOzuj7Z3/MdreeVmSU5I8OclVU9v5XoMGtb1BgFyJBdNll3sA5suFh/oNbtiZa6EGS2g8yQ5hYBrsjmDshDLQcA91MDB0fAaG3p3kD5MsFpCGXr9NLwSDEpWgGnQ+ypU1FACVNrht6VS+s3b9Rq6oTlmowWlYmVXXuccKAA/B87sANVY0398w2t55SbHz/TSa76eu/LvcW0j3gl211SDqtgZ+XQgAmEsLl1305CRnzN/f4CVq5lrV0ycUVanBd4+PbL1N3JiGtcZOjJ2UIFd2Z4SqGxh6XpJPJXmpYEDdua8F1j5Mf+ic81xpuAdohjckOUoYzLWQKxpZg60kZ4stABychnuAhph6870vshu+kAY1WMNYeAHG5AXQtILxkkX9GwZFDYA5tG7q1yzMO+WKUtkmBEz5Grb8skXz+4IZYyf117Lzy1zY3dkz9C3VBBU1MHREBobenOT9SZa6fiNXqEHA+TjvxpN8QhgAam5w2zFJftYlH4GXK2XRaKuFAAAOzrO7AA009eZ7NwiQK3A+NlorycXqAIC5sHDZRQ9P8gqRwFzrwcq/y33jc/Vf4yNbP6JSmYYzkxzmfHSdgx7XoN3toaoGhk5J8tEklwqG67fphWBQ1hJUg85HauiW7Np4pzAA1N66JIvMtUANylWjabgHgIeg4R6g4eaq+b4llG4QHKgu3L+oTK6oP+fj5EXQtILx6kX9G04QNQDmwE8kOXr+/5oJkcbah7nOld3tma5zhMDYKVez517OrN0gBFBBA0M/luSWJGsEA3OtJnJfC4ydTH/onLNceWkZQN0Nbjssyc+ZyvgBQQ02PldrxRUADk7DPQD3ub/5fnhy8/3vJ/ma6FCDGwTIlVgwE0cl+WlhAGAOvH66f8CNO3Mt1GAJjCX5Y/lnmjTI4fotV2WgWQSqZGBoYQaGrknyZ0kebuxE2AVDrgDnY9d5aRlA/b20eC4YzLWoaVmowSk6Oauue5QwAMCBeW4XgAMabQ93RtvDN4y2h38+yUlJnpvkj5J826qd6bATkxpE3dbAzyzq37BQGACYqYXLLjoryZnd+xvtBmauVT19QlHWGhweH9l6hzgxTef0uG7B9ZvvFztkA1UwMHR68ZKM9YLhOgfua1VpuDBeGDspz9A5JzXopWUA9fcGcy1Qg1A4WwgA4MA03ANwSKPt4btH28P/ONoefk2SpUlenuQ9xUNr92kJVY+4mQNMjRdgTF4ITSsYJyR5pagBMAvrZn7NwtpHruipbULAtK5byy87McmjRcLYydxo2fllpm7p7Nl8pwqCChgYel2Sm5Oc4fqNXKEGQd3SM7cn+bwwANTY4LYnJXmqqYwfENSgXBXWiisAHNjhQgDAdIy2h7+b5M+T/PmxJ77mmCQ/muQnkjxLzz1zf4NAScmVWFAaG5L8oTAAMF0Ll120KMlPigTmkIfW10kmWnJVIv84PrLVg7ZM1xrnI3JFCdiZEcpuYGhh8XKn1wqG67fphWBQ5RLsJC016HyUq1qsoXZt1HEFUG8/6/qNXNGMslCDU7RaCADgwGySBcCMjbaHx0bbw28fbQ//YLFz1cZW8h/lX7XTbXbVVoOo2xpYvah/wxOFAYAZeEWSxd3/aydEHnNIZpsru9szE3ZDMHbK1Rxzb3VGbhACKLGBoYEk/67ZHnMtDs59LTB2Mv2hc1a5ulEAAWpscNsjkrxSIMy1kCvU4CQa7gHgIDTcAzAnRtvDXx1tD791tD28Oslgkk1JdolMZRfSoAZrGgsPaU9eDE07GBeKGgAzcMHsr1mYd0LXjST5G2FgBtesNaKA67dclYAd7qGsBoZemOQ/k9To5aauc8IuGMgVOB8rT8M9QL29NslCl3wEnp7mSlmUzXFZdd2AMADAg7U6HTMXgEoO4K1WJX7OY058zdlJfqJ4Q+bSEkWwjlVR6p+u05Kreh9TnY/L+VjnHE9M75j2JTnxjr3X3JEk1lIAHGq9tnDZRY9L8l9zc82aibq26ptP1/2YJlpyVYJjumx8ZOuVRnSm4/Dll/UlGZ1IFjsfHZPjmludllxNw7c6ezYfZ1SGkhnYdFiS30jya67fjqu3P55cVUufXFXmsHxPbJ3quMozdM7ouE7Iro3fmNY61XflACWfnhXXg8FtfUk+n6QmTZWtrvwRcxLHZb5fh/DJ1RS8Mreue5e5PQDszwZZAMyrsfbwf4y1hzcmeXSSFyT50yR3isx8sKu2XIHzcfoLomkFY3GSV4gaANPw+t7+9RMygLUPM8nVnUneLibMwMp0tdne2ElzuJczLTcLAZTMwKbjk/z9Pc32rt/IFWoQ1C0l84XpNtsDUCnPrU+zfV2nMuZaqEF6lquzxRQAHkzDPQBdMdYevnusPfz+sfbwK5I8Ksn6JB8TGXpwgwC5Egtm40IhAGAqFi676Kgk583Vf89NPHMt1GAX/en4yFYP2TITa12zcP2WqxK4UQ6hRAY2rUny8STnCgYuWYJBnUtQDTof5arCbhICgFr7Wddv5IpmloUanII1QgAAD+a5JwC6bqw9PDbWHr52rD38lCSnJbk8yZdqvGqnYCcmNYi6rYE1i/o3nCoMAEzBjyVZ0vsfwy735lrV0ycUva7Bq8WCGVpr7MT1mxLQcA9lMbDptUk+kuRkY6frHMyM+1rgmsD0h85p50rDPUBdDW4bSPJ8gTDXQq5QgwdxVlZdd5iYAsD+NNwD0FNj7eHPj7WHfzXJKUl+MMnOJHeITCkW0qAGaxwLL8CYvCiadjB+QtQAmILXz/01C/NOuWLe3Tw+svVmYWCG1gqBsZP507Lzy1RpFoFeG9h0WAY2vTXJHyY50vUbuQI1CJSal5YB1Hfe+VNJWuJgCi7wlCpXyqJMjk5yujAAwP48pwtAKYy1hyfG2sMfHGsPvzrJ0iSvTfIv87u0tmqvDrkC52OpaLgH4CEtXHbRYJKniwTmWjNX/l3ua5urbaqPmTh8+WVHJ3ncfeew8xG5oje+0Nmz+RvCAD00sOkRSf4+yRsEw/XbjycYNK0E1aDzUa4q6K4kn1AHADU0ePXCJBe4foMalCsOYY0QAMD+NNwDUDpj7eH/HWsPD4+1h5+dZCDJryfZLTL1uEFgV+3q5Ir6cz5OXhhNKxiDi/o3nCVqADyEC8v140zICNY+TMU3k86fCgMzdGaSw4TB2ClX88u9nEOyuz300sCm04vz8FzXOVy/mTvua4Gxk+kPnVPO1S3ZtfF7AgZQS69IskQYzLUA48UhrBZPANjf4UIAUNGlUnPeDv7fSTYfe9JrtyR5arHz/cuTPEwVNPEGQUsY5EosKItXtlqt/xQGAB5o4bKLjkzyqvn67/d5zNhcCzU4f64bH3mzB2yZqXNcs3D9lqsSuFHeoEcGNr0oyR8nWWzsdJ0TdsFArsD5WBk3Nej5Myi1Vsu8gDk2ePXPus655As8pc2VsiiT1eYhUyxbayeAxrDDPQCVMNYe7oy1hz861h6+IMlJSdYluWFuVu0AGDun7ZWL+je40wjAgfxIkuPL92NpeTTXqp4+oeh24V0jDMzCGmMnhlFKQMM9dNvAplYGNr0xyfum32xv7HSdg6lyX6s6w4XxwthJeYbOKdXgDQIFUEODV5+T5ExzLVCDyNUUPD6rrjtKGADgfhruAaicsfbwvrH28NvH2sNPTvLYJFcl+YbIVOcGQcv9i8rkivpzPk5eHE0rGCclWS1qABzA+vm/ZmE+LVfMub8eH3nzfwsDs7BGCIyddEd37+VUqgbHk3xChUAXDWw6Ksn/TXKFPalcv+UK1CDqlkq6SQgAaulnXL+rOpWRK9QgXc/V4UmeKJ4AcD/P5wJQaWPt4c+MtYcvSdKf5EeT/L0VvxsEyJVY0CUvFgIAJlu47KKBJM8SCcwh506fB1+6ZbtqY6YOX37Zo5I85oDnsPMRuaJ7buns2XynMECXDGw6PskHkrxCMFy//XiCAfuXoBp0PspVRYwm2SX3ADUzePUjk7zc9Ru5QlmowWnwYnUAmETDPQC1MNYe/v5Ye/gvx9rDz09ySpItSdoW0uVlV201iLqtAQ33ADzQunLv6jchQ8CBfD7JPwoDs+AhDOtvupwr91YP6GYhgC4Z2DSY5IYkT3Wdw/Wb7nFfC4ydTH/ofMhc3ZRdGyUToH4uSHKkMJhrIVeowWnwXS8ATKLhHoDaGWsPj4y1h38tybIkL03y/mbe2XAzBzUoFlPjIe3JC6RpBeNxi/o3LBc1AHLP7vaHJ3ld965ZmHfKFXNm+/jImyWH2ThHCMD1uwRukCvogoFNT0/ysSQrBMPaR9gFA7kC52Ol3STnADUzePVhSX7Kdc4lX+CpTK6URVmcLQQAcD/P5gJQW2Pt4bvG2sPvHWsPv+DQu95btVeHXIHzsVReIgQAFH44yaOEAXOtudfXkat59J0kw6qMWXrIXQ/6nI/IFd2hWQTm28Cm85L8c5Ilrgmu39AbdrmvznBhvDB2Up6h86A16KVlAPXzoiQnm2uBGkSupmkwq647RhgA4B4a7gFohAfsev+yJB9wg6D37KpdnVxRf87HyYukaQXjxSIGQOHCavyYHkzG2of9vHN85M2jwsBMHb78sr5DNdxj7JSr+eFezn5Gk+wSBpgnA5taGdj060muT3KEgOD6DWoQ1G0teGkZQP38jOt3XaYycoUapOu5Wi2WAHAPDfcANEqx6/17xtrDz0lyWpK3JrldZBp7gwC5Egtm6+mL+jccLQwAzbZw2UUnJ3let/9eN/bMtVCDc2C73DFLg0ke7pqF67dc9dhNnT2bFRTMh4FNRyb5oySbBMN1TtgFA3A+ylVtfDG7Nn5dvgFqZPDqlUnOdf1GrlAWanCGNNwDQMEzTgA01lh7+PNj7eGNSfqTvDbp3Cwq3WcnpskEA3VbQUck+QF1ANB4FyRpVefHtcu9uVb19AnFfPjI+MibPykMzNJaYyeowRKwMyPMh4FNi5P8bZLzjZ3IFeXhvlZ1hgvjBZRn6OxYQwHU308JgfU3coUanAUN9wBQ0HAPQOONtYe/O9YeHh5rD69JcnaSdyT5noU0qMGmxcILMCYvlKYVjB8UMYDmWrjsosOKhvseXbMw75QrZszu9syFtUJg7KR3WnZ+udcNqgHm2MCmE5L8a3N3x3P9litQg6Bua+1GIQCokcGrH3bPhlOu36YyAk9Fc6UsysB3vgBQ8EwuAEwy1n7Hf4613/G6JI9O8sYkI6JSVu6wgPOxNJ6tBgAa7bnF+gHMteZZ+Xe5r1SubkvyblXFHFgz5XPY+YhcMX/szghzaWDTQJKPJTlTMKjk9dv0QjAoUQmqQeejXJWUhnuAejkvyWLXbwDjxSyclFXXnSgMAKDhHgAOaKz9jm+Otd/xpiQrkrwsyb+4QTB/7KpdnVxRf87HyYulKQfjSYv6NzxCxAAa68Jq/tgTMoe1T7NdOz7y5u8LA7Nx+PLLFiZ5gkgYO+ltrtzLyRc7ezZ/Xc3BHBnY9MQk/1Z8P+Y6h+s3JeW+Fhg7mf7QeV+u7kryCQEBqJWfEQJzLeQKNTgHVosjAGi4B4CHNNZ+x91j7Xe8Z6z9jmcnOSPJjiR3iAxMlxuKYlFrrSTPEgaA5lm47KKTkvxwr38ON/jMtVCD03RXkmvlijlwZpLDXLNw/ZarHrO7PcyVgU3PTPKhJEsFw3VO2AUDuQLnY23dkl0bvyfHADUxePUziudaXedc8gWeaudKWZTBWiEAAM82AcCUjbXf8f/G2u/YkOTkJL+Y5Mui0mvusIDzsTQ03AM002um22hYLnYDM9eqnj6hmAvvHR95815hYLZanbI/dGHA+P/Z+/cwPav6Xvx/PwPDYSCgiHjISMyAGeOJRElCrT3aardVd2ur1VarRSA2CexrfyFgKwo2aFs5WI7Whk7aYq3t7ll/bmsFbGt3k4CorS1gJ5CM4njW4aAOgZnfHw46QA4zmeew7vt+va5rLk8488z787nXutc9z3oWerAhbLiHdhh6+y8k+YckRxk7USuqwXOt6gwXxgtjJ+UMndPWUAD1s04E7rXQg6hVmzjhHgBsuAeA+ZsY3/LNifEtFycZSvJLSbZ6QLBwLc8vKlMr6s/1OHvBNOcwfkhaAM1y+PH/qy/JaeXMWbifVivm7CoR0CarRWDspAzdfZZTXA9u0wGwQENvPyPJXyQ5RBjmb9QKPQj6tva2igCgJoavenKSV5i/634ro1boQbpWq5Oz/NqWHAFoOu/FBYADNDG+5YGJ8S1/MTG+5YeSnJLkA0kelEzlHhCgVrKgHU46YvGbBsQA0CgvTLJUDEDF7vf/c/eui/9JjWiTAzrhvs/1iFrRPg8k+ZQYYAGG3n5ukvd67wi1nL/dXgiDglpQD7oe1aogTrgHqI8zkhwsBvdaaoW20INt8tgkJ4oBgKbzR1MAaIOJ8S3bJsa3vCbJU5NckmRCKvPnVO3ZhIG+rZiDkjxPDwA0yun1+DWmVNK9VuX0iWIhrhYB7dC/5M3HJXmqZzlQzvzd0OvxM9N3bvqOPoMDNPT2C5L8rrUP6MHq8lwLjJ3M07cyNf05MQDUwPBV/UnWCsK9FmoFbe7BVTIEoOlsuAeANpoY3/KFifEtG5M8Jck5ST5fs4U06MGGZGHTxOxF05zD+CFpATTD4cf/r+OS/Fx5cxbuO9WKfbonyXVioE1Wi8DYiR4sgJMZ4UAMvb2Vobf/TpILhWH+FrswUCugUdfj9oyebZABqIdXJHmiec6UL3hqVytt0Ws23APQeN6HCwAdMDG+5Z6J8S2XJhlK8tokn5ZKJ3nCAq7HIthwAtAcv5qkXwy41+qd8k+5L/IF/tHuXRffq3tok1MWdA27HlEr2mObCGCeht7eSnJNkvOEgfmbenDKfXWGC+OFsZMC+NAygPpYJwL3WuhB1KoDvAcWgMaz4R4AOmhifMsDE+Nb/nRifMvKJD+d5KMeEOybU7WrUyvqz/U4e+E0pzCeLymA+jv8+P/VSnJ6vX4rb0zG2qchrhEBbbTa2tHYSXm1auD1aMM9zMfQ2w9KsiXJm4ydoAcBjJ2NtFUEADUwfNVzkvyo+btptzJqhR6kK7V6bpZfe7AMAWgyG+4BoEsmxrd8bGJ8y4uTPDfJX3j6UNQDAtRKFrTDk45Y/KYniwGg3lpT0z+WZFmpr8/DPvda6MG9uH73rotvUxPaoX/Jm1vtON3AnIX5W60WaCLJ7eoAczT09kOSvC/J64VhnhO7MFAroLHXoxPuAerB6fbup9UKbaEHO+WwJM8SAwBN5v1MANBlE+NbPjUxvuWXZjbpbE6yWyoP52S02YSBvq2YleoPUHtvrOev5ZR791rV0yeK+bhKBLTRcJKjZ/8XLSe/gB7svu3Td24SLMzF9zbb/2WSVxs7USvqyXOt6gwXxgtjJz10R0bP/qoYACpu+Kqjk7xWEO4hUSvoYA+ukh8ATWbDPQD0yMT4ltGJ8S1nJFmS5JIk91VkIQ16sEFZ+ACM2YunOYWxQlIA9TUweNYxSV5Z/pyF+0614mE+n+SDYqCN1ojA2Em5Ws05+cXJjDAXP9hs/zJhmL9RK/Qg6NtGs4YCqIc3JDnC/O1WBmp/kbgee2m1CABoMu+/BYAemxjfMj4xvmVjksEkb0/yLakcKE9YwPXYczbcA9Tb65Ic2ppy34l7rVL0OVV7Ln5/966LH9QttFHbNtz3Ne96RK1on20igP2w2R7zt9sLYVBkC+pB16NaWUMBcECGr2ol+XVBuNdSK9CDHeaEewAazYZ7ACjExPiWb02Mb7kwyVOS/EaSrzc5D6dqzyYMXI/lLKD2G4YN9wD1dlq9f70pFcbap37uT3KtGGiz1daOxk7KrlVDrkenM8K+1GazvXkOPchcea4Fxk72w4Z7gOr7qSTDYnCvhVpBh3vwWVl+7YD8AGgqG+4BoDAT41vunRjf8jtJnprk7CRfKmwhDXpQFuzdCUcsftMiMQDUz8DgWc9P8qyH/nPpp9x76OdeCz044y9277r4K2pAu/QvefNhSU4yZ2H+pse12jV956Yvyx72YujtByX5P062N3YidmGoFeB6nPFAkk+pIUDlrTfPmfIFT6NqpS165aAkK8UAQFN5HxMAFGpm4/1lSYaS/O8kX5TKXHjCAq7HnmoleY7aA9TS6c34NZ0G5l6revpEsS9Xi4A2W5nk4L0uiIq/Hg0Y6MGacDIj7M33Ntv/SZKXGztRK5rHc63qDBfGC2MnXfbpjJ79XTEAVNjwVUt8sJ57LfQgatVFq0UAQFPZcA8AhZsY3/KdifEtv5fkxJmN92088b7sBwQtzy8qUyvqz/U4exG13zB8uidAzQwMnnVUkldJAqx9KuZTu3ddvFUMtNkaERg7qYbuPsvpeg9uV2HYg6ELH9ps/8vCMH+jVuhB0LdYQwHUyps6v+/D/F2dKNQKPUjHa7VKdgA0lQ33AFARszbeDyX5/5J8XSptf0CAWsmCdlghAoDaeW2SgUf+l62psudvD/7ca9H4HrxS7nRARzbcm7MwfzNPPlAGHun7m+2nbbbH/O32QhhUpAX1oOtRrayhAJiT4asOTfJGQbjXUiu0hR7sIhvuAWgs72ECgIqZ2Xj/7iRPTfIbdd9471Tt2YSBvq0IG+4B6ue0Zv26UyruXqty+kTxSN9M8gEx0AGr9/cPtJz8Anqwsx5McosYYJahC1tJrqn3yfbGTvQgc+W5Fhg72QMn3ANU2y8lebwYcK+lVtDFHjwxy689RnYANJEN9wBQURPjW+6dGN/yOzMb7y9Ick8XF9LQRnqwKln4AIzZC6l9hvGsIxa/6WApAdTDwOBZz0uysrpzFu471aqh/nD3rou/IwbaqX/Jmx+fZEgSxk6qo1XPk18+M33nJnMcPNy7kpwhBvM3YheGWgGuxz34VpLPqRtApa0zz5nyBU+ja6UteuVkEQDQRN5zCwAVN7Px/rdm3vD87iTflUo8YQHXYy8dmuTp6g5QG2v39T+2ptx34l6rFH1O1Z79g96jI+iA1R29ho2dqBVz42RGmG3owrckOcfYifkbqOZwYbwwdtKVNdTo2RoMoKqGr3pekjWCcK+FHkStemCVCABoIhvuAaAmJsa3fG1ifMv/l2Q4yZYkD9blAYFTtatTK+rP9Th7MbXPMFZICKD6BgbPOiLJq5v5209pAKx9quvDu3ddfIcY6IBTrB2NnVSvVjW8HrfpH5gxdOH6JBcZO0EP8kiea4Gxk1luEgFApW0wf7uVUSv0ID2qlQ98AaCRbLgHgJqZGN8yNjG+5dQkz07yN81Ow8MctZIFPbNSBAC18Ooki/b3D5V+yr0HgO61aFwPXi1nOmR1p3+AOQvzt1rNgRPuIUmGLnxdkquMncZOxC4MtQJcj/uxVb0AKmr4qsc198Ph3U+rFfSyLfTgDCfcA9BI3rsEADU1Mb7l1onxLa9I8oI6fGK1k9FmEwb6tgKccA9QD2c0+9d3Gph7rerpE8UdSf5BJ9Bu/Uve3JrvhvuWk19AD7bfPUluEwONN3Th/0zyR8ZO1Ar2xXOt6gwXxgtjJx3mQ8sAquvUJIeJAdzvQ4968IlZfu1iuQHQNDbcA0DNTYxv+dcka5K8NskX2riQhjbTg1XJwgdgzF5Q7TUMG+4BKm5g8Kxnd+Mk3+7NWbjvVKuGuHr3rovtKqATliV5jBiMnVRTqz4nv2yfvnOTeY5mG7rwhUn+j2We+Ru1Qg+CvmUOdmb07K+IAaCChq/qS/Lr5m+3MmqFi4QeWyMCAJrGH2EBoAEmxrdMT4xv+dOZN0e/Lcl9zfntPcwB12NPHHPE4jc9Rc0BKm1ep9u3ptx34l6rFH3NfePLd5p70ild0LUPoemrx/WIWtEZTmak2YYuXJHkr5P0Gzsxf7u9EAb1akE96HpUqw7Zpk4AlfWSJEvF4F5LraBXbaEHZ6wSAQBNY8M9ADTIxPiW70yMb9k0s/F+S9WeCDhVezZhQAU45R6gogYGzzosyeskkSQOEMXap0Lev3vXxd8QAx1yQKcXeJZj7KScWtXkerRZhOYaunBJkg8nOUoY5jn0IHPluRYYOxvPGgqgutaLAPdaagUF9KAN9wA0jg33ANBAE+NbvjgxvuXUJCcn2bqAhTS0mR6sShY2TcxeVO01jJXSAaisVyY5un5zFu47qXkPXi1XOmh1N3+YOQvzt1rthc0iNNPQhcck+UiSJxk7jZ2IXRioFbgeraEAam74qhOSvNg8Z8pH8GqlLQqwKsuvbYkBgCbxniUAaLCJ8S23JHl+kjcm+Wp9f1NPWMD12BNOuAeorjMO5P/UmnLfiXutUvQ1L4p/273r4k+pPJ3Qv+TNhy5kfVP+B7YZO9GDFTE2feemL4mBxhm6cCDJB5M8XRjGTrWCA+GU++oMF8YLYydt9kASzwsBqml9Epsb3WuhB1GrEhyVZFgMADSJDfcA0HAT41umJ8a3jMy8WWuzU7WrRBi4HstZWO0xDBvuASpoYPCs4SQvkMRs3piMtU8FON2eTlqZpF8Mxk6qr7vPctr+w5zMSPMMXXhQkvfNfHAy5m/UCvQg+pb5+ExGz/6OGAAqZviqgSRvMH+7lVErXCQUVKuTZQZAk9hwDwAk39t4/42J8S1nJPmRJLfW7zf0MEetZEHXLT1i8ZuOFgNA5ZyxkP9z6afcexjoXota9uBXkvwfedJBa8xZmL8pwHYR0EBXJPl5Yyfmb7cXwqA5LagHXY9qZQ0F0Hi/nOSxYnCvhVpRSlvowSSrRQBAk3i/EgDwMBPjWz4xc3LZBUnuL/E1OlV7NmGgbwt3knoDVMfA4FmHJnm9JPbEKffutaqnrzlRbN696+L7VZwOWvCG+5aTX0APLtxWEdAoQxf+RpJ1gjB2ogdpB8+1wNjZSNtEAFBJ60WAey21gsJ60IZ7ABrFhnsA4FEmxkcmJ8ZHfivJ85J8UiJ0nweKVcnCB2DMXlztMYwVkgGolJ9L8rj6z1m471SrGnkwye+LgQ7zJgpjJzXSqubJLw8m+ZTq0RhDF/5SkncKwvwNYLwA1+MC2HAPUDXDVz2/zPcZue8UheApsFbaoptWZPm1/WIAoCm8vxYA2KuJ8ZHPJjklyflJdlf/N/KEBVyPXWfDPUC1nNGOb9Kact+Je61S9NX/VO2/373r4i+oNJ3Sv+TNxyY5oWfXsLETteJ7Pjt956b7xEAjDF24OskWYyfmby9PGDS3BfWg65E2mEhyuxgAKsfp9u610IOoVYkOTfIcfQBAU9hwDwDs08T4yAMT4yPvmNl4f1spr8up2rMJA9djOQusR4WxUioA1TAweNaJSX5SEvsyJQKsfcpzlQjosLadbm/taOyknFpV8Hp0MiPNMHThU5L8XZLDhWGeQw/Sbp5rgbGzUbZn9GxBA1TJ8FXHJXml+dutjFrhIqHQWq2SFwBNYcM9ADAnE+MjtyR5bpKrq/2beJijVrKgq555xOI39YsBoBJObec3K/2Uew8F3WtRix68NcmN8qPD1pizMH9TQK22y5HaG7rwiCR/n+SJxk7USuzCQK3A9WgNBdA4ZyTx/iKw9qHYtmh8D9pwD0BjeJ8SADBnE+Mj35kYH9mQ5OVJvtnr1+NktNmEgb4tVH+SZ6g1QNkGBs/qb/eG+/pyGph7rerpq28U1+zedbFC02lt3XDfcvIL6MEDs1UE1NrQhX1J3p9khTCMnWoFneS5VnWGC+OFsRNrKIAGGb7q4CRrBeFeCz0IBVstAgCawoZ7AGDeJsZHPjjzxq9/kwad5YFiVbLwARizF1mPCsMbZQHK97IkT2jenIX7TrWqsHuT/LEY6AJvnjB2UlOt6pz8cm+SW1WMmg/Tvz3zQcdg/lYr0IPoW9rBCfcA1fKyJIPmb7cyaoWLhIJr9Ywsv/YIeQHQBN5XCwAckInxkbEkP5rk96r36j3MAbrKhnuA8p3WiW/amnLfibVPKfrq98aXP9m96+J7VJZO6l/y5qcleWwR17CxE7Vqsu3Td25yHC31tfTCX0tyrrET87eXJwx4ZAvqQdejWh2gnRk9+ytqAVApZ4rAvRZqRRXaotE92JfkeRoOgKZMegAAB2RifOSBifGR/53kV5J8uxevwanaswkDfVuoleoMUK6BwbOWJPkZScyH/U64hyzANSKgCzpyur1nOcZOyqlVRa5HJzNSX0svfEGS9wrCPIcepJs81wJjZ+1tEwFAhQxftTzJTwgC91pqBRXowdWyAqAJbLgHABZsYnzk/Ul+KMmYNGg/DxSrkoVNE7MXWg8Lwwn3AGU7NUmruXMW7jupYA9+fPeui/9TXnTBKeYszN8UUCubRainpRc+OclfJunv/nBm7DTPIXZhqBVQ4+vRGgqgWtab50z5CF6ttEVFnCwCAJrA+5MAgLaYGB/595lPr9tajVfsCQu4Hrvm6CMWv+mp6gxQnoHBsw6a2XDfMa0p95241ypFX32iuEo16ZIGn1Jg7EQPFsRmEepn6YWHJPmrJE8QhrFTraAXnHJfneHCeGHsxBoKoMaGr1qU5FcF4V4L9KBaVYQT7gFoBBvuAYC2mRgf+XKSn0jyF938uU7Vnk0Y9JbrcfZiyyn3ABXwkiSDYjgQ3piMtU+P3JXk79SfTutf8uZDO7mOsXY0dlKOwq/Hu6bv3DSuStTQlUlOMUxj/lYr0IOgb9vsgSSfEgNAZbwuySLzt1sZtcJFQkVqtTTLrz1WVgDUnQ33AEBbTYyPfDfJq5P8Xvmv1sOc6lArWVSeDfcAZXpjN35I6afce0DoXotK9eB7d++6+AE50aU1zCHmLMzf9LhWW2VG7Sy98I1JzjB2wrSXp1YwxxbUg65HtZqHz2T07O/IH6Ay1ovA/I1aUcW2aHQPrtJsANSd9yYBAG03MT4yPTE+8r+TnNutn+lktNmEgb4tkA33AIUZGDzryUleKomFcMq9e63q6at2FLuT/IEq0iWrO/0DWk5+AT24f9tFQK0svXBNkmsEYewESuC5Fpi/raEA6KHhq348yTMEgXst1IqK9aAN9wDUng33AEDHTIyPXJzkTd6xQHt4oFiVLHwAxuwF1/fDWCkNgOKcmuQgMTw0Z+G+U60q4K9277r4y+pOl5wiAmMnzdEq9+SXbapDbSy98AlJ/irJIYZpzN9qBXoQ6BBrKIDq2OC+0y04glcrbVFBa0QAQN15Ly0A0FET4yPvTfKr5W6694QFXI9dcfwRi9/0WDUGKMPA4Fl9Mxvuu6Y15b4T91ql6KvuqdpXqR5dtLrYa9jYiVo1xVSSm8VALSy9sD/JXyRZbOyECvWgS0QYFNSCetD1qFZzZMM9QBUMX7U4yc8JwvwNelCtKuhktQeg7my4BwA6bmJ85E+7seneqdqzCYPecj3OXnR9P4wV0gAoxk8lWSqGdpgSAdY+3fGZ3bsu/lf1phv6l5z3uCQnWjsaO2lWrQq8Hj87feem+/QANfHbSX5UDOY59CCl8VwLjJ21MpHkdjEAVMLaJAeJAfda6EEqWKvjsvza4+UEQJ3ZcA8AdMXMpvvXl/nqPMypDrWSRaXZcA9QjjN68UNLP+Xeg0L3WhTdg063p5tWl/4CzVmYvxtRKyczUg9LL3xZkrPLHc6MneY5xC4MtQJqcj1uz+jZBgCA0g1fdUiv/lbtvlMUgkdb0CZrRABAnXlPEgDQNRPjI+9Lsk4SwN7V+omnDfcABRgYPOu4JC+XRDs5Dcy9VvX0VSuKbyV5v6rRRasbfqq2sRM9WIbtak/VtZZeeHwr+WNJGDtRK0rmuVZ1hgvjhbETayiAWnhFkieIwb0W6EG1qrBVag9AndlwDwB01cT4yHuSvK1T37/lWdMswqC3XI+zF17TSbJSEgBFeEOSfjHsbc7C/bRaFWjL7l0Xf1ud6SKnEhg7aahWWadqb1URKn09Lb2wP8mfJ3msYRrzt1qBHgR92wXWUADVsMH87VbGC8RFQsVrZcM9ALXmPbQAQNdNjI9sSvL7Zb0qD3OqQ61kUVnLj1j8pkPFANA7A4NntZKc1svX0Joyf+MeshR91Xjjy3SSa1SLLltdhfGir/vXI+Y5uufeJLeKgYr77SSnJEnL2AnV7kGXiDAoqAX1oOtRrfbBCfcApRu+6qQkPywI8zdqRZ3aopE9eHKWX2svIgC1ZZIDAHplQ5IPdeIbO1V7NmGgbwtycJJnqi9AT/1YkqeJoROmRACd8dHduy4eFQPd0r/kvBOTPK7bP9ezHOtvyqlVIdfjJ6fv3PSgulNVraUXvizJ2ZIwz6EHqQrPtcDYWXk7M3r2V8QAUPw8t14GuNdCrahBDx6Z5OkyAqCubLgHAHpiYnzkwSS/nOS/pMH8eaBYlSxsmpi9+JpOkhWSAOipM0QwlzkL951qVZCr1JYuWy0CzAkUUKttsqGqWksvPD7JH1dvODN2mucQuzDUCqjw9WgNBVC64Ssfk+RXzHOmfASvVtqiJlaJAIC68v5ZAKBnJsZH7kny0iRfL+MVecIC5ajt9WjDPUCPDAyedUySV5TwWlpT7jtxr1WKvrKj2JlMf1iV6LI1VRovuvtHLmMndNF2EVBFraUXHpzkz5M89lH/m3isfVArCueU++oMF8YLYyd7YMM9QPl+LcmA+du9FuhBtaoJH+IOQG3ZcA8A9NTE+MidSV7T7ncxOFV7NmHQW67H2QuwaRvuAXrnV5McKoZO8sZkrH3a7Jrduy5xYdFta6wdjZ2oVQHX41b1pqLemuQUMQDutdCDoG+7zIZ7gJINX9lKss787VbGCwQ9WKNa2XAPQG3ZcA8A9NzE+Mg/Jnl7Ga/Gw5zqUCtZVNJJRyx+kwOtAHrj9JJeTOmn3Hto6F6LnptMMiIGuql/yXmHJFlZtddtzsL8XbtafXH6zk13yYWqaS298PlJ3lLt4czYaZ5D7MKgKi2oB12PajXLA0k+JV+Aor0oyYliMH+jVtS5LRrXg8/J8msdegJALXkfEgBQiouSfLSd39DJaLMJA31biKOSDKktQHcNDJ71/CTPkEQ3OIzbvVb19JUZxZ/t3nXJ11WHLluR5JBejhctJ7+AHnS6PRXUWnrhoiTXJTlon/+cqIydqBWF81wLqKTPZPTs74gBoGjrrX2w/katqFkPHpLkOfIBoI5suAcAijAxPjKV5PVJviYN5s4Dxapk4QMwZi/CpldIAaDrzhDBgcxZuO9Uqx66Wi3pgdUiMHbCQ1q9O/llu/SpoCs6+iGbhmk0hlqBHkTfsnfWUAAlG77yqUleav52K4Pg6VGttEUn+dsyALXkfbMAQDEmxke+lOTU3r8ST1igHLW8Hm24B+iigcGzjkryqhJfW2vKfSfutUpR2Cn323bvuuRmVaEHTqnqeNHdP3YZO81zdHoeFAFV0lp64S8mecOc/3ljJ1S7B10iwqCgFtSDrke1mmHDPUDZ3lSJxwG410IPolbzt0rNAagjG+4BgKJMjI98MMm17fp+TtWeTRj0luvx+2y4B+iu1yY5XAzdNCUCrH0W5ho1pEeKOIXA2tHYSTm16sH1OJXEh85QGa2lFy5O8l5JGDtBD9aJ51pg7KwcH1oGUKrhKw9Lcpp5DvdaQE3HCyfcA1BLNtwDACU6O8nnxcDcePgri8qx4R6gu84o+cWVfsq9h4futei6ryb5czHQbf1LzjsmydOq/DuYszB/16JW/zV956Z7ZUEVtJZe2Eryx0mOqd9wZuw0zyF2YagVUJHr8e4kt8sUoFi/lORx5jlTPoKnx7XSFp3y9Cy/dpEYAKgb7z8CAIozMT5yd5I39fZVeMIC5ajd9Ti4aPHaY9UVoPMGBs86OclJkugFp4G516qevjKi+MPduy6ZVA16YFVJ40X5p9wbO9GDHeJkRqrkfyV54QHNc7IzdqJWFM5zreoMF8YLY2fjbc/o2QYtgHKtN3+71wI9qFY11kpyspoDUDc23AMARZoYH/lwkve3ZUXvWdMswqC3XI/f55R7gO44QwQL5wGi+2m16pqpJL+vdvTIahFgnmNPuvssZ3q7xKnEdbH0wqcleadhGvM3aoUeBH3bY9ZQAKUavnLV3D7o1vwtCi8QFwmVrtUq2QBQN94vCwCU7Owkd/fux3uYUx1qJYvKseEeoMMGBs9alOQ1VXitrSnzN5Six6fcf3D3rkt2qQI9ckod1pzd/aOX+bs61KpCnHBP+eu3pRf2JRlJcviCvo+xE6rdgy4RYVBQC+pB12Oja7VVlgDF2iAC8zdqRVPbolE9aMM9ALVjwz0AUKyJ8ZEvJXlrO76XU7VnEwb6tgA23AN03quSHCmGXpoSgXst5udqEdBDxZ1w71mOOYFyatWl6/HbST6rrlTAWUleIAZjJ+jBuvNcC4ydleCEe4ASDV95bJJfMs/hXgu1ogE9uFouANSNDfcAQOmu8UZL5sYDxapkYdNEYsM9QFesFUH7eIjovlOtOu72JB9TM3qhf8l5JyQ5VhJAj908fedFD4qBkrWWXvi0JO9szi2utY+1D2IXhloBBV+PuzJ69pflCFCkNyY51DyHKARPYbXSFp1wfJZf+wQxAFAn3isLABRtYnzkgSTn9O4VeMIC5ajV9fj0RYvXHqamAJ0xMHjWSUlWVek1t6bcd+JeqxR9vYniPbt3XaII9Mo8Tx4ou1W7+4cvl615jjbaJgKKXrMtvbAvyUiSw9v2PcUK5m8K55T76gwXxgtjpzUUAIUYvrIvya+bv91rgR5UqwY5Wb0BqBMb7gGA4k2Mj/xDko8s9Ps4VXs2YdBbrscclOTZOgGgY04TQSm8MRlrnzm4L8kfqRU9tMbakQqOnXS5Vl24HrerJ4U7K8kLxGDsBD2IHgR9WwhrKIAyvTTJEjGYv6sVhVqhB1lQrdbIBYA6seEeAKiKjb17quJhTnWolSwqZYUIANpvYPCsgSSvq+JrL/2Uew8S3WvRMe/bveuSCTHQQ7V7E4Q5C/N3JW0VAcWu1ZZeuDTJO5s5nBk7zXOIXRgAhY6d1lAAZVonAvM3aoW2aFgPrtJYANSJ9xwBAJUwMT7y2SR/ttDv42S02YSBvu0xG+4BOuMXkxwthpI45d69VvX0dTeKqyVOr/QvOa8/ycqSx4uWk1+gCT04Pn3nRV9QS0rUWnphK8lIksM78v1FbOxErSic51rVGS6MF8bORnkwyS1iACjM8JVPS/Ji8zfuIVErGtaDJ8sEgDqx4R4AqJILZv5wCPvggWJVsvABGDbcA3TI6SLoHA8T3XeqVdv98+5dl/yHGtHjdcmhYsA8x1x08FnONulSsF9L8uOGaczfqBV6EPRtQT6T0bO/IwaA4jjd3vwtCsFThVppi3Y7NsuvHRIDAHXhPbIAQGVMjI+MJvmj3vx0T1igHLW5Hp+zaPFaazKANhoYPOsZSV5Q5d+hNeW+E/dapejSKfdOt6fXVtd1vOjuYsvYaZ5jgbaLgCLXZ0svPDbJxR3/OcZOqHYPukSEQUEtqAddj42plTUUQGmGrzxi5kP7MH8DNHG8WK3WANSFzR0AQNX8zkJPuXeq9mzCoLcafj0emeQEXQDQVm8UQammRIC1z6ONJ/kbtaHH1lg7UrGxkx7XqkPXo80ilOqSJMeIwdgJerDpPNcCY2dxtokAoDi/nORo8xzutVArGtqDJ8sEgLqw4R4AqJSZU+7/XBLsmweKsqiMlSIAaI+BwbMOTfL6OvwupZ9y74Giey3a5g9277pktxjosVqfNmDOwvxdmYLYcE9567KlF/xEMv364q8eYydqJXZhoFbQxOvRhnuA8mwQgftOUQieCtVKW7SbE+4BqA3vNQIAqugdvfmxnrBAOWpzPa5QS4C2eUWSx4mhZE4Dc69VPX2di+KBJO+VML3Uv+S8xyQZrsp4Uf4p98ZO9OABunX6zovuUT9K0lp6waFJfr+rP1Psxk7UisJ5rlWd4cJ4YeysvbuT3C4GgIIMX/mCJM8xf7vXAj1Ig2v1vCy/9iC1BqAObLgHACpnYnzkv5J8eCHfo+VZ0yzCoLcafj3acA/QPqeJAKjQ2uevd++6ZFxN6DEnDVC1sZNCtPlZzlaJUqA3J1lmmMb8jVqhB0HfFmh7Rs/2KSAAZVkvAvN3faJQK/QgB1SrgSTLZQJAHdhwDwBU1aW9+bEe5lSHWsmiEmy4B2iDgcGzTkzyk3X6nVpTZc/fHiq612LBrhYBBWjEhvvuzlnmBPM3B2C7CChqLbb0gmVJfqMX40X5p9wbO9GDLhFhUJUW1IOux1rXyhoKoCTDVz4xyS8IwvyNWqEt9GDWaCoA6sB7YwGASpoYH7khyacW8j2ccj+bMNC3PfKkRYvXHqeWAAt2ugiqwsE77rWqp6/9UfzH7l2X/LNkKcApVRsvPMuBWs7f29SNwrwnyaFiMHaCHuTRPNcCY2cRtqo/QFHOSNJvnsO9FmqFHswqeQBQBzbcAwBVdrkI2DcPFKuSRcM3TTjlHmABBgbP6k/yekl0nweL7jvV6oBdow4UYrUIMM9xoNr0LOfbST4rTYrp66UXvCrJTxqmMX8jdmGoFVDw9eiEe4BSDF95cJK1gnDfKQrBU+FaaYt2suEegFrwvlgAoMr+PMnXu/9jPWGBctTielypjgAL8vIkT6jjL9aact+Je61StPGU+7uTXCdReq1/yXlLkzy+KeNFd/8YZuw0zzEPt0zfedEDYqCI9dfSCw5P8q5ejxctYyfoQaBNw4XxwthZS7syevaXxQBQjJ9L8mTzt3st0IOoVZLkOVl+7WHqDEDV2XAPAFTWxPjId5P84UK+R8uzplmEQW81+Hp0wj3AwpwugqqZEgFNXvv80e5dl9ynBhRgjbUjFRo7KbRWbbget6oXBTk3yRIxGDtBD7JvnmuBsbOntqk7QFHWi8D8Xd8o1Ao9yLxrdbD3wgJQBzbcAwBV957ePFnxMKc61EoWxfOQEeAADQyetSTJi+r8O5Z+yr2Hi+61mLerRUAh1jTtFzZnYf4u0k0ioIh119ILjk9yXqXHi+na/jDUSuzCQK3A9fgD2+UDUIjhK5+Z5McFgftptUJb6MGHWaWhAKg67y8CACptYnxkZ5KPLeR7OBltNmGgb3tg2aLFawfUEeCAnJakJYYqchqYe63q6Vt4FP+4e9cln5MkhejAhvtKnapt7MT8XQanM1KKi5McXsqLscg1dqJWlM5zreoMF8YLY2ftbBUBQDHWmb8B9/vwqB5cIwsAqs6GewCgDjaLgH3zQLEqWTT0AzD6kjxbbwLMz8DgWQcl+TVJlDGR4b5TrebE6fYUoX/Jef1JVkoC8xztsIBnOV+evvOiXRKk5z289IIfS/IqwzTmb9QK9CD6tnAPJrlFzQEKMHzlUUl+VRDm7/pHoVboQebtZBEAUHXeDwsA1MHfJfl693+shzlQjspfjza7AMzfS5IsbsIv2ppy34l7rVIs4JT7sSQfkiCFeE6Sw5o4XnT3j2LGTvMc++F0e3q/1lp6wUFJrihxvCj/lHtjJ3rQJSIMqtKCetD1WJtafSajZ39HNgBF+NUkR4oB91pqhbbQg48ynOXXHq2hAKgyG+4BgMqbGB+5P8n7FvI9Wp6hzSIM6IEVIgCYtzNEUHVTIqBJa5/37N51yYMypxCr6/BLeJbTiLGTitTqAK9HG+4pZV35HDFgnkMPMn+ea4Gxs+u2qzVAAYavbCVZZ57DvRZqBXvtwVWyAKDKbLgHAOriT0XAvnmgWJUsGrppwoZ7gHkYGDzryUn+R5N+59JPufeQ0X0n+3R/kj8UAwVZ0+Rf3pyF+bsYNovQ2zXW0guOSvJbtRsvnMSEWoldGKgV1PV69KFlAGX4iSTLxeC+UxSCp4a10hbtcrIIAKgy7ysCAGphYnzkpiT/3f2f7AkLlKPS1+OzFy1ee5AaAszZG5MYN8G9Vk/0zT+KD+zedclXJUdBOrzhvvhTtY2dmL/LeGE23NNr5yY5tuQX2FIjYydqReGccl+d4cJ4YeysBRvuAcqwwfyNWqEHUat9Wq2+AFSZDfcAQJ0s6JT7lmdNswiD3mrg9TiQ5GkqDzCHAXPwrL6ZDffUgjcm04i1zzVyphT9S847OsmwJKjA2EnFzPNZzm3Td150t9ToWb8uveDJSf4/wzTmb9QK9CD6tiLuTnK7OgP02PCVT0nyckGYv5sXhVqhB5lXrdbIAYAqs+EeAKiT9/fmx3qYUx1qJYuirRABwJz8VJIlTfzFW1Nlz98eNLrXYo8+uXvXJU6foiSrHZhrzsL8XQBzI732W0kOr8J4Uf6kbexED7pEhEFVWlAPuh4rXavtGT3bp9cC9N7aJAeJAfdaaoW20IP79OQsv/ZJmgmAqvKeIgCgNibGR/47yfaFfA+n3M8mDPRtl9lwDzA3a0VQN94n6F6revrmHsVV0qIwq+s2XrSc/AJV7EEb7umZ1tILlid5gyQwf6MHaQ/PtcDY2RXb1Regx4avPCTJ6eY53GuhVjCnHlwlBwCqyoZ7AKBu3i8C9s0Dxapk0cAPwFipJwH2bWDwrCckebkkyuVho/tOtXqYbyT5gHwpzCkiwDxHp8zjWc5N0qKHfrcRp9EZptEYgPEC6nQ9bpUDQM+9MslxYnDfKQrB04BaaYt2WCMCAKrKe2ABgLr5QG+OEvCEBcpR2evRCfcA+/f6JAc3OYDWlPtO3GuVYg6n3F+7e9cl35UUhVndvR9V9njR3T+QGTvNc8zy3SSfEQM9WU8tveBHkrysauNFy9gJ1e5Bl4gwKKgF9aDrsbKccA/Qe+vM36gVehC1mrOT1RaAqrLhHgColYnxkS8n+fhCvkfLs6ZZhEFvNex6PG7R4rVPUnWAPRsYPKuV5AxJ1NWUCKjb2mc6ye/LlZL0LznvqXU9gceznNqMndSgVnO4Hm+ZvvOiB9SErs8VSy9oJblYEpjn0IO0n+daYOzsqF0ZPfvLagvQQ8NXrkzyfEGYv0WhVuhB5lyrVTIAoKpsuAcA6uhve/NjPcypDrWSRbGccg+w9znrx5OcIIfyT7n3wNG9FkmSD+3edcmdYqAwa0RgzsL8XYCtIqBH/mf750Knahs7zXOIXRhqBXTcNhEA9Nx6EYC1D9pCD87LY7P82qdpJACqyHuJAIA6WvCGeyejzSYM9G0X2XAPsHeni6DunAbmXqt6+vYexTXSoUCr6zxetJz8AlXpwe1qQbe1ll7Ql+Ttlf4dlNH8jVpROM+1qjNcGC+MnZVjDQXQS8NXHpPkl83fqBV6EObdg065B6CSbLgHAGpnYnzk80lulgT75oFiVbJo2AdgrNSPAI82MHjmsUl+QRLV4aGj+86G12o0yUflSYGccI95jq7Yz7McpzPSC69K8hzDNGgMtQI9iL6tIGsogN56Q5LDxWD+FoVaoQeZNxvuAagk730FAOrqb3rzYz3MARbECfcAe/baJIe41/qB1pQs6DU9+JA9nHJ/ze5dlzjajqL0Lznv4CTPNV7s4RqWBWrVTV+ZvvOinWKgq2un751u/7Y6jBfln3Jv7EQPukSEQVVaUA+6HivjwSS3iAGgR4av7EuyThC411IrtIUePCCrNREAVWTDPQBQVwvecN/yDG0WYaBvu+TERYvXHql2AI9yhgiawh5lKn8P+e0kfyRHCvTsJpzC41mO9Tfl1Gov1+N2NaAHXpVkuRgwz6EH6TzPtcDY2Xb/kdFzvq2eAD3z4iQnmOdAD6oVHJCVWb75YDEAUDU23AMAtTQxPnJrktslwb55oFiVLBq0aaKV5Dn6EeAHBgbPfIHNEdXkwaP7zoZ6/+5dl3xTDBRojQjMWZi/C7BVBHRT50+3r8h44SQm1ErswkCtoKq2iQCgp9aLwH2nKARPw2ulLRbi8CTPFAMAVeM9RABAnf1tb36sJyxQjkpejyvUDeBhTnOvtWetKVngXqsUfT+I4ippUKgeb7jv+anaxk4oowedcE+3vbZuH+DWUlPzN2pF4ZxyX53hwnhh7KwEG+4BemX4yqVJXmL+Rq3Qg6jVgqxWVwCqxoZ7AKDOFrzhvuVZ0yzCoLcadD3acA8wY2DwzMckeZUkmsYbk6ns2udfd++65DPyo1BOuKfUsZMa28OznJukQtf6b+kFB3fndHvDNBoDtUIPgr7tGBvuAXpnnc+9M3+LQq3QgyyYDfcAVI4N9wBAnW1P8vXe/GgPc6pDrWRRnJUiAPi+X0lyuDlr70o/5d7DR33bMFeLgBL1LznvqCRPl4Q5C/N3j90+fedF3xIDXfTaJCcYL4yd6EEvTxiw9xbUg67Hot2T5DYxAPTA8JWHJzlVELjXUivoflvUrgdXaSAAqsb7hwCA2poYH5lK8pGFfh+n3M8mDPRtFzxr0eK1B6sbQJLkdBE0lVPu3WtVzpf7pvNXYqBQq8s4iad740XLyS9QYg86mZHuzQNLL+hL8hu1/f2U2PwNFM5zLTB/t8X2jJ5jQAHojVcnOcY8B3pQrWDBnpXlmw8XAwBVYsM9AFB3HxEB++eBYlWyaMgHYByWZFgvAk03MHjm6iQnSaL6PIB039mQWv3B5Ngl98uNQq0WAeY5emXWsxwb7ummVyRZJgbDNBpDrUAPQoVtFwFAz6wXgftOUQgetdIWbXFQkueKAYAq8X5XAKDuPtK7Rx2esEA5Knc9rlAzgJzmXmtuWlOywL1Wjz2Y5L36gIKtMV7MTZ8sUKtOslmEbnpz3ceL8k+5N3aiB10iwqAqLagHXY/F8qFlAL0wfOUpSZ5n/kat0IOoVdusUlMAqsSGewCg1ibGR76W5KaFfp+WZ02zCIPeasj1aMM90GgDg2cuSvIaSTTdlAioytrnbyfHLrlLXhRsTRN/ac9yih87aVCtWtP5bpLPyJyu9NvSC36qWm+Mx9gJerCePNcCY+eC2XAP0BvrRADWqehB2mq1CACoEhvuAYAm+L+9+9Ee5lSHWsmiKDbcA033miRHmrPmrvRT7j2E1Lc1d7UIKFX/kvOOT/IESZizMH/32Kem77xotxjokjf39sc7VdvYaZ5D7MJQK2DBxjJ6zpfEANBlw1c+PskvCcJ9pygQPNqirZxwD0ClHCwCAKAB/m+SC8TQTtNJWmJA33bOSvUCGu40EfA9U7Y+utcq3X9Njl1yo/pTsAJPt+/eeNGaTqaLHpo8X6ExPehkRroz7i+9YFWSFzbm9/UeT/M3akWpJpLcnUzdnfTd/b1///2ve5Pck+TBmX/uwZn//oGZ/+2h5p2Y9f0e+ufn4tAkhz/ivztq5gHb7P/tMTP/euTMf78oyRFJDtvDvz965uuoJAfVc7iYTlrGC2NnUayhAHrjtCSHmL9RK/QgatVWJ2b55mNy6+nfUFcAqsCGewCgCW5K8vUkj1vINyn/TdrQHA24Hh+3aPHawXvueu8XVBtomoHBM1f4dON66pvZPk/8IbtetXK6PaVbLQLMcxTAZhG65c0iMEyjMdSKNtqd5GtJvjLz9dUkX575168lGZ/51x9sqN/xm3fXOpETfueIZPqopPXQBvyjkxwz83f4h/712D38d8doJ4yd87JdzQC6bPjKg5K8SRDmb1GoFS4SOuLkJB8VAwBVYMM9AFB7E+MjU0c/6dSPJPmV3rwCD3OqQ61kUZQVSWy4B5rodHPWgWlNTWe6Txa4h+yie5Jcp+4U7hTjxfx190Ni3MuY5xrBZhE6vx5aesFwkp9v2nhR/in3xk70oEuk2DDuT/L5R3yNzfoaz47fdPLaI+14831J7pv5sIG5O+F3D0ny+CRPTHLczL8+Yda/Py7J4MzXEb1pQafcG5yKslUEAF330iTHiwH3WqgV5bRFrXpwlQ33AFSFDfcAQFP8Yzs23DvlfjYPFNG3HbYiyYfUDGiSgcEzB3r3IUmUa2pm6yMUdw/5x5Njl9wjH0rVv+S8g5M8t+k5eJZj/U3Pa/W1qZ0X3SFnumCjgQfzHHqQR/h2ktGZr9uT/Pf3//OO3xwXTxftOO/+JHfNfO3bCb97dJInJ3lKksUz//6hzfhLZjbCHS1Uajx2PpjkFvUC6LoN5jnQg2oFHbNaBABUhQ33AEBTfEwEzI0HilXJogGbJlboQaCBXuXNkvXW3ROD3WvRcdeIgMI9K8mAGMxZmL97zOn2dFxr6QWPT/Ja40WpL8/YaZ5D7B0P494k/5nkP5J8duZfb8+O37xLphW047yJJBNJbt3rP3PC7z4myVNnfS2Z+XpqkqVJHiNIKuw/MnrOt8UA0EXDVw4n+SlBWDCJAsGrlbboGBvuAagMG+4BgEaYGB+56+gnnXpbkqf35hV4wgLlqMz1aMM90ESnuddamNbUdKb7ZIF7rS64cXLsklvVm8KtMV4YO6EAW0VAF6xNcmhj14EzMwnmb9SqIT4/84E+t8xsrv/3JLuy4zcNhU2y47xvJfn0zNejnfC7j0vytJmvE2a+HvrPx+x9uJhOWsYLY2fPbRMBQNetM3+jVuhB1Kqjnpjlmxfn1tN9OCIAxbPhHgBokuvbseG+Aadqz4MHb/RWza/HExYtXnvUPXe9926VBppgYPDMZyT5YUmwZ1MzZw1DMWufK2VCBTgpoBlrxyqNnTSzVk64p7Nj/NIL+pP8uiTA/K1WtfTlmXuJm2e+bsqO3/yq2rNfO877epKv7/HDn0743ccmOTHJ8MzXM2f+dZn3Uho7C2HDPUA3DV95RJI3CML8LQq1wkVCx61J8tdiAKB0HhIDAE3ysSTre/fjPcypDrWSRTFOSvIvYgAa4gxzVnuUfsp938z2efRthX0hyQfFQAWcIgJzFubvAthwT6e9MsmTjRelvzxjJ7hE5uTWZPpfkta/JPlEdvzmTpHQdjvO+2aSm2a+fuCE3z04yQmZnl6eVmt5ktlfRxic6CIb7gG663VJjhID7rVQK8pti9r04Cob7gGoAhvuAYAm+Xi7jsZ0MtpsHiiibztohQ33QBMMDJ55aJLXSoJ9c8q9e61i/P7k2CUPqDMl619y3qKZTQHGixnlP8vxfIVa9uDnpnZe9E3Z0mFnieB7V++0GMzfqFX1ivLpJDfM/B3kE9nxlq+LhZ7Zcd4DSW6f+frb7//3J76rL8nSJM+e+aDsZ898nehhJR1wT5LbxADQVeusfUAPqhV0xckiAKAKbLgHABpjYnzkW0c/6dRPznxKHuyHB4pVyaLmH4CxQv8BDfELSR4nhuZwYrD7zgrXaneSzbKgAlYbXDDPUQCn29NRraUXnJJkjSQM02gMtaqMzyf5xyQfTXJ9drzla2pI8UbPnUqyY+Zr9kb8gSTPmLUR/zlJnueEXGPngtdQo+d4dA7QLcNX/ujMXI75WxQIXq20ReetzvLNrdx6us+OBaBoNtwDAE3zsd5uuPeEBcpRievRhnugKU53r9VeranpTPfJAvdaHfB/Jscu+Yr6UgGrjRft0d0PiXEvo29rZ6sI6LD/ZbyYtQ4s/pR7Yyd6sIGXyP1J/inJB5P8Q3a85XP6kNoYPffbSW6e+fqBE981NLPx/qGvFUmONXYyRz60DKC71osA91roQT2oVl1zVJLhJLepJwAls+EeAGia65P8Rju+Uc1P1Z4nD97orRpfj89atHht/z13vXe3KgN1NTB45olJflwSzM3UzNZH6Nna5yoZUBFO+23W2rH0sdNzo+bWymYROjemL71gcZJflATmOSiuB7+Z5MNJ/m5mk/3dakSjjJ57R5I7kvyf7/93J77r+CQnJ3lukpUza/bHCcvYuQfb1AagS4avfFKSV5jnQA8CXXWyDfcAlM6GewCgaf41yWSSQ3v3EjxQrA61kkXPHZJkeZJ/FwVQY2eYszqj9FPuu3tisHst2uLTk2OX/psYqIjVIjBnYf7usfuTfFoMdNDa6rzfwanaxk7zHLWPfTzJX818/Ut2vOVBxYRZRs8dSzKW5K+//9+d+K4TZ9buPzTzryuT9Aur8Wy4B/BcAetUUQieKtVKW8zX6iTvEwMAJbNQBAAaZWJ85LtHP+nUTyR5oTSAijzxXGHDPVBXA4Nn9id5vSSYH6fcu9fqmSvVlCroX3LeYJInGS/2rPxT7r0zh9r04Kemdl60W550ZCxfesHBSU6TxB6ymbmKMX+jVl3w9SR/OXOK98dtsod5Gj13NMlokvcnSU5816Ezm+5PSbJm5mupsbNRxjJ6zpfEANAFw1f2t/9D4a19UCv0IGo1Bz40HoDi2XAPADTRx9u14b78N2l3kwdv9FaNr8cVSf5EhYGaenmS48TQXE4Mdj9dId9M8gExUBGniADzHAVwMiOd9NLqfbiMYRqNQS1q9Z2ZU+z/NMn12fEWH64D7TJ67mSSrTNf33Piu56Q5AUzXz8y8zfDg4RV23nOGgqge37ecwXztyjUChcJPXFSlm/uz62ne6YEQLFsuAcAmuhjSTb19iV4mFMdaiWLnlshAqDG1pqzOqs1NZ3pPlngHrINRibHLv22elIRFT0ZoOzxorsfEuNeRt/Wgs0idFIFT6Hr3nhR/in3xk70YAVf3rYkI0k+kB1vuVsPQZeMnvvlmQ+5+KskyYnvOjLJD83agH9KksONnbWxXQQAXbNeBFgIolZUsy0q34OHJXlOkk9qHABKZcM9ANBENye5N8mR7fhmTrmfzQNF9G0H2HAP1NLA4JlPTfJTkuDATM1sfYSu3TC+RwxUyBoR7JtnOdbfdKVWNovQmTF86QXHJ/kZSWCeg4734FeT/HGSkex4y63yhQKMnntvkn+c+UpOfNfBSU6e2YD/giQ/keQoQVV2/t6qHgBdMHzls5L8qHkO9CBqRc+ssuEegJLZcA8ANM7E+MgDRz/p1H9K8rPSYG48UKxKFjXdNPHYRYvXHn/PXe8d039AzbzRBEu6fmKwey0OyEcmxy7dIQaqoH/JeQfNvNkeoJe+PrXzolEx0CGnVvem2ana1j76lkrEvi3J1Un+PDvecr9iQMFGz31gZpP21iSX5MR3HZRkZZIXzmy+/5EkA4KqhAeT3CIGgK7YIAILJlEgeLXSFj21KsnviwGAUtlwDwA01Q2933DvCQuUo/jrcWUSG+6B2hgYPPPgmQ337rW6oDU1nek+WeBeawGuVkMq5FnVfjN92eNFdz8kxr2Mvq00p9vTmbXN0gsO6vxasiZZzYxOmBNQqzmaTPLnSa7MjrfcLA6oqNFzH0xy88zX7+bEdx2SZHWSn5z5OiXJocbOIv1HRs/5thgAOmz4yqOSvNbaB7UCPahWPbVaDQEomQ33AEBT3dDOb1bTU7UPkAdv9FZNr8cVSf5OdYEa+R9JniQGFmZqZusjdNQdSf6vGKiQNSJo9NqxAjw3akittsmPDnlJkkExALRt/v7GzIfMXZkdb/mq/KBmRs+9P8knZr5+Kye+6/AkPzyz+f5nZv7+aIFWxjrVGgqgO34tyRFiMH+LwgvERUJPPSPLNx+RW0+/TxQAlMiGewCgqf49ydeTPK63L8PDnOpQK1n01AoRADVzhjmru0o/5b67Jwa712Je3jM5dqn2pEqcCGDOwvxdAptFqPhassHjRVdfnrFT39LD2D+f5NIkf5gdb7lX2NAQo+d+J8nHZr5+Mye+67gkL5r5enGS44RkDQVQW8NXtpL8uiCw/katqEdbVLoH+5I8N8m/aBoASmTDPQDQSBPjI1NHP+nUjyf5hXZ9TyejzeaBIvq2zWy4B2pjYPDMwZlTCaENnHLvXqujvptkRO2omFOMF3NX/rMcz1eobA9ulx1tH7OXXvBka8l5ZjZzFWP+Rq1muTXJ7yT5s+x4y249AA03eu5Xkrwvyfty4rtaSVbObLx/cZLnJ+k3dnaNDfcAnffCJMPWPqAHUSuKsMaGewBKZcM9ANBkN7Rzwz1N4IFiVbKo4QdgPHXR4rVH33PXeyf0HlADv2aHNHvixGD3nQX6s8mxS78hBqqif8l5i5IslwTmOXpsdGrnReZPOuFXrCUN02gMDrhWO5JclORPsuMtHr8Ae7iLP3c6yS0zX7+dE9+1KMlPJPmZJD+b5HjzXMfck+Q2TQjQcRtEYP4WBYJXK21RjJNFAECpbLgHAJrshjJehicsUI6ir8eVST6uRkCVDQye2ZfkNGN7b7SmpjPdJwvca83DVWpGxZxcn42IZY8X3f2QGPcy+rZynG5Pp7zWeHEA68DiT7k3dqIHO/zyPp/kt5L8UXa85QH1BuZs9Nx7kvz9zFdy4rtOSvLSJC9LplcnLRN4O9dQo+f4MBSAThq+8vjvzWFgnQoYLwqxWv0AKJVPgAcAGmtifOS2JHe183u2puX6A8Kgt2p4Pa5QVaAGXlT/k3DoPu9FpCO2To5deosYqBhvTLB2rBDB17hWW2VG28fqpReclOQ5ksA8B3PuwW8kOSvJidnxlmtttgcWbPTcz2T03Hdk9NxTkjwpyalJ/jbJfebvBfOhZQCd9yZ7JqxT0YOoFUVZmuWbjxUDACVywj0A0HQfT/IrYmDufIqsLHrGhnugDk43Z/VW6afc99k+r2/LcbUIqCAb7s1ZmL9LYLMInfDa+v1KtT9V29hpnqM3se9OclWS38qOt3xLeEBHjJ775SRbkmzJiRcfmuQnZ04NflmSQQFZQwEUZfjKQ5OcJggLJlEgeLXqWq20xVydnOQjYgCgNDbcAwBN97EyNtx7wgLlKPZ6tOEeqLSBwTOfmOTlkqAzphxM4V6rnb6a5C/Uigo6xXhxYFrTyXRLFtCGHrw/yaflRVvH6KVvO8iH5i4wQ+dSmb9pSq3+Jsm52XH+qJoCXTO6cTLJ/535WpcTL35ekp9P8otJhgU0J9tEANDR+/1XJq3Hy8E6Va1AD6pVcVbbcA9AiWy4BwCa7uPt/oblv0m7mzx4o7dqdj0+c9Hitf333PXe3SoLVNTrPYsC99MVsXly7NL7xUCV9C85d3GSJ0sC8xw99umpnRdNioE2e2Ey/STjhWEajcFefS7Juuw4/3pRAD03uvGTST6Z5PycePEzkvxCkldU54PFuz7PfSGj54xrHICO2iAC61RReIGgB4u0RgQAlMixTwBAo02Mj+xMsqOMV+OMmepQK1n0xMFJnikGoIoGBs9sJTndnFWG1lTZWXhgSY89mOS9YqCCTqnnr2XOci+jbytmu/rTAa8zXrRhHSgLqHYP7vnlTSa5IMlzbLYHijS68b8yunFTRjeuTHJiko1Oc3+UrSIA6KDhK55rMx/WqagV9W+LyvbgyRoFgBJ5/yoAQIdOuechwkDfttFKtQEq6ieTnCAGOmtKBO612uGDk2OXjqkRFbRaBAvjWQ60Zf62WYT2js1L33Zkkp+vwD0kVHHtQ7X9Y5JnZcf5v5Ud50+KAyje6MYdGd14SUY3npJkcZKzZt6nUeBk2dWX5EPLADrrTGsz61T0IGpFsY7L8s3HiwGA0hwsAgCAfCzJG8XA/ExX4lwgWXxv08R0fUq1Qr8BFXWaCJiPPtvn3Xf2zlUioKLWGC8wz1EAm0Vot59PcoQYmjJMmxM0BnOI/Z4k/ys7zt8iEKCyRjd+McmVSa7MiRc/Ocmrkry6oScQ+9AygE4ZvuKYmfkF61RRIHh6UyttMRdrkjgQAYCiOOEeACC5sZyX4lMhwfW4TzbcA5UzMHjmsUleYWwvS2tKFrge9+C2JDeoDVXTv+Tcg5KcbLzojT5ZoFYP+cbUzov+W+1ps18wXrRxHaifoOrz90On2ttsD9TH6MYvZnTj782cfH9ikt9M8tmG/PYPJrlFEwB0zKlJDqvQ/b61D2qFHqSJtTpZ7QAojQ33AEDjTYyPfDnJf7b7+7Y8a5pFGPRWja5HG+6BKnp9kkPEQHdMiYCFeM/k2KUWL1TRM5z+a+1YbYKvSa1ukg9tHZOXvu3IJC82XmCeg9yXZH2SF2fH+U78AuprdOOOjG787YxufHaSZyW5KMkdNZ6/P5vRc+5TeIAOGL6iL8k6QVh/i8ILBD1YvNUiAKA0NtwDAHxPQacYephTHWoli647atHitUvFAFTMG81ZZSr9lHsPLvVtl92b5I/EQEWdYrwwZ2H+LsA2NafNXvrwk+iMF814ee5l9C2P8Jkkz80d51+TO84XOtAcoxv/M6Mb35rRjSfMbMC4LMkXraEAmKP/kcR7a7D+Rq1oWFtUsgdPzvLN/tQKQFFMTAAA39ORDfdORptNGOjbNlmpLkBVDAye+SNJlkuC7nLKvXutA/K+ybFL71YTKqoBn/zfvfGi5eQXONAetFmEdnulCDowz4nA/E2VanV1klNyx/mfUxeg0UY33pTRjWcneUqSFyd5f5Lv1OA32664AB2z3trMOhU9iFpRCUcmeboYACjJwSIAAEiS/NPMzhwfSMQ8TXubYkWyaE0n0/Uo1Yokf63fgIo4XQQsRJ/t8+47u+cqEVBha4wXmOcogM0itE1r6duOTPIS44VhGo3RUN9K8sbccb6/AwDMNrpxKslHk3w0J158VJJfTPL6JD9a0Xluq6ICdMDwFSck+RlBWKeKQhRQzEXietyfVUn+SwwAlMKGMgCAJBPjI99M8qlyXpFPhQTX416tUBOgCgYGz3zMzBvejO0Fa03JAtdjkn+aHLv0P9WCKupfcu4RSZ5pvOi9PlnQ7FrtmNp50dfUmzZ6aZLDjBcdWgfKAkruwf9McrLN9gD7Mbrx7oxuHMnoxh9LMpTkgiQ7KvQb3JvkVoUE6Ih1tjVinYpaoQcrZbW6AVASG+4BAH7g+k5805ZnaLMIg96qyfVowz1QFa9LcrgY6I0pETAfTrenyk72tx5rx/oQfIVr5XR72u2VxgvMczTQ3yY5JXecv0MUAPMwuvHOjG78rSRPS/IjSTYnubvw+Xt7Rs/xEBug3YavGEjya9Zm1qnoQdSKSlklAgBK4k1YAAA/cKMIODAeKMqiq56yaPHaY8QAVMBp5qxqKP2Uew8w9W2HfXFmUwNU1RrjhTkL83cBtqkzbVufLH3bEUleYrxo+stzL6NvG+fCJK/IHeffKwqAAzS6cTqjGz+R0Y1nJHlikl9J8k+FvlofWgbQGa9O8lgxWKciCsFTXK20xb6clOWbDxUDAKU4WAQAAN/3z0l2J+kv4+VMJ2mpCrge92RFkhvUBSjVwOCZq5M8RxJABe61/mBy7NIH1IAKW2286IzWdDLdkgXMsQdtuKedXpzkMDF0eJ7zHk/zN6XU6rtJXpc7zv9LmQO00ejG7yR5f5L358SLl818QPAbkjy+kFdoDQXQGWdam1mnqhXoQSpXq0Nm3mN2k9oBUAKHbQAAzJgYH/l2pz5JvOWda7MIg96qyfW4QiWBwq0VAb03JQL2Z3eS94qBijvF+pt60bcVnU8/JQba6OXGC8M0GqMhvpnkp222B+iw0Y2fy+jGc5MMJvnFJP84v8mrI/OcDfcA7TZ8xQ95Lw3WqVWMQq3QgyTN+5B5AEpmwz0AwMN9rKyX42FOdaiVLLpqpQiAUg0MnrkoyavMWdXSmio7Cw8x9W2H/PXk2KVfEgNV1b/k3CcnWSwJcxbm7x779NTOiybVmLasS5a+rS/JS4wXXcpbFtDLHhxL8sO54/xPyBmgS0Y33p/RjX+V0Y0vSjKU5KIk4z14JV/I6DnjCgLQdutFgHUqaoW2qGwPrtIgAJTC+34AAB7u4536xk65n00Y6NsF8qncQMlek+RIMVAGp9y719qnq+ROxa0xXnRWy8kvMJcevEkOtNHqJI8XA+5lqLnPJvmh3HH+raIA6JHRjTszuvGtSZ6S5OVJPrTvh8ltnb+3KgBAmw1fcdz8PxDe2kwW6EHUioLYcA9AMWy4BwB4uP+X5Dti4MB4oFiVLGrwARjLFy1ee6g+Awp1hgjoBA8y3Xe22b9Pjl3qJEGqbg4b7o0XmOfoOJtFaKeXGi8M02iMmvtskp/MHed/URQABRjd+GBGN34woxtflmRpkt9O8tUO/9Ttggdou9OT9IsB61RRCJ7ia6Ut9mZ5lm9eJAYASuB9qgAAs0yMj9yf5F/LelWesIDr8VEOSvIs9QBKMzB45ookzzO2V1NrShY06np0uj11sKa5v3rZc1afLGhWrWwWoZ1eKoLujhctWUA3e3B7kh/JHed/Va4ABRrdOJbRjb85c+r96zu41vGhZQDtNHzFwUneZM1p/a1WoAepdK1aSU5WMwBKYMM9AMCjXd+pb9zyrGkWYdBbNbgeV6giUCCn21OgKRHwSBNJ3i8Gqqx/ybkHedOBtWO9Cb4ivpVMf04MtGW8Xfq2pyQ5yXiBeY6a2p7kRbnj/G+JAqBwoxsnM7rxTzK6cU2S1Un+OMlkm+bvB5PcImSAtnpZkkExYP1d9SjUCj1IVokAgBLYcA8A8Gg3lPeSPMypDrWSRdesFAFQkoHBMweSvNacVW2ln3LvYaa+bZMtk2OX3icGKm55kiONF+YszN89tn1q5zsMMrTLz4qgQuPFtCxQq3n495nN9hOiAKiY0Y03ZXTjG2Y2cv5Gkl0L/I6fzeg5nksCtNcGEWD9jVqhLWrRgzbcA1AE7/cBAHi0Tya5u1Pf3MloswkDfbsATrgHSvOqJIvEQJmccu9e62GukTM1sEYE3VubtZz8AnuzXQS00ctE0BstEZi/6WStRpP8lM32ABU3uvFrGd34O0lOSPJzSf7xAL/TNmECtNHwFcuT/KS1mXUqYLygFlaLAIAS2HAPAPAIE+MjDyb5J0lw4DxQrEoWFf8AjJMWLV7r/bBASc4QAd3ggab7zgX6h8mxS/9bDNTAPN9wYLzAPEdHbBUB7dBa+rbDF/YGeeOFYRqNUaS7kvxk7jj/q6IAqInRcx7M6Dl/l9FzXpTkmUmuTfLdeXwHH1oG0F6/LgKsU+sUhVqhBxvu+CzffJwYAOg1708FANizG8p7SR7mgOvxYY6cOUUBoOcGBs98ZpIfMrbXQ2tKFtT6enS6PXXhhPsKzN99sqD+tbJZhHZ5QZLDxNC78aIlC2h3D04k+enccf7nZQdQU6Pn/FdGzzk9yZIkb08ylw9Y8aFlAO0yfMWiJG8QBNapqBXaolY9uEpzANBrNtwDAOzZ9Z385i3P0GYRBizAChEAhThdBJRvSgTsSvIhMVB1/UvOPSLJsyTRXZ7l9IrgC3bH1M53OLGXdvlp4wXmOWrkgSS/mDvOv1UUAA0wes5XMnrOhUmOT3JGkr2N//fu438DYP5em2SRtZl1KnoQtaJWfOg8AD1nwz0AwJ59NsnXxMCB80CxKllUfNOEDfdAzw0MnnlYkl+VBN3koab7zgP0nsmxS33yAnXw3CQHGS/MWZi/e8zp9rTTC0VQ0fHCSUyo1Z5syB3nf0wfADTM6Dnfzeg5m5M8M8lL9nDIw/aMnuPZJED7rBcB1qmiEDyVrpW22BMn3APQc97nAwCwBxPjI9NJbijvlXnCAq7Hh1mpDkABXpHkscb2emlNyYLaXY+TSf5QrtTEKSLozfxd/ge2mb/pKhvuac/YuvRtj/OMq5BaiMD8TTtq9Xu54/z3ygqgwUbPmc7oOf83o+f8VJKTkvxxkt3WUABtNHzFj898wIm1mXWqWoEepF61OlmtAOg1G+4BAPbuxk5+85ZnTbMIg96q8PXohHugBGeIgOpwgFCDfWBy7NKviYGaWC0CmsVzo0JtEwFt8hPt2+ttvDBMozF66l+SbFR7AL5v9Jx/z+g5b0jyVB8GCtBWTrfHOrXWUagVerDBjs3yzUNiAKCXDhYBAMBefazMlzXtrJnKUCtZdNyTFy1e+/h77nrvV0UB9MLA4JnLkvyYOaueWlPTme4rN4s+2+f17fxcLQJqZAEn3BsvzFmYv9vigSSfUkPa5KdFUM540Sr+7aTuZSi2B7+c5NW54/wHZEQlO3vaZgLosC9+71/OlgTAQg1fsTjJzwsC9rtORa3QFlXtwVVJ7tAcAPSKE+4BAPZiYnxkNMldnfwZTrmfTRjo2wPklHugl04TAdVjy2MD77W2T45depM8qYP+Jec+KcmgJHq3Nms5+QWS5DNTO9/xHTHQJi8UAZi/K24qyWtyx/lfFAUAAHTcGUkOsjazTkUPolbU1ioRANBLNtwDAOzbx0TAwnigWJUsKvwBGDbcAz0xMLjhkGT6DZKglzzcdN85R9eIgBpZY7zAPEcBtouAdmgtfdtTk5xgvDBMozEq7qLccf6N6g0AAB02fMUhMxvuwTpVFIKnPrXSFo+0WgQA9JL3pAIA7Fuhb5DxhAVcj99nwz3QKy9P8nhje721pmRB5a/HryX5czlSI2tEUM35u08W1KtW29SONvkpEZQ3XrRkAfPpwZuTbJIJAAB0xSuSPNGa0/obtUIPUutaPS/LNx+kVgD0ig33AAD7dn2nf0DLs6ZZhEFvVfR6XKlyQI+cYf6muqZE0Bx/ODl26XfFQI34RH9rxwYTfEFsuKddftx4Afq2wr6b5HW54/wHRAEAAF2xTgRYfzcpCrVCDzbUQJLlYgCgV2y4BwDYh4nxkS8kGS3z1XmYUx1qJYuOGl60eO3hYgC6aWBww1D9TyI0Zz2k9FPuPeDUt/swleT3xUBd9C85ty/JKuNFdZmzqMn1OJHkdnWjTX5YBDUaL6ZlQeNq9Ru54/zb1BgAALpg+IqTkvyIIIDq81yLXrdFJXrQh9AD0DPe2wMAsH9Oue8qYaBvD2Bd92w1ALrs1CQtMVBtTrlvwL3WhybHLt0pP2rk6UkWiaGMtVnLyS801/apne/QYCx8HF36ticneaokCq2PCMzf7K9WNyW5Qg4AANA1XTzd3tpMFmoFepAes+EegJ6x4R4AYP9uEAG0U9kPVyv6ARgr9BXQLQODGw6e2XBfmbGd+vOQ0/W4F9eIgJpZY7wAfVuA7SKgTTp8Kp3xwjCNxuiYqSRvyh3n+yQ/AADohuErHpPktYLAOrWJUagVerChThYBAL3ivagAAPt3Y7kvzcOc6lArOsqGe6CbXprkSebvZmlNyYLKXY//neSjcqNm1oig+vN3nyyofq22qRdt8sMiKHu8aMkC9uaq3PHWW8QAAABd84YkA2KA/fGsRK3QFrXpwZOyfPNhmgKAXrDhHgBgPybGR76a5D86/XNanqHNIgz07TzZcA900xtFQH04jK7Grpkcu9TCgrqx4b4wnuU0cv2NE+5pnxcYL0DfVtCXk7xVDAAA0CXDV7SSrLM2s05FD6JWNMrB3hMLQK/YcA8AMDc3iICF80CxKllUcNPESYsWr7W+AzpuYHDDU5K8xDxHiUyErsdZvp1kiz6gTvqXnDuQ5NnGC3MW5u8e2zW18x1fVisWqrX0bUcmOUkSNR0vnMREvWv19tzx1rvVEwAAuuZFSZ4mBqxTRSF4GlErbTHbKhEA0Ave0wMAMDfXl/vSPGEB12MG/IER6JJTm/c8yb3WQ1pTsqAy1+P7JscunZAXNfPcJAeJwfwtC3psmwhok+d7r0JF1oEiMH8z238n2SwGAADoqnW9+9HWZrJQK9CDatVDq9UIgF7wR2wAgLn55yRTnf4hLc+aZhEGvVXB63GFqgGdNDC4oW9mw735m5qZEkH9XC0CaugUEVg74r6zANtFQJv8sPHCMI3GqKDfyB1vfUAdAQCgS4aveGqSlwoC61RRqBV6sJGccA9AT9hwDwAwBxPjIxNJbi73FXqYUx1qJYuOseEe6LSfSXK8OavZSj/l3sNOfZvkXybHLv139aeGOvgJ/uY5cxbm7znbqka0yfNFYP6WBRXzqSR/LQYAAOiqN3mUCgfCsxK1QlvUogeXZfnmozUEAN1mEQoAMHc3duOHOBltNmGgb+fBhnug004TAfXllPsa3WtdIyNqao0Iyl2btZz8QjM8mOQWMdAmzxNBdbREYP4mSd6ZO96qKAAA0C3DVxyW5I3WZtapoAfVisZqOeUegF6w4R4AYO4+JgLawwPFqmRRsQ/AWKmfgE4ZGNzwxCQvM89RBR54Nvp6/FKSv1J36qZ/yblPTHK88QL0bY99ZmrnO74jBhaqtfRtT0vyWOOFYRqNUSG3Ot0eAAC67peSHCsGrFNFIXgaWStt8ZCTRQBAt3n/KQDA3P2/JPeX+/I8YYGGX49PWLR47RNlD3TIqUkONraTJK0pWVDs9fgHk2OX7pYPNbRaBPWcv/tkQbVqtV1taBOn21dwvGjJgma7OHe8dUoMAADQVetEAAvhWQl6kFrUyt/JAeg6G+4BAOZoYnzk20n+rRs/q+VZ0yzCoLcqdj2uUDGg3QYGN7RmNtybv6k5752vuAeSvFcM1NQaEVg74r6zANtEQJv0aMO98QLzHAfkq0n+VAwAANBFw1esKmuDnbWZLNCDoAd7xIZ7ALrOhnsAgPm5seyX52FOdaiVLDrChnugE34yyQliMGfNVvop9x56NrJv/3Zy7NIvqjc11aU3EpjnzFmYv/fJCfe0ixPumzR/T8uCytfqD3PHW+9XMwAA6Kr1IsA6VRSCR1uIIMniLN/8RDEA0E3exwMAMD/XiwCYm5488bThHuiEM0RAczjlvsL3WlfJhDrqX3Jun0/ur87arPxT7r0zhwN2T5LbxMCCx8mlb2vZcF/h+onA/N3M8N8rBgAA6KLhKx6X5NXWZtapqBV6ELWa4W/lAHSVDfcAAPOzPcm3u/GDWp41zSIMeqtC16MN90BbDQxuODbJz5m/qSIPPht1Pf7n5Nil/6TO1NRwkqOMF6Bve2z71M53+GQi2uHE7s5rxgvDNBpjQT6SO966U60AAKCrTktyqBiwThWFWqEHmbFGBAB0k/edAgDMw8T4yP1J/qXsV+lhTnWolSza7mmLFq89QgxAG70+ySFiMGftSWtKFhRzPTrdnjrzBoIGzN99sqD8Wm1XD9rE6fYVHy9asqBZrhMBAAB00fAVfUneJAhoJ89K1AptUfkePFkjANBNNtwDAMzfDd36QU65n00Y6Ns5rvGeI3egjc4QAc3j8NaKuSfJ+8RAjdlwXzGe5TRm/d0020RAmxTwxjjjBeY55uS+JB8UAwAAdHXp87NJnmptZp0KelCtYJZVIgCgm2y4BwCYvxtEQPt4oFiVLCq0aWKFXgLaYWBww48kWWaeo8o8/GzE9bhlcuzSe9WXGlttvADzdwFsuKddniuChs7fTmKierX6UO54q7UmAAB013oRYJ0qCsGjVtriER6b5ZufpucA6BbvOQUAmL9PJflm2S/RExZo8PVowz3QLk63d6+1X60pWdDz6/E9MqCu+pece3iSkyTRjPm7TxaUa2xq5zu+JAba5BkiqME6UATuZZrhAyIAAIAuWnbF05K8yNrMOhW1Qg+iVntwstoA0C023AMAzNPE+MiDSf65Wz+v5VnTLMKgtypyPdpwDyzYwOCGxyR5pfmb5poSQTVcPzl22W1ioMaem+QgMVg74r6zx5xuT3vGxqVvOzbJE4wXQAXsTnK9GAAAoKvWJWlZstN7mrA6UagVerBBVosAgG6x4R4A4MBU4I02HuZUh1rJoq2evWjxWptygIV6XZJDxWDOmovST7n3ALTWfXuVmlJzpxgvmsWcRaHX43Y1oE2eJYKGz9/TsqAytfpE7njrPWoDAABdsuyKgSRvEAQ0bv2NWlFkWxTZgzbcA9A13rsDAHBgbuzmD3My2mzCQN/ux+FJhmUOLNAZIgCn3Bfu80k+KAZqzhsHKrw2azn5hfpwwj3t8kwR1EdLBObvevuwCAAAoKt+JcljqrP0sTaTBXoQtaLLVmb55oPFAEA32HAPAHBg/jPJl8VA+3igWJUsKvIBGCv0EXCgBgY3rGn/yYPmOXrLQ9BaXo/vmRy77EH1pObWGC9A3/bYg0luEQNt8mzjBWKnIo3xMTUBAICuWi8CrFNFgeDVSlvsw+E+1BeAbvFeUwCAAzAxPjLd7VPuD4wHb9DQ69GGe2AhnG7vXmveWlOyoKvuT/KHYqDO+pece1ySJZJo3vzdJwvKqtVnp3a+4z750ybPEEG9xouWLKine5P8hxgAAKBLll3xw0lOEgR0g2clQKXHi9XqAkA32HAPAHDgru/mD2t53jmLMOitClyPNtwDB2RgcMNRSV5t/oaHTImgTH8+OXbZV8RAzXnDgLUj7jtLsE0EtNGzy3tJxgvMczzK1tzx1gfFAAAAXbOhmksfazNZoAdRK7pslQgA6AYb7gEADtyNIqC9PFCURdvYcA8cqFcnGRCDOetAlH7KvQehterba9SQBjjFeNFc5iwKuh63y522rBWWvm1xksdIwvzd/ZfnXkbfztu/qQUAAHTJsiuekOQXBIF1qigQvFppiznwgfUAdIX37AAAHKCJ8ZEdSXaV/0o9eIMGXo+PX7R47ZPlDRyAtSKAR3LKfWFumRy7bKsYaABvGKjH2qwCp9x7bsQ+mXNpl2eIoJ5aIjB/13DNKQIAAOiatUn6rc2sU1Er9CBqNQfPyvLNh6sLAJ1mwz0AwMJ09ZT7lmdNswiD3qrA9bhSlYD5GBjc8NwkzzV/U2cehtbierxK7ai7/iXntsracG/+xjzXUPcmuVUMtMnTjReInYo0xn+qAwAAdMGyKw5Ocoa1I9apolArXCTM0UGdf18bAHiPKQDAQl1fjZfpYU51qJUs2maFCIB5Ok0E5qyFak3Jgo76RpIPiIEGGE5ytBiaPX/3yYLe12r71M53TMmcNhkSQX3Hi5YsqI/JJHeIAQAAuuJ/JlksBugFz0rUCm1R2R5cpQEA6DQb7gEAFubGbv9Ap9zPJgz07T7YcA/M2cDghiOSvFYSsDf2mhViZHLssu+IgQZYI4J68Syn9uvvutouAtroROMF6NsKuC13vPVBMQAAQFdsqMfSx9pMFizQt/Wg8QLmwYZ7ADrOhnsAgAWYGB+5K8ntkqC9PFCsShaFb5qw4R6Yj19KssjYThN4IFrZ63E6yXvUjIZYU+YlCDTMNhHQRk8Tgfm7ty/PvYy+nZOd8gcAgC5YdsUzkvy4ILBOFUWSSwWrB9VKW8zDan0GQKd5fykAwMJdX42X6cEbNOx6PGHR4rWLZA3M0WkicK/VLq0pWdARH54cu+wOMdAQ3ihg/k66/kc887e+fRQn3NOe9cHSt/UlWSqJmtdZBNTDXSIAAICuWF+vX8ezVVmo1QG6Jckfq4UeRK3m4cQs33yMmgDQSTbcAwAs3I3d/oEtz5pmEQa9VfD12EryHBUC9mdgcMOzk/yQ+Rv2Z0oEvXW1CGiC/iXnHp7kJElYO+K+s8fumtr5ji+KgTZ5SpJDjBegbyvg8yIAAIAOW3bFoiS/aumD9bcoklyX29btSPINtcJFwjycLAIAOsmGewCAhbuxOk9JPMypDrWSRVusFAEwB063N2e1Xemn3HsoWrm+3ZHkH9SKBt3DH2y8wJxFj6/HrTKmjU4Ugfm7jJfnXkbf7pcPmwEAgM7f778+yZFygEavv5PkwSR/NvPvb1KLomuFtiitB1cpPgCd5H06AAALNDE+8vUk/97tn+tktNmEgb7dixVyBvZlYHDDYUleJwmYK6fc98g1k2OXCZ+mWCOCWq7Nkko8y/F8he/bLgLayIb7hmiJwPxdfXeLAAAAOmjZ5a0k66zNrFMhyUdz27ovz/z7m/Sg8QLmYbUIAOgkG+4BANrjehHQfh4oViWLgjdN2HAP7M8rkzzW2E4TeTBamevxO0m2qBENUvgbBMzfmOcaYpsIaKMKbbg3XoidhjfGt+QOAAAd9eNJlls7Yp0qiiTvm/XvfQAsLhJD03w44R6AjvK+UgCA9rixOi/Vw19o0PX4rEWL1x4sZ2Af3igC91qd0pqSBW3x/smxy74pBhrEJ/Kbvx+lTxZ0t1ZTSW6WL210ggiaM8+1ZEG13SsCAADoqDOtzaA0Pbke703yt7P+803qUGytoMQefFKWb16sHgB0ig33AADt8fEkD3b7h7Y8Q5tFGPRWodfjoUmerjrAngwMbhhO8mPmb5ivKRF019UioCn6l5z7+CRDkrB2xH1nj312auc77hMDbfQU4wXo24p4QAQAANAhyy4fTPLyei99rM1kwRz9VW5b9+3v/6fb1n0pyRf0oPEC5mGNCADoFBvuAQDaYGJ85F6ftElneKAoiwVbIQJgL04XgTmr00o/5d7D0eL79v9Njl32KbWhQSpyur15zpxFza/HbXKlzZ4iAvN3WS/PvYy+BQAAemBtkoPc72OdKook1+3hv/NcWg+qlbaYj1V6DIBO8f4cAID2ub46L9WDN2jQ9bhSxsAjDQxuOCTJr0oCDpRT7rvE6fY0zSkiqPXa7PtaTmKibNtFQNvGu6VvOyTJEyTRsLqLwPwNAAAw27LLD0lyhrWZdSpqleSuJDfu4b+/WR30IGo1DyerBQCdYsM9AED73NiLH9ryrGkWYdBbhV6PTrgH9uTnkjze/A0U7CtJ/lIMNMzq6rxU8zdVpG/naKsIaKMnGy8QOxoDAAAa7xeSHGeJgHWqKJK8P7et29On229XK1wkzMPqLN/ss18B6Agb7gEA2udfk0xW5+V6mKNWsmgIG+6BPTldBOasbmlNlZ2FB6TF9u3mybHL7lcTmqJ/ybmtam24x5xFTefv+5LcKlPaaLEImnm/35IF1bRIBAAA0BEbrM2gdF27Hq/by39/s0GhuFqhLUruwaOSLFN4ADrBe3MAANpkYnzku0n+rRc/2yn3swkDffsIxyxavPYpMgYeMjC4YSjJCyUBCzUlgs55MMnvi4GGWZbkMWKo9drsYcp/luP5SkPdPLXzHQ+KgTaq8DMp4yD6toGOFAEAALTZsstXJHl+s5Y+1mayYC8+k9vW/cce/5fb1t2d5HN60HgB87BKBAB0gg33AADtdb0I6AwPFKuSRaGbJpxyD8x2WnmHzZnn6C0PSYu7Hv9+cuyyL6gFDVPB0+3N35jnamibCGgzHwKJYZoqNcbRsgYAgLbbYCGIdaooZly3n/99u0D1oFppi3lYrb8A6ATvJQUAaK8bqvVyPXiDhlyPK+UL5Hun2x+c5A2ScK/Vba0pWTAvV4qABjpFBObvueiTBZ2tlTc00m6DImjuPNeSBdXzZBEAAEAbLbv8sUl+2fq76WShVkmSqSTv388/4/m0HhSBWs2HDfcAdIQN9wAA7bU9yX29+MEtz5pmEQa9VeD16IR74CEvTfIk8ze0y5QI2u/WJB8XAw3kDQHWjrjvLMFWEdBmFd9wb7xA3zbME0UAAABt9YYkh1v6YP0tiiTX57Z14/v5Z25WK4wXzMNJWb65XwwAtJsN9wAAbTQxPvJAkn+q1qv2MEetZNEANtwDDzlDBOasXin9lHsPSovp26snxy5z4dAo/UvOPbS69+wuV3MWNboevzi18x13yZE2c8K9+bvwl+deRt8+zBI5AwBAmyy7vC/JemszsP6ecd0c/plPJXlADXpeK7RFVXrwsCTPVnQA2s17cgAA2u/GXv1gJ6PNJgz07SxLFy1ee7R8odkGBjc8JcmLJQHt5pT7Nro3yZ+IgQZameRgMTRibfYo5T/L8XylQZxuTyc8TgTN1hKB+btaniYCAABomxclOcHaDFmQ5L4kf7Pff+q2dZNJPi0u4wXMw2oRANBuNtwDALTf9SKgczxQrEoWBW6aOEnPQOO9sfxnQeY5esvD0p5fj38yOXbZPbKngdYYL0DfFmC7COiAJxgvEDsVaoxlMgYAgLZZ3/GfYO1I/depdYnib3Lbunvn+J1uViuMF8zDKhEA0G7eQwoA0H6fSfLNar1kD3OgAdfjCtlCcw0Mbuib2XCPe62eak3Jgn26WgQ01BoRmL/nq08WtL9W2+RHW+/9l77t0CRHSsI815IF1XFEhjYtEQMAACzQssuXJvlZazOoqrZfj9fN45+9Sf7GTqrUFj3vQSfcA9B2NtwDALTZxPjIVJIbevXzW56hzSIMmMWGe2i2n0kyaP6GTpkSwcJ9fHLssv8SAw3ljQAN51mO+85CbmZuFgNtdqzxAvRtBT1PBAAAsGC/3rXPXyt+6WNtJovG+1KS6+fxz2/Tg6gV8/CMLN98hBgAaCcb7gEAOuPjIqBzPFCsShaFbZpYqV+g0c4QAcXMj1NODHavtUdXypsm6l9y7rFJTjBeYM6ix9fjrVM733Gv7Gizx4vA/F2dl+deRt9+nw33AACwEMsuPyzJG63NsE4VxYz357Z1D87ju9yW5D5h6kG10hZz1JfkuXoLgHZPLgAAtN/HqveSPXiDml+Pz1y0eG2/bKF5BgY3PDHJSyXhXgsKdleSvxcDDeV0e/N3UolT7t3L1NxWEdABNtzzg3lOBObv6lgjAgAAWJBXJzlGDNZmslCrGdfN65/+3ub8W+SP8UKt5sHf2wFoKxvuAQA6YGJ85LYkX+rVz2951jSLMOitgq7H/iTPUBFopFOTHGT+hk6bEsGBe+/k2GUPiIGGsqEH3HeWYLsI6IBjjReInQo2xvMztOkQGQMAwAHbYO2IdaooZnw2t6379AF8l21qhfGCeVglAgDayYZ7AIDOub56L9nDHLWSRc2tEAE0y8Dghr4kp0nCnFWa1lTZWXho2tW+3Z3kD+RMg9Vow715zpxFha/HbTKjAx4nAvP3w9aBsqAaDncqFgAAHKBll69J8jxrM6iLBV+P1x3g/+9m2Rs7qVpb9LQHPcsDoK28DwcAoHNu7OUPd8r9bMJA386w4R6a5yeSLBUDdItT7g/AX06OXfZlMdBE/UvObXkDQGPXZntU/rMcz1dq6ttJPisGOuCJIgDzd0W9SAQAAHBA1ln6WJvJglmFfv8B/n+360HUinlYmuWbjxUDAO1iwz0AQOdcLwI6ywPFqmRR0KaJlXoFGmetsR0OjAenXbser5YvDfa0JI81XoC+7bGbp3a+40F9QAccY7xA7FS0MV4uXwAAmKdllz8+yastBLFOZSaKG3Pbui8c0P//tnV3JvmaIPWgWmmLeThZXwHQLt43CgDQIRPjIzuT3Fm9V+7BG9T4enTCPTTIwOCGxyf5OUm41ypVa0oW5NOTY5f9qxhoMKfbm7/bok8WLKxW22RFh3pwkQzMc49aB8qCajgpQ5uWiAEAAObljUkOEYM1pyzUasZ1C/zBN8ke44VazYO/uwPQNjbcAwB01g29/OEtz5pmEQa9Vcj1ePSixWufqhrQGL+apN/8Dd02JYK5c7o9TV+nrpEBha4dm3g9NvmX367+dEhNN9wbqNG3DfELIgAAgDladvlBSX7d0gc04YzvZDp/tcDvcZNaYbxgHmy4B6BtbLgHAOisG6r5sj3MUStZ1JhT7qEBBgY3tJKcIQlzVulKP+Xew9OO9u23krxfrjRcTf/wb54zZ1Gx63GrnOiQo0Vg/q7my3Mvo2+TJK+VLwAAzNlLkxxvbQbM+Nvcvu6eBX4PHxRr7KSSbdGzHlyl0AC0i/ffAAB0Vs833DsZbTZhoG9tuIfG+JEky8QAveKU+znYMjl22bfFQFP1L9l46Pfuza1TG7w226vyn+Xo2xoZn9r5ji+IgQ5ZZLxgj/OcCMzf1bAyQ5uWiwEAAOZkvQiszWShVrO8rw0/9Ca5Y7xgHo7L8s3HiwGAdrDhHoBqLJWnp3356tnXQkyMj3wpyX+5iunwKCmCimRRyKYJG+6hGU43tkN7eIDaketxOsk18qThViQ5xHgB+rbHnBJEJx1pvEDsVLwxTpMvAADsx7LLlyX5aWtH0IQzvpLkowv+Lret+0qSMbXCeME8rBEBAO3g/aIAAJ13YzVftoc5UFMrRQD1NjC44Zgkr5SEe62qaE3JooH+YXLsslEx0HCrRWD+brc+WTD/Wm2TDx20yHhhntvrOlAWVMMbMrTpMDEAAMA+rbM2gyaY8/X4Z7l93QNt+qE+MNbYSSXbomc9eLJCA9AONtwDAHTe9b1+AS3P0GYRBo3v2+MXLV77WJlCrb02yaFigF6bEsHeXS0CyCnWqeyLZzm1WH9XgTcs0klH1vvXM1CjbxvgmCSvEgMAAOzFssuPSPJrlj7WZrJgluva+L1u0oOoFfOwSgQAtIMN9wAAnfdPnvbQeVqsKlkUsmlihT6BWjvd2A7t5SFqW6/HnUk+LEdowgn35m9zFoVfj9M23NNhR4nA/F3tl+deRt8mSc7O0KaWjAEAYI9e2/n1v7UZ1qkVcmtuX/fJNn4/z6/1oFppi/lYleWb/akUgAUzmQAAdNjE+Mg3ktxSzVfvwRvU9Hq04R5qamBw/fOT6WdJwr1W1bSmZNEg10yOXTYlBpqsf8nGxyU5URLmb1nQY7dO7XzHPWKgI/f3S996lPGC/faJCMzf1fCcJC8SAwAA7NE6EVibyUKtZnlfm3/gJzUIxgu1mocjkzxd9gAslA33AADd8fFev4CWZ02zCIPGX4823EN9vdH8DSWxr/wRvptkRAywp9PtzXMUuXZsqMYEv1Wt6aAjjReInRo1xm/IFwAAHmHZ5T868wFV1o6gCR/6hf+0rd/xtnX3JLlVrTBeMA+rRADAQtlwDwDQHR+r7kv3MEetZFFDK0UA9TMwuP6oJK+WhDmrqko/5d6D1Lb07Qcmxy77uvwga4wXmLMo4HrcLhM66BARmL9lQY38WIY2/bgYAADgYbp4ur21GZRjr9fjP+f2dbs68ANvkrmxk6q2RU96cLUiA7BQ3nMDANAdn0jyQK9fhJPRZhMGje7b5YsWrz1UnlA7v5JkwDwHpXHK/SxXiQCSvW+4N383cG22X+U/y9G3FbZNBHRy+DJecICNgvm7VL8tAgAAmLHs8icl+QVLH2szWTDLdR36vjfpQdSKeXDCPQALZsM9AEAXTIyP3OtNrHSHB4pVyaLHmyYOTvJMPQK1c5qxHTrLw9QFXY/bJscu+6TcIGneJ+ubv9G3Bfp2ks+qMx10tPECsVOzxjglQ5teLmMAAEiSnDHzvhMLQdC3SfLdJH/Zoe+9XR/pQbXSFvNwUpZvPkQ/AbAQ3iMKANA9N1T3pXvwBjW8HlfIEupjYHD985I81/ztXqvqWlOyqLFrRABJ/5KNJyY5RhLm707rkwX7rtUtUzvf8YA8MHZSQq1asqA6Ls7Qpn4xAADQaMsu75/ZcI81pyzU6iF/n9vXTXToh/17kvtljvFCrebokCQnyR2AhbDhHgCge4rYcN/yrGkWYdDo69GGe6iX083fULKppgfw1SR/rg8g2f/p9uY5ils7Nlitg9+mvnTYwc36dQ3U6NuGWJZknRgAAGi4n0vyZEsfYJb3dew737ZuMslnDBg0gx5sk9UiAGAhbLgHAOierUm+U92X72GOWsmiZmy4h5oYGFx/RJJfloQ5qy5KP+XeA9UD6ts/nBy7bFJekCRZY7zAnEUB1+N2OdBhR4rA/F2vl+deRt9+329laNMT5QwAQIOtt04FfTvL15J8pMM/4yZ9pAfRFvOwSoEBWAjvtQEA6JKJ8ZHvJvl/kiiNB4o0tm9PWrR4bUuWUAuvTrLIPAelm2ryL/4e9Yfvm8OGe/N3w9Zmc1L+Kff6tmKccI/xgqJ4SOl6rJCjklwmBgAAGmnZ5c9K8mOCsDaTBbNq9YHcvm53h3+YD5DFeKFW82HDPQALYsM9AEB33VDCi2h51gTF6OH1eFSSIRWAWjiteb+ymxl6y0PVeV2PH5wcu2xMTpD0L9l4SJKVxgvQtz325amd79iltnTYocYLxE6NG+M1Gdr0YjkDANBA6yv5qq0d0YSddF0XfsZNaoXxgnlYnuWbF4kBgAPlvaEAAN11Q7Vfvoc5aiWLmlkhAqi2gcH1z05yiiTMWXXTmpJFjVwlAnjY/fchYjB/d1OfLHg0p9vTDYcbL8xz814HyoJq2ZyhTUeJAQCAxlh2+VFJXmdtBsy6Hj+X29d14/T525LcK29jJ1Vui67+sFaS5ykwAAfKhnsAgO66OcndJbwQp9zPJgwa27c23EP1nWGegyqZatovfHuS69Udvm+1dSoL4VlOpdffJbHhHowXoG8X7ilJLhUDAAAN8oYkR1j6WJvJglne15Wfctu6qZn33epB1Iq5Wi0CAA6UDfcAAF00MT7yQJJ/kQTd4YFiVbLo4aYJG+6hwgYG1x+W5LXGdugND1bndD2+Z3LsMhcr/MApIjAkmLMowHYRALWav6dlQc9qdVqGNr1M1gAA1N6yy1tJft06FfTtI7yviz/rJj2kB9VKW8zDKn0EwIHyHhsAgO77WLVfvgdvUKPr0YZ7qLZXJnmM+dvYXletKVlU3H1JtogBHsYn6Zu/ZUEJBbLhHuMF5a4DReB6rJ4tGdr0ZDEAAFBzL0zydDFYm8mCWT6R29ff2cWfZ8M9xgu1mg9/lwfggNlwDwDQfR8v5YW0PGuaRRg08nocXLR47bHSh8o6QwTmb6poqim/6Psmxy67W73he/qXbDwmydPMc1R07Uh9rsfbpna+0/wMxgtwPbbP45L8SYY2HSRvAABqbL0lAmjCR7iuyz9vu1phvGAejs/yzceJAYADYcM9AED3fSbJ16r9K3iYo1ayqBGn3EMFDQyuH07yAkmYs+qu9FPuPVzdZ99eJRN4GJ+ib54zZ1GCbSIAajl/T8uCnnphkgvEAABALS27/PgkL7NOBWa5P8lfdPUn3rZuV5KviN7YSdXboqs/bJXiAnAgvL8GAKDLJsZHppP8Uymvx8loswmDRvatDfdQTQdwur15DspR+1Pu/3ly7LLPqjM8zBrrVGuzdin/WY6+Ldh2EWC8oHQtEbgeq+n8DG16iRgAAKihtUkOsvTxAmXBLB/K7eu/1YOfe7MeRK2YBx+ID8ABseEeAKA3PiYCuscDxapk0aNNEzbcQ8UMDK4/JMnrJWGeowwesO7xerxaFvAo/qBv/kbflsCGezBeiB2N0RmtJO/L0KYTZA4AQG0su/zQJKcLAiq5Tu2k63r0c7fpHz2oVtpiHpxwD8AB8X5QAIDeuKH6v4IHb1CT69GGe6ien0vyOPO3sb0pWlOyqJjxJH8jBngUG+7N3z3XJ4um+26Sz4gBYydVqFVLFlTTY5N8KEObjhIFAAA18cokj7c2A2b5RpIP9+hn3yR+zAlqNQ823ANwQGy4BwDogYnxkc8luauU19PyrGkWYdC46/HpixavPUzyUClrRWD+pg6m6vqLvXdy7LLd6gs/0L9k4wlJjjXPUfG1I9W/Hm+Z2vnOB9QQjBegbzvq6Un+LEObDhIFAAA1sN7SxwuUBY/w57l9/f09+tk360FgHo7N8s1DYgBgvmy4BwDonRtEQPd4+CuLvTooybPFANUwMLh+KMlPSsKc1TSln3LvIev3PZBM/4EY4FGcbm+eM2dRgq0ioIvuE4H5u/4vz72Mvt2rlyS5XO4AAFTassufm+QU9/ugbx/hup795NvWfTXJnfrH2KlW2mIenHIPwLx5Xw0AQO/UYMO9B29Qk+txhfygMk4zf0Od1O6U+7+aHHv3uLrCo6wxf1ubdULLSUzMz3YR0EW7jRcseJ4Tgfm72tZnaNM5YgAAoMI2iMDaTBY8wo4CPtj1JmXAeKFW83CyrAGYLxvuAQB6p6gN9y3PmmYRBo27Hm24hwoYGFzfn+RUSZi/KZMHrUmSa0QAe7RGBOZv9G0BtqkdXeSEe/Oc2NEYycUZ2vQa2QMAUDnLLj8myastEUATPsL7cvv6Xr/wm9UK4wXz4O/0AMyb94ECAPTIxPjI2MynflachzlqJYsasOEequFnkzxBDOaspmpNyaJw/zE59u5/FgM8XP+Sjf1JVkrC/F2SPlk00Vemdr5zpxjoot3z/78YL8xze1gHyoLq++MMbXqJGAAAqJhTkxxunQo8wvsKeA0+WNbYSW3aois/7LlZvvkghQVgPmy4BwDoLafcF0sYNKpvn7No8VrrQyjfGeY5qKOpuvwiV6sl7NGKJIeav+kUz3Iqt/7ule1qRpfdKwLzN/qWJEl/kr/M0KYXiAIAgEpYdnlfkl+39PECZcEj/FtuXz9awOv4ZG/+wK4HjRdU1BFJlosBgPmwoQIAoLduEAHd5YFiVbLo8qaJI5OcoCegXAOD649P8jOSMM9RtgY/bL27kBMNoESrRWD+hgJsFQFd9oAIzN/NeXnuZfTtfh2e5P+XoU1r1AAAgAr4mSRD7vdB3z7CdUW8itvW3ZfkVr1j7FQrbTEP/l4PwLzYcA8A0FvX1+PX8OANanA9rpQdFO3UJC3zt7G96VpTsijUlsmxd98nBtijU0Rg/i5Rnyya5iYR0GUHeMK98YI9rANFQD0cleSjGdq0ShQAABRuvQhK4lmJLIqwO8lfFPR6tisJxgu1mgcb7gGYFxvuAQB6aGJ85KtJ/rOk19TyrGkWYdCo63GFxKFMA4PrD0ryRkmYv6mzqar/AteoIexVm/+Ab56j52tHqnk9egMi3ebDmMzf6Fse7agkH87QJh9+CwBAmZZdfkKS/2HpA5rwET6c29d/vaDXs12tMF4wDyeLAID5sOEeAKD3PlaPX8PDHLWSRcXZcA/l+h9JBsVgzuJ7Sj/lvoEPXP9xcuzdn9OZ8Gj9SzY+NskySZjnzFn02O1TO9/5LTHQ1VH9zk3fmTn5CvN3Q16eexl9O2fHJvl4hjatUQsAAAr060la7veBR7iusNdzs5IYO6lTW3T8h52U5ZsPVVQA5sp7aQAAeu/jpb0gJ6PNJgwa07c23EO5TjPPQRNU9pT7q9UO9mqV+dvarFvKf5ajb3tomwjokQP8oAfjBXuY50Rg/q6Xo5J8NEObfkgUAAAUY9nlhyc51dLHC5QFj/CtJB8q7DV9Jsn9ehC1Yo4OTrJSDADMlQ33AAC9d2OVd9dQVR4oViWLLm6aeNKixWuP0w9QloHB9U9O8lJJmOeolgY9dN1V4BssoCSrRWD+Rt8WwIZ7emVCBOY5saMx9uqoJNdnaNOL1QMAgEK8JsljxQCNXafuzV/k9vWTRb2i29btTvIpfdOYHqRXtapXW6zSOwDMlQ33AAA9NjE+MpHklnr8Nh68QcWvR6fcQ3l+LclB5m/U6uFaU7IoxO9Pjr37QTHAXp0iAkqfv/tk0QTbRUCPfOvA/6/GC/PcHtaBsqB+Dk/ywQxt+iVRAABQgA3WqcAevK/Q13Wz0kCddHz+9kH5AMyZDfcAAGW4vrQX1PL3h1mEQWOux5XShnIMDK7vS/JGSZi/aZKpKr3YySR/qGawTx38w715jp6uHanO9fjdJJ9RI3rECffmb/Qt+9ef5P0Z2rROFAAA9Myyy09p/PtFpr1AxWIPdib5RKGvbZseRK2YByfcAzBnNtwDAJThBhHQfR4oyuJRnHAPZfmpJEvFgDlrz0o/5b4BD17/fHLs3V/VibBn/Us2Lk3yeEmY56rAHwtr7VNTO9+5Wwz0iA335u8Gvjz3Mvr2gG/Hrs7Qpt/O0KaW2gAA0AMb6vXrWJuhb9vkfbl9fakX1E16xtipVtpiHpZl+eaj9Q4Ac+E9NAAAZfhEkpq8+dWDN6jw9WjDPZTlNPM3NFFlTrm/Rq1gn9aYv+lFrVpOYuLhtomAHvq68YK2z3MiMH/X25uT/HGGNh0iCgAAumbZ5ccleaUgrM1kwR5cV/Br+1ySu5UI44VazVEryckyBmAubLgHACjAxPjIt5NsLe11tTxrmkUYNOJ6XLZo8doBaUPvDQyuPy7Jz0nC/A2Funly7N028MG+rRGB+Rt9WwDzNb30VRGY58SOxpi31yX5aIY2HaM+AAB06b749CQ+9MnaEU34SNtz+/rPFRvVbeumktysVhgvmIdVIgBgLmy4BwAoxw31+VU8zFErWVR4jfhsMUARXp+kXwyYs/atNVV2FjV++Hq17oP9suGeSs3ffbKoq5tEQA990XhhnuvIOlAW1N+PJfm3DG1aJgoAADpq2e8dlGStdSqwB++rwGv0/NvYSe3aoqM/bLViAjAXNtwDAJSjyA33TrmfTRg0om9Xygx6a2BwfSvJaeY5aLKpkl/c15N8QI1g7/qXbOzv3n21+ZtH8yyHGV+b2vnOHWKgh5xwb/5G33Lgls1sun+hKAAA6KCXJ3mK+/0qLX3UShZd8UBF/h58kx5ErZgHG+4BmBMb7gEAyrE1yXfEQPd5oFiVLLq0aWKFPoCe+7GZN9VinqMGavgA9g8nx979XZWFfTopyWFiMH+jb3tsu5rQY18WAYZpNMaCHJPkoxnadLY6AQDQIevd74O+3YOP5Pb1VfgwTc/AjZ1qpS3mY3GWb36ivgFgf2y4BwAoxMT4yP1J/qU+v5EHb1DR69GGe+i903r3o83f7rWqpzUliy433u+LAfbLp+NTyfm7TxZ1s1UE9FibNtwbL8xze1gHyoLm6EtySYY2vT9DmwbEAQBA2yz7vacneaEgrL9lwR5cV4lXedu6z/vQT4wXajVP/o4PwH7ZcA8AUJYbS3xRLc+aZhEGtb8en71o8dqDJA29MTC4/pgkvygJ8zckUyW+qA9Njr37TrWB/VpjnqMBa0fKvx6d7kOvebOr+Rt9S/u8JsknMrRpiSgAAGiTde73LX3QhHtwd5K/r1BY2xtcK9CD82fDPQD7ZcM9AEBZPlavX8fDHLWSRQUNJHmaPoCe+dUkh4oBc9b8lH7KfY0ewl6j22BO/KHePFdZ/nBYKzbc09tR/M5N30xyvyTM3819ee5l9G3brUxyc4Y2/YSaAQCwIMt+78gkb3C/D+zBX+b29d+t0Ov1HNzYSS3bomM/bJVCArA/3jcDAFCWT818SmhxnIw2mzCofd+ukBf0zGnmOeAHijrlfjTJP6gJ7Fv/ko1HJxk2f1NCrcp/lqNvO+hzUzvf+U0xUIAx4wUdm+dEYP5upmOT/GOGNr05Q5tcBgAAHKjXJVkkBmszWbAH11Xs9d6sB1Er5sGGewD2y4Z7AICCTIyPPJjkRknQGx4oViWLLmyasOEeemBgcP3zkzxTEuY56qkGD2KvmRx7twsJ9m+1/V/mb/RtAZzqQyl2icA8J3Y0RtsdlOS3k3w4Q5uOVTsAAA7Aegsma0c04R6MJfnnigXlWTiYtObjsVm++WliAGBfbLgHACjPx+v163iYAxW8HlfKCnriDPM3anXgWlOy6KBvJ9kiBpiT1SKg6vN3nyzqYKsIKMRY+76V8cI8t4d1oCxotp9J8ukMbXqBKAAAmLNlv/djzfsQeGszmKM/ze3rpyr1im9b940kO5TO2Ekd26JjP+xkhQRgX2y4BwAoz8dKfWEtz9BmEQa15oR76LKBwfVHJXmlJMzf8GhFvKfh/ZNj7/6WWsCcnGKeoySe5TT2enSqD6UYE4H5G31LRy1O8vEMbTo/Q5u8BwwAgLnY4H6/LksftZJF211X0dd9sx5ErZiHVSIAYF/8sQUAoDz/meSrYqA3PFCsShYd3jRx3KLFa5+kB6CrXptkQAyYvxc4P045MbhDrtJdMGdOuDfP1YI/IFba/Uk+IwYKYcO9+dvLcy+jbzvvoCSbknwkQ5uOU0cAAPZq2e89OcnPud8HfbsHt+T29bdWNCgfQGvspJu1qn5brNEvAOyL98sAABRmYnxkOskN9fqtPHiDCl6PTrmH7jrd/A0U6l8nx95t0x7MQf+SjU9N0uMNLubvGq7NFqzlJKam+dTUznfeLwYKsct4QcfnORGYv3nITyf5jwxteqkoAADYi7VJDhaDtZks2IPrKvzabbjHeKFW87Eyyze7HwJgr2y4BwAoU7Eb7lueNc0iDGp9PdpwD10yMLj+ea458zfs21Qvf7jT7WHufBo+UMJ95zbZU5CdIrBOFTsao6uOS/LBDG16T4Y2DagnAADft+z3+pOcYcFk7Ygm3IMHk/xZhUP61MzvYMDAeMFcHJ7kmWIAYG9suAcAKNMN9fuVPMxRK1lUzEr1h65ZKwLMWe3Tmio7i4o9kP1ykr/WVTBnq0VgnqsTf0SsLBvuKcmuJA+YE8zfHV8HygIe6U1JbsnQpueJAgCAGa9I8kTrVGAPPprb13+5sq/+tnX3JfkvZTR2Ute26MgP83d9APbKe2UAAAo0MT4ymuTzpb4+p9zPJgxq27dO24YuGBhcf0SS15jngP3rySn3750ce/f9soc5O8X8Tam1Kv9Zjr5to+0ioJgr+85NDyS5QxLgXoaeGE6yNUObfiNDmw4SBwBA4613v1/XpY9ayWLBrqvB77BND6JWzMMqEQCwNzbcAwCU6wYR0DseKFYliw5umjhx0eK1R6o/dNyrk7jWjO00TEUeyj6Y5A9UC+amf8nGg5M8VxLmb+hx3359auc7R+VOYT4nAvOc2NEYPXNwkncm+XiGLlqqtgAADbXs956T5EcEYSGIvt2De5P8XQ1CulmfGDvpcq2q3RY23AOwVzbcAwCU6/r6/UoevEGFrsdWkufICTpurfkbtWq/1pQs2uBvJ8fefZcYYM6ek+QwMVC3+btPFlXjdHtK1IEN98YL89we1oGygH15QTL9Hxm6aH2GLmqJAwCgcdaLwPpbFuzFX+X29d/+/7N353F21/W9+F9nIEQYEveNwaA5MRo3ApKE2sXaa2uvV1tra13qDgZIAm2VXn/tbXvJ6uRe2RcrVNMScGttrdrlWiDiSiZRBFEYlJ4Qg9Fq1YgkbJn5/WHQAFnmzJzluzyfj0cfbYFk5rzen+/n/Tmfmc/5VOB1bFJKzBdq1YbnZt5lh8sVgH1x4B4AoLDGNxT5u2vYa9q7ViKgqs/jfOlC9xxx9NLn+sRc/RvaM9bLL3aRvKEtC/U5avzekeI8jxvlTQGNikD/xrilEAb3vNe/xm33AAA1Mve8RyZ5vfW+tz4YhPuxviIB3ZjkbhMGGIMTdEiS48UAwL44cA8AUFA7tq/b1p3bf/rNZo5ayaJEHLiH7losAvSs7in6LfcF35j9+j1bz/20UQRtWSQCfa6q/DCxVBy4p4i+IQL927dnLWPcFsqvJnHbPQBAfbw5yRFi8N4M9uGOJBsq8UpuWXJ/kq8oqbmTKg+Ljn8xl+QAsE9+RwYAoNjccl8awqCS4/Y4GUF3HHH00sOTvEGfA9rXk1vu3W4P7SvggXv921rr4Yq/l2PcTtGICCigLt1wb75gH31OBPo3E62V2+4BAOpg7nmNJEsF4b2ZLNiPKzO6dKxCr2eTkmK+oA0O3AOwTw7cAwAU2vhVMqDPY1AEJcmiS4cmnjNj6JRD1R664veSPFIM5nbqraCbs3cmuUJ1YOKmHfMnM5M8UxL6N/R53H5zbMuaH8iawo3+1spvJ/mhJPQ5sWNgFNKvJrkps1e9PbNXHaLmAACV8+IkT7cu9hYBg3A/qvYz4Y0mDDAG27BQBADsiwP3AADFdm01X5bNHCiJRyR5hhigKxbr36hV9zXGZDEJf3vP1nPvFAO0ZaELVal6/x6QRRm43Z4iu9F8oc/17H2gLKDdMXhEkrOTbMzsVcfLBwCgUpaJwHsz2I8bMrr0qxV7TW64N3dS+WHR0S82J/Mue7QCAvBQDtwDABTYju3rvpfkhiJ/jw17aHsRBpUct/NlBJ11xNFL5yX5JUno3zB5Y938yy+RL7StwJ9+r8/xcPZyKvs8XidjCuxGEejfGLcU3vOTjGT2qv+b2auOEAcAQMnNPe+YJC+z3q/bWx+1ksWEra/ga/pGkh3GIGpFGxaIAICHcuAeAKDwxjfIgD6PQRGUJIsuHZpw4B4672QRAA8o2AbtNfdsPfdmVYG2LRKB92Z6FgXghnuKzIF7it+/x2WBWiU5JMmZSW7K7FW/rv4AAKV2mi09632M2/0YS/KBykVzy5Jxt9ybO+lTrco7LBy4B+BhvJEGACi+q6v5smy8QUmeRwfuoYOOOHrp9CRv0r9Rq95pjMmiDReJACbFgXtK178bbmKqmnuTfEUMFNhXzRf09H2gCPRvplqrpyX5VGavujyzVz1OXgAAJTP3vOlJThKE9T6y2I+rMrp0e0VfmwP3mC/Uqh0L5QnAQzlwDwBQfJ9NxncX+Rts2GvaizCo3PN4nFSho34nyWPFoH/D1I11+i/8VpJPyBXaM+2YPzkmyRP1OaDPz+NXxrasuUe+FNhNGpL+LXYMjFJ6Q5JbM3vV4sxe5XfMAADK49VJOvzBSd4wiYIKDcL1FQ5nU8VqBcZgd7nhHoCH8cMQAICC27F93Y4km6v56mzmqJUsSuCxM4ZOOVrdoWPeJgL0rN4r+i33Bdmkfe89W8+932iBtrndXp+rFT9YLKwREVDoGbu18q4kt0kC/VsWlHIMPjrJe5N8MbNX+YBeAIByWCoC781gP+5K8rEKvz575eZOajEsOvbFnpx5lw0pHgB783sxAADlcE3Rv0G33O9NGFRu3M6XD0zdEUcvnZPk1/Q5oHM6dsv9fUkukydMykL9m7LWqvh7OcZtG64TASXQxdulzBfso8+JQP+mG+99Nmf2qgsye9UjxQEAUFBzzzuhe/vW1vvliUKtZLFf/5jRpT+p7Ku7ZckdSbYbg6gVbVgoAgD25sA9AEA5XGMzh/4zBsuSRRcOTThwD51xkgjM7bA/fd6o/cg9W8/9T1WASXHDvf4NRRi3bu2hDDaJQJ8TOwZG6Q0kOT3JLZm96nXiAAAoJLfbW+9j3B7I+hqEYx/S3Em/alXOYeHAPQAP4sA9AEA5fD7JPdV8aTbeoATPowP3MEVHHL10WpK36N+oVf80xmRxABeLANo37Zg/OTTJ8ZKgbv17QBZF88OxLWu+IQZKoMsfDGG+0Of28T5QFtCtMfikJFdm9qprMnvVs+UIAFAQc897bJLXCgLvOWWxH9uTXF2D1+kDajFfqFU7TpAlAHtz4B4AoAR2bF+3K8l1NbxVu8SEQaWeRwfuYep+K8kTxaB/Q+eNTfUvuP6ered+UY4wKc9JcoQ+h/eO9Pl59MuDlMX1SXaLQf/GuKVSXpTkhsxedV5mr3qkOAAA+u6kJNOt9731gf34QEaX1mF/roB75iYMjMECW5h5lzXEAMADHLgHACiPCn+6qM0ctZJFwTVnDJ0yU81hSk4SAXpW/xX9lvs+bdZeZGTApC0SgT5XV37AWCgbRUApZuvWyp1JviYJStG/x2WBWrXhkCR/mOQbmb3qpMxeZakIANAPc88bSHKaIKz3MW4P4IqaBLPZ2DB3Updh0ZEvNjPJXIUD4AF+yAEAUB4byvBNuhltb8KgUuP2WNnA5AwOLTkmyW/qc0D3TPqW+x8m+ZD8YNIW6t9UoVbF38sxbg/CgXvKpMu3S5kv2EefE4H+Ta9q9fgkf53kusxe5cPJAAB676VJnioGvDeTxX7clNGlX6nFK71lyQ+TfNOYx3xBG04QAQAPcOAeAKA8Nia5y2YOMFEdPjQxX6IwaSc1xsf9fndpWGvRXz3esH3/PVvP3Sl1mLQTRaB/QwHG7YgsKRHjVZ8TOwZG9S3Yc+h+XWaveqI4AAB6Zpl1sbcIGIQHsL5mwYyUuFZgDPaeD48E4GccuAcAKIkd29fdl+Rz1X2FNnPUShYF58A9TMLg0JJDkrzFPIhaFUdjTBZ7DYr3iAEmZ9oxfzIjyTxJUOf+PSCLIrhtbMua74uBEvms+YJ+1KohC+jHGHxzkm9k9qp3Zvaq6TIGAOiiuefNSfIbgvDeDA4wuK+s2WvepOzmTuoyLDryxRYqGgAPcOAeAKBcrirDN9mwh7YXYVCZcevAPUzOS5McLQag+8ba/QP/es/Wc2+TG0zawlKc3fI+lQmyl1Pa59Ft4ZRrxLdW3pLke5LQvzFuqY0ZSYaT3JzZq14pDgCArlnS+/1q6/3yRKFWssg1GV16R81e8yZjELWiDcdm3mXTxABAHLgHACidDT/9XzZz6DdjsCxZdPDQxHNmDJ1iUxHad/LPn0dzp7kdJqZHm7YXSxqmxKfc69/4QWMRbBQBJfRZEVCa/j0uC9SqQ56W5KOZverTmb3Kh/sCAHTS3POOSPIWQVjvY9wewBU1DOXLSXYbG+ZO+lircg2LRyR5rvEBQPweDABA6Vyf5IfVfXk23qDAz+NhSebJBSZucGjJUUn+Rw3nC9Sq8Bpjtc/iP5L8m5EAU7JIBOjfsigAB+4pox4cuDdfsI/3gSLQvylCrV6Y5MuZveqyzF71RJkDAHTE65I8Sgx4byaL/diV5KO1K/MtS3Ylucl4x3yhVm3wgfsAJA7cAwCUy47t68aSXPvT/682t2pXgDCozPPo5hloz0lJDhGD/g29MzbR//A992w9d0xeMCUlP3Cvz9HV94705nm8b8+Hc0LZfE4E+jd4Huu97ExycpJvZPaqP83sVYeLBABgSpZaF3uLAAcYhB/L6NI7axrKiAkDjME2nCACAOLAPQBAKV1d7ZdnM0etZFFgDtzDBA0OLRlI8taH/vPGuLkTPasoin7LfRc3bncleb8RAJM37Zg/eUqSJ0lCn6PrPYsDu2Fsy5p7xEAJXZ/kLjFQmv49LgvokhlJ1iS5JbNXvT6zVzVEAgDQprnn/aLf4/DeDA5ifY1f+yblN3dSp2Ex5S+2SMEAiN+BAQAopQ1l+UbdjLY3YVCJcesHtTBxL07yVH0O6L2DXlz/oXu2nvsDOcGUnKh/U9VaFX8vx7jdy4gIKOWM1lq5O8m15gv6wWle/ZtC1mrWngMgmzJ71S+rAQBAW5b2/1uw3i9PFGpVwyz+M8mnalzoEWMQtaINz8q8ywbFAIAD9wAAJbNj+7qvJfnuT/8/mzn0mzFYliw6dGjCgXuYuFP2/zyaO83tMDFd2ry9ULIwZQtEoH9DAcbtdXKjxK4SgT4ndgwMHuL5ST6T2av+MbNXzRUHAMBBzD3viUl+TxDW+3CAcfvBjC7dXeNAvpZkl3Fh7qTPtSrPsBhIcryxAYAD9wAA5XR1tV+ejTco6PP46BlDp8ySCRzY4NCSJyR5ec3nC9SqFBpjtcviunu2nnu9ysOULRIB+veDDciiH9xwT5n9u/mCftWqIQso+hh8RZKvZfaqCzN71ePUAwBgv96WZJoYgANYX+tXf8uS+5P42TgdYL+uRrVaKEMAHLgHACinDT//P2txq3ZFCINKPI/HSRIO6s1+uUH/hv4a29+/uFg2MDXTjvmTQ5KcoM/hvSN9fh5/lORWmVHa0d5aeVOS7ZLQvzFuYT8OTbIsyTcze9U7M3vV4SIBANjL3PMOTXKq9b63PmoliwO4OaNLv6TORf7gWs8jFNACEQDgwD0AQDldXf2XaENRrWRRUPPVGfZvcGhJY89tAgfUGDd3omcVRdFvue/gBu73knxExWHKnpPkCDHoc3S1Z3FwI2Nb1hjolN1VIqBU/XtcFqhVHzwyyXCSWzN71Vsze5UlJwDAT/1WkiExWO/DAcbtelkkSTaJwNxJAWpVnmHhwD0AfvcFAKCMdmxf10pyuySA3njQjqcD93BgL0wyx3wB9N/Dbrm/7J6t594rF5iyRfo3dahVw01MRTfieaACenTgXp9jH31OBPo3ZavV0Unel+SGzF71P9QHACDLRID3ZrI4yAu7Un0TB+4xX6hVm2Zn3mWPkyFAvTlwDwBQXnvdcl/szZyGvaaUpVZUXweeRwfu4cAWi0D/hk7rwCbu7iR/JUnoiIUi0L+hAOP2OllRAf8uAn1O7BgYtOk5ST6Z2auuSXPVCeIAAGpp7nnPSvIi62JvEeAAg/AzGV26VQ5JblnyjSQ/NGGAMdgGe04ANefAPQBAeW2o/ku0maNWsiigp84YOuWR6gwPNzi05DFJfnei/31j3NyJnlUUjbHKZ/GJe7ae+y2Vho7MnSfKAP17/wZk0StuuKf8s1lr5fYkXzZf0K9aNWQBZR6DL8p4NqW56oNprpqtVgBAzSwRgXUxHMR6ETyIW+7NndRuWEzpi/kAfoCac+AeAKC8ri7TN+uW+70Jg9KP2+PkAfv0xiSHiUGfg+IYe+D/uFAWMHXTjjlzRpJ5+jd1YS+nsM/jf4xtWfM9OVERnxCB/o1xC1PwmiS3pLnqwjRXPVEcAEDlzT1vRpI3We9766NWsjiAu5P8vbo+yGZjELWiDQ7cA9ScA/cAACW1Y/u67Ulu+fk/sZlDvxmDZcmiA4cm5qsx7NPi9p9Hc6e5HSZmChu5tyTZIEHoiBP8XEX/hgJwGw9V4sA95evf47JArQoW+7Qky5LcluaqFWmumikYAKDC3pjkSDFY78MBfDyjy3aI4UGP8EYhmDspSK3KMSxOMCYA6s0vhgEAlNvV1X+JNt6ggM+jA/fwEINDS15Q3Rtv9W+1qofGWGWzuOSerecqNHTGInMn+vfBDcii2/xyIFXy5STfNl/Qt/eBIrCWoUq1GkzyF0n+I81Vf5zmqunqBwBUytzzGkmWCALvzWRxEOvV82F8iC3mC7VqxxMz77JZ8gOoLwfuAQDK7SE3VVb+Vu0KEQalfh4duIeHWywC/RsK6CfJ2N+KATpmkT6H944U4Hl04J7qjPTWyvEk/ywJ/Ruggx6b5Jwk30hz1ZvTXOV34wCAqvjVJM/yPtVbdjiA7yf5f2J4iNEl2zPeqw/9NGGgaVXEIhEA1JcfKgAAlNuGeux02MxRK1kUzLNnDJ0yTY3hpwaHljwqye9P9s83xs2d6FlFUfRb7iexmbv+nq3n/1hloWMWmjv1ObrWs5iY+5NcLwYq5hMioHT9e1wWqFUJYn9KknVJvprmqt8WFABQAUtFYL0PB/GhjC67Twz75INszZ3UclhM+oudoFAA9eX3XQAASmzH9nU/SHJDmb5nN6PtTRiUdtwemuTZsoCfeV2Sw8Wgz0EBXSwC6Ixpx5w5lOQo/Zs61qr4ezm1Grc3jG1Zs8v4p2KuSnKX+YJ+aYhA/6bqtXpWko+lueoLaa76FfUEAEpp7nlHJ3mFNaTltFrJ4iDWq+N+bTIGUSvasEAEAPXlwD0AQPld/eD/12YO/WYMliWLKR6aOE594WcWT/15NHea22Fi2tjQvfaered/TWLQMSeKQP+GAozbEblQuZHeWrkryScloc+JHQODLvuFJNemueqf01x1rDgAgJJZnOQQMQAHcGtGl9k/3r9N3rL3i+DVqpTDYkHmXea8JUBNaQAAAOV3TT1epo03KNjzOF8OkAwOLVmQxC9o6t9qVSGNscpkcZFqQkctNHeif7dnQBbdsNG4p6L+znxBP2vVkAWUewy29+29NMn1aa66Is3Vs9UWACi8uecdluQUQVgXw0G43f7ANokA9O82HJnkGbIDqCcH7gEAyu8zSXY/+B9V+lbtihEGpX0eHbiHn3qbCPRvKKBvJ/mYGKCjFulzeO9IAZ5HB+6pqn9JcrcY9G+MW+jV8jbJHyTjt6S5+sI0Vz9RJABAgf1ukidY73vro1ayOIgr1e8ARpfsSDJqDKJWtGGBCADqyYF7AICS27F93U/8si3FY0OxBlk4cE/tDQ4tmZHktZ36+xrj5k70rKIo+i33E9jUfe89W8+/XyWhM6Ydc+YhSU4wd+pzdKVnMXEl+YVAmMQM3Vq5a8+heyhX/x6XBWpV8tinJVmW5LY0V69Mc/WjBAkAFNBSEVjvw0F8LqPLWmI4qM0eYXMnBapV8YfFIuMBoJ78ngsAQDVsqMfLtPEGBXoeZ84YOuVpcqDmXp3kSDHo31Aw9yW5VAzQUc9KMqh/U/daNdzE1G8jY1vWeDipsr8zX9BPDRHo39S5VoNJ/nzPwfv/mebqw9UbACiEuefNT/KLgsB6XxYHsV7dJmREBJgv1KoNbrgHqCkH7gEAquHqh/+jYm/mNOw1laZWVN8UnsfjpEfNLRaB/g0F9NF7tp7/HTFAR50oAv0bCjBuN8mCivtkkl1i0OfEjoFBH2v1mCRr9xy8PzXN1YfKBwDos5Lfbm9dLAp64N4kHxHDhIyU43k0YWAMFsSxmXfZYWIAqB8H7gEAquGLSe6px0u1maNWsiiQ+WpLXQ0OLZnfjU+ybYybO9GziqIxVuwsDrCxe7HqQcctNHeif3elZ1nLtOc6Y51Kz2StlT9J8jHzBf2sVUMWUO4x2Llv78lJ3pPkljRXvy7N1X6/DgDovbnnPTrJ6wRhXQwH8YmMLvuRGCbkhiT3i8HcSV2HRdtf7LAkxyoSQP34gQAAQAXs2L7u7iSfL9v37Zb7vQmDUo5bB+6ps5NEoM9BAd14z9bzPycG6Lia3nCvf/Nw9nL6akQE1MAVItC/MW6hQGOwmeTKJNenufrlcgIAeuzNSY6w3vfWxzcoi4OwnzZRo0t2JfmqMYha0YYFIgCoHwfuAQCqY8PD/5HNHPrNGCxLFpM8NOHAPbU0OLTkiCRv6N7zaO40t8PE7GNz9yKpQGdNO+bMI5M8SxL6N/R53N4+tmXNd+VADXwqyX+KAcsLaxkDg4LF/rwkH09z9RfSXP2rQgYAum7ueY0kSwRhvQ8H8YMk/yKGtox4hM2dFKxWxR4WDtwD1JAD9wAA1XFVfV6qjTcoiKfMGFr8GDFQQ69K8kgx6N9qVX2NsVJl8aMkH1A16LgTJvazFHMn+veBDMhiqjYa49RiJmutvD/JB80X9LNWDWGDuXP/fiHJhjRX/1uaq483FgCALnpJkjliwHpfFgfx4Ywuu1et2rJJBJg71aoNC2UGUD8O3AMAVMfmJD95+D+u5K3aFSUMSvk8uuWeOjpZBOjfFNDf3LP1/LvEAB1X8x+i63N07L0jUzMiAmrkChHo3xi3UPAx+JIkX0pz9d+lufqZsgMAuqBit9tb74uCLlkvgraNlOd5NGFgDBbAvMy7bIYYAOrFgXsAgIrYsX3d/Umurc8rtpmjVrIoCAfuqZXBoSXPSvJL3f46jXFzJ3pWURT9lvuBnxfsEtWCrmjjwL25U59jAj2LyblOBNRmhm6t3JzkFklQuv49LgvUqoax/16Sm9Jc/f40V88SPADQEXPPfVqSlwnCwhMO4raMLvuiGNr29SQ7xWDupM7Doq0v1kjyfAUCqBe/2wIAUC0byvhNuxltb8KgdI4TATXjdnt9DoroU/dsPf8bYoCuOFEE+rdaPVzDzS+9tDvJl41vamad+YJ+aohA/0atJu6QJG9J8o00V5+X5urHiwQAmKJTvS3Bel8WE3CF+kzC6JKS7bd7HtWKAlggAoB6ceAeAKBart73P7aZQ78Zg2XJYhKHJtxwT20MDi2ZnuSNvXsezZ3mdpiYAbfbQ1dMO+bMo5IMSUL/hj67YWzLu3aJgZr52yT3i0GfEzsGBiWq1WFJ/jBJK83VK9Jc/Sh5AgBtm3vuI5KcZK1l2QkT4MD95I14HqGATau4z+NC4wCgXhy4BwColhuT/KA+L9eOJxTAvBlDi6eLgZr43SSPFYP+rVb10xgrdBZbknxSlaArFpk70b87a0AWkzFiXFO7may18rtJPm6+oJ+1asgCyj0G+/ftDSb5iyTfTHP1n6S5+nBjBQBow2t++vNo633rYjigL2Z02TfFMGmbRGDuxBhsgxvuAWrGgXsAgArZsX3dWJINZfzeG/bQ9iIMSvU8HpLkOVKjJk4WAfo3BfRXu7aePyYG6IpFItDn6Nh7RybPgXvq6jIR6N8Yt1DiMfjYJP8nyW1prj41zdWHyhYAmICl1lqWnb5BWUzAenWZkk3GIGpFG47JvMueIAaA+nDgHgCgeq7Z9z+2mUO/GYMVzmK+mlJ1g0NL5iR5Ua+/bmPc3ImeVRQFveX+niR/rTrQNZM8cG/u1Oc4ED+cbNtGEVBTn0qyVQyUrn+PywK1EvuDPDnJe5Lckubq16W52nIYANi3uecuTHKCICw84SDuS/JhMUzB6JLbkvzAI2zupIC1Ku6wcMs9QI3YxAcAqJ5r6vVybbxBARwnAmpgsQj0byigD+3aev5/iQE6b9oxZx7ilxv1b7U6uIabmLrtziS3GNPUciZrrRxL8n7zBf3UEIH+jVp1TjPJlUmuT3P1y8QBAOzDUmstrPdlMQH/ktFlP1CTKdskAsydatWGhfICqA8H7gEAKmbH9nW3JPn2vv9tsTdzGvaaSlMrqq/N59EN91Ta4NCSaUneKAn0bwroYhFA18xLcqQY9G/os5GxLe8aEwM19r4ku8Wgz4kdA4MK1ep5ST6R5urPp7n6hbIGAJIkc899fJJXW2tZdsIErBdBR4yU63k0YWAM9pkb7gFqxIF7AIBq2lCvl2tDUa1k0WfHzhha7MInquy3kjyxX1+8MW7uRM8qisZYobIY2bX1fJ+8D91zorkTuscPKCfe70VArd+JtFZuS/IP3vvQz1o1ZAHlHoPF/fZekOTTaa7+tzRXH2ccAUDtnZRkuvW+dTEcxI+SfFIMHWHv3dyJYdHOF3PgHqBGDhUBAMBB3k6X8JDbo45669VJ/qCMeTfGk3HHdh8YfaX4dT7Yc/NnM8k3RUFFLRaBPgcFdMm4D+SgnfdaDXNumxaKQP9WqwnOL4Xfyyn1uN1oLEMuTvIqMYC1DFR0DL4kyUvSXP13Sf4it/2vUdkDMFH2fCti7rkDSU611rLs9A0q1gR8JKPL7lGLjthsDKJWtOFxjWf99dPGv35ySxQA1ecCCQCAajrADfcO5dBvxmBZsmi09+3NV0+qaHBoyTFJfr3/z6O509wOD/L9JB8SA3TVIhHo31AADtxjhm6tvDbJjZLQ58SOgUHFY39Vkq+lufp9aa6epWgAUCsvT3KMGCw8YQLWi6BDRpd8J8m3PMLmTgpaq2IOCx/YD1ATDtwDAFTQju3rtiS5rV6v2sYb9JkD91TVyT52WP9GrfbWGCtEFu/btfV8txdAl0w75szBJM82d6J/d9eALA5m69iWd33HOIYkyYXmC/pZq4YswBjsjUOSvDXJrWmuPi/N1Y8TCQDUwhJrLaz3ZTEBW5J8Xg06akQEmDtpo1YnyAqgHhy4BwCork/v/19V6lbtihMGpXkej5MWVTM4tOSBX3AE/ZsiGUvyHjFAVx2/56AD+hydf+/IxLndHn7uA0l+KAb9G+MWajIGpyf5wyStNFf/ZZqrj1QLAKiouec+PclvWGtZdsIEXJHRZUZLZ20u3/NoCGAM9tEi9QeoBwfuAQCq66r6vWQbimoliz5ywz1V9NIkRxXlm2mMmzvRswrzPPb3lvtP7tp6/u2qAF11orlTn6M3/KDygNyuAw/M0K2VO5NcJglK17/HZYFaiX1KjkyyPMltaa5elubqwxQSACpnqQgsPGGC1oug4+zBmzsxLNr5Ysc3nvXXhzQajfifA/8PQNn5PRYAgOr6dJm/eTej7U0YlMJRM4YWP14MVMxiEehzUEAXiwC6bqEI9G+1al/DzS+d5oZ7eLALktxnvqBf/Jqg/o1a9dETklyY5OY0V78uzdWmJACogrnnDiZ5s7UW1vuymICRjC67VfYdt8ngxtxJGwaTPFMMANXnwD0AQEXt2L7uO0m+tv//wmYO/WYMliWLNg5NuOWeyhgcWnLUnhvuC/Y8mjvN7dTcN5L8uxig604Ugf4NfbY7yZfFAHvN0K2VdyT5gCT0ObFjYFDjWs1OcmWSL6e5+jfUBgBK7/VJHmmthSiYgMtF0AWjS+5MMlq+59GEgTHYR4vUH6D6HLgHAKi2DfV7yTYUoY8cuKdKTrJvon+jVgfSGOtLFhfv2nq+IkAXTTvmzCcnOdrcif7dOwOy2Jebxra86y5jFx7m3eYL+lmrhiyg3GOwOo/I/CT/L83V16S5eoFxBwCltcR637oYJuD+JB8RQ9dsEoG5E8OijS+2UFEAqs8vjgMAVNvVZf7mG/bQ9iIMSsGBeyphcGjJQJKTJYH+TcHsTPI3YoCu86n0+hxTYC+nYzaKAPbReVorb0ryr5LQvzFuwRhMkrwoyUiaq/8uzdVz1QkASmTuub+c5HmCsN4vVxRq1acs/i2jy74n867ZaAyiVrThBBEAVJ8D9wAA1XZtkrH9/2ubOfSbMViWLCZ4aOI4daQifj3JrOI+j+ZOqKkrdm09f4cYoOu6dOBe//bejAPxA8uHGREB7Nf/FQGl69/jskCtxN5Vv5fk62mufm+aq5+syABQCktFYOEJE7ReBF212SNs7qTgtSrWsDg28y6brv4A1eb3VwAAKmzH9nU/THJ9/V65jTfok2fMGFp8uBiogMUi0L9Rq4lojPU0i4slDj2xUAR6glpNsT+6iakTrjNmYT9PcGvlhiSbzBf07X2gCPRv1KqYDtmzr31bmqtXp7n6USIBgIKae+6TkrzSWgvrfVlMwI+TfFzWXfWVJPeLAXMnE6zVoS6lAqg+B+4BAKrvmgP/60rcql0TwqDwz+NAkudKijIbHFrypCS/JQn0bwrms7u2nn+jGKC7ph1z5oAD90AB/CTJzWKAA1ojAu9TxY6BgVrt0+FJ/mzPwft3pLnahyQDQPGckmSaGKyLRcEEfCSjy+4WQxeNLrlnz6H7Ej6PJgyMwT45Qe0Bqs2BewCA6rumni/bhqJayaJP5qsjJffGPZ9GW2iNcXMnelZhnsfe3HLvdnvojXlJjjR3olb94YeWPzMytuVdY2KAA/qn/f4iLPp3L94HygLKPQbr8Yg8Jsm7k4ymufotaa623AaAIph77qFJFlvMWBfDBF0pgp7YLAJzJ4ZFG19skYIAVJvNdACA6vtskvvK/ALccr83YVB4DtxTWoNDSxpT/wUH9DnouO8k+QcxQE/44bj+rVYd0nDzy1SMGKtwkCe4tXI8yWrzBVjLgDF4UE9J8v4kN6S5+n+oIQD03SuSHCUG6/1yR6FWPcpia5LPyLgnRoxB1Io2LBABQLU5cA8AUHE7tq+76+CbgjZz6DdjsCxZTODQhAP3lNmLkjTL8s265d7cTm28d9fW8+8TA/TEQhGgf1MAG0UAE/IPSW4Wgz4ndgwMmJDnJPlkmquvSXP188UBAH2zTATW+zBBV2Z02ZgYemLEI2zupAS1Ks6wmJt5lz1S7QGqy4F7AIB6uKqeL9vGG/TBsTOGFnuvSVmdLAL9G7WajMZY17K4P8mlEoae6cEN9+ZO9O8DGZBF3HAPE3yCWyvHkqwwd9KvWjVkAeUeg/V9RF6UZHOaq69Mc/XTjFMA6KG55z47yQstZrDel8UErZdtz9yS5CdiwNzJBGvVSHKCjACqyyEIAIB6+PTB/5PS36pdI8Kg0M/jEUmeLiXKZnBoyeOS/K4k0L8pmH/ctfX8b4sBum/aMWcekeS5ktDn6Nl7R/btjrEt79L7YeI+sucXYtG/MW7BGGzP65Lckubqs9Nc/Rh1BYCecLu99b4omKjNGV12sxh6ZHTJ7iRfLu/zaMLAGOyDBeoOUF2HigAAoBa+kGRXksPr99LHS3HXDGpVsSzmJxlVR0rmDUkOK9s33Rgfz3jD3ImeVYjncWw84wMdz+JiyULPHJ/kEHMnatV/A0nG6vvyrzMCoI1ZurVyrPG0vzgryYekQWn6d0+/PWsZ4xaxH9BhSd6e5K2NOWtWJ42Lctuf3W1gAEAXzD13ZpLXC8LCEyboShH03EiSXxGDuRPDYoJfzIF7gApzwz0AQA3s2L7u3j2H7kvNzWh7EwaFNl8ElNDbRKDPQcHctGvr+deKAXrmRBHo32rVeQ03v7RrxPiEtn0kyVf0OfrBr/zq36hVRTwqyf/96Y33a16X5hrTGwB03puSHGmthfW+LCZgd5IPyrTnNokAcydtWCQCgOpy4B4AoD6uOvh/YjMHiqPYz+NBDk04cE+pDA4t+eUk88r6/TfG9W9zOxXldnvorYUiQP+mADaKANqcpVsrx5P8uST0ObFjYKBWU3bMnps0R9Jc80vqDAAdMvfcRpIlgrAuFgUT9KmMLvuuGHpuU7mfRxMGxmCPDWXeZU9Sd4BqcuAeAKA+NtT3pdtQVCt67DgRUDIniUBPQK06oTHWsSzuTHKFRKGnevwp9OZO9O8DGahnFmNJNhubMImnuLXyn5Ncp3/Tj1o1ZAHlHoMekX2FcUKSz6a55qNprnm6XABgyl6U5JkWM9ZaMEHrRdAHo0taSb4vCHMnhkUbX8wH+gNUlAP3AAD1sTnJj8v+Ihr20PYiDArriTOGFvsET0phcGjJo5L8viSAglm3a+v5PxED9Ma0Y858UpJZkvA+le6wlzNhN41tedddYoBJ+1MR6N8Yt2AMdtQrk3wtzTXnprnmMWoOAJN2ugistaobhVp1OIs7k3xMln2zyRhErWiDA/cAFeXAPQBATezYvm53kmsP/l/azKHfjMGyZHGQQxPz1Y+SeH2Sw8v+Ihrj5k5zOxXzHhFATy0SAfp38dTwh5gbVR2mMFO3Vn46yb9LgtL073FZoFZiL0UY05L8UZLb0lzzx2muOUxGANCGuec+JcnLBYGFJxP0DxldtksMfTPiETZ3UpJaFWNYnKDmANXkwD0AQL1cU9+XbuMNesyBe8riZBHo36hVJzXGppzFVbu2nn+LJKGn+nTg3tyJ/i2LBxlRB5iyM7v/QJs72cf7QBFYy6BW1feoJOckuTnNNa8UBwBM2KlJDrHWwnpfFhO0XoZ9tUkEmDtpo1ZuuAeoKAfuAQDqZYIH7kt9q3bNCIPCPo8O3FN4g0NLFiY5VhLo3xTMxSKAnvPDcH2O/r135OeuEwFMsQO1Vt6YZJ0k9G+xY2CgVl0zO8lH01zz6TTXHG8MAMABzD33sCRvE4S1liiYoDuSbBBDX42U/3k0YWAM9tCjM++yp6s5QPU4cA8AUC9fTfL9+r58G4pqJYsecuCeMlhcpRfTGDd3omcV5nmc/C33W5N8QoLQO9OOOXOgvwfuzZ36HAdSox9k3pXkZhWHjviLJLvEgP4tC4xBj0hXw3hhks1prnl/mmueJDMA2KdXJXm8xQxqxQRdmdFlY2Loo9El30tyuyDMnRgWbXyxExQCoHocuAcAqJEd29eNV+WTUN2MtjdhUEhPnzG0eFAMFNXg0GkzkrxaEvocFMxf7dp6/m4xQE89I8kMMejfatV9DTe/HMjmsS3vsgaATjzJrZXfTnK2PkevNURg3Qn1nPrekuQbaa750zTXPEIkAPAgy0RgvV+fKNSqA1lcLrtC2GTCQK1owwIRAFSPA/cAAPVzzcT+M5s59JsxWJYs9nNoYiDJ89SOAnttkiOr9qLccm9up9TuTfI+MUDPLRIB+jcFsFEE0FFrk3xXDPqc2DEwUKueODLJmiQ3p7nmVeIAgCRzzz0uyYmCwBqSCboho8u+JoZCGPEImzspUa36Pyz8rgFABTlwDwBQP1fV++XbeIMemi8CCuxtItC/Uatuaoy1ncWHd209/z8lBz1XgB+CmzsxBg9koB5ZjBiH0MEnubXyJ0n+l/5Nr2vVkAWUewx6RKYaxlOTfCTNNZ9Jc83xMgSg5vpwu73FDJR4Pb1eZoWxSQTo37RRq/mZd9mhsgGoFgfuAQBqZsf2dd9McsfE/utS3qpdU8KgkM+jA/cU0uDQafOTnGDuRP+mYC4RAfTFQhHoc/T9vSPJdSKAjluXZLMY9G+MWzAGe+6Xk2xOc81fp7nmCeIAoHbmnvuYJK8VhLVW/aJQq0kaS/IBMRTGl6oxmD2PGIM9ckSSZ6s3QLU4cA8AUE9uuUetZNELDtxTVIur/OIa4+ZO9KzCPI8Tv+X+S7u2nu+gHfTYtGPOPDzJseZO1Kr4Kv4DzW+PbXnXHaoMHZ6tWyvHkpwuCUrRv8dlgVqJvXJhNJKclOTWNNf8UZpr3PYGQJ28JcnhYsDCkwm6KqPLtouhIEaX3JnkZo+wuRPDog0+4B+gYhy4BwCop0+LAOiB584YWnyIGCiSwaHTjkjyup//Ez+MKQ+1otIuFgH0xfFJrFf1b3pcq4abmB7Kh+5At57m1srrklyuz9FLDRFYd6JW7O2RSc5NcmOaa14sDgAqb+65A0mWWGthvU8bWVwuq8IZEQHmTtqo1QK5AFSLA/cAAPXUxg33xd7MadhrKk2tqL59PI+HJ3mGZCiY39/zS34Vfx71BP2bEvlBkg+JAfriRBGgf1MAfnkPuuudSe4Ugz4ndgwM1Kqv5iX59zTX/GOaa54mDgAq7CVJZovBWksUTNBdSf5JDIWzqRrPowkDY7BHHLgHqBgH7gEAamjH9nXbktxW7xRsKKqVLHpkvrpRMG8TAehZvdQYO2gW79+19fxdkoK+WGjuhPKMwYHqZrHR2IMuPs2tld9JskL/ppe1asgCyj0GPSLdDOMVSb6e5pqVaa45Qr4AVNAyixnUijb8Y0aX/UQMhbNJBOZODIs2vthzM++ywxUBoDocuAcAqK+rqvJC3HK/N2FQOA7cUxiDQ6c9K8kLzJ36HBRsUF8iBuibRSLQv+kPezk/M5Zksxig685PcpMY9G+MWzAGC+ERSf48yWiaa14tDgAqY+65s5P8d0FYa4lCrdrIYr2MCumGJPeaMFArJuiQJMeJAaA6HLgHAKivayb+n9rMod+MwbJksY9DEw7cUySL6/RiG+PmTnM7JfAvu7ae3xID9N60Y858YpJjJIH+TZ/dPLblXW4wgm7P2K2V9yU5VRK4VdtaxrhF7IUK4+gkH0pzzTVprnmmnAGogNOSNMSAhScTtD3J1WIooNEl9+45dO8RNndSplr1d1gsVGuA6nDgHgCgvjaIwMYb9IAD9xTC4NBp05O8QRL6N2rVD42x/WZxkXSgbwr6Q29zJ8bggQxUL4vrjDno0RPdWvn5JH+tf9Oz94EisJZBrZioFyW5Mc01w2muGRQHAKU099zDk5xkrQXGYBtZXJnRZbvlU1ibRIC5kzZqtUAmANXhwD0AQE3t2L7ue0m+OvE/UbpbtWtMGBTqeXz8jKHFR0mFAvjdJI8xd6J/UyC3JfmUGKBvThSBPkeh3jvW1YgIoKfemeR7YtC/AcydhTNtT5++Jc01rxIHACX0miSPFoO1lihow5UiKLSR6jyPJgyMwR5wwz1AhThwDwBQb9eIwIaiWsmiB45TMwpgcR1fdGPc3ImeVZjn8eG33F+ya+v5Y5KBvinwp8ybO/U5DqRiP9zcqKLQw1m7tfIHSc6UhP7t27OWMW4Re2HDODrJR9Jc8+9prnmm3AEokWUWM6gVbbgpo8u+IoZCc8O9uRPDop0vNifzLvPhSwAV4cA9AEC9VerAvZvR9iYMCmW+COinwaHTnp7kheZOfQ4KZFeSdWKA/pg+68yGT5nXvylGrRr1vvllZ5KbjDfoufXd2RfX59hHnxOBdSdqxWS9OMkNaa5ZneaaI8QBQKHNPffEJMcLwhpSFGrVRhbrZVJ4tyT5iQkDtaINJ4gAoBocuAcAqLdrk7Rxq6bNHPrNGCxLFg85NOHAPf32tjq/eLfcm9sppA/s2nr+D8UAffOMJI8UA/o3fbZ5bMu7dosBejxrt1aOJzl5z4dgoc+JHQMDtSquw5L8WZKb01zzCnEAUGBLRQC0+YbhSjEU3OiSsbZuufc20PtvilOr/g0LH/gPUBEO3AMA1NiO7et2JNksCRtv0GUO3NM3g0OnHZbkzZLQv1GrImiM/SyLi6QBfbVowM0vUOoxOFCNLDYaZ9CnGa61srXnAJ/+rc91/32gLKDcY9AjUoQwZiX5xzTXfCzNNbPUAYBCmXvuE5L8vv6NWtGGqzO67A4xlMImEaAn0EatHLgHqAgH7gEA2NDef16qW7VrThgU5nlszhhaPEMi9MnLkzze3In+TYF8YdfW878iBuirRSLQ5yjke8e6GVF96KsLklwnBv0b4xaMwdL47SRfT3PNO9Jcc6g4ACiIk5IcJgZrLVGoVRtZuN2+PDZXdAwC3bFABADV4MA9AABXiYBysflbwiwaSZ6nXvTJKSJIGuPmTvSswjyPY+Nut4f+K8mny5s79TkOpAI/5HTQF/o5c7dWjiV5S5J7paF/+/asZYxbxF6aMAaTvDvJ5jTXuDkOgP6ae+4hSU4TBBaetGFXko+KoTQ2eoTNnZS0Vv0ZFk/OvMuG1Bmg/By4BwDgC0nuE4ONN+iy40RArw0Onfa0JC/WE/RvKJD/9EsU0F/TZ515eJJjk2RAG9G/KUytGvW7iWn72JZ3bTPGoM9PdmvlLUlW6HN0vc+JwLoTtaLTjk1yXZprLklzzSPFAUCfvDzJU6y1wBhsI4uPZXTZnXIoidElW/f8fB/MnUy0Vj4cEKACHLgHAKi5HdvX7dxz6L4Nxd7MadhrKk2tqL69nsf50qAP3up3mtG/KZhLd267wA2a0F/HJTlUDOjf9NmICKAw1ibZLAZ9TuwYGKhV6TT23Cp8S5prXiMOAPpgqQistURBm9aLoHQ2V+t5NGFgDHbZAjUGKD8H7gEASJJPiyA2FNVKFt3lwD09NTh02qFJTpLEzzXGzZ3oWX22O8l7jQPou0XmTqjOGBwobxYbjS0oyCzXWnl/kjckuVv/1ue6qSELKPcY9IgUOYwnJflgmmv+Lc01T1UfAHpi7rnPTPJi/Ru1og3fTfIpMZSOvXxzJ4ZFO1/MgXuACnDgHgCAJLmqai/ILfd7EwaF8JwZQ4vdJEovvTTJk82d+hwUyD/t3HbBNjFA3z3owP2ANqJ/Uxg128txwz0UqSu1Vt6S5E8loX9j3IIxWGovSXJTmmv+KM01h4gDgC47TQTWWqJQqzZ9KKOn7xZD6VRwL9/zqFZ00cLMu6whBoByc+AeAIDs2Rjc2d4fsZlDvxmDZcliz6GJ6UmeqVb00NtEsK/n0dxpbqePLhIBFMIiEaB/U4CB4sA9FM/5ST4tBv273t+etYxxi9hLH8ZgknOTfCHNNc9RJwC6Yu65RyZ5iyCw8KRN60VQSps9wuZOSlyr3g+LmUnmqjFAuTlwDwBAdmxfd2+Sz0oiNt6gu+aLgF4YHDrtKXtuuEf/Rq2K4maHd6D/ps868/FJnvrQfz7g5hco9RgcKF8WN49tededxhUUbKZrrRxP8qYkHXo+9W8eztVGYO6kZxYmuT7NNSvSXDNdHAB02OuTzLDWAmOwDTdn9PQvGQMlNLrk+0lagsDcSRu1OkEWAOXmwD0AAA+4pv0/UopbtSlBrai+Pc/jcZKgR97cmT0Pcyf6Nx1z8c5tFygo9N9CEehzlOK9Y9Vdp9JQ0M7UWrk1yemS0L8xbsEYrIRDk/xFkq+kueYXxQFABy0VgbWWKGiT2+3LbaR6z6MJA2OwixapL0C5OXAPAMADrhHBA2woqpUsusQN93Td4NBpA0lOlsT+NcbNnehZPfaTJJerOxTCieZO1KqaSvYDzxEVgwLP4q2Vf5vkQ5LQv+v77VnLGLeIvXJhPDPJZ9Ncc1Gaa2aqGwBTMvfcFyZ5jv6NWtFmMa8QQ6lLuFkG5k4Miza+2AKhA5SbA/cAADzg+iQ/qtqLcsv93oRB3zlwTy+8JMksc6c+BwXytzu3XXCnGKAQ9nvD/YA2on9TmFo1qn/zy0bjCQrv1CS363N0pc+JwLoTtaJf0+/SJDelueY3xAHAFCwRAVjvt+kzGT39W2pfaiOeR9SKNszPvMumiQGgvBy4BwAgSbJj+7rdSa5t/0/azKHfjMGyZNEYz2NmDC1+ijrRZW63n9DzaO40t9NDl4gA+m/6rDMbBzpwD/o3PbIzyU1igILP4q2VO5L8QZLd0tDnxI6BgVpVylOS/L8011zmtnsA2jb33KOSvFIQ1lqioE3rRVB6X0oy5nk0EVLiWvV2WDwiyXPVF6C8HLgHAGBv14jgATbeoEvcck/XDA6d9qQkvyUJ/Ru1KpANO7dd8HX1hkKYm+RRB/oPBqp/qzZUegwOlCOLL49tedf9xhKUYMZrrfx8kpX6tz7XDQ1ZQLnHoEekCmGc7LZ7ACZhcZJD9W/UijbcneTvxVByo0vvSsZvFgTQRv92EQBAiTlwDwDA3ip54L7h5w97EQZ9fx6PkwJd9Jbu/JKDuRP9m0m7SARQGH6orc9RrveOVbVRdaFUViX5nBj0b4xbMAYryW33AEzc3HOnJTlFENZaolCrNn08o6fvMCgroaJ7++ZOtaJLThABQHk5cA8AwN6+luS77f8xmzn0mzFYoizccE9XDA6d1khykiQmrjFu7kTP6rI7knxcnaEwTjR3olbVV4IffI6oEpRoJm+t3J3ktUn+Sxr6d/2+PWsZ4xax1yYMt90DMBGvTPIkMWCtRZsuF0FlbPIImzspea16OyxcBgBQYg7cAwDwMzu2rxtP8mlJPMDGG3SBA/d0y68laYoB/ZsC+aud2y64XwxQGBP6ofaANqJ/U5haNap5E5Mb7qFss15r5bYkb9Dn6HifE4F1J2pFkbjtHoCDWWKtBcZgm76f5FNqXRmbzJ2YO2mjVs/OvMsG5QBQTg7cAwDwUFdN7o8VezOnYa+pNLWi8p4286jFjxQDXfA2cyf6NwVyX5LLxADFMH3WmY/wwU/o3xTAd8e2vOt2MUAJZ/PWyn9NsloS+pzYMTBQq8pz2z0ADzf3nOcl+RVBWGuJgjZ9KKOn3yeGyrgxyT3VfB5NGBiDXTCQ5Di1BSjvJA4AAHtzw/2D2FBUK1l0wbFqRCcNDp32uCS/I4n2NcbNnehZXfJ3O7dd8F31hcI4Lsmh5k6oh4HiPo9ut4dy+99JPqN/e5/aSQ1ZQLnHoEekqmE8cNv9RWkOH6G2AFTvdnuLGbWiR9aLoEJGl96X5CueR3MnhkUbX2yRwAHKyYF7AAAeZMf2dd9MUsnbttxyvzdh0FduF6XT3pTkMHMnakWBXCICKJS2fpg9oI3o3xSmVhXby3HgHso887VW7k7y2iTfk4b+jXELxmAtLE3Gvpzm8AJRANTY3HMemeT1grDWEoVatenWjJ4+YhBWziYTBmpFG+wnAJSUA/cAAOzLhsn9MZs59JsxWJIsHLin004WweS55d7cTsd9Zee2Cz4vBiiUhSJA/6YA/IIllH1Gb638dpLXJBmTBpYXGBiIvRZhPCPJF9Mc/ss0hw9VY4BaenOSQU0fay3adLkIKmnEI2zupAK16t2XcuAeoKQcuAcAYF+uFsHebLxBhx0nAjplcOi0X07yTEmgf6tVgVysplA4bR+4H3DzC5R6DA4UL4txB+6hIrNfa+U1Sd6pf+tzndKQBRiDFN0hSZYn+Xyaw3PFAVAjc89pJDnNWguMwUm4Um0raZO5E3MnbZideZc+VgwA5ePAPQAA+7Jh8n+02Js5DXtNpakVlfbsmUctniYGOmSxuRP9mwL5YZIPiAGKY/qsdzwuGW9KQp+jvCqyl3PL2JZ3/Vg1oTLOTvL3YtC/MW7BGKyDsQf+j4VJvpLm8GlpDjfkAlALL07yDP3bWksUtOlzGT19ixgq6dYkP67u82jCwBjsArfcA5SQA/cAADzMju3r7kgyKom92VBUK1l00LQkz1Ifpmpw6LRHJfldSUxdY9zciZ7VIX+zc9sFO9UTCmVhdV+a/q1WHEjBfgi6UUWgQrN6a+V4krckuVka+nc9vj1rGeMWsQtjj8OTXJLkX9IcPkq9ASpvqQiw1mIS1ougokaXjrnl3tyJYdEmB+4BSsiBewAA9ueaqr4wt9zvTRj0zXwR0AFv2PMLbuZO1IqiDLiLxQCFs2iyf3BAG9G/KUytGuW/+WXEeIGKzYCtlT9J8ookd+pzTLnPicC6E7Wi4MYe+g9+M8mNaQ7/lmwAKmruOcckebm1FhiDbbo3yUfUtNI2iwBzJ21YJAKA8nHgHgCA/ZnCgXubOfSbMViCLBy4pxPeJoLOccu9uZ0p+387t11wmxigcBaZO9G/KQAH7qGKM3tr5a1JXm+S1+fEjoGBWtXSY5P8U5rDF6Y5/AhxAFTOqfv+HXv921pLFBzQxzN6+o/EUGkj1X4eTRgYgx12gpoClI8D9wAA7M+n7aA9lDigg44TAVMxOHTawiTPlQT6t1oViNvtoWCmz3pHI8nCqfwdA37xBUo9BgeKkcXdSW4wVqCis2Br5ceT/C/9W5+bqoYsoNxj0CNS5zCWJRlJc/hZag9QEXPPmZ7kJP0btWISrhBB5Y14Hs2dGBZteGLmXTpL2ADl4sA9AAD7tGP7uu8nubGqr69hD20vwqAv3HDPVJ1i7kT/pkBaSf5FDFA4T0/yaHOnPkc1lHgv58tjW951vwpCpQ0n+ZAY9G+MWzAGq2zsQP/yuUk2pzl8ipwAKuHVSR4vBmstUfgG2/SDJP9qsFXc6NJtSb5rwkCtaMNCEQCUiwP3AAAcyNWT/6M2c+g3Y7DgWTxy5lGLn6o2TMbg0Gkz9vyiAx3WGDd3omdN0nt2brtgTP2gcGryw2v9W604kAL8MPQ6VYCKz+6tleNJ3prkS9LQv6v97VnLGLeIXRgHcHiSv0pz+KNpDj/GGAAotSX6HNZaTMKHM3r6vWKohRGPsLmTitSqN1/qBDUFKBcH7gEAOJANIngoG2/QQW65Z7Jem2RQDOjfFMTdSd4nBiikEzvxlwxoI/o3halVo5w3MY0YI1CDmbC1cleSVyT5jj7HpPucCKw7USsKbkKft/nKJDekOfzL8gIoobnnPD/JImstMAYnYb0a1saIuRNzJ21wwz1AyThwDwDAgVybZPfk/3ixN3Ma9ppKUysqy4F7JusUcycYgwXyoZ3bLviBGKCQFpo7gQLYKAKoyTu01sptew7d7/I+FbFjYKBWtXZ0kk+nOXxWmsOHiAOgVJbp39ZaomASvpnR078ohtrYXP3n0YSBMdhBCzLvUmc3AUrEpA0AwH7t2L7uzo5sEFaODUW1kkWHOHBP2waHTjsuyfGS6J7GuLkTPatNF6kZFM/0We+YXq/1pv6tVhxIH38g+p9jW961RQWgRrN8a+XGJG/SE/TvyWrIAso9Bj0iwnjw25D/neRTaQ4/0XgAKIG55zw2yWv0b9SKSbhCBLUy4nk0d2JYtOHIJM8QNEB5OHAPAMDBXFXlF+eW+70Jg547TgRMwtvMnagVBbJx57YLviQGKKT5SaZ16i8b0Eb0bwpTq0a5bn4ZMTaghjNia+XfJfkzSYC1DBiDVTTW7h/4tSTXpzn8QtkBFN5bkzxCDNZaovANTsKVBleNjC79QZJvmjBQK9qwQAQA5eHAPQAAB7Nhan/cZg79ZgwWOItZM49a/Gh1YaIGh04bTPJ6SXSfW+7N7UzYxSKAwlpo7kT/pgCuEwHUdKZvrXxXkvfrc4gdAwNI8uQk16Q5/KdpDjfEAVBAc88ZSHKatRbW+0zCFzN6+jfFUDubPcLmTipUq+5/qUXqCVAeDtwDAHAwn09yjxgeysYbdMh8EdCGVyWZIQb0b7UqiO8l+YhaQWGd2Om/cMDNL1DqMTjQnyw2GRdQa6cluUb/1ufa1ZAFlHsMekSEsf+3JGuS/Euaw48RB0DhvDTJ08Sgf2MMTsJ6NaulTeZOzJ204QQRAJSHA/cAABzQju3r7k7yxan9LcXezGnYaypNragkB+5px2JzJxiDBfLXO7dd4IOpoLgWmjv1OaqrRHs5I6oFNe5grZX3JvndJF/Xv8G4BWOwSsam8od/M8lX0hz+BTkCFMpSEVhriYJJuDfJh8VQSxvr8TyaMDAGO2R+5l16mHoClIMD9wAATMTVItgXG4pqJYsOcOCeCRkcOu05SfwCWg81xs2d6FkHMJbkr9QIimn6rHc8NskccydqxUP1+Aejo2Nb3vUjqUPNZ/vWyh/tOVh3hzT072p9e9Yyxi1iF8YUPCXJtWkO/1Gaww1xAPTZ3HOaSV6iz2GtxST8S0ZP/4EYaukrSXaLwdyJYTFBhyU5VsgA5eDAPQAAE7Gh6i/QLfd7EwY9dZwImKCTzZ2oFQXyiZ3bLtgqBiishd36iwe0Ef2bwtSq+Hs54xuNByA/PXT/rSQvTfJjfY4J9zkRWHeiVhTc2FT/gmlJzk3y0TSHZ8gToK+WWoJba2EMTtIValVTo0vvSvJ1cyfmTtqwQAQA5eDAPQAAE7ExyV1T+yts5tBvxmBBs5g386jF09WEAxkcOu0RSd4oid5zy725nf26SARQaIvMnejfFIAD98DPZ/zWyhuTvCLJffocYsfAQK3Yy+8k2Zjm8FxRAPTB3HOOSPJm/dtaSxRMwo+SfFIMtbaxHs+jCQNjsEMcuAcoCQfuAQA4qB3b192f5DOS2BcbijBFhyZ5thg4iN9N8mgxoH+rVUGMJrlabaDQFnXzLx/wiy9Q6jHYwx+OjhgLwINmx9bKDUler3/rcxPVkAWUewx6RIQxcfOSjKQ5/HJRAPTc6/wcWv9WKybpIxk9/R4x1Nomz6O5E8OiDQsFDFAODtwDADBR11T9BTbsoe1FGPTUfBFwEG8zdwIFcsnObRd44KHY2vhhtcfZ+1TKrMB7OXcnuUGFgId1s9bKjyT5Y/0bjFswBqtgrJN/2SOTfDzN4bPSHG7IFqBnlorAWksUvsFJutwgqr1NJgzUijY8M/MunSEGgOJz4B4AgInqwC2eNnPoN2OwoFk4cM9+DQ6d9owkL5RE/zTGzZ3mdvZyV5K/EQMU1/RZ73h6ksdIQk9QKw6kBz8gvX5sy/B9kgb2OfO3Vp6XZKUk9O9qfHvWMsYtYhdGh/3vJP+U5vBMUQB02dxzXtC531XQ57DWqplWki+Iofa+uufDdz3C5k6qVKvufamBJM9XS4Dic+AeAICJuiHJD8WwLzbeYIocuOdAThIB+rdaFcj6ndsu+LGaQKEt7MUXGdBGoDD9u6C33G80BoADzpKtlX+Z5BLvUzlonxNB5dcyqBVlN9aNv/TlSTalOfws+QJ0ldvtrbUwBifryoye7gGpu9Gl9ye53tyJuZM2LBABQPE5cA8AwITs2L5uLMmGqf9Nxd7MadhrKk2tqJRjZx612O+O8jCDQ6cdluTN5k4wBgvkYhFA4Z1o7tTnoAAcuAcm4owkH9a/ETsGBmrFPsxNsjHN4d8RBUA3ZtlznpDkVfq3tZYoRDBJ60XAHpvq8zyaMDAGO2ChOgIUnwP3AAC0Y4MI9seGolrJYgpmJpmtHuzDK5I8Xgz91xg3d6JnJfnMzm0X3KQWUHg+Fd57H7ViQrr8Q9JNEgYOOvu3Vu5O8sYk/08a+rcsoMJj0CMijMk7Msk/pDm8Is1hH1wN0FmLk0wTg/6tVkzCSEZPv1UM/Gw8eB7NnRgWE+d3GQBKwIF7AADacXUdXqRb7vcmDHpmvgjYh5PNnagVBXKRCKDYps96x2FJjuvV1xvQRvRvClOrgu3lfH9sy/Bt6g9MaKZsrbw3ySuTXKvPsd8+JwLrTqDgxrr9Bf4iyUfTHB6UNUAHzD3n0CSnCMJ6n7JEUbhv8HKDhr3U7MN3zZ1qxRQdk3mXunwIoOAcuAcAYMJ2bF93c5LvTP1vsplDvxmDBczCgXseZHDotNlJXiyJ4nDLvbm95r6d5GNigMKbn+Qwcyf6N302IgKgrQ7QWrkzyW9Xe/7Q58SOgYFaMUW/k+RzaQ4fIwqAKXt5kqP1b6whmYT7k3xYDOzlG0l2eITNnVSwVt37UgvVEaDYHLgHAKBdV4tgf2y8wRQ4cM9DneQCL/RvClSrS3duu+A+NYDC6/kPpwfc/AKlHoNd+kHpdeoOtD1btlbuSPIbSW7Sv/W5fWnIAso9Bj0iwuiM+UlG0hx+gSgApuR0EejfGIOT9G8ZPf376sHPjC4d3/8t9+ZOzJ3skwP3AAXnwD0AAO3a0Jm/ptibOQ17TaWpFZXhwD0/Mzh02qFJ3mLuBGOwIO5PcqkYoBRONHfqc9RXgfZy3HAPTK67/fTQ/a8l+Zr+DcYtGINlM9arL/SEJBvSHP4DmQNMwtxz5iV5kSCw1hLFJK0XAftQs58JmDAwBqdogRoCFJsD9wAAtMsN9wdkQ1GtZDFJR888avHj1II9XpbkyWIonsa4uZNa9qyP7tx2wXbZQyn4NHjvfdSKtnXhh6UO3AOT7wStld9L8ptJbpOG/l2+b89axrhF7MLokcOSXJHm8PI0hxviAGjLUn0Oay0m6cdJPi4G9mGTR9jciWHRBgfuAQrOgXsAANqyY/u6LUm2SKJubCjSE2655wEnmztRKwrkEhFA8U2f9Y7HJHl6P772gDaif1OYWhXglvtbx7YM/1DNgSnNmq2V25LxX3Xonof1ORFYd6JWFNxYr7/gXya5Ms3hR8geYALmnjMjyRsFYa2FMThJH8no6XerA/uwydyJuZM2PC7zLn2aGACKy4F7AAAmo0O33Bd7M6dhrwl6zYF7Mjh02lOS/HdJFLk/apDloVYdcOPObRd8RgxQCh263d7cif7NlLjdHuhMN2it3Jakgofu9TmxY2CgVnTYa5Ncnebw40UBcFBvSDJD/0atRDFJV4iAfRpdekeSb9freTRhYAxOkVvuAQrMgXsAACZjgwgOxIaiWslikhy4J0lOsl8BFKhnud0eymNRP7/4gF98gVKPwQ6+AblOrYGOzZytFRU9dK/PTUVDFlDuMegREUZ3vCDJF9IcnisKgANaKgL9W62YpK1JPisGDsAt9+ZODIt2OHAPUGB+gR0AgMm4ui4v1C33exMGXefAfc0NDp02kOQt5k7UioLY4aYCKJUOHrjXE/RvyqzPezluuAc62+kqeehe/8a4BWOwysb69YXn7Dl0/4tqALAPc8/51STPEgTWWmWPom/f4JUZPX3MAOEANpkwUCvasEgEAMXlwD0AAG3bsX3dd5J8vTN/m80c+s0YLFAWz5x51OJHqEOt/WaSWWIovsa4udPcXgt/s3PbBXeJAUpjoQjQv5mKDvzQ9N4kN0gS6HhX+Omh+5ck+Q9p6N/l+PasZYxbxC6MPnlskqvSHP49UQA8zDJ9DmstpmC9CDiIEY+wuZMK16rzX+r4zLv0EDUEKCYH7gEAmKwNIjgQG28wCYckea4Yaj13vk0G6N8UqFaXyBnKYfqsd8zZ80vlfTXg5heo+xi8fmzL8L3qDHRlBm2tuC3JC6t10z2T1RCBtQxqRcH19fLTRyT5SJrDf6QOAHvMPWcoySsEYa2FMThJmzN6+s1y56DjxNyJuZOJG0zyTDEAFJMD9wAATNbVnfurir2Z07DXVJpaUQnzRVBPg0OnPinJy8ydYAwWxKd2brvgVjFAaSwwd+pzsLc+7eVslDzQ1Y7305vufzXJqP4NeB7VCg70lijJuWkO/580h31OC0Byyp4P/9e/UStRTMYVIuCgRpf+MMk36vc8mjAwBqdgkfoBFJMD9wAATNa1dswORjxqJYtJcOC+vt6a5FDPY3k0xtWKSvcst9tDufhhtPc+akVHTPEHpw7cA93vDj89dP/LSW6Shv5d7G/PWgY8IsIogD9J8rdpDh8mCqC25p5zWJLFgtC/1YpJ2p3kQ2JggjZ5Hs2dGBZtWCBUgGJy4B4AgEnZsX3dD5JcX5fX65b7vQmDrnLgvoYGh05tJDnJ3IlaURC3J/mEGKBUCnPgfkAb0b8pTK36sJczor5AT2bS1orvJfm1JF+VRn25rti6E7Wi6MaK8o28Ickn0hw+Uk2AmnplkieKAWvIqkXRs2/wUxk9/bsGBBNU058RmDvVikly4B6goBy4BwBgKjZ07q+ymUO/GYMFyeJ5M49a7L1q/fxaktliKB+33JvbK+qvdm67YEwMUA7TZ71jWpLjzJ3o3/TZf41tGf6mGICedYifHrr/5XL/Iq8+J3YMDNSKHvmNJFenOfx4UQA1tEz/BmNwCtaLgDZs8gibO6l4rTr7pY7NvEunqx9A8TjEAADAVFwlgoOx8QZtOjJJUwy1c4q5E/2bgtTqniTvkyuUyvwkhfpB9ICbX6DUY3CSPzx1uz3Q+9m0tWJHkhd19oNxKVOfa8gCyj0GPSLC6K2FSa5Nc/hoUQC1MfecY5P8oiD0b5ikO5N8TAy04foku82d6N9M0KHdu1gAgKlw4B4AgKn4XJL7O/fXFXszp2GvqTS1ovRsJNbI4NCpj0vyCnMnGIMF8eGd2y74nhigVBaaO1Er9qeHezkbpQ30pfu1VuxM8ptJPq5/g3GLMUjRjBXtG5qX5AtpDj9dbYCaWCoCrLWqHEXXv8GPZvT0XQYCEza6dFeSr5owgDacIAKA4nHgHgCASduxfd1P/ELxRNhQVCtZtGm+/GvlTUmmeR7LqzGuVlSqZ10sTyidE0XgvY9a0WmT+AGq/TGgf52iteLeJK9McqU09O/ifXvWMsYtYhdGwTxlz6H740UBVNrccx6V5A/0OTAGp+AKETAJmzzC5k4qXqvOfqmFagdQPA7cAwAwVRtEAHSYA/c1MTh0aiPJ4nq9aj+MUSsKbPPObReMiAFKp5A/hB7QRvRvClOrHt1ybw0B9HdWba3YneQNPkSsfhoisO5ErSi4sSJ+U49LsiHNYR9iCFTZW5IcIQZrLYzBSbrD70QySZv6OG5B/y4fB+4BCsiBewAApurqzv51xd7MadhrKk2tKDUH7uvjl5LMFQPo3wVxkQigXKbPeseje7OWMHeif3NA3xzbMvwDMQB97xatFePjrRXLkpylzyF2DAy1goOYmeSaNId/TRRA5cw9p5Fkif6NWoliCq7M6OljBgCTMFLf59HciTE4mZVr5l36SLUDKBYH7gEAmKrrktwthoOxoahWsmjDk2cetfgJ8q+FxZ7HamiMqxWl71n/leTDcoTSKfQnvg/4xRco9Rhs44eobrcHijW7tlYsT3JqUa/U1ec6ryELKPcY9IgIo38OT/LPaQ7/liiAivmNJHPEoH+jVlNwuQiYpK8l2el5NHdiWExQI8kJAgUoFgfuAQCYkh3b192d5PN1es1uud+bMOgat9xX3ODQqY9O8ipzJ2pFQbxv57YLfIgUlM9CEaB/MxFd3su5TsJA4bpha8V7k/x+kvv0bzBuMQbpt0J/Bs4jkvx9msOvViegQpaKAGutOkXR8W/wKxk9/WsKz6SMLr0/yVdMGKgVbVggAoBiceAeAIBOuKazf53NHPrNGCxAFsfJvvJen2S6GKrDLffm9pIH8h4xQCmdaO5E/6YA3HAPFLNztFZ8NMlLkvxYGvp3/789axnjFrELo8CmJflAmsN/IAqg9Oae89QkL9PnwBicgitEwBRt9AibO6lBrTr3pRy4BygYB+4BAOiEa0QwETbeoA1uuK++xeZO9G8KUqtP7tx2wRb5QSkV/ofPA/W7+QUqNQYn8IPUe+t9Ww1Q+Fm2tWJDkhcm2S6NamuIwFoGtaLgxor+DQ4kudyhe6ACTrU8ttbCGJziou0D8mSKNpk70b9pw0IRABSLA/cAAHTC5s7fklPszZyGvabS1IrScuC+wgaHTj0xyXPMnWAMFsTFIoDymT7rHU9L8nhzJ2rFRHVpL+crY1uG75EuUOiu2FrxlSQnJvm6/g3gvQ8cwAOH7t8sCqCU5p7ziCQn69+olSim4KqMnu5DC5mqzfV+Hs2dGINtOjrzLn2SugEUhwP3AABM2Y7t6+5P8llJTIQNRbWSxQTNnXnU4iNkX1lv8zxWU2NcrShdz/pmkk/JDUppkQi891EreuEgP0wdkRBQig7SWrE1yS8m+Yw09O/+fXvWMsYtYhdGSd4CrUtz+DRRACX06iSPFYP+jVpNweUiYMpGl34jyQ89j+ZODIs2uOUeoEAcuAcAoFOurtsLdsv93oRBV96vPlcM1TM4dOrMJK+RhLlTrSiIS3Zuu0CBoZxKc+B+wCyjf1OYWnVhL+c69QNKM9u2Vvwoya8n+bA0qqkhAutO1IqCGyvTN3tJmsNvUjOgZJaKAOq8nJ7yN3hXko8pNB2yyYSBWtEGB+4BCsSBewAAOmVD5/9Kmzn0mzHY5yyOk3slvTbJEWKoLrfcm9tLZGeSdcYBlFafDtzrc+jfPIgb7oFydZHWinv37M38H30OsWNgqBUcxPvTHP4DMQClMPecBUkW6N+oFVPwjxk9/S4x0CGbTU16AjWpVWe+1AlqBlAcDtwDANApNyb5vhgmwsYbTNB8EVTSYnMn+jcFqdWVO7dd8CN5QflMn/WOaWX7cKaB6t/8ApUeg/v5geoPk3xT7YDSzbitFePjrRXv3LNHc79EqtXnGrKAco9Bj4gwivdW6HKH7oGSWCYC/Ru1mqL1IqCDNnoegTa44R6gQBy4BwCgI3ZsXzeW5Nq6ve6G/c69CIOOc+C+YgaHTn1+kuMlYe7EGCyIi9UfSuvYJI8wd6JWTEYH93JGxrYMG2RAebtka8VlSV6a5Mf6Nxi3GIP0yljZvuEHDt2/Vu2Awpp7zuOSvFoQWGuJYgrf4PYkVyswHTQiAnOnWtGGR2fepXPEAFAMDtwDANBJV3X+r7SZQ78Zg33M4rkzj1p8iNwr5WTPYz00xtWKwvesz+3cdsENcoLS8gnv3vuoFT23jx+qbpQKUPqO0lrx70l+Icnt0qh5/x6XBWoldmFwwLdDf5vm8G+JAiiok5JM1+fAGJyCKzN6+m4x0DGjS7+T5A6PsLmTmtSqM19qgZoBFIMD9wAAdNIGEUyUjTeYgCOSPF0M1TA4dOpgkj+QBPo3BeF2eyi3RWX8pge0Ef2bwtSqQ7fcO3APVGP2ba34+p711XXSqIaGCKw7USsKbqyM3/S0JH+f5vB/Uz+gUOaeM5DkNEFYa8EUx+AVcqMLRro8bkH/rhYH7gEKwoF7AAA6Zsf2daPd+WTOYm/mNOw1laZWlNJ8EVTGa5LMEIO5E2OwAL6b5B/UHUqtAAfu9W+MQdr5ZTmAgneV1orvJnlRkg/oc5YXYGCoFezHtCSfSHP4l0UBFMjLkhyjf6NWopiCr2b09BsUli4Y8TyaOzEG27BIvQCKwYF7AAA6zS33E2ZDUa1kMQEO3FfHSZ7HemmMqxWF7Vnv3bntgnvlA+U0fdY7HpXkGZLw3gdjsB/2+sHqbWNbhr+vXkClZuDWiruTvD7Jn1kUlL/PNWQB5R6DHhFhFNfhST6Z5vAJogAKYokI9G/Uaorcbk+3bPY8mjsxLNowP/MuPVSQAP3nwD0AAJ12dR1ftFvu9yYMOuo4EZTf4NCpz03yC5Iwd6oVBbA7yaVigFJbUOZvfkAb0b8pjCnu5bjdHqhmx2ytGB9vrXhXkt9Jcpf+DcYtxiDdMlbmb35mkn9Nc9gHIgL9Nfecpyd5iSCw1hLFFL7B8SRXKihdskkE5k61og1HJHmWGAD6z4F7AAA67Zru/LU2c+g3Y7BPWbjhvhreJoJ6csu9ub2A/nHntgvuUG8otYXmTjAGC2CjCIBKd5jWin9K8otJtkrD8sJaBrUSuzDYh8cluSrN4aNFAfRRRW631+cwBvvo6oye7mfHdMfo0h1JRj3C5k5qVKupf6lF6gXQfw7cAwDQUTu2r9ua5DZJTJSNNziIJ8w8avGTxVBeg0OnPiLJ682d6N8UpFYXywRK78Syv4CB6tz8ArUcg3t+uOrAPVD92bi14oYkJyT5jDTK2ecawgbvfSi4sbK/gKOT/Huaw49XS6Dn5p4zmOQtgrDWgimOwSvkRJdt6sK4Bf27uhaIAKD/HLgHAKAbannLfcNeU2lqRem45b7cXpXk0WIwd2IMFsDXd2674NPqDKW3sFjfjv6tz1Fmk9zLuT/J9dIDatE9Wyu+l+TFSS7Sv8G4xRiEfXhmkn9Oc/hIUQA99rokj9S/UStRTMGuJB9VSLpsxPNo7sQYbIMD9wAF4MA9AADdcI0I2mFDUa1kcRAO3JfbyZ7HemuMqxWF6VkXyQLKbfqsdzw1yRMk4b0PatVnXxnbMnyPGIDadJrWivvGWytO37PHc69EatC/x2WBWoldGLRlQZK/T3N4miiAHlomArDWmqKPZfT0n6g9XbbJ82juxLBow3Mz79LDhQjQXw7cAwDQDbU9cO+W+70Jg445TgTlNDh06jOS/IokzJ1qRQHcmeQKMUDpLarKCxnQRvRvClOrSezljKgPUMuZubXifXv2eb4jjfJoiMC6E7Wi4Maq8kJekuTSNIe1HqD75pz9S0meJwhrLZjiGFwvH3rgK0nuF4OeoFZM0CF+Vxag/xy4BwCg43ZsX/efSb7Wnb/dZg79Zgz2IQs33JfXYhEQt9yb24vhb3Zuu+BO9YXSW2juBGOwAK4TAVDbjtNasTHJ8Uk+r89ZXmBgoFbwEG9OskoMQA8s1b9RK1FM0XeTfEoB6brRpXcnudHzCJpWGxaoFUB/OXAPAEC3XC2CdtjxhAOYM/OoxUeKoVwGh049LMkbzJ3o3xSkVu+RAVTCiVV6McW/5V6fwxjcDzfcA/WenVsrtid5UZILpFGOPteQBZR7DHpEhFEuf5bm8GliALpmztlPSvK7gtC/Uasp+mBGT9+t5vTIJs+juRPDog0LBQjQXw7cAwDQLRvq+sIb9tD2Igw681gleZ4YSucVSR4vBnMnxmABXL1z24U3qyuU2/RZ7zh0z22q5k7Uis6/6Zz4sPhRklslBtS+m7ZW3DfeWvGHSV6fZKf+DcYtxiBTMVa1F3RRmsMvVVegSxYnmZYxfQ5rLVFM6Rtcr3D00CYRmDvVijY4cA/QZw7cAwDQLRu699sBNnPoN2OwD1nMl3XpLBYBe2uMmzvpm4tFAJVwbJJHiMF7H9Sqz0bu3zIsbIAHuk9rxZVJfiHJbdKoYP8elwVqJXZhMCkDST6S5vBxogA6as7ZhyY5RZ8DY3CKbs7o6V9Wa3poxCNs7qSGtZr8l5qTeZc+Wq0A+seBewAAumLH9nU7klwviXbYeIMDcOC+RAaHTp2d5NfMnejfFMC3knxCDFAJlfwk9wFtRP+mMLWa4C33I2oC8JCZurXixiQnJPknaRRXQwTWnagVBVe5W+4Hk3wyzbVHqy3QQa9IctTPp07921oLJjUG3W5Pr309yU5zJ/o3bThBBAD948A9AADddFX3/upib+Y07DWVplaUhlswyuVkv8dr7sQYLIj37tx24f3qCZWwyNwJxmABXCcCgH10oNaKHyX5nSR/kmS3Pmd5gYGBWsFPD8WOfzLNtTNEAXTIUv0btRJFB77TKxSMnhpdujvJlzyP5k6MwTYsVCeA/nHgHgCAbtoggnbZUFQrWezHc2YetfhQWRff4NCphyZ5q+eRfWmMqxU9dW+Sy8QAleGHyt77QBG44R5gfyuG1orx8daKdyf51STbJVK8tVZDFlDuMegREUY5HZvkA2muPUQUwJTMOfvZe95roH+jVlNxbUZP/5Ya0wcjnkdzJ4ZFGxYID6B/HLgHAKCbPpvkvrq+eLfc700YTNkjkjxDDKXwsiRPFIO5U60ogL/bue3C/xQDlN/0We+YmeSZVX19A9qI/k1hanWQvZzW/VuGv6ceAAeZtVsrPpdkfpKrpQHWnRiDtGOsqi/sZUlWqy8wRUv2PXXqc1hriaKtb3C9QtEnm0Vg7lQr2uAyAoA+cuAeAICu2bF93c4k13XvK9jMod+MwR5nMV/OpbBYBByIW+7N7T10kRpCZSwsxYWc3iNgDFad2+0BJtqNWiv+M8lLkizv7OlBfc7yAgMDjMGS1uqdaa59gyyASZlz9swkb9TnwBicoruTfFRt6ZMRj7C5k5rWanJf6smZd+mQOgH0hwP3AAB02zUiaJeNN9gPB+4LbnDo1Kck+U1zJ/o3BXD9zm0XXicGqIzKf4L7QDlufoG6j8GN6gDQxszdWrF7vLXirCQvTrJdIsXocw1ZQLnHoEeEcvvrNNe+QAzAJLwxyZH7/bduubfWgon5eEZP3yEG+mJ06X8k+S9zJ/o3bXDLPUCfOHAPAEC3dfnAfbE3cxr2mkpTK0rBgfviO6k8t8+aO6HiY9Dt9lAti8ydqBW9coC9HAfuASbTbVsrNuzZ1/t3/RvrTjAGOZixKr+4w5L8Q5pr3dIHTNycsxtJlggCay1RdMDlCkSfbfY8mjsxBtuwQI0A+sOBewAAuu26JLvE0C4bimoli304TsbFNTh06iF7Dtx7Hjmoxrha0VU/TPJBMUClLBKB9z6oVZ/dn+R6MQBMsjO1Vvxnkpck+dMkuyVSwv49LgvUSuzCoCO1euKeQ/fTZQJM0IuSzNPnwBicou8l+ZSa0mcjnkdzJ4ZFGxy4B+gTB+4BAOiqHdvX3Zvkc3XOwC33exMGU/LYmUctPloMhfWSJOpj7lQriuD9O7dd6AOfoCKmz3rHMXt+GbvyBrQR/ZvC1Gofezk33L9l2PoCYCqzeGvF+HhrxXCSX0lyu0T6pyEC607UioIbq/oLXJjkEnUGJmjZxKZO/dtaCw7oQxk94z4x0GcjIkD/pg0LMu9SW7kAfeDAPQAAvXBNd/96mzn0mzHYwyzmy7iwFouAdrjl3tzexW/WL2tCtZT0dnt9DmOwYvwiHECnOlRrxRf27PF9RJ+zvMDAQK2o7Rh8a5prl8gEOKA5Zz8lyW+ZO1ErUXTAFQpDAWzyPJo7MQbb8MgkT1cjgN5z4B4AgF64WgSTYUMR9sGB+wIaHDr1yUleZu4EY7AA/nXntgv/QwxQKQvr9GIH/OILFHUMbpQ9QAdn89aKH423Vrw6yclJ7pJI7/tcQxZQ7jHoERFGNZyX5tpfFANwAKckOUQM+jdqNUW3ZvQMH6hK/40u/W6Sb5k7zZ0YFm1YIDiA3nPgHgCAXvhykh/XOYCGPbS9CIMpceC+mN7ilx3MnRiDBXGxWkHlnGjuRK3oh4fs5ThwD9CNDtxa8b4kz0/yFf0b604wBtnbWB1e5LQkf5fm2ieqN/Awc84+LMnb2ps69TmstUSxT5crCAXiZw3mTrWiHYtEANB7DtwDANB1O7av251kQ3e/is0c+s0Y7FEWDtwXzODQqQN7biODtjXGzZ101H8k+TcxQHVMn/WOQ5McLwnvfVCrPtuRZFQMAF3qVq0Vo3s+ZOndmlfcqm0tY9widmHUrVZPTvLBNNf6UGfgoV6V5Ali0OcwBjvgSjWkQDZ7hM2d1LhW7X8pN9wD9IED9wAA9MqnRTAZNt7gIZozj1o8UwyF8mtJnmbuBGOwAC7Zue3CMTFApTw3yeF1e9ED2ggUZq2155b7TfdvGfZkAnRzZm+tuGe8teJPkrw4yR0S6VGfE0Hl1zKoFWVXm63OFyVZqd7AQyyZ3NSpf1trwYN8NqNnbBEDBbLJ3In+TRvmZ96lh4oBoLccuAcAoFeu6v6XKPZmTsNeU2lqReEdK4JCWSwCcyfGYAHsSrJOjaByFpo7USsKYEQEAD3qxq0V1+z50KWP6N+WTRgYqBW1GoN/mubal8kGSJLMOfu4JC8QhP6tVqLogCsUgoLZ1Jeno/BTk7kTY3A/HpHkeeoD0FsO3AMA0CtfS/J9MUyGDUW1ksVDzJdvMQwOnfqEJK/wPDIVjXG1oiM+uHPbhT8QA1TOQhF474NaFcB1IgDoYedqrfjheGvFq5O8Kcmd+nd3NWQB5R6DHhFhVMvlaa59ihiAJEtFoH+jVh1w78Q/0A96ZHTpnUlGzZ3mTgyLNiwQGkBvOXAPAEBP7Ni+bjzJ1XXPwS33exMGk+bAfXG8Ick0MZg7UasCuEgEUEkn1vWFD2gj+jeFqVVj3A33AH2Z6VsrLk/ynCQbpIG1DFBfY3V6sY9O8sE01x6q7lBjc85+TJLXTW3qtNbCel8USZKPZ/SMHykCBbRJBOZOtaINDtwD9JgD9wAA9NI13f8SNnPoN2OwB1k4cF8Ag0OnNpIslgSd4JZ7c/sUXbdz24XXqw1Uy/RZ75iRZJ65E4zBPrv9vtuHvysGgD51sNaKrUn+W5IzkuzS5ywvMDBQKyo/Bn8xyXL5QK29OcnhYtC/MQY74Ao1o6A2eoTNndS8Vu19qYVqA9BbDtwDANBL14hgsmy8wV6eM/OoxW5V778XJplr7gRjsADcbg/VtDBJo84BFP+We32OWozBjXIG6PNs31oxPt5acWGSY+s1L/durdWQBZR7DHpEhFE9f5rm2l8XA9TQnLMHkiwRhP4NHfCDJP8iBgqqAzfcmzvRv2vk2Zl36aAYAHrHgXsAAHpmx/Z130zyre5/pWJv5jTsNZWmVhTWYdW57bTUThKBuRNjsAC+l+Tv1AQqqWKf1K5/qxUlNSICgIJ06NaKb+y59fZPk9yrf2PdCcZgfYzV7QU3kqxPc+0T1B5q5yVJmp2ZOvU5rLVqHsWHM3rGfcKnoG5Icl+NnkdzJ5rW1AwkOU5tAHo78QIAQC+55X7SbCiqlSz2Ml+2/TM4dOpjkrzK80gnNcbVikm5dOe2C+8VA1TSIhFYa6FWBXCdCAAK1M1aK3aPt1YMJzlhzy8n69+1+fasZYxbxC6MmtXqiUnel+bahpygVpaKQJ/DGOyQ9WpFYY0uvace+1ro33RwWCwUGEDvOHAPAECvOXDvlvuHEAaT4sB9f70hyXQxmDtRqz7bneS9YoDKcuA+yYA2on/Tz1rtTvJlGQMUcPZvrfhqkgVJVu+Zr5kipxmtO1Erim6sji/6ZUlOU3uoiTlnPy3JSzs7derf1lrU1DczesYXxUDBbTJ3on/TBgfuAXrIgXsAAHqtRwfubeZAxTlw318ni4BucMt9mRSiVp/Yue3Cb6kFVM/0WW9/SpInmTvBGOyzG+67fXiXGAAK2tVaK+4bb6348yQvSDKqz1leYGCgVlRyDL47zbXz5AS1sMTnQOnfaiWKDrlC4JTAppo8j+ZONK3OWKAuAL3jwD0AAD21Y/u6bUm+IYnJsqGoVrLYw4H7PhkcOvUFSZ5jDIIxWAAXigAq60Rz588N+MUX6NcY3CRbgBJ0gdaKkT17hf+3mrfd926t1ZAFlHsMekSEUU2HJ/lAmmsPEwVU2JyzD0/yVkHo36hVhzhwTxmMmDvNndDGsJideZc+VmAAveHAPQAA/XCNCJKGPbS9CIO2PXrmUYtniaEv3G5v7oQiuCXJBjFAZS3Uv1ErCmCjCABK0rVbK+4eb634n8n4iUlulAjWnWAMVtNYXV/4/CT/W/2h0l6T5DHdmTr1Oay1ahbFFzN6xm3CpgRuSfITMZg71Yo2uOUeoEccuAcAoB+u6s2XsZlDvxmDXc7iOLn21uDQqTOTvFoSdFNj3Nypz03IxTu3XWiwQHWdKALwPrUAHLgHKFuXa63YnOSEPYfy7tW/q/jtWcsYt4hdGDWt1TvTXGu/CKprqQj0OYzBDlmvNpTC6NLdSb7kETZ3olZtfCkH7gF6xIF7AAD64VoRTIWNN9hjvgh67vVJjjB3gjHYZz9JcrkYoJqmz3r7IUmON3c+2EDho1ArKjcG79xzwwwAZesIreX3jbeWr9izpvThKW1qiMB6GrWi4Gp7y/0hSf4mzbWHGwNQMXPOPjHJ87s7derf1lrUxL1JPiwGSmSTuRP9mzYsFAFAbzhwDwBAz+3Yvu57SW7ozVcr9mZOw15TaWpFITlw33snicDcCQUYg5fv3Hbhj2UPlfWc8n7Aj/6tVlTIyH23D4+JAaDEXby1/GtJfjHJHyfZJRHLJgwM1IrSj8FnJHmXrKBylohA/1YrUXTIv2T0jB8ImRIZMTWZOzEG2+CGe4AeceAeAIB++bQIpsKGolrJwoH73hocOvX5P79t1hikuxrjasUBXSICqLRFIrDWQq0KYEQEABXoeK3lu8dby89L8uwkG/RvaxnwiAiD0jsjzbW/LAaoiDlnPz7JqwWB/q1WHbJeTSiZTRV+HlErOj8snph5l84SFkD3OXAPAEC/XCWCn3LL/d6EQVueOvOoxY8UQ88sFoG5E7UqgE/v3Hbh18QAlbbQ3LlvA6LQv+llrTbKE6BCHaK1vJXkv+3Z39ohkQNriMC6E7Wi4Mbq3qben+baw40DqISTkxzWm6lT/8YasuJR/CjJPwuXUhlduiXJ9wVh7lQr2rBQBADd58A9AAD98tkku3vzpWzm0G/GYBezOE6m3Tc4dOpgktdKgl5yy70+tx8Xyxsq70RzJxiDBeDAPUDVOl9r+fh4a/llSZ6V5KMSsbzAwECtKO0YnJNkhbyg5OacfUiSUwWhf2MMdshHMnrGPepBCY14hM2dqFUbX+oENQHoPgfuAQDoix3b1+1IslkSU2HjDZLMF0FPvCbJDHMnGIN9dkeSj4kBqmv6rLfPSDLP3Ll/xb/lXq2oxBjcet/tw9+RJUBFO0Vr+bfHW8t/L8nLk2ytYZ+bkIYsoNxj0CMijOr74zTXOmgA5fayJLPEgP5Nh1wuAkpqk7kT/Zs2uOEeoAccuAcAoJ+u6d2XKvZmTsNeU2lqReE4cN8bi0Vg7oQCjMFLd2678H5ZQ6WdUK+fW+jfakVBud0eoA7dvbX8k3tuu/+/SXZLBOtOMAbLZazuARyS5P1prp1mLEBpLev91KnPYa1V0ShaSb4gVEpqkwjMnRiDbTgh8y51DhSgy0y0AAD00zUimCobimpV+ywcuO+ywaFTn1u9T0f1PJZFY1yt+Jn7klwqBqi8RSKw1kKtCsAvuAHUpRO2lt813lr+P5McX54PXHGrtrWMdSdiF4Za7fHcJO+UGZTQnLOfkeTFgtDnMAY75IqMnuFBoKxGPMLmTmhjWMxI8gxBAXSXA/cAAPTTF5LcIwZgCp4986jFbq/oLrfbl4YfxqhVpX1057YLvyMGqLxF5s6DGxCF/k23a3WdDAFq1jlay29M8oIkS5PskMhPNURg3YlaUXBjIkj+V5prm2KA0lnSv6lT/7bWooKuEAGlNbr0e0m2mDvRv2nDAhEAdJcD9wAA9M2O7et29vaXmIu9mdOw11SaWlEohyZ5thi6Y8bQKY8YyPgbJEF/+6OeoH8nSS6WL9RCDW+41+cwBgtmd5IviwGghh2xtXxsvLX8kiTPTPJhiVheYGCoFZRiDD4iySUygxKZc/ZgkjcLQv9WKzoUxUhGz7hVmJTcJlOTuRNjsA2L1AOguxy4BwCg364RwVTZUFSr2mdxnDy75lVJHmkMAn12w85tF35ODFBt02e9/egkT9a/J2bAL75At8bgTffdPnyX/ABq3EFay78z3lr+miT/PUmr7mut4t9yb92JMegREQb5jTTXvkYMUBpvSDJTDOjfatUhl8ueCthUkecRtaI3w+IEIQF0lwP3AAD0mwP3e3HL/d6EwYTNF0HXLBaBuRO1KgC320M9nCgC9G8KYKMIAMhPD97/W5JnJ1mZ5B6JYN2JMUgxjYngp85Nc+0jxQClsKT/U6c+h7VWRaK4P8mHhUgFjIjA3KlWtGF+5l06TQwA3ePAPQAA/bYxSQ9vDrOZQ78Zg13IwoH7LpgxdMozkvxSkgwYt/RZY9wYrHGf+1GSK+UKtbDA3AnGYAH4xTYAft4hW8t3jbeW/+Weg/f/on8X9duzlrHuROzCUKs8ac+H5ABFNufsX0nyXEHocxiDHfKvGT3j+3KnAr5ciE/S0kYET3FqdeAvdZjflwXoLgfuAQDoqx3b192X5HOSmCobb9SaDcTuqMHt9uZOjMES+Jud2y7cKQaohUXmzvYMFD4KtaKUY/A6uQHwsI7SWn7beGv5/0jy8iT/UbfX3zAErKdRKwrOLfd7LElzrYO8UGxLizN16t/WWlTAFSKgEkaX3pnkFnMn+jdtWCACgO5x4B4AgCK4qrdfrtibOQ17TaWpFYUxc+ZRi58mhs6ZMXTK9CRv2vufueXe3Al9GIPjSS6RJ1Tf9FlvPyTJCeZO1Io++0mSm8UAwH5XAa3ln9xz2/3/TnK3RADvfaBQY/CQJBfJDQpqztlPTvJKQejfqFWHovhxko8LjwoZMTWZO9G/2+DAPUAXOXAPAEARfFoEnWBDUa1qncVxsuyo307yWGOQImmMq1UNfWrntgu/IQaohWclGRSDtRZq1Wcj990+7GpIAA7cMVvL7x5vLV+xZw37Cf27KN+etYx1J2IXBkmSX0lz7WvEAIV0SpJDxYD+rVYd8pGMnuGD8KiSTeZOcye0MSwWCgigexy4BwCgCL6c5Idi+Dm33O9NGEzIfBF01CkiMHeiVgVwsQigNk40d07OgCj0bzpZqxF5ATDhDtNa3hpvLf+tJC9LclvVX29Dya07USsKzmeH7eXdaa71wY5QJHPOnpZkcfGmTv0ba8gSR3GF0KiYTSIwd6oVbXhm5l06QwwA3eHAPQAAfbdj+7qxJJ/p7Ve1mUO/GYMdzsKB+w6ZMXRKM8mv7evfDRi39Jlb7ms1t29J8s9yhNrwCezeI2AMFoED9wC03z1by/85ybOT/HmSnRKxvMDAUCvo+xgcSvJO2UGh/E6SJ4tB/4YO2dr73zOErvtKknu1Ef0btZrglxpIcrxaAHSHA/cAABTFVSLoBBtv1JYD951zkrkTjMECeM/ObRe6lgnq48T2/4i58wHFv+VerSjNGNwoKwAm1Wlay+8Zby1fnWRukg9Uda1V/FvurTsxBj0iwuBnzkxz7dFigMJYKgL0b7XqoCszeoYBQbWMLr1vz6F7cycwUS41AOgSB+4BACiKDb3/ksXeUGzY7yxNrSiEp8w8avFjxDA1M4ZOmZbkrQf6b9xyb+6EHozBe5K8T35QD9Nnvf3IJM+ShP6tVvTZHffdPvxtMQAwpdVBa/kd463lf5DkF5JskgjWnRiD9JbPL93L4UnWiAEKYM7Zz0nyK8WdOvU5rLVKGMV6YVFRm0Vg7lQr2uDAPUCXOHAPAEAh7Ni+7mtJvisJ6sWGYoezcMv91L0syRONQYqsMa5WNfChndsu/C8xQG2c4GcV1lqoVQFcp/YAdKybtpZfl2RRkjcl6cEHurhV21rGuhOxC0Ot9uH1aa49QX7Qd8tEoM9hDHbQ5oyecbN8qaiN2oi5E7Vq40stUAeA7vBLbAAAFMk1IugEG2/UlgP3U/c2EYD+XQAXiQBqZZG5c+oGRKF/M9VajcgIgI52ntby8fHW8suTPGPPDbt3V+F1NZTWuhO1ouDccv+QtnWOGKCP5pw9M8nriz916t/WWpTIFSKgwjaZO9G/acMxmXfp48UA0HkO3AMAUCR9OHBf7M2chr2m0tSKQjhOBJM3Y+iUY5L85kT+2wHPo7kTujcGR3Zuu3Cz3KBWFopA/8YYLICN6g5AV7pqa/lPxlvL/1eSZyX5e8sLMDDUCno6Bn85zbUvlx/0zVuSDIpB/0atOhTF/Uk+KCQqbDTJT0xN5k707zb4XQuALnDgHgCAInHDfcfYUFSrWmbhhvupeatLqjyPZdEYV6sKu1gEUDsnisBaC/o8BseS+MAfALrbhVrLW+Ot5a9K8sIkN5R5rVX8DUTrToxBj4gweJB3pbnW78lCr805u5HkNEGgf6tVB/17Rs/4T7lSWaNLx9xyj1rR5rBYIByAzrORCABAYezYvu4/ktwuiQdzy/3ehMEBzZt51OLpYmjfjKFTDtlz4B5zJ2rVT99P8mHjAOpj+qy3H5XkKHNnZwyIQv9msm667/bhu8QAQE9WDq3ln0ly/J69uG9LBOtOjEE6b0wED/bsJG8QA/Tcf0vyjPJMnfoc1loliGK9cKiBTSIwd6oVbXDDPUAXOHAPAEDRXN37L2kzh34zBjuUxSFJniPDSXlpkqPb+QMDxi195pb7Ss7t79u57cJ75AW1skgE3iNgDBbARvUGoKddtrV8bLy1fF2Spyf5yyQd+uAXt2pbT1t3InZhqNV+rEhz7WEyhJ5aJgJ9Djo4Bu9M8jF5UgObqvkII3i16tKXcsM9QBc4cA8AQNFsEEGn2HijluaLYFJOEoG5E2Owz8aSvEf9oXY6dOBe/35A8W+5VysKOQZH5AJAX7pSa/nO8dbylUnmJLksye6yfO8N5QPvfSg4t9w/xKwkS8QAPTLn7FlJXl6+qVP/ttaiwD6a0TN2iYEa6OLPK8yd6N8V9LjMu/RpYgDoLAfuAQAomqv782WLvZnTsNdUmlrRd8eJoD0zhk45KsnLJvNn3XJv7oQOjsFP7tx24e1ygtpxw73+rVYUgRvuAejvSqK1/DvjreWL93yY6L9KBOtOjEHoinemufZIMUBPnOr30/Vv1KrDUVwuFGphdOnWJN81NZk70b/b4JZ7gA6zoQEAQKHs2L5ue5JRSXSKDUW1ql0Wbrhv31uTHCIGz2MZNcbVqkIuEgHUy/RZbz8kyQmSsNZCrfrsriRfV2sACtF5W8tvGm8tf2mSX09yYyX793hlvxhqJXZhUPxaPSnJMhlCl805e3qSkwWB/k0Ha3VHkmvlSI1sNneiVrQxLBy4B+gwB+4BACiiq0TwcG6535sw2K9jZx61uCGGiZkxdMrAngP3mDtRq3661foPamlekg7eKqbPPWBAFPo37dRq8323D++WCQCF6lSt5VclOS7JW/YcLCgkm7DWnagVRTcmgoc70y330HWvSvL48k6d+jcU0JUZPcPChjoZEYH332pFGxaKAKCzHLgHAKCIPt2fL2szh34zBjuQxZFJmvKbsBcnedpU/oIB45Y+c8t9Jeb2S3Zuu1AhoX5OFIH3CBiDBbBRjQEoZAduLR8bby3/myRPT/KnSXZYXmDdiVrBlMfgY91yD13nGdO/UatOR3G5MKiZkQI/j0C/H5KHf6nnZ96lh6gBQOc4cA8AQBFdY5uuk0RJ7cwXwYS9TQTmTozBPtuZ5G/UG2qpC5+0rn8/oPi33KsVhRmDbooBoNgdq7V813hr+XCS2UnOTnJ3kdZaxb/l3roTY9AjIgwexi330C1zzj4+ySJBoH/TwVp9JaNnfE1+1MxmcydqRRsGkzxTDACd48A9AACFs2P7uh8kuUESD9ewh7YXYbBfDtxPwIyhU56Q5Lc78Xe55d7cCVMYg+t3brtwh1yglvzipf6tVhTBdSIAoBSrjNbyH4y3lp+ZZG6SdUnGpGLdCcYgB6dd7INb7qF7Tq/G1KnPYa1VoCjcbk/9jC79fpKWIMydakUb/O4FQAc5cA8AQFFd3Z8vazOHfjMGO5DFcbKbkDcnmSYGqqAxbu4ssUtEAPUzfdbbB5M8RxLW+6hVn337vtuH71BfAErVlVvLvzXeWv7WJM9N8vHS9u/xyn4x1ErswqActfqjNNceLkfooDlnPybJawShz0EHx+BYkg/JjZoa0UYQvFq18aUWyB+gcxy4BwCgqDaIoJNsvFErbrg/iBlDpzSSnCQJcyfGYJ99Zue2C29UZ6ilE7r38wn9+wEDotC/OVit3G4PQHm7WGv518dby387yS8l+Xw/v5eGclh3olYUnFvu9+GJSd4qBuiotyZ5RHWmTv3bWosCuCq3nrFdDNTUJnMn+jdtOEEEAJ3jwD0AAEV1bZLd/fnSxd7MadhrKk2t6JujZh61+PFiOKAXJpnbyb9wwPNo7oT2x6Db7aG+FopA/8YYLIARdQWg9B26tfzz463lv5Tkt5J8zfIC607UCmNwwt6Z5tppcoQOmHP2QJIlgtC/UasOu1wE1Fgxf35R+KnJ3Eltx+D8zLt0uvwBOsOBewAACmnH9nU/8YvPnWZDUa1qlYVb7g9ssQg8j1XTGFerkvlOkn8QA9SWA/dYa1EEG0UAQGVWVa3ln0jyvCRvTHJbr9daxb/l3roTY9AjIgwe5ilJ/kAM0JG5878neZoc0L/pYK3uSvIxeVFjX04yZu5ErZjgsDg0yXFCAegMB+4BACiya0Swb26535sw2CcH7vdjxtApj0nySkmYO1GrPnvvzm0X3qe+UFsnmjt7Y0AU+jf7M5bkS2IAoFIrkNbysfHW8vVJnpnktCTbpGLdCcYgP38LxD68M821DTHAlC2t5tSpz2Gt1Ucfza1n3GUMUFujS+9K8nVBmDvVijacIAKAznDgHgCAIru6f1/aZg79ZgxOMQsH7vfvjUmmd+MvHjBu6TO33JfG/cn4pWKAepo+6+1PTnK0JLxHwBjss5vvu33tnWoKQCU7dmv5/eOt5X+VZG6SP07yX5YXWHcidmGo1T49M8lL5QhTMOfdzSS/ae7U56DDY/BKOUFGtBEEr1ZtfKmFsgfoDAfuAQAosi8muUcMnWTjjdo4TgT79TYRmDsxBvvsH3Zuu+jb6gq1tcjc2VvFv+VereiL60QAQNWNt5bvGm+ddV6Spyb5iyQ7uvn1in89sHUnxiCwT+8QAUzJklIsBSfLLffWWvTD9v5e0gOFscncif5NGxy4B+gQB+4BACisHdvX3Z3k8/37Doq9mdOw11SaWtEXz5h51OLDxfBgM4ZOeUGSZ3Xza7jl3twJE3CJCKDWFolA/1YrCmBEBADUZlXSOusn462zVu05eL82yV1Sse4EY7COxkSwby9Kc+3xYoBJmPPuI5K8RRD6N2rVYVfm1jN2qz304sB9VacmfY5ajsG5mXfpTNkDTJ0D9wAAFN0GEXSaDUW1qkUWA0meK7eHWSwCz2PVNcbVquC+unPbRdeKAWrNJ6tjraVWRbBRLQGoXRdvnfWj8dZZ/1+SOUnOT3J3/ZYX1p3WnYhdGGq1T265h8l5TZJHmzuBDvfvK+QDSZIbe7N3o397n0pFhkUjyQKBAEydA/cAABTd1SLYP7fc700YPMx8EfzcjKFTZib5fUlg7lSrPnO7PdTY9FlvH+jtgXt97gEDotC/2dvOJDeJAYDarlBaZ31nvHXWHyWZneTCJPd16u9uiNe6E7Wi4Nxyvx+/n+bao8UAbTu9HlOn/m2tRQ/dmFvPuEEMkGR06X1JPA/o37TDgXuADnDgHgCAotuU5K7+fXmbOfSbMTiFLBy4f7DXJzm8F19owLilz9xyX1g/diMB1N68JEeKwXsEjME+23zf7Wt3qyMAte/orbO2j7fOOmPPjffv7eTBe0tcDAy1gpKNwUOTnCJHaMOcd/+Cn8fr36hVF1yp3vAgI6Ymcyf6dxscuAfoAAfuAQAotB3b192f5NOS6DQbitSCH/A/2GIRmDsxBvvsb3Zuu+gn6gi1dqK5s38G/OILPGCjCABgr1VY66yt462zTu3Uwfvi33Jv3Ykx6BERBvu0OM21h4kBJmypuRP9mw7XatyBe3iYkT49j+hzlHNYLBQGwNQ5cA8AQBlsEMH+Neyh7UUYPMixM49a7H1vkhlDpzw/ybGSwNxJn10iAqg9P+DVv9WKIhgRAQDsY9Xy84P3z0zyt0l2S8W6E4zBKhoTwb49IcnviwEmYM676/e8jOlzWGv1wNW59Yw71BoeZLMIzJ1qRRuOzrxLnyQGgKlx8AAAgDK4ur9f3mYO/WYMTjKLI5I8XWZJklN6/QUHjFv6rDFuDBbMVTu3XTQqBqi9RSLAex+1KoDr1A8ADtDlW2f9x3jrrDf3/OB9T5cX1p3WnYhdGGq1T8vkCBPytiTTzJ3mTujwGLxCHvAwo0l+rI0geLVq40stkDvA1DhwDwBAGdyY5Adi6DQbb9TC/LoHMGPolCOTvNZQMHdiDPbZxWoH9TZ91tuPSPIcc2d/DYhC/+Y7992+dpsYAGACK5jWWd+c7MH7hvisO1ErCs4t9/uxKM21J4gBDmDOuw9Ncmo9p07921qLLtqZ5KNigIcYXTqeZJO5E/2btt7XAjAlDtwDAFB4O7avG0uyob/fRbE3cxr2mkpTK3puvgjy6iRH9uMLu+Xe3Al7bE3yCTFA7R2f5BAx6N/QZxtFAABtrjoffPD+siT3WeLivQ9qRYXH4ClyhAN6eZKjxWDuRK067J9y6xk/UWPYp82mJnMn+ncbfIgcwBQ5cA8AQFlsEEE32FBUq8pn4cC9XwzyPNZYY1ytCuKvdm67aLcYoPZOFAHWWmpVAA7cA8BkO/9PD94vTjInyXsPdvC++LfcW3diDHpEhME+vSbNtTPEAPu1zNyJ/k0XarVeDrBfI+ZO1Io2hsVCQQBMjQP3AACUxdUiODC33O9NGPzMcXV+8TOGTnlekgWGAeZOteqje5P8tZoB/f/Brj73gAFRGIP1NiICAJjiqqZ11tbx1lmnTvTgPdadGIMU1ZgI9u3IJK8VA+zDnHfPS/Jr9Z469Tmstbrgu0k+pbawXz5I2NypVrTj0Zl36RwxAEyeA/cAAJTCju3rbkny7f5+FzZz6DdjcBJZPHHmUYufVOOg3tbvb2DAuKXP3HLfdx/eue2i74kBSLJIBN4jYAwW4Jt14B4AOtVYf37w/qlJzk9ytyUu1p1AReaLk+UI+3Sa/m3uhC74YG49Y7cYYD9Gl96R5DvaCIJXqza+1AkyB5g8B+4BACiTDSLoBhtvVN78Or7oGUOnHJHkDcpv7sQY7LOL1QqYPuvtT0oyy9xZHMW/5V6t6Iqb77t97Z1iAIAOr9xaZ317vHXWHyWZ/dCD943if/cKiDHoEREG+7IgzbXzxQB7mfPuGUneLAj0b7rgchHAQW0yd6J/04aFIgCYPAfuAQAok6v7/y0UezOnYa+pNLWip+r6CzG/l+SRRfhG3HJv7qS2vrRz20UbxQC43V7/Rq0K4joRAEAXVzqts7bvOXg/K8naJHdJxboTY5CiGxPB/p0kAniQ1yeZIYYkY/oc1loddHNu/cPr1RQOqvi/d+HDvqFIY9DvZwBMgQP3AACUiRvuu8aGolpVOou6Hrh/mzHieeSnGuNq1Sdutwce4Ae6WGupVRGMqBUA9GBl0Drre+Ots/6/JE/dc/B+R7GXF9ad1p2IXRhqtU+vTXPtNFnCzyw1d5o7oQvWiwAmZLMI0L9pY1jMz7xLDxUEwOQ4cA8AQGns2L5uS5L/kMSBueV+b8IgqeOB+xlDpzwryS8pPeZOteqjHyT5oBoBeyw0dxbPgCiMwfrZKAIA6OGqp3XW98dbZ/1/jZ8evF8+qYP3WHeqFfSAW+7347FJ/ocYIMmcd/9qkmcLYu+pU/+21qJDxblCDDAhm8yd6N+04YgkzxIDwOQ4cA8AQNkU4JZ7mzkYgyXL4ukzj1o8WLNgTiraNzRg3NJnbrnvufft3HbR3WIAps96+0CxDtx7jwA1HYM7k9ykTgDQh1VC66wfpXXWWXtuvP/zJP9liYv3PmoFJRmDb5QjJJO/3R79G7U6oGtz6x9+Sy1hAkaX/iDJN01N5k707zYskjfA5DhwDwBA2Vwtgm6xoUil3/s+ry4vdsbQKdOTvEnZzZ0Yg33+pt6jNsAez0wyw9xZ0IWyX3yhPq6/7/a194sBAPropwfvV+85eP+nEz54b91JLYz79tSKYnrZ/8/ev4fbWdZ34v97LQ4BhIBnDRh2ki1GrRIs2cn03E6nnbGtbe202ta2OkqwhJLRme93SHBMaGvHJMzMb74lAdJDMtYerGOn1Y5tHQJ4JgEFrAdAsyGaTTzLRndQAnv//mBrAuSw197r8NzP83pdVy4VQ7L2+/N57vu5n7XudWfJxqeKgUYbvursJL9o7MT8TQ+8TQTQkVuNnagVHbTFhUIAmB0b7gEAKM2NIji+lmdohxEGSZJlDfpZX57Eh38wdjJI7z2w7+p7xABM883p5m/UqgpuFgEAVMQ9G76Veza8tZob7913gh5sqkkRHNlJSV4pBhpuVZITxHCkodM8h3utOfh2kr9RQ+jIbhFYp6oVHVguAoDZseEeAICijO/f/sUknxr8K/EwBz1YWBZN2nD/uqq+sLa+ZcBaU3qwT64WAXAYG+6x9lGrKvBBNAComplsvO/r7YX7TvediF0YanVENtzTXMNXnTy94d7YaeyEbnt37l4zLgboSBnvc5hGBE9VavXiLN12qrwBOmfDPQAAJXLKfc948EZtNWLD/RlnXzyc5CeU29iJHhygPUnepybAYSr6zenm7+9qi4Jm2CUCAKgoJ95b+6BWVIRT7o/iB7Nk40Ix0FAvT/IsMRxr6DR/u9dilt4mAujYbUkeMXZi/maGTkhygRgAOmfDPQAAJdpZjZdR7Yc5Lc+aiqkVffGi+QtWndCAn/N1VX+BTrk3dlJ7Ww7su9onM4EkybyFbzw1yfmSMH+jVgP2pYN7N+4VAwBU3GM33q9LMu62CffTagUV6MFWkl+WIw11iQiMnahVD3zFF7jDLNy1+kCSTxmazHOYvzuwXNYAnbPhHgCAEn3AV+z3kgeKalXLLE5N8rw6J3DG2ReflOTVesH1yLG1ptSqhx5MskMMwGFeMv3N6eBeS60Gyen2AFCSRzfe/5fpjfdXfm/jvftO3E97ecJgcF4pAhpn+Krzk/ywsRPzNz3wl7l7zUExwKzsNnaiVnRgRAQAnbPhHgCA4ozv3/71JLdJ4viccn84YZBlNf/5XpbkmcqMsVOtBujPD+y7+htqARxmpbGzDG1R6MF6s+EeAEp0z4b7c8+GDdMb7zcmmRCK+06g13zn/VFcmCUbl4iBhnG6/YyHTvdauN/v0J+rGczaLSJo7NipVsyGE+4BZsGGewAASnVjNV6GhznowYKyqPuG+9eV8kLb+pYBc8p9z2wRAfA4vjHdGgE9WAW71QQACnbPhvszuuHy6Y33/y3Jt4WCtY9awQB68JflSGMMX3VWklcJwtgJPXB37l7jeS3MXjkb7k0jgqcKtXpulm47S9YAnbHhHgCAUu0UQS958EYt1XbD/RlnX3xukp9WYmMnenCAPnJg39W3qwHwOCuMneWo/in3asWsG8cHOAGgDkY3fDWjG/5DksVJ/r8kB913Ut9bWC9PraigXxQBDfLqJKcZOzF/0wNvEwHMyT8P5osIjZ2YvwvmlHuADtlwDwBAqT7Yuw9TdaraD3NanjUVUyt6rs4n3L8uSaukF+yUe2MntXO1CIDDzVv4xmcmOVcS5m/UasDuPLh34wNiAIAaGd2wP6Mb1iQZTnJddd4rct8JerAuJkVwZCNZsvEcMVB7w1e1klwiiE6HTvMc7rVm6M/VCubgrtUPJ7lNENap6MGO1rIAdMSGewAAijS+f/uEE8p6zQNFtapdFk+fv2DVgrr9xGecffEJSV6j9q5HOtOaUqsu+nKSd4kBeBxv3OJeS62qwLMjAKir0Q2fz+iG1yd5wfSmjS7egLjvdN+J2IWhVkf0C3KkAX4qyXONnagVPfCB3L3mXjHAnJXzvodpRPBUgRPuATpkwz0AACXbKQKgQxfU8Gd6aZKzlZbe8maMWh3TdQf2Xf2Q7IHHWWnsLE9bFHqwfnaJAABqbnTD5zK64VVJzk/yboG471Qr6Aan3B/FL4qABnC6/ayHTvO3ey2Ow+n20B23GDsxf9MBG+4BOmTDPQAAJbuxOi+l2g9zWp41FVMrem5ZDX+mVaW+8LbrkYHPj3qwCx5Jsk0MwBE44d7aBz1YhRfhhHsAaIrRDf+c0Q0/n+RfJHm/QNx3olbQgx78kSzZ+BQ5UlvDVw0l+VlBYP5Wqx54KMlfqxF0RVnve0x5gTDgHlyQpdsc5gTQARvuAQAo2UeTPCiGXvJAUa1ql0WtNtyfcfbFC5L8GzV3PcIA/e2BfVfvEwNwuHkL39gub8O9+fu72j74Qn18O8kdYgCAhhndcHNGN/xYkp9O8jH3nZRrystTK6rnxCQvFQM19vr+fa7c2In5u2HenbvX3C8G6IrPJRnQ9WTsNM9RKKfcA3TAhnsAAIo1vn/7d5J8RBIz45T7wwmjwep2wv1rk5ygrBg7GWCttsgbOILzkswXg/kbtRqwjx/cu/FhMQBAQ41ueN/0h0n/bZI7BeK+Ez1IpyZFcGS+CJt6Gr7qlOn3npnT0Gmew73WUbxdbaBL7lo9leRWQVinqhUdGBEBwMzZcA8AQOmur85L8TAHPVhAFkvmL1h1Rh1+wjPOvrhdhw89tPUtA9aa0oNz8OkkN4kBOIIVIgAqsE69Wf4A0HCjG6YyuuFdSV6U5KIk+wu6l0GtxC4Mqlmrf50lG30ZNnX0iiRPM3aiVvTA15K8VwzQVbtNIwherTrghHuADthwDwBA6W4UQa958EattJK8uCY/y08mOVdJjZ0wwB7cemDf1ZodOJJCN9wb0r6rPaVW1MJuEQAASZLRDQ9ndMMfJ1mS5Iok480OxP20WsFMOeX+CJ7iyyapqUtE0K2h0/ztXovH+evcveagGKCrbjF2Yv6mA8uzdFtLDAAzY8M9AACluzXJA9V5OdV+mNPyrKmYWtFTF9Tk57i4LgVxyr2xkyJ9M8nbxAAcxYgIzN+oVQXsEgEA8BijGx7M6IY/SDKc5L8neUgo7qdRK/TgLLxUhtTK8FXLPdPF/K1WPfRnagJdV94XDvuybxhkD56Z5LkyBpgZG+4BACja+P7tjyT5gCR6zQNFtapVFstK/8nOOPviZyR5mRq7HumO1pRazcLbDuy7+ptiAB5v3sI3nprkfEngXosB1+rLB/duvFf2AMARjW74akY3vDHJ85K8/dg3LO47wdJMGDzBz4iAmllt7MT8TY98Lnev+agYoMvuWn1fkvuMnagVHVguAoCZseEeAIA62CmCmXPK/eGE0VDLavAzvDrJiUqJsZMB1mqrfIGjuKDs+xTz3He1RaEHy7ZbBADAcY1uuDejG35jeh3zf913olZwJJMieKJlWbLx6WKgFoavemqSVwqi20On+Rv3kNPerhbQM94Hsf5WKzoxIgKAmbHhHgCAOrixWi/Hwxz0YMWz+L75C1YVuwnsjLNXtZKsqlul2vqWAXPKfWf3Xgf2Xf1pMQBHsUIE1ghQgR7cJXMAYMZGN9yR0Q0/leTfJPmkQNx3olbowRn4SRlSE69LMk8MmL/pkT8TAfTMLaYRBK9WHbDhHmCGbLgHAKAOPpHkq2LoNQ/eqI15SZYW/Pp/NJlaoozGThhgD14tV+AYarDh3vz9XdU/5V6tOConuwAAnRvd8I9Jlk1/4emX3Hdi7WNpJgyO4V+KgOINX9VO8npjJ+jBHvlI7l4zKgbomQFvuDd2Yv4uzLIs3XaiGACOz4Z7AACKN75/+5RT7jvT8qypmFrRM8sKfu2r6loUp9wbOynCviTvFgNwDE64N3+jVlVgwz0AMDujGx7J6IY/SjKc5PeTPOi+E/QgkyJ4IifcUwc/k2RIDL0aOs1zNP5e6+1qAD11iwisU6EDpyR5sRgAjs+GewAA6uIGEcDhPPw9ThYXlPiTnHH2qqcm+SU1dT3SG60ptZqB6w7su/phMQBHMm/hG5/hA5q416ICtbrr4N6N98sbAJiT0Q3fyuiG/5zkuUl2JB4cue9E7MJQq8c4N0s2DsuQwq02dqJW9MhDSd4hBuihu1bfn+SzphEEr1YdWC5fgOOz4R4AgLrYKYJ+8OCN2ij1hPvfSHKy6xFzAgOq1cEk2+QJHMOIsbN+2qLQg+XZJQIAoGtGN4xldMNrknx/kg+670StaC6n3B+BU+4p1/BVz03yU4Lo9dBp/nav1Vjvzd1rvi4G6LkBn3Jv7MT8XZgLRQBwfDbcAwBQC+P7t382yVi1XlW1H+a0PGsqplb0RKkb7lfVvTBt1yNU2TsP7Lv6y2IAjmGlCKx9oAI9aMM9ANB9oxtuy+j6H0nyK0n2CsR9J2qFHkzyI/KjYJckaYkB87da9cjbZA99sdvQZJ7D/N2BFbIFOD4b7gEAqBOn3PeFB4pqVYssnjJ/warnlPQTnHH2qh9K8ny1dD3SW60ptTqGLSIAjmO5COqp7YMvlGW3CACAnhld/87p57RvSnJAIFj7WJoJo9FsuKdMw1edluTVxk7Qgz3yjSTvFQP0RQXeDzF2mucoyAuzdNuTxABwbDbcAwBQJzeKoDNOuT+cMBqotFPuX6dvMXYywFrdfmDf1R+RI3A08xa+sZVkxNgJenDAvp3kDjEAAD01uv7BjK5/S5LzkvyZ+07Qg80xKYLHOjtLNg6JgQL9epKzxNCvodM8R+Putd6Zu9d8R+7QF7cneUQM1qlqxQy1k1wgBoDjD5YAAFAX11fvJXmYgx6scBbFPDw84+xVZyX5laZUqq1vGTCn3B/R1SIAjnOvdZ4PaVojQAV68LaDezcelDEA0Bej68cyuv43k6ysxqlyWPuIXRgMoFZOuadEq42dqBU99DYRQJ/ctfrBJJ8wjSB4terAiGwBjs2GewAAamN8//Z9SfZIoh88eKMWSjrh/teTnOp6NHbCgHrwG0n+Un7AcdT0jVnz93e1p9SKIuwSAQDQd6Prd01vun9tkq8IBGsf6s0p949jwz1lGb7qB5OcL4h+D53mb/dajXFPko+IAfrqFmMn6MEO2HAPcBw23AMAUDdOue9Qy7OmYmpF15W04f6iphXHKffGTiplx4F9Vx8QA3AcK0Vg/katKsDJsgDAYIyun8ro+j9N8rwkW5M84r4T9CCN6MEfkh2FuVQEmL/Vqof+LHev0RjQX7camsxzmL87cKFcAY7NhnsAAOrmRhH0iweKalV8FovmL1h1ZtVf8RlnrxpxyoDrkf5rTanVYU27RQzADIyY53CvRQVqZcM9ADBYo+u/kdH1q5N8f5IPC8QaQezCoPaelyUbnywGijB81TOT/JKxE/RgD71dBNB3u4ydqBUdWJKl254qBoCjs+EeAIC6uUEEnXPK/eGE0TAlbGR/nb7F2MkAa/VPB/ZdvUduwLHMW/iGU5IsM3bWX1sUerDavnpw70b3LQBANYyuvyPJDyf5rSRfdN+JWlEvkyJ4rBERUIiLk5wkhkENneZvam937l7zWTFA3306yQExWH+jVh1YLgKAo7PhHgCAWhnfv/0rST5ZvVfmYQ56sKJZVHpj2Blnrzojya82tVJtfcuAOeU+SXK1CIAZuCDJie47rRFgwD3odHsAoFpG109ldP3bkjxv+hmLHarWPqgV9ezBlbKj8oavOjHJKkFg/larHnqbjGEA7lr9cJLbDU0IXq06YMM9wDHYcA8AQB3tFEG/ePBG8ap+Eusrk5zuejR2woB68J4k/yAvYAZWGDubo/qn3KtVg90sAgCgkkbXP5DR9b8zvXb6uEBoxNrH0kwYzbJCBBTg55OcbewEPdgjDyd5hxhgYHYZO4EOjIgA4OhsuAcAoI5uEEHnWp53HkYYDXJBxV/fRU0vkFPujZ0M1NYD+6528howEz5UbP5GrarACfcAQLWNrr91+gOtlyX5pvtO0INl8+j4MDYrUIJLRVCFodM8R23vtd6bu9d8Vb4wMN4fsU5FrTrhhHuAY7DhHgCAOnp/Nd/h9zAHPVjBLF44f8Gqk6r4Cs84e9UyDzddjwxea6qxtfp2kj/VAcAMjZjncK9FBWrlA2UAQPWNrn8ko+v/MMnSJO8UiDWC2IVBLWr11CzZOCw7Kmv4qhck+TFjJ2pFD71dBDBQt5pGELxadeCZWbrtOXIFODIb7gEAqJ3x/dvHk3xMEv3iwRtFOynJCyr62l7negQGOH//1YF9V39dTsDxzFv4hqcnWWzsbJa2KPRg9dx9cO/Gb4gBACjG6Pr7Mrr+V5K8NMle952oFWVyyv1hLhABFbZaBFUaOs3f7rVq54Ek7xEDDNBdqz+XpCLvkRg70YOFWCECgCOz4R4AgLq6oZovq9oPc1qeNRVTK7pqWdVe0PwFq05rTeVVSvOotuvR2Mkg/KEIgBlaLgLzN1SgB51uDwCUaXT9PyT5viT/w825tQ9qRdE9aMM91TR81RlJflMQmL/pYa3+Onev+bZcYeDKfp9kyguEPvfghTIFODIb7gEAqKudIugnDxTVqugsllXwxf1KkjPVyPVINbSmGlerXQf2Xf1xlQdmaIV5DvdaVMDNIgAAijW6/lsZXf/vk/xAkk8JhFqtfSzNhNEcNtxTVb+V5HRjJ+jBHnq7CKASbjV2olZ0YEQEAEdmwz0AAHX14SQHxdA5p9wfThgNUcUPwLxW32LsZIC1ulo2QAdWGDubqS0KPVgtt4gAACje6Pqbk3x/kiuTPOS+E2sfyjApgkfZcE/1DF/VSnKJIKo4dJrnqM291t4kH5AnVMJuEVinolYduDBLt9lTCnAEBkcAAGppfP/2A0k+Us1X52EOerBiWVTqhPv5C1a9IMkPxRdgPEZb3zJgDTrl/itJ3qniwEzMW/iG1rG/+dz8bY0AfenBh5LcLkMAoBZG138no+s3JHlJkl0CsfYRuzAoplbPzJKNz5IbFfNjSZ5v7ESt6KE/z91rFB6qofwN90YTwdPPWp2R5DyZAjyRDfcAANTZTSLoJw/eKNaZ8xesGqrQ61nlejR2wgB78I8P7Lv6O3IBZui5SZ5s7Gyu6p9yr1YNcdvBvRsfEgMAUCuj6z+V5AeT/L9JPKvB2gfK8BIRUDG/I4IKc8q9e616eLsIoCLuWv3FJGPGTtCDHRgRAcAT2XAPAECdXV/dl1bthzlO1S6nVnRNJU65n79g1bwkr3I9HplT7o2d9NxkkmvFAHTAG7Dmb9SqCpz8CgDU0+j6RzK6fnOSC5J8zH0n1j5U16QIHvVCEVAZw1edk+RlgsD8TQ9rdWvuXvMZOUKllP9+iS/7hn724Ap5AjyRDfcAANTZ7iQPiqGfPFBUq2KzWFaRF/NLSZ6qJq5Hqqk1VftavfvAvqs/r9JAB1aa53CvRQVqZcM9AFBvo+s/M73+elOShwRijSB2YVDZWtlwT5VcnOQEYyfQQ063h+q5xfyNWtGBC0UA8EQ23AMAUFvj+7c/lOQDkpgdp2ofThgNUJUN9xfpW4ydDLBWW2QBdKjBJ9yb576rLQo9OHi7RQAA1N7o+oczuv4t0+uwO9x3olZUj1PubbinMoavOjnJKkGUMHSav91rFevhJH8pBqicW0RgTkCtOrAsS7edJAaAx7LhHgCAuruxui/Nwxz0YIWyuGDQr2D+glXDSX7sSP+fL8A4pK1vGbAan3J/Z5KdKgzM1LyFb5g38y8tMn9bI0DPevBrB/du/JzcAIDGGF1/R5LlSf6L3a3WPmoFlevB52fJxpbMqEDf/lKSZ8gB8zc9rNX7cveaL8sPKufWWgzCphHo10VycoUOqgKoDBvuAQCoOxvH+s4TT4q0cP6CVU8e8GtY5Xo0dsIAe/CaA/uu1ohAJy5I0vBvOzdsflf1T7lXqxpzuj0A0Dyj6w9mdP266S9w3SsQiln7WJoJo/6elORcMVABlxo7QQ/22NtFABV01+rxJHcbO1ErOnChCAAey4Z7AADq7rYk94thdpyqfThhNMDAvq1z/oJVJyX5LSWYGafcGzvpuokkO8QAdGiFCMzfqFUF7BIBANBYo+s/mOT8JH/hvhNrH6phUgTJC0XAQA1vXpbkB4ydJQ2dakVx91rfTPK3coPKukUE1qmoVQdGRADwWDbcAwBQa+P7tz+S5P3VfYUe5qAHK5TFsgH+5S9L8oxj/QZfgAHV0Zqq3QX5Zwf2bXlAZYEOdfjGq5sZrH3oSa1suAcAmm10/XhG1/96kl9PMi4QawSxC4OB1+o8eTFgl7oeUSt67F25e82DYoDK2m0aQfBq1QEb7gEex4Z7AACa4AYR9JsHbxRpkBvuL3Y9olYM0BYRALPgjVfz92O0RaEHB8NJLQAASTK6/i+mT7v/sPtOawQYrMafcj+sBxhc921+cpJfE0SJQ6f5271WUd4mAqi0Cr5vYuxED1bY0izddoYYAA6x4R4AgCao+Ib7aj/Mcap2ObVizi4YxF86f8Gqc5P8pOuxM23Xo7GTbnn/gX1bPikGoBPzFr7hqT48bP6GCvjcwb0bvyYGAIBpo+v3JvmxJBuFYe2jVjCwHnTCPYP06iSnGjsxf9PDWu1L8n55QaXdnuRh04gXiPl7htpJXiJLgMcOjAAAUHefSvJlMfSbB4pqVZznz19w0bwB/L2vS9ISP67HsrSmalMrp9sDszHL0+3Nc7jXoqu12i0nAIDHGV3/cEbXX57kpUm+IhD3016eWtF3vqSSAXXe5naS1cZO0IM99he5e82kHoAKu2v1t5PcYexErejAiAgADrHhHgCA2hvfv30qyY2SmD2nah9OGDV2YpIX9vMvnL9g1QlJXqtvMXYyIPcl+d9iAGZhhQjMc0fSFoUe7K+b1R4A4ChG1/9DkmVJPuC+E2sf+q/R+/AWZsnGk/UAA/BTSZYYO0seOtWKIu613iYnKMKtIrBORa06sFwEAIfYcA8AQFNcX+2X52EOerAilvX573tpkmd38i/4AoxD2vqWAavBKffbDuzb8rBKArMwhw335m9rBOhaDzrhHgDgWEbX35fkJ5K8RRjWPkDfxot2ksWyYgBWux5RK3rs9ty95lNigCLU5/0T04jg6UetnHAPcBgb7gEAaIqbRDAIHrxRnH5vuF/lekStGJCDSbaJAZglb7iav4+q+qfcq1VNPJTkdjEAABzH6PpHMrr+TUlelmRcINapXp4w6IslIqCvhjcvSvIzgqgBp9ybv6vN6fZQjopuuDfPoQcr6tws3fZ0MQA8yoZ7AAAaYXz/9s8l2VvtV1nthzlO1S6nVsxJ3zbcz1+w6pzpE+5dj3PglHtjJ7P2Nwf2bdkvBqBT8xa+4blJniIJ8zdqNWC3H9y78TvqDgAwQ6Pr35PkwiRzPJHSGgFrH2Zqssk//LnqT5/9dpKWsRPo4b3WZJK/lA8U4zNJDlgGeoE0fv7uhEMXAKbZcA8AQJM45X4gPFBUq6KcP3/BRa0+/V2vsS7H9Vi+1lSxtdqiesAsdeGNVvMc7rWYc612ywYAoEOj6z+XZEWSvxaGNYLYhUFPa7VQTvTN8OZTkrzW9Yha0WPX5+41XxQDFOKu1Y8k+ZggMH/TgeUiAHiUD/YDANAk14tgbpyqfThh1NT8JIt7/pcsWNVO8jp9i7GTAfnEgX1bPigGYJZWisA8dzxtUejB3rtZvQEAZmF0/URG178iyX+c/fHTbvitEWCmGnvK/ZDa00evTPIUMdRp6DR/u9eqpLepNxSnol9cbJ5DD1aUDfcA02y4BwCgSQo44d7DHPRgBSzrw9/xU3M93cIXYBzS1rcMWIGn3G9VNWAORrrzx5i/rRFgTj3ohHsAgLkYXf9fk7w0yQPCsPZRK+h6Dzrhnn661NiJ+Zse12oiyd/KBYpzi2nEC8S9VgdGZAjwKBvuAQBojPH92/cluUsSg+CBIkXpx4b7i8SMsZNB3RIlebsYgNmYt/AN8/p0r2T+roG2D77QO99I8jkxAADM0ej6f0qyMsmoMKxTvTxh0FU23NMfw5tXJPl+YyfowR57V+5eM6HWUJwKb7g3f5vnqKCnZem2RWIAsOEeAIDmuUEEc+NU7cMJo6Z6uols/oJVz0ryMn2LsZMB2XFg3xYfiADmcp90shjM36jVgO0+uHejpgQA6IbR9Z+ZPsHqg+47sfahNyab+EMvyJKNJ6k9fXCJsbOuQ6daUal7LV/mDiW6a/Vokq8KwjoVterAchEA2HAPAEDzFLDh3sMc9OCA9frU1t9KcmI3/iBfgHFIW98yYK2pYnpwi2oBc9DlN1jN31j7MKta7ZIHAEAXja7/WpKfTPKnwrBGELsw6EqtWkmeISN6anjz05O8UhDGTrWix/Y73AaKdqtpBMGrVQdsuAfo1gf8AQCgIDdNP1VoiaLfxE4xzpm/4KKnPXDfH3X9W37nL1jVSnKR6xG1YkDed2Dfls+KAZiDlSIwf3eiPZVMioLus+EeAKDbRtc/lOS1WXzl3iRXWvtYp0J3TTbxbKizk4ypPT302iQni6HOQ+dU0jZ/u9cauA8keVHO+x81+pFafflXivi5aqvlZzrkPmMn6MEOjIgAwIZ7AAAaZnz/9q+e+ezXfCLJ+dV+pdV+mNOaSqY8ayqiVszasiTX9+DP/YkkS1yPvdHOVCZdj8ZOjsXp9sBceYPV/C0GtaqC3WoMANAjo+t/N4uv3Jfkj5q4O9baR62giz34TPnQM8ObT0jy28ZOzN/0oVavSPIKUWhbNKEo1IpGXCQvydJtJ+TOVY/IEWiytggAAGigG0QwKFMiUKtSLOvRn/tavYXrsb5aU5Wu1d4kf69KwGzNW/iGpyR5rnkO91oMuFZ7Du7d+FVZAAD00Oj6P03yc0keFIa1j5cnDGZtgQjooZ9NslAMxk70IGoFrkfUii46PclSMQBNZ8M9AABNZMN9F7Q8QzuMMGqo6xvu5y9Y9bQkv6RvQQ8OyLUH9m2ZFAMwB063N8/NSlsUerC7nG4PANAPo+vfm+THk3zV2gfojsY9nnbCPb20em7/uvm7nKFTrRg0PVhOFGolC/QgatUVK0QANJ0N9wAANNEHkjxS/ZfpYQ56cIB6ccL9byY5uRcv1hdgHNI2djJgFT3l/jtJ/lh1gDnq4Rur5m9rBJhxD+6SAQBAn4yu35Xkh5OMWfugVtBxDzrhnt4Y3nxekn8lCHOCWoEeRN+KAsHTg1otlx/QdDbcAwDQOOP7tz+Q5FZJDIoHbxRh6fwFF53S5T/zda5H1IoBeceBfVu+KgZgjnyTufl71tpOfqF7bLgHAOin0fV3JvmxJJ8XhnWqpZkw6MjTRUCPXCICMH+DHpSFWoEe7JELRQA0nQ33AAA01fVlvMxqP8xxqnY5taJjJyR5Ubf+sPkLVv1wkue7HvvDKffGTp7gahEAXTAiAszfajVgDye5TV0BAPpsdP3nkvxgkj3WCFj7MDeTTfphn6bedN3w5icleY2xs2lDp1rhXksUQHnXowGDYntwWZZumyc/oMlsuAcAoKluEsEgeaCoVkVY1sU/63V6Cddjc7SmKlWrWw/s23KLqgBzMW/hG4aTPNU8h3stBuz2g3s3fUcMAAADMLp+X5IfSfJJawTELgxmVKunyoUeeFWS+WIwdqoV6EH0LehBeuTELn9uFqA4NtwDANBUH0riQ9pd4FTtwwmjZrry4HD+glVnJfllfQt6cECcbg90g9PtzXNz1haFHpy73eoJADBAo+vvS/ITR95074bfGgFmqjGn3D9FremBS0TQ1KHT/O1eC/SgLNQK9GDfLBcB0GQ23AMA0Ejj+7d/O8nNZbxaD3NgQLr1TZ2/keTUfrxgX4BxSNvYyYBV5JT7ryV5h2oAXbDC2ge1ogJuFgEAwICNrv9Kkn+dZI+1D2oFx+xBJ9zTXcObfyTJi42dmL9RK1GgCSklCrWi2B50IAPQaDbcAwDQZNeLYJA8UFSrynvx/AUXdWPd/Do9hOuRAfnjA/u2fFsMQBesEIH5uxvaPvjC3DjhHgCgCkbXjyX5sSR7hWGdamkmDI7q5CzZ+CQx0EVOtzd2ogdRK3A9olb0gw33QKPZcA8AQJPdKILucKr24YRRI6cnWTKXP2D+glUj3T9pQN9i7GTGoV4rBmCu5i18w0lJlkkC87daDdj9Se5WSwCAihhdvy/JTyYZs0bA2ofOTTblB32KWtMVw5ufneSXjJ1NHzrVCvdaolArWaAHUau+OC9Lt80XA9BUNtwDANBku5JMlPFSPcxBDw7IXDeXXdzvF+wLMA5pGzsZsNbUQHvwPQf2bblXFYAu3Q/Nc98JDNjug3s3GSAAAKpkdP3npjfdf73eP6jbULELg1nX6skyoUtWJTlRDMZOtQI9CPpWFIKnD7VqJblQdkBT2XAPAEBjje/f/nCSD0hikDx4o/IumO2/OH/BqjOS/IrrEbViQLaKAOiSERGYv7up7eQXZme3CAAAKmh0/Z1JXpbk2+6nrVOhM4045f50dWbOhjefNL3hHpxy714L9KAs1Ar0YL/4nAjQWDbcAwDQdDeU81Kr/TDHqdrl1IqOzOWE+18d1AdpXI+HOOXe2NlQn0vyPjEAXbJSBJi/1aoCblZDAICKGl3/4SSvqvfuWWsftYJZ9aAN93TDLyRZYOzE/I1aiQI0YalRqBVF9qAT7oHGsuEeAICmu0EEg+aBolpV2lw23DtpANcjaU0NpFZbDuzbokmAbhnAN5cbwnCvxRM44R4AoMpG178ryb8XBJZmwuAxzhABXbBaBMZO9CBqBa5H1Io+WyECoKlsuAcAoOluT/INMXSHU7UPJ4yaePb8BRc9o9N/af6CVcuSfL++BT04AAeS7BAD0A3zFr7hyUnOk4R5rtvaotCDnbnn4N5NX1E/AICKG13/h0n+u7WPNQLM3GTdf0Ab7pmb4c3fl+RHzQk8duhUK9xDikKtZIEeRK167pws3fYsMQBNZMM9AACNNr5/+2SSm8p5xR7moAcHYDan3A/8dHtfgHFI29jJwK/Hvvbg2w/s23K/1IEuGRncX23+tkaA73G6PQBAOf6fJNdb+6BW6MEkyZmyYI6cbo/5G/Qg6FtRCJ5B1Wq53IAmsuEeAACSG0QwaB68UWkXdPKb5y9YdVqSX3c9olYMyFYRAF00IgLzd6+0nfzCzO0SAQBAIUbXP5LkFUlGhWGdamkmDJxwzxwMb56f5DcEYexEDwIYO0EPDojPiwCNZMM9AAAkO8t6udV+mONU7XJqxYx1esL9rySZ73qsFqfcGzsb4kMH9m25QwxAF60UAeZvtaoAG+4BAEoyuv7rydTPJ5kQBtY+HN9knX+4E9WXOXh1kicZOzny0KlWuNcShVrJAj0IPeeEe6CRbLgHAKDxxvdv/0ySL0li0DxQVKvK6nTD/So9guuRx2tN9aVWWyQNdNmAv7HcPId7LfJwktvEAABQmNH1n5zeKGiNgNiF0eRanSYHZmV4cyvJbwvC2KlWoAdB34pC8AywVjbcA41kwz0AADzqehEAR3He/AUXzegDMfMXrHpBkn9R/o/sQTh6sEBfTPI3YgC6Zd7CNyxJ8jRJmOd6qS0KPXh8dxzcu+lBNQMAKNDom/9XkmsFYY0Ax1fbU+5PVltm6V8mWSoGjj10mr/da4EelIVagR7sqadk6bZhMQBNY8M9AAA86qayXm61H+a0PGsqplbMeO38ohn+3lWuxyoXUhjU2rYD+7Y8JAagiyrybeXmb2sfGm63CAAAivaGJJ+09kGtaGgPzpMBs7Ta2In5G7USBWjCOkahVhTXgxfKDGgaG+4BAOBRTrivBA8U1aqylh3vN8xfsOqUJL+pN3A9cjStqZ7V6uEk2yQMdNkKEZi/+6Htgy8c2y4RAAAUbPTN307yiiQHhGHtY2kmjAY6VQR0bHjzwiQ/JwhjJ3oQtQJcj2pFBYyIAGgaG+4BACDJ+P7t9ya5VxLd41TtwwmjBi6Ywe95eZIn61vQgwPwtwf2bRkTA9BlNtyDe60qsOEeAKB0o2/+dJI3CgJrH45tso4/1InqyixcnOQEYyczGzrVCvdaolArWaAHUauesuEeaBwb7gEA4JCdZb1cD3PQg320bAa/Z1VVX7wvwDikbexk4NdjT3pwi2SBbpq38A0nzfALh9x3olb00niSu8QAAFAL25L8X2sfxC6MhjldBHRkePO8JBcJwtiJWqEHQd+KQvBUpFYXZOm2E2QGNIkN9wAAcMiNIqgCD96opBfNX3DRUR8czl9w0XlJftT1iFoxAJ86sG/LTWIAuuz8JKeIwfzdL20nv3Bktxzcu0n4AAB1MPrmqekvrZ0QhrUPHN2kCGi6X07ydDHQ2dBp/navBXpQFmoFerBnTkvyQn0ANIkN9wAAcMjO8l5ytR/mOFW7nFpxXKclee4x/v/XVf0HcD0e4pR7Y2fNON0e6IUREWD+VqsK2K1GAAA1Mvrme5P8J0Fg7QNwVKuNnaAH1UoUoAmbEIVaUVQPrpAX0CQ23AMAwLTx/du/mOQzkqgCDxTVqpKWHekfzl9w0clJXq1vcT0yU62prtXqm0n+TKJAD1TwDVPzHHqwgW4WAQBA7WxN8iFrBMQuDOBxhje/JMlKQRg70YOoFeB6VCsq5kIRAE1iwz0AADzWDSLoLqdqH04YhVt2lH/+siRP17egBwdgx4F9W74lBqAHfEO5ea7v2qLQg0/khHsAgLoZffNUkkuTTArDGgGOzPBAY10qAmY/dJq/cQ8pCrWSBXoQteqZ5XoAaBIb7gEA4LEK3HDvwRt6sE8uOMo/X1VKFr4A45C2sZOBX49d6cFrJAl027yFbzgryfPcd6JWDNjeg3s3fUkMAAA1NPrmO5Jss/ZBrQCmDW9+SpJXGjtBDwIYO0UheCpYqxdn6bZT5QU0hQ33AADwWDd54lMVykDlPOGE+/kLLlqc5Cddj6gVA7DzwL4tnxED0AMjIjB/D0rbyS8csksEAAC19qYk3xCDtY+lmTCAJMm/S2IDi7ETPYhaAa5HqKITjvTZWYC6suEeAAAOM75/+9eT3FbeK3eqtlrRB8+Yv+CiZz/un70mSaukH8L1eIhT7o2dhdsiAqBHbLjH/K1WVbBbXQAAamz0zV9Lsl4QWPtwZJMioDmGN7eT/Laxk7kPnWqF8UIUaiUL9CBq1TM+RwI0hg33AADwRDeKADrVmAeK3/umzvkLLjoxyWsbnAWuR+aoNTXrWn0hybslCPTISvMc6MEKuFkEAAC1d12Se60RELswoOH+dZLFYjB2olboQdC3ohA8Fa6VDfdAY9hwDwAAT7RTBFXhwRuVs+yw//4zSZ7tegQG4NoD+7Y8IgagR5aLwL3WILVFoQeTR5J8XE0AAGpu9M0PJblSENYIcGROuacxVouA7g2d5m/3WqAHZaFWoAd7wudIgMY4UQQAAPAEH5z+cPcJZb3sqSStyr661lQy1dJcJdSKYzp8w/3rSv0hXI+HtDOVSdejsbMsDyX5YzEAvTBv4RuGkjzDnIBaMWB3PHTvxgeTjZIAKEyrZd4HOvb2JG9KssTaB7Wihr4jAo5pePOSJP/G2Al6UK1EAZqwyVGoFUX04HOzdNtZuXPV/fIC6s4J9wAA8Djj+7d/K8nNkqgK30yqVpVyQZLMX3DRc5K8VN/iemSuWlMd1+qdB/Zt+bLkgB5ZIQJwr1UBt4gAAKAhRt/8sFPurX0szYRRYw+KgOP4bburjJ3oQdQKcD2qFYVwyj3QCDbcAwDAkd0ogu5reYZ2GGEUanj+gotOT/KaZq6p9S16sAKuFgHQQyMiMM9VQVsUTe/BXWoBANAof5nk82LA+psnmhQB9TW8+dQk/87YSfeHTrXCeCEKtZIFehC16gkb7oFGsOEeAACObGeZL9uDN/Rgj7WSLEvy2tKz8AUYh7SNnQz8epxxD952YN+WmyUG9NBK952oFRVgwz0AQJM8esr9H1r7IHZhQMP8apIni8HYiVqhB0HfikLwFFIrBzgAjWDDPQAAHNnNSb4thqrw4I1KuTzJQtcjasUA/KEIgF6Zt/ANJyZ5iSTM31XRdvJLU30zyZ1iAABonD9OMiEGax94oqJPuX9A/TiGS0VA74ZO87d7LdCDslAr0INd54R7oBFsuAcAgCMY37/920k+XOard6q2WtFjP1OXH8T1eIhT7o2dBfhGkr9Sf6CHzk9yihgwf6vVgO0+uHfTpDoAADTM6JvvT7JdEFinUjPWtxzZ8OaVSS4wdoIeVCtRgCYUhVpRUA8uyNJtZ8sJqDsb7gEA4OhuFEGVeKCoVrIAPVhfranj1upPDuzb8qCkgB4aMc+BHqyA3SIAAGisa6wRELswoCGcbm/sBIwXgOtRrSiRU+6B2rPhHgAAjm6nCHrDqdqHEwb6FvTgjH7ga9Qd6LEVIjDPVU1bFE3swV3yBwBoqNE3fzrJLYKwRoAnKvag+IfVjicY3vyMJL8sCHo/dJq/3WuBHpQFehC16job7oHas+EeAACO7tYk3yzzpXvwhh6Uxcz4AoxD2vqWgV+PR+3Bfziwb8uohIAeK3TDvflbragZG+4BAJrtbdY+qBU18i0RcAQXJTnZ2Al6UK1EAZpQFFDgRTIiI6DubLgHAICjGN+//eEkH5BElXjiCa5H1KqRrhYB0EvzFr7hzCTPk4T5u4qqf8q9WnXR5w/u3fRFMQAANNpfJnlIDNY+lmbCqIkDIuAxhjefkORiQRg7QQ+qFeB6VCsKtTxLt7XEANSZDfcAAHBsO0XQG07VPpwwcD1WhVPujZ0VNJrkn9Qb6LGRJN4UxfzNoGvldHsAgKYbffPXkrxPEFin8kSTJb5oG+55vJcleY6xk/4NnWqF8UIUaiUL9CBq1VVnJnmu2gN1ZsM9AAAc243lvnQP3tCDsgBK05p6wnix5cC+LZOSAXpsuXst0IMVcIsIAABI8rfWCIhdGDXxLRHwOKtFYOxErdCDoG9FIXgKr9VyGQF1ZsM9AAAc2yeSfFUMVeLBG7geUavGeDDJDjEAfbBCBObvKmuLoik9eLPMAQBI8vcWRNYIcGTFfTftN9WM7xnevDTJvxQE/R86zd/utUAPykKtQA921Yi6A3Vmwz0AABzD+P7tk0neX+5PUO2HOS3PO4upFfXnejyk7Xo0dlbHXx7Yt+Xr6gz0gQ33mL8ZtEeSfFwMAABk9M1fqseXMVn7qBXkgAg4zCXGTtCDaiUK0ISiUCtqcJE44R6oNRvuAQDg+HaKoGo8UFQrWYAerK/W1PdqdbU0gF6bt/AN5yZ5pnkO9OCAffLg3k0TYgAAYNr/EYG1j6WZMGrgQRGQJBnedHqSVwvC2Al6UK0A16NaUQMXZOm2E8UA1JUN9wAAcHw3iKB3nKp9OGGgb0EPfs9HD+zbcpv6An3gdHvzXBHaoqh7D+6SNQAAh7lRBFh/c2STJb3Y+9WLab+R5AxjJ4MbOtUK44Uo1EoW6EHUqmtOSfJidQfqyoZ7AAA4jvH92+9KMlbuT+DBG3pQFjPjCzAOaetbBn49Tm2RAtAnI+61UCsqYLcIAAA4zK31OBna2gc92HAHRMC01SIwdqJW6EHQt6JA8DWq1XL5AHVlwz0AAMyMkzQqx4M3cD2iVrX15STvFAPQJytFYP4uRdvJL3V2swgAAPie0Tc/5B7R2sfSjBp4UARkeNOPJnmhwYmBc8q9ey3Qg7JQK9CD3XOhmgN1ZcM9AADMzM6yX75TtdUKXI+dcsq9sXOA/mhibOtD6gr02ryFbzgxyUskgfmbAdfqW0k+I2cAAB7nAyLAOpUjmyzlhX5TrUhyqbETwHghCjShKNSKml0kK2QD1JUN9wAAMDNOuK8kDxTVShagB2vnkSTXiQHokxclOdU8B3pwwHYf3LtpUgwAADzOx6wRELswCjcugoYb3rQgyS8IwtiJWqEHAdcjalUzL8jSbU8SA1BHNtwDAMAMjO/fvjfJHkn0jlO1DycM9C00uAffPTG29QvqCfTHpG8dN88Vpy2KOvbgbvkCAHAEnxCBdSocXeW/t+3r2XO5C4WLk5xo7KQ6Q6cedK8FelAWgPGiK05IcoGaA3Vkwz0AAMxc4afce/iLHpTFzPgCjEPa+pb+u1oEQB/VdMO9+VutKIwN9wAAPNHom/fW53Roax+1ooG+LoKGG950UpJVxk7Qg6iVKNCEolAranqRjMgGqCMb7gEAYOZ2iqCKPFAE1yNqVRufKf8LfoDCOOHe/F2ktg++1M0uEQAAcBR3iMDax9JMGIWy4Z6XJ3mW69HYCXpQrQDXI2pVUzbcA7Vkwz0AAMzcDSLoLadqH04YAA0cO7dOjG01AQB9MW/hmjOSLE0mhYH5m0HWauzg3k33yRYAgKO4UwRYp3J0lX6uZcM9q42dVHPoVCuMF6JQK1mgB1GrrrhQvYE6suEeAABmaHz/9i8n+VTZP4UHb+hBWcyML8A4pK1v6Y9vJXmbGIA+GknScq8FenDAbhYBAADHcI81AmIXRqG+JoIGG9704iQ/LAhjJ2qFHgR9KwoEX+NaLcnSbU+RDVA3NtwDAEBndoqgijx4A9cjalW8t02MbX1ADEAfjYjA/F2ytijq0oO7ZQoAwDHcKwLrVDi2yp5y74T7Zltt7KTaQ6cedK8FelAWagV6sCt87gSoHRvuAQCgMzeW/yM4VVutwPXYKafcGzv7YKvaAX224tB/nZQG5m8GZZcIAAA4hpptuLf2USsa5KsiaKjhTWcmeZWxE/QgaiUKNKEo1IoGXCTL5QLUjQ33AADQmZvsRqkqDxTVShagB8u9v5gY2/opMQB9tsI8B3pwwCaT3CoGAACO4fMisPaxNBNGoZxw31yvTnKa69HYCXpQrQDXI2rVAE64B2rHhnsAAOjA+P7t9ye5TRK95VTtwwkDfQsN6MGr1Qzop3kL1zwnybMe+099r5h5rjxtUZTeg588uHfThDwBADgGJ0Rj/c0MVPK5lg33TTS8qZVktbGTMoZOtcJ4IQq1kgV6ELWaMyfcA7Vjwz0AAHRuZ/k/ggdv6EFZzIwvwDikrW/pjbEkfycGoM9WutdCraiAXSIAAOCYRt/8UJKafUmTtQ80hA33zfSTSZ4rhjoyf6sV6EH0rSgQPEeo1TOzdNtz5ALUiQ33AADQuRtEUFUevIHrEbUqzraJsa0PiwHosxERmL/rou3kl5LtFgEAADPwDRFYp1qaCaNA94mgkS51PQLmb/SgLFAraFgP+vwJUCs23AMAQOc+mORg+T+GU7XVClyPnXLKvbGzyw4muU6tgAE4ygn3k5LB/E0/a+WEewAAZsKGe6xTmYHKPdf6opo0zPCmc5P8rCCMnWUNnWqF8UIUoAnLi0KtqFwPLpcJUCc23AMAQIfG928/4EPhVeaBolrJAvRgMd41Mbb1S2IA+mnewjUnJnmJeQ704IBNJPm0GAAAmIEabri3RhC7MGruYPZc/mUxNM5v+0y2sRO1Aj0IYOxsICfcA7Xi4Q4AAMzOThH0nlO1DycM9C3UsAevViNgAL4vyWlH/7+dcm+eK09bFCX24K0H9256RIYAAMzgvtMdv3UqzFBlnms53b5phjfNS/JaYydlDp160L0W6EFZqBXowTm5MEu32Z8K1IYBDQAAZufGevwYHiiC63FmfAHGIW1jJ91xx8TY1g+LARiAFe61UCsqYJcIAACw9kGtqKn7RNA4r0jyNDEYO9GDqJUo0ISi8AJp4EVyRpLzZALUhQ33AAAwOx9N8qAYqsoDRbUCXI+Vt0UEwIAsF4H5u47aPvhSmt0iAABghrwfZ51qaSaM0thw3zyrXY/GTtCDqBW4HlGrBhsRAVAXNtwDAMAsjO/f/lCSD0mi95yqfThhoG+hJj14f5I/VxtgQFYe/7dMSgnzN72u1c2yAwBghr5jjYB1KjNXiedaX1SHBhnedKHNJcbO8odOtcJ4IQq1kgV6ELWaE2sioDZsuAcAgNm7oR4/hgdv6EFZzIwvwDikrW+Zmx0TY1sPiAHot3kL15yR5PnutYABu+/g3k1jYgAAYIZOtU5F7MIozD4RNMpqERg7USvQg+hbUSD4htdquTyAurDhHgAAZm+nCKrMgzdwPaJWlQ15ixiAAbnQ+wLm7zprO/mlFE63BwCgE/PcT1unQmcGfsq9E+6bYnjTU5P8qrGTegydetC9FuhBWagV6MFZW5al205SZ6AOfLAOAABm7+NJHqjHj+JUbbUC12OnnHJv7Jyl902Mbf2cmgADsmLmv3VSWpi/6VWtdssMAIAOzHM/jVpRmPtE0Bivrf88ZexED6JWokATisILhOP24MlJlskDqAMb7gEAYJbG929/JMlNkqgyDxTVShagByvnahEAA7RCBOY59GAF7BIBAAAdeJIIsDQTRmH2iaABhje1k/y269HYCXoQtQLXI2pFkuRCEQB1YMM9AADMzY0i6A+nah9OGOhbKLQH703yXrUABqjDDfdOuTfPlactiqr34GSSj8kLAIAOPNnaxzoVOjfQ51qj8m+ElyYZEoM5oV5Dp1phvBCFWskCPYhazdpyNQbqwIZ7AACYm531+VE8eEMPymJmfAHGIW19S2eumRjbavcqMBCnLlxzTpJnS8J9p1oxYJ85uHfTN8UAAEAHnmztg1pRkK9kz+UHxNAIl4oAzN+gB9G3okDwfK9WK2QB1IEN9wAAMDefTPJVMVSZB2/gekStKuE7Sf5EDMAArRSB+bsp2k5+qbKbdSgAADO2+MqTkjxJENaplmbCKMg9ImiA4U3DSX7K9WjsBD0IuB7VCvTg9yzN0m1nqDFQOhvuAQBgDsb3b59yyn3/OFW7nFpRf67HQ5xyb+ycob+cGNv6NTUABmhkdv/apOSw9qGbtdotJwAAOvBsawSsU5m9gTzXsuG+GS5J0hKDsbOeQ6daYbwQhVqBAQNm1YPtJC+RBVC6E0UAAFDDZeuUhyf9dNaCf3djkldIotJXhfe71UoWoAcHbYsI6LZWyzXKzJ26cM2Ktu3z5jn04ODt8twKAIAOnG2NgNiFURgb7utueNNpSV4jCIydagV6EH0rCgTPE4y0Wq33i8FeDiiZE+4BAGDudooAYKY8SKSRPbh7YmzrrbIHBuXUhWtOSHLh7P8E2/TNc+Vpi6KKPXggySdlBABAB86x9rFOhbnp+3MtG+7r79eSnGXspN5Dpx50rwV6UBZqBXpwVparL1A6G+4BAGCOxvdv/1ySffX5iar9MKfleWcxtaL+XI+HtF2PHJvT7YFBe0GS0+JNAffTasVg3Xpw76ZHxAAAQAcWWvugVhTmXhHU3moRGDvRg6iVKNCEovAC4Yg9aMM9UDyfrQMAgO5wyn3leaCoVrIAPTgQX03yDjEAA7ZSBObvJmr74EvV7NKVAAB06DwRWKdamgmjMKMiqLHhTT+YZJnrEbVCD6JW4HpErTiioSzd9nQxACWz4R4AALrjBhH0j1O1DycM9C1UvAf/eGJs63dkDgzYyNz/iEkpAnO919otGwAAOnTeLO47YdBrHypnsp9N8Xl515rT7Y2dDRo61QrjhSjUShboQdRqVkbUFyiZDfcAANAdNdtw78EbelAWM+MLMA5p61ueaDLJtWIAKmDlY+cs3HeqFQNxswgAAOhQA0+4t/YRuzAKti97Ln9IDDU1vOmZSf6tIDB2qhXoQfStKBA8x6zVcjkAJfO5OgAA6ILx/dv3JfmsJKrOgzdwPaJWffWeibGte8UADNKpC9ecnuQFkjB/N1XbyS9V8cWDezft05EAAMzY4iufmmSB+2nrVOiOvpxyf5eca+2iJCcZO2nW0KkH3WuBHpSFWoEe7JgN90DRbLgHAIDuccp9HzlVu5xaUX+ux0Occm/sfJwtcgYq4MLuvRcwKU2sfZhtrXbJBACADi0TAdapFOYzIqip4U0nJnm9IIyd6EHUShRoQuLLvuF4PTgiA6BkNtwDAED37BRBCTxQVCtZgB7si7uTXC8GoAJWHOkfenPAPIce7DMb7gEA6NT51giIXRiFuVMEtfWyJGe7HlEr9CBqBa5H1IrjelqWbhsSA1Aqn6kDAIDuuUkE/eVU7cMJA30LFevBrRNjWzU5UAVd/vZwp9yb58rTFkUVenC3PAAA6NBKax/rVOiunj/XcsJ9fV0qApo7dJq/cQ8pCrWSBXoQterYcrUFSmXDPQAAdMn4/u1fSfKJev1UHryhB2UxM74A45C2viWZSLJDDEBFrDz6nIX7TrWib0Wz4R4AgE79gNto1IrC3CWCGhre9IIkPy4IYyd6EABjpygEz4xrNSIDoFQ+TwcAAN11owhK4MEbuB5Rq556+8TY1nExAIN26sI1ZydZIAnzNyWccl/rWn3m4N5N39SFAADM2OIrFyY5WxDWqV6eMAryQPZcfp8YaukS1yNqhR5ErcD1CHqwIzbcA8Wy4R4AALrr+vr9SE7VVitwPXbKKfeNHzu3yBWoiJW9+WMnJYu1D53U6mY5AADQoR+zRsA6ld7o2XOtO2VbQ8ObzkjyW4Iwdho61QrjhSjUShboQejIS7J02wliAEpkwz0AAHTXB+0+gW7z8FcW6MGifGBibOs/iwGoiOXH+w3eJDDPoQf7YLfaAgDQoZ8UgXWq2IVRmM+IoJZ+M8npYsDYqVagB0HfikLwdOT0ZGqpGIAS+SwdAAB00fj+7eNJbpFECTx4A9cj9KQHt8oTqJAVvfujfc+Ye63ytEUxqB7cJQMAADo0iw33bvitU2GmevJc6y651szwplaSS4yd8N2hUw+61wI9KAu1Aj3YkRF1BUpkwz0AAHTfjfX7kar9MKfleWcxtaL+XI+HtF2PTbQ/yd+IAaiCUxeuOSHJhTObs3A/rVb0zIEknxQDAAAztvjKC5I8WxDWPmpFYZxwXz8/luQFYjB2ogdRK1GAJiw3CrVioJaLACiRz9EBAED37RRBKTxQVCtZgB7sqm0TY1sPigGoiOcnOV0M4F5rwG47uHfzw+oKAEAHfl4E1j5enjAK9AkR1M5q1yNqhR5ErcD1iFoxazbcA0Wy4R4AALpu6iNJviOH/nKq9mN6UAToW+h/Dz6c5Do5AhWysvd/xaSU3WsVpy2KfrtZBAAAdGgOG+7d8GP9zUx19bnWA0nukWmNDG86J8kvCMLYyeOHTrXCeCEKtZIFehC1mrFlWXrdPHUFSmPDPQAAdNn4/h0H6vmBcg/e0IOymBlfgHFIW982yd9MjG3dLwagQkY6m7Nw36lW9MRuEQAAMGOLr1ySZJkgrH3ELozC3JE9lwupXlYlOUEMGDvVCvQg6FtRCJ5ZO9FzPqBEPkMHAAA9MXWDDIqplQjA9YhadcNWEQAVs0IEmL+PrO3kl37apeMAAOjAr4nAOhX6p2un3N8hyxoZ3nRykouNnXC0oVMPutcCPSgLtQI9OGMXqilQGhvuAQCgN2q64d6p2moFrsdOOeW+EWPnP0+MbX2//ICqOHXhmicl+b7+/G2TAsfah6P50sG9m/eKAQCADvy6NQLWqRTodhHUyi8leYYYjJ3oQdRKFKAJ6xOFWjEwDooAimPDPQAA9MbuJBNiKIUHimolC9CDc+J0e6BqLpzN839vGJjn0INd5nR7AABmbvGVI0meJwjrVLELo0A23NfLahFg7EQPolbgekSt6IrlIgBK4/NzAADQA+P7dzyUTH1IEv3nVO3DCQN9C33owQeS/JncgIrp87eEO+XevVZ52qLoBxvuAQDoxMXWPtap0H9zfq71SJJPyrEmhjctS/KDxk443tCpBwFzlizQg6jVjDwvS6+br6ZASWy4BwCA3tlZzx/Lgzf0oCxmxhdgHNLWt3W2Y2Js64QYgIoZmf2chftOtaJrdosAAIAZWXzl/CSvFIS1j1pRoM9kz+XfEUNtON3e2IkeRK1EAZpQFNA9rSQXigEoic/OAQBA79zoKVpJ1Apcj6jVrGwRAVBBK0WA+fv4qn/K/VTpjWbDPQAAM/VbSU4Tg3Wql6dWBbpdBDUxvOnJSX7N9YhaoQdRK8D1qFZ01YgIgJLYcA8AAL3z8STfEEP/OVX7cMLA9VgVTrmv5dh5/cTY1rvlBVTJqQvXPDvJ2f3/myeFj7UPh7vr4N7ND4gBAIDjWnxlO8kaawSsUxmcOT3XukN+tfFqX/5i7KSToVOtMF6IQq1kgR5ErWbECfdAUWy4BwCAHhnfv2MyyQfq+dN58IYelAWQ5GoRABW0Yq5/gDcO3GuhB7tgl9oBADBDL0uyRAzWqWIXRqFuEUENDG9qJblEEBg7USv0IOhbUQiernPCPVAUn5sDAIDeut7DnJKoFbgeUasZ+3ySv1d/oIJWDO6vdsq9+bs8bVH0ig33AADM1OXWPqgVgzer51qPJLlVdrXw00mGjZ3Q6dCpB40XoAdloVagB4/rOVl63bPUEyiFDfcAANBbN9X3R6v2w5yW553F1Ir6cz0e0nY91mnsvGZibOsjcgIqyLeDY/6mCnaLAACA41p85U8P9ovjrH1QK+bkk9lz+YQYasHp9sZO0INqJQrQhA2JQq0YiOUiAEphwz0AAPTQ+P4dn0zyJUmUxANFtZIF6MHjeijJn6g7UDWnLlzT7taGe28euNdCD87Bt5PcoW4AAMzAWhFQzNrH4wFhPNHNIqiB4U2Lkvys6xG1Qg+iVoDrUa3oGQdHAMU4UQQAANBzNyRTv5q0JNFnralkSuzTpqIH0bfQtR58x8TY1q/IB6ig5yc5fbAvYdJ2ffdaxWlPJZOi6KaPH9y7+WExcCytVv0uuvbQ2mdM3vtfvqy6ADBDi6/810l+1NoH62+qo+PnWrtkVguvd5EaO5nL0DmVtNUK44Uo1EoW6EHU6piccA8Uw6feAACg926o74/mWyHRg7KYmZZSfU9b39bBFhEAFbWyu3MW7jvVillxwh9N9RftobUfbg+tfVl7aK1PqgHAsSy+sp3krYKw9hG7MKx/GajhTackea0gMHaiVuhB0LeiEDw9ZcM9UAyflwMAgN6b3nDvYU451Apcj6jVUX1sYmyrU2uAqhoRAebv2WlPqVUX7dZRNG4MGVrbnp6HfyDJ3yX5VHto7WvaQ2tPlg4AHNGvJTlfDFinUrDxJHeJoXivTPJUYyfM0aQeNF6AHpSFWoEePKanZOl1S9QSKIEN9wAA0GPj+3eMJtlb35/QqdpqBa7HTjnlvuix82qZABW2ohovY1IlsPZpNl9ORBMtTXLGYf/7+Un+NMloe2jtf2wPrT1dRAAwbfGVT0qy0RoB61SqacbPtXZnz+UegpVvtQiMnaAH1UoUoAmbGYVa0XdOuQeKYMM9AAD0xw0iKI0HimolC9CDT/D1JH+lzkAVnbpwzZOSfF+3/1xvIrjXQg926MsH926+V61ooKN96c3ZSTYn2dceWvsH7aG1zxQVAORNSRaIwTpV7MIo3G71L9zwppEkFwoCYydgvABcj2pFX4yIACiBz8oBAEB/TG+49zBnEJyqfThhoG9hDj34xxNjW78tD6CiXpLkhOq8HAd8udcqT1sU3XCLCGioFcf5/89MsjbJve2htde2h9YOiwyARlp85fOSvNHaB7Wi2mb0XOujcipezU63N3Yy6KFTDxovQA/KAjBeHJMN90ARbLgHAID+qPkJ9x7+ogdlMTO+AOOQtr4t8eK6VgxAha3s3ZyF+061YsZuFgENtWKGv++UJBcnubs9tPad7aG1TlMEoDkWX9lKsi3JycKw9lEralBMG+5LNrzp6UleIQhjJ+hBtRIFaMJmR6FW9NUFWXrdCWIAqs7n5AAAoA/G9++4L8ldkiiNB4rgekStvuf/TIxtvUd9gQrzbeCYv7ug7YMvc7VbF9G4cWNo7WlJXtThv9ZK8m+T3NIeWruzPbT2pyQJQAO8LsmPiIFarH0so5sexiey5/Kvq33RXptknusRtUIPolaA61Gt6JvTkrxQDEDV2XAPAAD9c/2j/+FhziA4VftwwgCYxdi5RQZAxVVww/2kqmDt0zw23NNEL0kylxM5fiLJP7WH1t7eHlr7q+2htSeKFIDaWXzlwiRXWSOAHizHMZ9r3SSfgg1vaid5vSCMnfRi6FQrjBeiUCtZoAdRq2NykARQeTbcAwBA/9T8jXcP3tCDspgZX4BxSFvfluJzSd4nBqCqTl245llJFvZ2zsJ9J3rwuO46uHfz/epDA63s0p9zfpK/SPLZ9tDa1e2htaeKFoBaWHxlK8mOJPOFYZ0qdmHUhA33Zfu5JOeKAWMnaoUeBH0rCsHTd8tFAFSdz8gBAED/3HDoKY6HOeVQK3A9olbZOjF2jWOagSpbIQLM393TFsVs7RIBDdXt0ziGklyd5AvtobVvbg+tfaqIASjcmiQ/bu2DWlGeyaM15gdkU7RLjJ3Qy6FTDxovQA/KQq1ADx6VDfdA5dlwDwAAczQ1NTWjX/fft/3rST5R8zQq/eqcql1Orag/1+MhTrmvvAenT+ACqLIKb7j3fSVY+zSIDfeYh7vrqUmuTLK3PbT2f7SH1i4UNQDFWXzl9yfZKAhrH9SqRj6RPZd/XQyFGt703CQ/JQhjJ+hBtRIFaEJRqBUD8eIsve5UMQBVZsM9AAD01/UiKJEHimolC2hwD/75xNg131BPoOJG+vGXeEPBvRZ68Dh2qwtN0x66/FlJer0R/klJLksy2h5a+/b20NoXSR6AIiy+8owk70hysjCo7frb44EmhvEhtS7aatcjagV6UK0A16NaMTAnJFkmBqDKfD4OAAD666ZD/9XDnEFwqvbhhIG+hRnYIgKgyk5duKbdrw33s+eUe/da5WmLolPfTnKHGGigkT6OnSck+fUkn2gPrf2n9tDaf9UeWttSAgAqafGVrSTbkyyx9gE9WLYnPNe6SSaFGt70pCSvFoSxk34MnWqF8UIUaiUL9CBqdVTL1RCoMhvuAQCgv25K8ki9f0QP3tCDspgZX4BxSFvfVtWHJ8auuV0MQMUtTXJG/+Ys3HeqFUd028G9mw+KgQZaMaC/96eSvC/JHe2htb/VHlrr5GAAquY/JfklMVj7QA29XwTFelWSM8WA+Ru1Qg+CvhWF4BmoFSIAqsxn4wAAoI/G9+/4VpLdh/6JhznlUCtwPdLAWjndHiiBNyMxf/dI28kvnditY2iokQFfjy9KsiPJve2htZe3h9Y+WUkAGLjFV/7rJG8RBI1Zp1pGNymMT2XP5V9R52Jd4nqEPnLKvfEC9KAs1Ar04JE54R6oNBvuAQCg/26o/4/oVG21Atdjp5xyXzlfSvIuMQAFKGTD/aRKYe1Tb7tEQOPWcEOXtw9tuB+4Zyf5L0m+0B5a+/+1h9YuUiEABmLxlS9I8o4yPpNmjYAeZKa+91zrfbIo1PCmH07yYkEYOwHjhShAE4pCrRi452bpdWeJAagqG+4BAKD/bhBBqTxQVCtZQIN6cNvE2DUPqR9QgL5vuPfGgnst9OAROOGeJnpekvkVe01PSvI7ST7XHlr7zvbQ2pXKBEDfLL7ymUneW8H50RoBsQujW/5JfYu1WgQYO1Er9CCAsZPKcMo9UFk+FwcAAP33kSTfOfQ/PcwZBKdqH04Y6Ft4nEeSbBMDUHWnLlxzWpIXlfOKnXLvXqs8bVHMxFcP7t28Rww00IoKj53tJP82yUfbQ2s/3B5a+/L20FqfDQCgdxZfeXqSv09yrrUPakU9TX47yQfkUKDhTc9K8nJjJwxi6NSDxgvQg7JQK9CDR2TDPVBZ3lQHAIA+G9+/49vTm+5rzgNF9KAsZsYXYBzS1rdV8bcTY9fsEwNQgAuSnDCYOQv3nWrF9zjdnqZaUcjr/IEk70ry2fbQ2jXtobVOHQaguxZfeXKSv0lyoTCsfVCrGnt/9lz+oBiKdHGSk8Rg7AQ9qFaiAE0oCrWiMmy4ByrLZ+IAAGAwbhBBqTxQBGjA2LlFzYBCrBQB5u/ea/vgy/HcrEtoqJHCxs7FSf5/ScbaQ2v/sD209rlKCMDcZ5crT0jytiT/Shg0fp1qGV33MP5JXQs0vOnEJKtcj6gV6EG1AlyPakWljIgAqCob7gEAYDB2PvZ/epgzCE7V1oPoWziCT0+MXXOjGIBCFPgm5KSq4R6yfpxwT+O0hy4/Ncn5hb7805NcmuSu9tDa97aH1v50e2htS1UB6NjiK1tJ/meSV1gjgB5sABvuy/QLSRaIwdjJAE2qFcYLUaiVLNCDqNUTLMjS685WP6CKbLgHAIDBuCXJRP1/TA/e0IOymBlfgHFIW98OmtPtgZKsGOychftO9GBiwz0N9ZIkJxT+M7SS/Jsk/5jk0+2htZe0h9aerrQAzMijm+23Jvl1YVgjIPYGhPGF7Fn3aTUt0qUiwNiJWqEHQd+KAsFX0nIRAFXk83AAADAA4/t3PJzkpsf+Uw9zyqFW4HqkprX6ZpI/UyugBKcuXPPMJOdKAvN3f7RFcTR3H9y7+RtioIFW1mzsXDr95WNfaA+t/a/tobWLlBiAo1p85QlJrkvyemsf1IqGcLp9iZZsfGGSHxWEsZMKcMq98QL0oCzUCvTgE9lwD1SSDfcAADA4NzXjx3SqtlqB67FTTrkfmLdNjF3zTTEAhRgp96VPqh7WPvXhdHvMw/VyVpI3JtnTHlr7v9tDa39cqQF4jMUbTkjytiQXCcPaB7VqkH8UQZGcbm/sBD2IWokCTSgKtaK6RkQAVJEN9wAAMDjXi6BkHiiqlSyghj24RY2AgqyswovwJoN7LRrfg7vkTkPV/UNArSS/kOSG9tDaf24Prb2oPbT2ScoO0HCLN5yS5J3J1K8JA+tvjwcaFMbDSXaqZWGWbJyf5FWZckEanNQK9KBaAa5H1KqiLszS61piAKrGZ+EAAGBwPpHkG4/9Rx7mDIJTtfUg+haS3Dgxds1nxAAUpPCNfk65d69VnrYojsQJ9zRvLBi6/BlJhho0dn5fkm1J7msPrfsf7aF1S3UBQAMt3nDm9AnPv2jtAzTM+7Nn3f1iKM5vJTldDE1g/i7GpFphvBCFWskCPYhaPcZZSZ6rdkDV2HAPAAADMr5/x2SSG5rx03rwhh6Uxcz4AoxD2vq23/5QBEApTl24pl2lDffeaHDfqVaN9VCS28VAA4009Oeen0xdluQz7aF1N7SH1r28PbTuRO0A0ACLN5yT5P1JflQY1j6oVQP9rQgKs2RjK8klggDM3+hB0LeiQPCVt1wEQNX4HBwAAAzWjU/8Rx7mlEOtwPVITWq1L8l71AYoyPMe3fQG7rX6re3kl8PddnDv5od0BQ200tiZH0/yriR720Pr1reH1i3QFgA1tXjDBUl2JTnfGgHrVMvohobxbjUscr2y9FALuiANTmoFehA9KAvUCj1YUSPqBlSNDfcAADBYO5vzozpVW63A9dgpp9z3zXUTY9c8LAagICvq8WNMqiTWPmXbJQIaquEf/nnM2LkgyYYkn28Prfvb9tC6l7aH1vkMAkBdLN7wsiQfnB7vrRFADzbRx7Nn3efFUJzfEYGxk4qaVCuMF6IADBjwGE64ByrHm90AADBA4/t33JlkvyRK5oGiWskCCu/Bg0m2qQlQmMptuPdmg3stGtmDNtzTOO2hy1s23B/RCUl+Psn/SXJPe2jdf3bqPUDBFm9oZfGGNyX5uyRPsvaxRkDsDQ7j79SuMEs2PifJzwkCYydqhR4EfSsKBF+EC7L0uhPFAFSJz8ABAMDg3fDEf+RhDoOmB9G3NMY7J8au+bIYgMLU6Fu+nXLvXqs8bVF8124R0EDPS3KmsfOYFib53ceden+C1gEoxOINZyR5Z5Lfs/ZBrSB/K4LivH76C8EeN1wYL4ydVIZT7o0XoAdloVagBw85JcmL1A2oEhvuAQBg8G5ozo9a7Yc5Lc87wfVYQW1vxvTa1SIASnLqwjWnJjm/mnMWpax9UKsu+NrBvZs/JwYaaIUIZjx2Hn7q/b3toXW/1x5at1h2ABW2eMP3Jbk1yS8Jw9oHtSL3ZM+6T4ihIEs2npzkIkEYO0EPolaiQBOKQq0oyogIgCrx+TcAABi8G0RQOg8U1UoWUGgP3j4xds1H1QIozAVJThQD7iEHq+2DL063p6lWVPB6LME5Sd6U5HPtoXU720Prfq09tO4UsQBUyOINv5VkV5LzzHNYp1pGCyNJ8ndqVpxfTvL0o7egC9LgpFagB9UKcD2iVhV0oQiAKrHhHgAABmx8/457k4w+8f/xMGcQnKqtB9G3NMofigAoUA1P1p1UVdxDlmeXCGgop2zMbexsJfmJJH+eZH97aN0ftofWvUSWAAO0eMMZWbzh7Ul2JDlNINYI6EG+529FUJxLRWDspBCTaoXxQhRqJQv0IGr1PSvUDKgSG+4BAKAabmzOj+rBG3pQFjPjCzAOaevbXvhGkr8SA1CgSr/Z6E0H9500hhPuad66bOjyU5OcL4muOWt6Q8zH2kPrPtEeWvcf20PrniUWgD5avGFlktuS/Lq1j3UqYhfGY3w5yYfUqyBLNl6QZKUgMHaiVuhB0LeiQPDFeUGWXvckMQBV4bNvAABQDTuP/I89zCmHWoHrkcJqtX1i7JoDagCUpjU55du9ca9VEe1mn/xiwz1NdEGSE42dPfGiJJuT7GsPrfs/7aF1v9IeWjdPLAA9snjDSVm84femN5MuEYj5W63gCf46e9Y9IoaizOx0+ynjhbGTynDKvfEC9KAs1Ar04KNOSLJMzYCqOFEEAABQCTc268edStKq7KtrTSVTLU1ZQq2oP9fjIe1MZdL12M3BbasYgNKcds5lz0gyVM+fbtJ3BGPtU47PHdy7+WtioIFGRNDzsfOEJC+d/nV/e2jdO5L8zyQ3T977Bz6hCNANize8OMmO6S+SwfyNWnFk7xBBQZZsfEqSXxUExk70IGolCjShKNSKYq1I8mExAFXg02sAAFAB4/t3fDHJpyRROp/7VStZQCE9+I8TY9fskT1QoJE8esp9pV+kNx7ca1H7HnS6PU21QgR9dVaSi5N8JMme9tC6328PrVsqFoBZWrxhXhZv2JDkY73ZbG/tAy6R2oTxBR/yL85rkpw68xZ0QRqc1Ar0oFoBrkfUqmJ86TVQGT73BgAA1XHTkf+xhzmD0BK7HkTfUmdbRAAUamW9f7xJFXavVZx2M6O4WeVpqDl+2MfYOQeLklyR5DPtoXUfaw+te2N7aN0CsQDM0OINPzi90X59khMFYv5WKzimv86edRqqFEs2tpNcIggo1KThFveQolArWaAHUaskyYXqBVSFDfcAAFAd1zfrx/XgDT0oi5nxBRiHtPVtN9yT5B/EABSqmG/19uaD+061qjUn3NO8tdjQ5U9PslgSlRg7X5Lkvyb5Qnto3fXtoXWvbQ+te7I6ABzBog1PyaINf5TkQ0leKBCsfdSKGflLERTlp63VMHaiB0EPom9FgeCLtyRLr3uKGIAq8K3FAABQHR+YPtLxCHtTppK0JFQEtQLXIxWv1daJsWscoQwU57RzLmsdvuG+NTmVqbZ5DvdaVdCeSiZbjanVQ0luV3UaaKSC12Pjh98k/3L619b20Lr3JfnrJO+evPcPxsUDNNqiDScmuSjJ7yZ5mjUC1qlenjBmbE/2rPuY+hTl0tm14FTSckEanNQK9CCAsRM9WCEjSf5RzYBBc8gMAABUxPj+HV9PcluzfmqnaqsVuB475ZT7Ofl2kj8VA1Co5yU5s/4/pu9Ewdqn4m4/uHfzd8RAA60UQaXHzpOT/GyStyX5cnto3d+0h9a9sj207nS1ARpn0YafmH6vaWt/N9ub50AP1oLT7UuyZOPiJP9GEBg7CzepVhgvRKFWskAPQpLkQhEAVeCEewAAqJYbk3y/GKBffIusLGhYD/7lxNg1X5c1UKjlj/8HVT/lvm37vHst6tiDu2VJQ42IoBgnJ/nF6V/fbg+te2+Sdyb5+8l7/+Bb4gFqa9GG4SRXJfn5wS5HrH2sUxF70WG8Q12K8tuuKIydqBXoQfStKBB8bawQAVAFNtwDAEC17EzyH4/8f3mYUw61AtcjFXW1CICCNehk3cnp7fq41ypHeyqZbEYUN6s2jbu+hy5vdXfDvbGzj05J8vLpXw+1h9a9L8nfJPm7yXv/wJexAfWwaMPTklye5LIkJwnE2ge1Ytb+OXvWfVIMhViy8dQkr53bcDGVtIwXxk4qYXIqaetB4wXoQVmoFTS8B5erFVAFNtwDAEC1fCjJwWZ9KKraD3NaU8mU551F1Ir6cz0e0s5UJl2Pnbp5Yuyaj4sBKFiRJ+s65d79tFrVzi0ioIHOS3KWGIofO09O8rPTvx5uD637QJL/Nb35/j71A4qzaMNZSf59kjckme8WF2sftWLOdoigKK9M8mQxYOxED6JWokATisILpDaemaXXPSd3XvwFUQCDZMM9AABUyPj+Hd8689mv3p3kB6VROg8U1UoWULEe3CJfoFSnnXPZKUmWHen/a01OZcrJL7iHrITqn3I/51p9I8lnVZoGGqng9cjcnJjkJ6Z/bWkPrftokncnec/kvX/wafEAVdZatOH0JJdOJf9PkqdYI0CBPegSqWIYDyf5c/Uoyu90pwWdcm9wUivQg2oFuB5RqwoZSWLDPTBQNtwDAED17Dz6hnsPcwbBqdp6EH1L8b6S5J1iAAp2QfOe508maas8VMvug3s3T4mBBlopglqvv1tJfmD611vbQ+v2JHlPkr9L8qHJe//gYXUFKjFYLdpwapKLk1ye5JkSMc+hB+mqf8iedV8SQyGWbFw5/bwUjJ11MjmV+HJhjBeiUCtZoAdpeq2WJ3mXegGDZMM9AABUz41J3tysH9mDN/SgLGbGF2Ac0s5UJvXtTP3RxNg13xEDULAVZc9Zj26fx32nWhVvlwhoqBERNMqSJP9++tf97aF1701a70nyj5P3vuV+8QD91lq04awkq5OsSfL0cm5x3U9b+yD2osLYrg5FWS0CMJGoFehB9K0oEHwtLRcBMGg23AMAQPV8NMmDSU498v/tYU451Apcj1SgVo8kuU6uQOGOueG+NTmVKSe/4F6rEtpTyWR9T36x4Z7mXdNDl89LsszY2VhnJfm1ZOrXktYj7aErPpLkH6Z/3TF571umRAT0SmvRhnOSvGH6VPsnPeH/n55JsPZBrZizryb5ezEUYsnGZyT5le4OF1NJy3hh7KQSnHJvvAA9KAu1gqb34PIsva6dOy92pgMwMDbcAwBAxYzv3/GdM5/96o8k+ZfN+smdqq1W4HrslFPuZ+Q9E2PXfF4MQOEaerLuZJK26mPtUx27RUADXeA9dWPntBOS/PD0rz9Isr89dMU/Jnlvkusn733L/WoPdENr0YYXJvkPSV6V5CSJANapPffn2bPuoBiK8dokJ4sBYyd6ELUSBZpQFF4gtXRGkvOS3CkKYFB8OAAAAKppZ/M23NeVB4pqJQsYcA9ukSdQstPOuezpSRYf7/dV/ZT79vT2edxrUWwP7jm4d/NXZUcDrRABRxk7n53kNdO/HmkPXfGRJP+U5P8m+djkvW95RGbATLUWbTghycuSrO75e0N9XY5Y+1inIvYiwvhT+RdiycYTkvy2IMBEgh5ErcD1iFrV2ogN98Ag2XAPAADVdOOx/28PcwbBqdp6EH1Lce6c/hIbgJKNNPvHd8q9e63ytKeSyfpF4XR7mqrHG+6NnTVxwvTJ9z+c5PeT3N8euuLGJNcnuX7y3rfcLSLgSFqLNjwjyUVJLk7ynI7//emZBGsf1IpZuy171n1CDMX4udnMlzMbLqaSlvHC2EklTE4lbT0IpgRzlizQgzS4ViNJ3qZWwKDYcA8AANV0S5IHksxv1o/twRt6UBYz4wswDmlnKpP69miumRi7xueOgdKtrM+c5ZR7951qVbBdIqChRkRg7JyFs5L84vSvtIeu+MJ3N99Pb8D/sh6BZmst2vBDSV6f5JeTnGyYxvyNWg3MDhEUZbUIMHaiB1ErcD2KAsHX3oUiAAapNTXlM8cAANC3G/AOvhX9zGe/+j1JfvY4f2IdU6r0q5v9Bl+18nPJwvXYO5OuxyP5VpKzJ8auecC1DJTstHMu+8ckPz3j+bHiJ7/MbsN9XU+4N3/X/Weq/in3Hb3Af3Fw7+abu3If771JOnxGNijtocufluQrxk4/Uw9+rk8leX+SDya5afLet3zRqAANmPsWbTgnyW8meXWS53bzz57V3VVfh2nznJ/Lz9X9l6dWXfBgkrOzZ903zFIFWLJxaZLP9GGxKmvzt5+rCtpq5efyM1Xm52qplb71c7ke1crP1HcPJTk9d158sOSUvScO5XLCPQAAVNfO42+4p9+cqn043+CJ67EqnHJ/RG+32R4o3WnnXNZysm6mt+m3xYC1z+A8nOR2fUADmYONnb3ywulflyRJe+iKu5LcNP3rQ5P3vmWfiKAeWos2nJLkF5K8Jsm/MjCa50APVspf2WxflN8WAcbOBpmcqvGme4wXolArWaAHUavjODnJsiS3qBUwCDbcAwBAdd3YzB/bgzf0oCygKz14tfyAGnhukid38i+0Jqcqfcp9e9an3JvnYIA9ePvBvZu/LS+app2sMGfRp/n7edO/Ls6jG/D3JHl/kg8n+UiSuybvfYujUKAQrUXrT0jyY0lekeRXkpxpOWLtY52K2CsZxlZ5F2LJxtOnv7wGMJGoFehB9K0oEHwzXGjDPTAoNtwDAEB1fSLJV5M87ei/xcOccqgVuB7po/dPjF3zKTEANeBk3e9xyr17rfK0p5LJekSxWzVpqBXGTgZkyfSvfzf9v7/eHrrio4dtwL9l8t63HBATVEdr0fp2kh+d3mT/8iRP7+vfPz2TYO2DWjFjt2bPulvFUIxXJTmjP8PFVNIyXhg7qQSn3BsvQA/KQq2gyT24PMk16gQMgg33AABQUeP7d0yd+exX35Tk3zbvp6/2w5zWVDLleWcRtaL+XI+HtDOVSdfjd20RAVATK0UA1j4VcLP60zQnDl3e8sU3xs4KeUqSn5n+lSSPtIeu+HiSj07/umXy3rfsERP01/RJ9j80/R7OLyV5tmEa8zdqVQyn25dltQgwdqIHUStRoAkpIQq1omtWiAAYFBvuAQCg2nY2c8N9XXmgqFaygD704H1J/rfcgJqY1Ua/1uRUpip88kt7+rx63GtRTA864Z4mem6SJ/d3zjInmL9n7ITp012WJ7ksSdpDV3w9yS1Jbp0et3dP3vuWL6oVdFdr0fozk/x0kp+b/hKMJ1dlvKj+KffmOfSgS6QyYXwjyV/JuRBLNv5oku/rbws65d7gpFagB9UKcD2iVgO2NEuvOz13XvwtUQD9ZsM9AABU287j/xYPcwbBqdp6EH1LZW2bGLvmYTEApTvtnMvmJVkmicNNTm/Xx71WOdpTyWTZUdyf5G6VpIGcbk9pnjK9CfinvzcHDV1xX5Jdh23Ev33y3rd8RVTQmdai9YuSvCzJzyb50SQnSQVrH/Rg0XZkz7oHxVCMS0SAsbPBJqeStlphvBCFWskCPUgDa9VO8pIkH1AnoN9suAcAgAob37/js2c++9VjSc5u3k/vwRt6UBYz4wswDmlnKpPN7tuDSa7TCUBNXFDnjRxOuXffqVbF2H1w7+YptaeBVojA2FkDC5L84vSvR+/BHt2Ef3uS26b/8/YkeybvfYuxHqa1Fq0/K8lPJPnJJD+VZIlhGvM3Yq9VGNfItxBLNi5I8nJBgIlErUAPgr4VheAbaYUN98Ag2HAPAADVtzPJbx77t3iYUw61AtcjPazV30yMXfNFeQE1MaeNfq3JqUw5+QX3WpVQ/VPuj1mr3SpIQ33vhPv+fkmMsdM813MLpn+99LB/9q320BV3PLr5vnV7kk8m+fTkvb//gDrTBK1F609O8i8O22B/4fTwX9x40Zr+24ydoAc5quuzZ91nxVCMVQP7jPPUVNIyXhg7qQSn3BsvQA/KQq2gqT24XH2AQbDhHgAAqu/G42+4ryunaqsVuB471fBT7rfoAKBGnKx7RJPd3fsC1j7Hc7Oa0zQnDl0+L8kySRg7G+T0JD/46K9DtWoPvenz3918n+RT078+M3nv739LZJSstWj9/CQ/kOSHp3+NJJknGcxz6MFG+B8iKMSSjScluVgQGDvRg6iVKEATlhiFWtEVNtwDA2HDPQAAVN9OEdSNB4pqJQvoQQ9+YmLsmg/KCaiRkbn+AVU/5b6/Jwa714JZ9qAT7mmiZUlONmdh/s7C6V8vfcz1MPSmvUn+OclnktyV5LNJ7p689/e/qCeootai9YumP5z5Q9Mb7F/c/2/xqvh40deXZ+1jnkPsAwvj7iTvlWsxXp7kWWIAEwlgvADXI2rVWENZet3Tc+fFXxEF0E823AMAQMWN79/xhTOf/eo9SZYc+3d6mDMITtXWg+hbKsPp9kBtnHbOZU87/v1/kznl3r1WedpTyWR5Udx7cO9mH2CgiUYG+9cbO6n8/H3u9K+ffcxcN/SmB6Y33981vaHtu//9s5P3/v4DcqUfWovWPyvJ9ydZkeTC6Y32T2tUBtNXMeZv1Ion+O/Zs873aJXjksEPF1NJy3hh7KQSJqeSth40XoAelAV6kAbWarkvzwP6zYZ7AAAow87mbrjx4A09KIuZ8QUYh7Qzlclm9e14kj9XeaBGljdnznJisPtOtaqwXWpNQ60UgbGTWZk/vdH5+59wzzf0pi8nuSfJaJJ7D/vPe6Za+fzUPb9/UHx0orVo/QnT75m8OMmLkpyf5CVJniMdwzQaQ604gq8l+Z9iKMSSjS9O8iOCwNiJHkStRAGaUBQ0ng33QN/ZcA8AAGW4IckqMdSJJ57geqSLtdo+MXbNhHyAGlnRrT+oNTmVKSe/4F6rEqp/yv0TamXDPU11xBPu+/slMcZO81ztPGP615Hucydbi960b3pD/nd/jSXZl+TzScam7vn9B0TYTK1F61tJFiZ5XpLnH7bB/vuSnGq8OEpulT/l3tiJHnSJ9D2Ma7Nn3YPyLMYl1WlBp9wbnNQK9KBaAa5H1GqARkQA9JsN9wAAUIYbZvbbPMwZBKdq60Goooadcr9VxYGaWSGC45mc3voI1j49ZMM9jXPi0OVPTTIsCWMnfdwYPJX2VCsLpzdV/+gRf8+iN31regP+Fw7bjP/dX/uTfDHJV6bu+f2Dalem1qI3Pz3JoumN9eclWZq0zpv+76dICGMn6ME5eCjJH4qhEEs2npnkVYLA2MkTTE4lvlwY44Uo1EoW6EGaVisb7oG+s+EeAAAKML5/x1fOfParPzl9aksDefCGHpTFzPgCjEZ638TYNZ8VA1AzXX3TsOqn3Pf3xGD3WjDDHnw4yW3ywBxszsL8XRGnP7oBO0uPed+76E1fTfKVJF963K+vJLnv0f9sfTXJ16fu+b37xdofrUVvPiHJM5I8Z/qLFYaO8OtJxoumvTxjp75F7H0L4+3Zs+5LcizGq5tzXwAmEtQKPQj6VhSC5zielqXXDeXOi+8VBdAvNtwDAEA5ds5sw72HOeVQK3A90oVabZEJUCennXPZc5M8RRK416qn9lQyWUYUdxzcu/lBFaOBVhg7oegefNr0r+cf7ze2Fv3nySTfSPL16V+P/+9fnf7vDxz261tJvpnkW1P3/N43m9wdrUVvnpfkqdO/vpv7U5M8K8mzk5w9/d/Pnt5s33ZN9blG01cxxk7Uivx3ERRiycZWkkuqN1xMJS3jhbGTSnDKvfEC9KAs1Aqa2IPLk9hwD/SNDfcAAFCOG5Osae6P71RttQLXY6famcpkva/HvUn+XqWBmhkRwUxN2reDtU/v7FZfGmqFCIyd9F9/n+V8rwfbh20Y7/w1L/rPOWwT/vc24ie5P8lDSQ4c4T+/k+TBI/znwSQTj/srZvrPvvuKvvtfTk5y2jFe+kmHnRp71vR/nj79+aFTkpya5Mwk86f/+RnTv06f/v1nTW+uf5LxwjCNxkCtCvC+7Fn3STEU4yeTnCcGjJ3oQdRKFKAJ6xSFWjFnI0neKQagX2y4BwCActxkR0kdeaCoVrKAOfTgNRNj10zKA6iZlb34Q1uTU5mq8Mkv7enFDu61qEwP7pIDDXXcL74xZ2H+5jDzp3/pQSpZq+qfcq9v0YMukZ6H8V9kV5TV1W1Bp9wbnNQK9KBaAa5H1GpAlosA6CcbdQAAoBDj+3eMJ/n4zH73lMAGoCV2PYi+pZ++k+RPxADUkBPuO2LLo3ut8rTLiMKGexrnxKHLh5M8xdgJehDA2IkerIVd2bPuJjEUYsnGc5P8nCAwdnJck2qF8UIUaiUL9CANq9X3Z+l1J6gN0C823AMAQFl2NvvH9+ANPSiLmfEFGIe069u3fzUxds1XVRiok9POuWxekmXNnbNw36lWFfFAkrvUlgbypTfGTgaov89y9KDxArGjMWhAD26QWVFe7/EgmL/VCvQg6FtRCJ4jOD3JUjEA/eIBFQAAlKWDDfce5pRDrcD1yCxqtUUGQA0tS3Jyr/7wlpNfcK9VGRU/5X73wb2bFYsmWjHja9jYiVqhBymkVi1ZQNk96BKZrduT/JMYCrFk47wkr63+cOGCNDhRGd7rMF6AHpSFWkHTetCXZgN9Y8M9AACU5cNJDjY7AqdqqxW4HjtVw1Pub5kYu/YWlQVqyJuEszIpAqx9umu3mtJQK0Rg7GSwtfIsB+MF+hb0YJf8bvascyGW4xVJni4GjJ2A8UIUoAnrHIVaMSfLRQD0iw33AABQkPH9Ow4k+agk6sgDRbWSBXTA6fZAXa3s9V9Q9VPuvWnhXotKuFkENM2JQ5efnOQCcxbmb7UCPTiIl+d61LeIvathfCbJ38mqKJeIAEwkqBV6EHA9qhXHYMM90Dc+BwAAAOW5cea/1cOcQXASkx5E39JTX03yDjEANeWE+1lzyr17rfK0qxuFE+5pnNZUliU52dgJelCtqOU8JwLXI2rVLL+bPes8KCrFko3fn2RFOcOF8cLYSWVM6kHjBehBWQANGi/Oz9Lr5qkL0A823AMAQHl2isDDX/SgLGbGF2Ac0q5P3/7JxNi131ZRoG5OO+eypyQZloQ3Ltx3qtWA7T2496ovqScN5EtvjJ1URMup2qiV2NEYqNXs7Unyv9S+KJeKAGMn6EG1EgVowqZEoVbM2klJlokB6AefWwMAgPLsSvKgGOrIA0VwPTKDwlwrBqCm+rbRr+XkF9xrVUYFT7nfpSo01MpZXcPGTtQKPUghtWrJAsruQZfITMN4S/ase1hGhViy8alJXlleC7ogDU5qBXpQrQDXI2o1ABeKAOgHG+4BAKAw4/t3PJTkAzP/NzzMGQSnautBoCfeMzF27b1iAGpqhQjmalIEWPvM3W51pKFGPMsxdlKdWrkeMV6gb0EPzsKeJH+m5kX5d0lOEQPGTmbNlwtjvBCFWskCPUiTauUzNUBf2HAPAABlulEEHryhB2UxMz6kfUi7/L7dqopAjXlz8DFzFu47GZCbRUDTnHTu5U9J8lxzFuZvtQI9OOiX53rUt4h9TmFscLp9QZZsbCf5bUGAiQS1Qg+CvhWF4Jmh5SIA+sH7/wAAUKadnf12D3PKoVbgeuQoPpvkfWIAamykn39Zy8kvuNeqjHZ1ongkycdVhCbPwS0nMYEeVCtqrCUC1yNqVV+fTvIXYijKS5MsKne4MF4YO6kM73UYL0APykKtoCk9+Lwsve4MNQF6zYZ7AAAo021JxsXgVG21Atdjpwo+5X7rxNi1KgnU0mnnXDac5KmS6IZJEWDtM3ufOLj3qgfVkAZaIQJjJ9XTcqo2aiV2NAZqNXNXZM86D4XKsloEGDtBD6qVKEATNjUKtWJWWk65B/rBhnsAACjQ+P4djyS5SRJ15YGiWskCHudAku1iAGpsZBB/adVPufcGhnst+m63CDAPm7MwfwPGC1mgB728wmp1S5K/k0dBlmxckuSny29BF6TBSa1AD6oV4HpErfpsRARAr3nvHwAAynVjZ7/dw5xBcKq2HkTf0hVvnxi7dlwMQI05WberHGjmXqs87WpEsUslaKjHfDin5eQX0INqRY21ROB6hPp5U/asc5GVZbUpCfM3XTWpVhgvRKFWskAP0pBaXageQK/ZcA8AAOXaKYJ48IYelMWM+QKMQ9rl9e1WVQNqzob7o85ZuO9Uqz6y4Z7GOency5ckeZokjJ1UU3+f5ehB4wViR2OoVYHenz3r3qe+BVmy8bQkrxYEmBNQK/Qg6FtRCJ5ZcMI90HM+qwYAAOX6VJIvd/aveJhTDrUC1yPTPjgxdu0dYgDq6rRzLjs5yQWD+vtbTn7BvVZlDPiU+28muVMVaKCufTCnv2+8GzvNc6AH1WoO60BZQNk96BI5PIx1MijOryV5cn1a0AVpcAKMF+hBWaBW6ME+ek6WXvcs9QB6yYZ7AAAo1Pj+HVNJbpREnKqtVuB6nIWCTrl3uj1Qd8uSnCyGbpsUAdY+ndl9cO9VLhyaaIW1o7GTatfK9YjxAn0LevAo3ps9V3xEXYuzWgQYO+kJXy6M8UIUQIHXowGDWblQBEAv2XAPAABl2ymCOvNAUa1kQeN9Mcm7xADU3PJBv4Cqn3LvjQz3WvTFbhHQUCvMWZi/USv0YBVfnutR3yL2Y3okyX/SCIVZ8tYfmP7yUcBEglqhB0HfogeZrRUiAHrJe/4AAFC2WZxw72HOIDiJSQ+ib5mVbRNj1x4UA1BzK0XQKw7rdq9VnvbgotglfZrmpHMvPynJBUf7/1tOfgE9qFbUWEsErkfUqmx/nD1XfFIMxann6fZTxgtjJ5XhlHvjBehBWagVNKEHl6sF0Es23AMAQMHG9+/4XJLPSyIeKAIz5gswDmlXe+x8OMk2VQIaYEQEM5mzsPZRqx6z4Z4mWpZknhiMnVRfy6naqJXY0Rio1SHfTLJeLQuz5K3PSPLLxguMnaAH1UoUoAlFoVbMkQ33QE/5jBoAAJTvRhHUmQeKaiULGutvJ8auHRMDUGennXPZk5OcV4XX0nLyC+4hK2MAp9x//uDeq74oeRqoJ19609834I2d5jnQg2o1h3WgLKDsHmzuJfLW7LniS/qzOKuSnFTf4cKcZXBSK9CDagW4HlGrPnlKll63RAxAr9hwDwAA5bu+83/Fw5xBcKq2HkTf0pGrRQA0gNPte25SBLiHPL7d6kRDrTzeb/Asx9hJdWrlesR4gb4FPZjk80n+uxoWZslbT0xysSAwdtIXvlwY44Uo1EoW6EGaUCun3AM9Y8M9AACU7yYRfJcHb+hBWcyMD2kf0q5mrT41MXbt+1UHaAAb7juas3DfSY/YcI952JyF+Ru1Qg9W9OW5HvUtYn+MddlzxYMKX5yXJTnHeAEmEtQKPQj6VhSCp0tsuAd6xnv9AABQuPH9O/Yluavzf9PDnHKoFbgeG8fp9kBTrKzSi2k5+QX3WpXR7m8UN0ucpjnp3MufnOQ8YyfoQbWi6VoicD2iVuW4JclfiKFIlzZjuDBeGDupDO91GC9AD8pCraDuPbhCHYBeseEeAADq4UYRfJdTtdUKXI+dqtgp999M8nZVARrCCfd9MSkCrH2O7pEkH1cjGmjGJ19YOxo7qQ7XI8YLsaMxaHSt3pg9V2iy0ix56/OT/LjxAmMn6EG1EgVoQlGoFV10QZZed4IYgF6w4R4AAOphpwjqzgNFtZIFjbFjYuzab4kBqLvTzrlsSZKnVe11Vf2Ue29quNei6z55cO9VE2KggXr+pTfmLMzfagV6UBbgEumad2bPFR9S7CKtbtb1aM4yf6sV6EG1AlyPqFUfnJbkhWIAesH7/AAAUA/vn92TGQ9zBsFJTHoQfcsxbRUB0BBOt+8rp9y71ypPuz9R7JI0DbWyk9/ccvIL6EG1osZaInA9olbVdiDJfxBDgZa89YwkvykIzAkMxKRaYbwQhVrJAj1IzWvlMzdAT9hwDwAANTC+f8dXknxCEt/lwRt6UBYz4wswDmlXo1Y7J8auvVM1gIZYIYLZzlm471SrLtqtNjSUD+EYOylUf5/l6EHjBWJHY6hVBfxe9lzxBfUq0m8kOcN4AeBeCz0I+lYUgqcHLhQB0As+lwYAAPVxw+z+NQ9zyqFW4HqsvatFADRIZTfct5z8gnutyujDKfc3S5mmOencyxcleXpfrmFjJ2qFHqSQWrVkAWX3YH0vkbuS/Df9V6zVzRwuzFnmb7UCPQhg7EQP9oEv1wZ6woZ7AACojxtEcDinaqsVuB47NeBT7r+Q5D2qADTBaedcdlKSZZLot0kRYO3zWN9K8hl1oYFm9aU31o7GTqpTK9cjxgv0LTSmB38ne654SJ0KtOStP5bkBYLA2MlA+XJhjBeiUCtZoAepsxdn6XWnigHoNhvuAQCgPj6Q5BEx1J0HimolC2rr2omxa81jQFOcn+SUKr/Aqp9y780N91p0xe6De6/yTRQ00Yp+/mXmLMzfagW17sEpWaBWYu+Z/5U9V/xfhS3WpcYLMJGgVuhB0LeiQPA9dIKDLoBe8P4+AADUxPj+HQ8kuXV2/7aHOQDGzoF6KMkfiwFokBERDIq9xe61ytPuXRS3SJeGmvWG+5aTmEAPqhU11hKB6xG1qo4DSd4ohkIteevZSX6h2cOF8cLYSWU45d54AXpQFmoFde7B5WoAdJsN9wAAUC87RXC4aj9QbHneWUytqD/X4yHtwVyPfz0xdu2XpQ80yAoRdGPOwv20Ws3RLvWgaU469/KTklwgCWMn5Ws5VRu1EjsagzrX6vey54ovqE2xLp4+adB4gbET9CBqJQo0oSjUil7y2Rug63weDQAA6uVGETSBB4pqJQtqZ4sIgIYp4k2/lpNfcA9ZGT065d6Ge5ro/CSn9P0aNnaiVuhBCqlVSxZQdg/W4xK5M8l/02uFWvLWk5OsEoRT7s3fagV6UK0A1yNq1QcXigDoNhvuAQCgXj6U5Duz+1c9zBkEp2rrQfQt+fjE2LU3iwFoitPOueysJM+TxCBNigCSsYN7r7pPDDTQyFz/AM9yrL+pTq1cjxgv0LdQyx5clT1XPKQmxXp5kmeKAWMnleLLhTFeiEKtZIEepK61Oi9LrztLDYBusuEeAABqZHz/jm8nsWnxMTx4Qw/KYmZ8SPuQdn9rdbXEgYYZEUE35yzcd6rVLHl2QFOtEAHmBNQKPVj6y3M96ltqHPt12XPFBxWxaJcaL8BEglqhB0HfigLB99FyEQDd5LNoAABQP9fP/l/1MKccagWux1r4RpK/EgPQMEVtuG85+QX3WpXR7m4UuyWKebjP17CxE3CvRSnrQBG4HlGrwbgvyf8rhoIteev5SX5QEIcPF8YLYyeV4b0O4wXoQVmoFdS1B224B7rKhnsAAKifm0TweE7VVitwPXaqT6fc/8nE2LUPShtomJUiqIJJEdD0tc8uNaBpTjr38jOTPM/a0dhJvWrlesR4AVCbsfOS7LniAXUo2mrzN8ZO0IOolSjQhKJQK/rMhnugq2y4BwCA+rk5yYQYmsADRbWSBcU3wzViABpopLQXXPVT7r3R4V6Ljk0muVUMNHQOHuihveYszN9qBbXuwSlZoFZin7V3Zc8Vf6dwBVvy1rOS/LogMCeoFehBtQJcj6hVn42IAOgm7+kDAEDNjO/f8XCSD87+T/AwZxCcxKQH0bcN9N6JsWtHxQA0yWnnXLYoydMlURVOuXevVZ52d6L45MG9V/miPpqoqx+4aTn5BfSgWlFjLRG4HlGr/rk/yaViKN5rkpwmhiMNF8YLqIxJ1yPuIUWhVrJAD1LDWi3I0usWyB/oFhvuAQCgnnaK4PE8eEMPymJmfAHGIe3e1mqLhIEGWiGCXs1ZuO9Uqw7skj0NtVIExk7qqeVUbdRK7GgMSq7Vf8yeK74o+4IteWsrySXGC4ydoAcBjJ2iQPAD4pR7oGt8Bg0AAOrphrn96x7mlEOtwPVYpD1J/kkMQAMtL/WFt5z8gnutyujCKfe3SJGGqsSHbfr7Br2x0zwHelCt5rAOlAWU3YNlXCI3JvlTvVS8n0oyLIZjXY/mLPO3WoEeVCvA9Qg9tFwEQLfYcA8AAPV0e5JviOHxnKqtVuB67FSPTrnfOjF27aR0gQZysm7lmI5o5NrnZrnTNCede/lQkmdYOxo7qW+tXI8YL9C3UFwPTiR5bfZcoenLt1oEYCgrhi8XxnghCrWSBXqQOtbKCfdA19hwDwAANTS+f8dkkpskAVXj4a8sSPJgkh1iAJrmtHMuOzHJS0r+Gap+yr03PNxrMSMTST4tBhpohTkL8zdqhR6s48tzPepbCo79jdlzxT2KVLglbx1K8rPGCzCRoFboQdC3okDwA3Rhll7XEgPQDd7LBwCA+rphbv+6hznlUCtwPRblLybGrv26GIAGOj/JKWKoIqfcu9cqT3v2Udx6cO9Vj0iQBurZyRYtJzGBHlQrasynVF2PqFWP/GOSPxJDLbzedDHT4cJ4YeykMpxyb7wAPSgLtYK69eBZSYZlD3SDDfcAAFBfN4jgSKr9QLHleWcxtaL+XI+HtLt7PW6RKNBQIyLox5yF+2m1Oo5d8qahVorA2En9tZyqjVqJHY1BCbX6RpLXZc8VGqJ0S956SpLXGS9A36IHUStRoAlF4QVSAT6TA3SFz54BAEBNje/f8ekkX5JEU3igqFayoAgfmRi79jYxAA21og4/RMvJL1C63SKgaU469/ITk7ykaq+rv2/Um7/LoVboQapXq5YsoOwerN7LuzR7rhjTN7XwiiRPFUMn16M5y/ytVqAH1QpwPaJWPWLDPdAVNtwDAEC97Zzbv+5hziA4VVsPom9rbKsIgAZbIYIqmxSBe63itGcXxc2So4HOT3JKL/8Cz3KgOvO36xH3kOhbqHQP/q/sueIvZFsbl4oAzN/F8uXCGC9EoVayQA9St1otlzvQDSeKAAAAau3GJL8mhsebKuJMFvSgLAavNZVMKVWSpJ2pTM6tVl9O8k5JAk102jmXnZnkeZLo15xl+7z7TrU6ivsO7r3KKYI0kQ/YGDtBD6IHa//yXI/6lgJi/1KS1ytGTSx56/IkFxovwERSQTcmebdagR6kFp6a5E361iUseGbogiy97sTcefHDogDmwoZ7AACot+vn/kd4mFMOtQLXY6X90cTYtQ+JAWiokTpNDK3JqUy1zXO416qC9lQyOfMonG5PU62o7DXc1y+JMXaa50APMod1oDPEwNg5d6/Lniu+JobacLr9rIeLqaRlvDB20kO/l8/9hxvFAFADz7v6hCRvTHKaMNxroQdn4JQkL0pym+yBuWiLAAAA6mt8/457k+yVxJFU+6NhLZ9cK6ZW1J/r8ZD27K/HR5JcK0GgwUZEUIJJEVD3tc9uGdNQfdlwb+1Y27GTAmvlesR4gb6FyvXgH2XPFX8vz5pY8tanJXmFIMD8XUH7krxfDAA1cdeljyT5uPnbrYxa0YHlIgDmyoZ7AACov+tF0CQeKKqVLKikd0+MXbtPDECDrazbD9SarPb87c0P91ockQ33NM5J5/6n+UmWmrMwf6NW6MEmvDzXo76lorF/Jsm/V4BaeW2SecYLMJFU0F/kc//BN+sC1MsuEbifVis6YMM9MGfevwcAgPq7ae5/hIc5g+Akpv8/e3cebmdZ3wv/uzZEJQ6odUJTg90OwaEoQpIOp6fTsfPpsT1tPR1O6aQVQs85L2C0JgHtCxfwiqfnLaA7ak0FLHbw2Na3PVoDaB1IgrNWgpsVdmwSBBWTMBg27PX+wQoGMq219xqe57k/n+vaV6DY7L2/v/t57nvdz/qt2xjEuG2QPxMBUDgP9WrDe/GstepnotPz4L5RWhRoedJpjeqbtZz8AsagWtFgLRG4HlGr/u1L8qrc8sZ7RNEQkxdNJHmtIBZ6u3C/cO9kSN4jAoDG8WwLa0i16scKmQMLpeEeAACazwn3h2XjDWNQFr3xARjfNdF/rb4ymA9/AainxUv+aGmSp0tiHHMW1p1qdeCabHbmLXvlS4GWi8C9kzK1nKqNWokdA4Mq1Ors3PLGL8iwUX4+yVL3CzBuK+jzmT77y2IAaJzN5m9LGejDC7Ns6rFiABbC+80AAKDhdu/acFu32XGB7KLVh1qB67FSrrh7x9sFAZSssZ+g3Zpze8daqyp6OOX+BilR9jxc7fvFaB/au3ea58AYVKsFvA6UBdR7DI72x/u73PLGy42JxjlDBIO6Hs1Z5m+1GrAr1Qeggbauaif5piCstdSKHh2T5KViABZCwz0AAJThWhHUk1O1DyQMXI9V0ccp93cl+QuJAYVzsm7tzImAJr722SxXCjXyD77x2rFR905qXivXI+4XGLcwtjG4I8nvyq1hJi96XpKfEgSYvytoLslfigGgsbaIAGstterDCpkDC6HhHgAAyqDh/rBsvGEMyoIhes/dO96+VwxA4VY2+Zer+in3HoJYa/GQTSKgNIuWrl6a5Ol1+XnNWZi/1QoaPQY7skCtCop9Lsmv55Y3fkvYjXNGkwcuUOvrcWOmz96pNgCNNcKGe+tOUQi+AU4TAbAQntsDAEAZrh/MTozNnPpQK3A9VsLl6g+UbPGSPzo2ySmSqCOn3Ftr1c/E4aO4J8mXJESBVozrflH9U7XdOzEGUSsWMM+JwPWIWh3ZBbnljR8zDhpm8qLHJvkdQQz6duHe7t7JgFwlAoBG86HS1loYg/3QcA8siIZ7AAAowO5dG76V5HOSOJxqbyi27HfWplY0n+vxuyaOfj1ef/eOt/+rpIDCvSTJcWIAxvza58bZmbc8IFMKtFwE7p3Qcqo2aiV2DAxGWauPJnmTrBrp15Mc734Bxm0F3ZPk/WIAaLQto/125u/6RKFWHNJklk09WQzAfGm4BwCAclwrgtLYUFQrWTBWl4kA4JEn6zZTa67a87cHIdZaOPmDYq2s2w9szsL8jTFIXWrVkgXUewwO58fbleRVueWNPvCtmVaJYFjXoznL/K1WC/SBTJ99l5oANNjWVbcn2S4Iay21og8+lBuYN8/sAQCgHANquLeZMw5O1TYGMW5rZkeSv1N3gDIa7ptrTgTWWrUzcegoNkuG0ixauvrYJC8b5/2i5eQXMAYB3DspZwzen+TXcssbb5NRA01e9MNJvl8QYP6uqKtEAFAEz7qw1lKrfpwqb2C+NNwDAEA5PpbEiQKHZeMNY1AWvfEBGN81cfhaTd294+33SwhAw3115iysO4uulRPuKdGLkywWg3snZOR7Ocag+wVix8AoMvbX5ZY3/otQG+tM9wugotfj15N8WC0AirDFutMSXPD0wQn3wLx5jxkAABRi964NdyW5YTB/m82c+lArcD2O3GyS9eoNlG7xkj96QpJlpfy+rTnrTqy1quIRp9zfNjvzlq9JhQKtqOv9YrQP8N07zXNgDKrVAl4HygKMwQf9TZI/Ve+GmrzoGUl+WRDDvl2Ys8zfzNM1mT7bwSMAZXDCvbUWxmA/NNwD86bhHgAAynK9CI7EqdpqBa7Hfh3ilPu/uXvH278uGYAsr0X/AUcxJwLq/trH6faUPA977ejeiVq5HnG/wLiF4Y7Bm5P8bm55o4HZXK9OskgMYP6uqCtFAFCMT49+QjV/1ycKteIgT8+yqSViAOZDwz0AAJTlIyIokQ1FtZIFI3W5CACSEj8xu+qn3HsgYq1VKA33lGplnX94cxbmb7WCRo/BjixQq4bEfneSX8otb9wryIaavOjYJK9xvwAqej3elOmzP60GAIXYumpvkq8IwnparejDChEA8+FZPQAAlOWGJPsG81fZzBkHJzEZgxi3Fff5u3e8/RPqDJCU2HDfXE65t9aqn4nvRrFZGpRm0dLVj09yUlXuFy0nv4AxqFY0WEsErkdKrtWrc8sbv6zGjfafkjxTDKO6Xbi3m+fok9PtAcrjmRdY7/fjNFkD86HhHgAACrJ714bvJPm4JI7Ew1uMQVn0xgdgfNfEd2t1mTQAHuLTsis5Z2HdWVStOt58RKGW6//DPMehtJyqjVqJHQODQdXqf+aWN75XDo13pvsFGLcVdrUIAIqzxfxtKaNW9EHDPTAv3lsGAADluU4EJbKhCK7Hoft2Em+wA0iyeMkffW+SZ5T4u7fmrDux1qqKiU6+Mjvzlr2SoEDLm3C/GO2DfPdO8xwYg2q1gNeBsoB6j8H+f7wPJzlXXRtu8qIXJflRQYz6ejRnmb/Vqkcfy/TZM7IHKM4WEVhrqRV9ODXLpvTNAn1z4wAAgPJsHNxfZTNnHJyqbQxCRb377h1vv0cMAEmSlSJomjkRUMfXPjfIjUKtqNoPZC+nVvdOGl4r1yPuFxi3sCA3J/m13LLmAVE03hkiAPN3hV0lAoAifT7JfWLAWkutevSEJM+XNdAvDfcAAFCeG5M44e6IbLxhDMqiN96k/d1CTaRzhRgAHrK85F++6qfcezBi3VmQzSKgUCua8ouYszB/qxU0egx2ZIFa1Sz23Ul+Mbes+bbAGm7yoick+a/uF0BFr8f7kvy1zAEKtHXVfUk+Z91pCS54+nCaCIB+eUYPAACF2b1rw/1JPja4v9FmTn2oFbgeh+bDe3dMTasrwEOccA/WWlWwSQSUZtHS1d+b5BlVvF9U/wPb3DsxBlErFjDPicD1SNNrNZfkVbllzU1qWYT/muRxYhjX7cK93TzHUfx9ps/24S8A5bpRBNZaGIN9WCFnoF8a7gEAoEzXiuBonKqtVuB67MNlIgB40OIlf3RsklMk0URzIqBOr33uTfIlmVEgH3rDQu6dFKLlVG3USuwYGPRrdW5Z83/EUIDJi1pJznS/AOO2wq4WAUDRxvRh0+bv+kShVjzMqSIA+qXhHgAAyqThvlg2FNVKFgzcrUn+UQwAD3lxksWlh9Caq/b87eGItVYBPrNv+1vuFwMFOq1pv5A5C/M3UJf7RUsWUO8xePgf7z25Zc1b1K8YP5ZkmRjGfT2as8zfanUYd3ouDVC8zSKw1lIr+vCyLJtaJAagH57PAwBAmb6Q5JuD++ts5oyDU7WNQYzbirhi744pR/4CfNcKETSZKc9aqzZuMAYwD1fvftFy8gsYg2oFuB6p32vLV4uhKKtEAObvCntfps++TwwARbs5yV4xYK2lVj16VJKT5Qz0Q8M9AAAUaPeuDXNJrpfE0dh4wxiURW8K/gCM7yT5c+MT4GGWi6AePCCx7mx4rZzwQXEWLV19TJJTJYF5jl6Mdi/HGHS/QOwYGLV0a5JfzC1r9omiEJMXfW+S/+h+AVT4erxSxgCF27pqLsmN1p2W4IKnD54dAn3xfjIAACjXxsH+dTZz6kOtwPU4MNfs3TH1TXUEeNi9faUMHtSas+7EWmuMNqk/BXpxksVNvF+M9qG++ds8B8agWi3gdaAsoN5j8Ls/3u4kP5tb1tyuZkV5TZJjxFCV69GcZf7mEbYl+ZQYAPCh09ZaGIN9cmgG0BcN9wAAUK7rRNALp2qrFbgej+BylQf4rsVLznp8kpMk0XRzIqDqr32+vm/7W2bkRIFWeO3IAu6dFFgr1yPuFxi3cEizSX45t6z5iigKMnnRo5L8gSDA/F1hV2b6bKEBkCRbzN+WMmpFH1aIAOiHhnsAACjU7l0bbkqyQxKlsqGoVrJgwTbt3TF1oxgAHubUBw/0M2ftV/VT7j0ksdZq6jpNBBSq0SdUmLMwf6sVNHoMdmSBWlUo9j/MLWs2CqI4v5Lkae4XQIWvx6tlC0CXE+6x1qIfy7Js6nFiAHrluTwAAJTt+sH+dTZzxsFJTMYgxu2YXKF2AAfxydjFcMq9tValabinVCvrcr9oOfkFjEG1osFaInA9UudavSntNX+uRkU6QwRVvF24t5vn6Nqc6bNvFgMASZKtq76W5OuCsNbCGOzRRJJTZAz0c9MAAADK9RER9MKGIsagLHpT0Adg3JHkfcYjwEE03NeQByXWnQ2slZM9KM6ipasfn+QkSWCeo18tp2qjVmLHwGC/dyd5kxgKNHnRy5L8oPsFGLcVdqUIAHiEMT4LM3/XJwq14iHeywP0zPvIAACgbNeJoGQ2FIF5e9feHVP7xABwkBXWWgdrzckCr31G/MtquKdEpw7m2Xe17xejfbhv/jbPgTGoVgt4HSgLqNsY/FCS16S9xsVRpjNFUOXbhcvS/F18re73QfAAHIJnYdZaakU/ThUB0CsN9wAAULDduzbMJLllsH+rzZxxaIndGMS4HZ25JG9XM4CHW7zkrCVJTpBESeZEQBXXkFv3bX/LHtlQoNqdTGEvx+tvqlMr1yPuFxi3FO7TSX4l7TWzoijQ5EVPTvLrggDzd4V9KNNn3yEGAB7hRhFgraVWfVguX6BXGu4BAACn3PfExhvGoCx6U8CbtP9h746pGeMQ4CArRVBfHpZYdzbIJhFQqBWl/KLmLMzfagWNHoMdWaBWIzad5GfSXrNXFMU6Pclx7hdAha/HK2UJwCGM+YR7605RCL5mTsyyqaeKAeiF5/EAAMDGwf+VNnPqQ63A9di3y9UK4JCWW2sdXmtOFlhrjYiGe0o1wIZ7c5YsMAZRKwbyOlAErkeqXqtdSV6R9hqnBpdq8sKJJGcIog63C/d281yx9iT5ezEAcJCtq77V/QAxrLUwBnt1mnyBXmi4BwAAnHDfM6dqqxUUfz1uTfIRFQY4pBUiKNGcCKjaa5/NMqE0i5auflaSE7x2ZAH3TnA94n4hdgyM0uxJ8tNpr9kmiqL9VJJJ9wswbivs/Zk++14xAHAYN5q/LWXUij5ouAd6ouEeAAAKt3vXhq8n+bIkSmZDUa1kQc/etnfHlPABHmHxkrOOSXKqOevIqn7KvQcmxm0DfCfJ58VAgVaW9gubszB/qxUYg7LAGFyAe5P8XNprviD/4p0pgjrdLsxZ5u8ia/UeGQJwBFtEYK2lVvRhuQiAXngWDwAAJMm1g/8rbeaMg5OYjEGM2yG6O8m71QjgkF6cZLEYSuWUe2utyvjMvu1vuV+dKdAQ3iAzuvtFy8kvYAyqFQ3WEoHrkaqZTfLLaa/5uCgKN3nhc5L8rH0tMH9X2I4kHxUDAEewSQRYa6lVH5xwD/REwz0AAJDhNNw3lY03jEFZ9KaBH4Bx1d4dU3uMO4BDWiGCZvDQxLqz5rW6QRaYh8E8x/yNdi/HGHS/QOwYGCM3l+S30l7zT6IgyRnN/lwU9wtogKszfbZPBQHgSD6b5AHrTktwwdOjp2bZ1IliAI7Ge8cAAIAkuX44xzLazKkPtQLX41FdrjYAh3WatVZvWnOywFpriDarL6VZtHT1MUlOLfF+MdoH/eZv8xwYg2q1gNeBsoCqjMHXpr3mffImkxcel+R3BVHH24U5y/xdVK2ulB0AR7R11T1JviwIay2MwT445R44Kg33AABAdu/a8O3uJ37SE6dqqxUUdz1+bO+OqS+qKMBhrRRB6Ry0QyVe+2ySAwV6YZLHeu3IAu6dqJXrEfcLjFtK8N/TXrNeDHS9KsmTv/uv9rXA/F05n8/02V8SAwA98GHUWGvRj+UiAI5Gwz0AALDfRhGUzoaiWsmCw3K6PcBhLF5y1uO6zX7mrB5V/ZR7D06M25q6fd/2t9wqBgpU9IfemLMwf6sVNHoMdmSBWg3IG9Je87/EwAHOdL8AKn49XiUzAHpUgYZ7605RCL5GnHAPHJVn8AAAwH7XDeevtZkDUPN7564k/1tNAA7rVHvtPMhpYNZaY7VFXSnUkE+icKp2w++dmL9RK0Y1z4nA9ci4anVh2msuki8PmbxwZZKXH/wf7GvV53bh3m6ea7y5JO8VAwA98nzMWgtjsB8vz7Ip7+8BjshNAgAA2O9jSWbF0Ktqbyi27HfWplY0XwOux6m9O6bMDwCHt0IEzePhifV0Dd0gAgq1UgSY5xi0llO1USuxY2A0w8Vpr3mjGHiEM9wvwLituI2ZPnuncQBAj76U5Dvmb0sZtaJHj0tykhiAI/GeMQAAIEmye9eGe5JskkTpbCiqlSx4mPuTrBcDwBH1cbKuOWu/1pwssIYcsM1qSmkWLV39uCQvLP1+MdoH/uZv8xwYg2q1gNeBsoBRjsGL017zepnyMJMXPjXJrwmiCbcLc5b5u9G1ulpWAPRs66r7k3xGENZaqFUflosAOBIN9wAAwIE2DuevtZkzDk65NwYxbgfg/Xt3TO1SC4AjcrIuB5gTAeOi4Z4Sndq05932cop+/U3FauV6xP0C45Yau1yzPYfx+0kedfj/bF8LzN9jd0+Sv1V/APrkGRnWWmrVj9PkChyJhnsAAOBA14mgHzbeMAZl0Zsav0n7cmML4PAWLznrWUmeKYlm8gDFurNGtu7bfum3xUCBVogAzN9qBQWMwY4sUKs+vD3JWWLgIJMXHpPkD90vgIpfj3+X6bPvkhMAfdpi3WkJjuD7oOEeOCLvFwMAAA70qST3DuevtplTH2oFrsckyRf37pj6mBoAHNE8Tre31tqvNScLvPYZkE1qSaFG+IaYat8vRvvQ3/wNuF+wgNeBInA9MsxaXZ7kjLTXKDiH8gtJnn30/5lT7utzu3Cpm+ca6UoRADAPW0RgrYUx2IeTs2zq0XIFDkfDPQAA8JDduzbcl+QTkuiHU7XVChp7PTrdHuDolouAg3ljMiOn4Z5SrWziL2UvZ1wEr1auR9wvgFq7OO01qzTbcwRnmr/BuK2425P8s7oD0Letq76a5E7zt6WMWtGjRUlOFgNwOBruAQCAR9ooAmwoqpUsircnyVViADiqFeashan6Kfceohi3NbFZBJRm0dLVz0zyLEmYszB/qxUUMgY7skCtjuDitNe8Xgwc1uSFL0jyk4Jo4m3QfdCc0Kha/WWmz75fPgDMk1PurbVQq36cJgLgcDx3BwAAHuna4f3VNnPGwUlMxiDG7Txs2Ltj6m7ZAxze4iVnHZPkVElwaE65t9Yame8k+bw6UqAVo/+WTtVu0L0T8zdqxRi1ROB6ZJC1ukCzPT04o7//uX0tYCyuFgEAC3CjCBjy62+aVasVMgUOR8M9AADwSJ/unmxMz2y8YQzKojc1+gCMy40lgKM6KcljxdB8HqRYd1bcZ/dtv3RWDBTIG2EwzzESLadqo1Zix8CorjekvWaNMcARTV742CSnC8JEgnFbcTdl+mwnEwOwEJvM35YyCL4PTrgHDsv7xAAAgIfZvWvDA0muH953sJlTH2oFhV6P/7x3x9TNMgc4qpXWWoPRmpMFXvsswGb1o1Bjariv9v1iQhaoFcYgNalVSxaw0DF4VtprLpITPfitJE8QQ5NvF+Ys83cjanWVTABYIM/LrLUwBvvxgiyberxMgUPRcA8AABzKdSLol1O11Qoacz063R6gN8tFwJHNiYBR2CQCSrNo6epjkpzqtSPDIXi1cj3ifoFxS6XNJfmDtNdcJgp6dMb8hxpg/h6Zq9UZgAXZuuq2JDsEgbUWPWo55R44HA33AADAoWwUAdSNzV9ZDMRMkg+KAaAnAzhZ15y1X9VPufcwxbitMCd2UKKTkjxODOYszN9qBQWOwY4sKLpWs0n+S9pr3qnm9GTywh9J8hJBuLdDxa/Hf8n02bfKA4ABqNCHVFt3ikLwNaDhHjgkz9sBAIBD+VKSbwzvr7eZUx9qBYVdj2/fu2PqAVkDHNniJWc9NsmLJcHROQ3MWmuovrFv+6W3qB0FWlnK/aL6p2rbN8IYRK1YwDwnAtcj/dTq3iS/kPaav5ILfThzYf/v9rXqc7twbzfP1dpVIgBgQLaIwFoLY7APGu6BQ9JwDwAAHGT3rg2dJNdKol/V3lBs2e+sTa1ovopej/cleZfqAPTkVPvr5VFw6+kKcro9pVouAsxzjFrLqdqoldgxMMZnT5KfTHvNh9SZnk1eeEKSXxKEiQTjtuLuS+LDZAAYlIo13Ft31icKtSqU543AIXl/GAAAcDjXiYAH2VBUK1kU4pq9O6buEANAT1aYswavNScL6NMNIsA87DXnoUzIArXCGKQmtWrJAo42Bncl+eG013xSFvTpNUmOFUNJtwtzlvm7lrX6YKbP/rYcABiQGy0ErLVQqz58b5ZNPUMMwCNpuAcAAA7nI8P9623mjINT7o1BjNsjuEK+AD3zSdf0YU4E1lrD4oR7irNo6erHJnlxSb+zvRxzAtWplesR9wuMW0bsq0l+MO01XxQFfZm8cFGSVw/mL7OvBebvobpSXQEYmK2rdie5WRBYa6lVH06VJ/BIGu4BAIBD2r1rw3SSf5NEv2y8YQzKojcVe5P2jXt3TG0yZgB6tlIEZfJQxbqzYjTcU6JT3I4Bay0wBkf747kejduxuDHJD6W99lZ1ZR5emeQEMbi3Q8XdmeSfxADAgFXs2Zl1pygEX3EO2wAO4s0IAADAkWwc7l9vM6c+1Aoafj1eLleA3ixectYzkzzLWms4WnOywGufHt28b/uld6oXBarQh95U+34xIQvUCmOQurwOFAE80oeT/Gjaa+8QBfN05mD/Oqfc12epZa1l3Vkr78v0OfvEAMCA+bBqay2MwX5ouAcOouEeAAA4kutEMB9O1VYrqNX1+K0k16gGQM9WiID+eWMyA+cNQ5SqyDe+2MsZF8GrlesR9wuMW0buXUl+Pu21d4uCeZm88MVJfkQQ7oMYtzVwlXoCMARbzN+WMmpFH04TAfBIGu4BAIAj2SgCvsuGolrJoqHeuXfH1HfEANCzITXcm7P2q/op9x6sGLcVsUkEFGqlCMxZmL/VCozB0f94rkfjdiTemPba30977aw6sgCrRADUwLYknxQDAEPwuST3i8Hrb9SqR0/OsqlJMQAH8owdAAA4rN27NvxbkunhfhebOePgJCZjEOP2gL/o7fIE6ItPuGaenHLvNcJAOeGe4ixauvqEJEtKvV+0nPwCxqBa0WAtEbgeyzab5DfSXnuhKFiQyQufkOQ3h/OX29eqz63dvd08VwtXZfocBQJg8Lau2tdtugdrSLXqlfcAAQ+j4R4AADgap9zPi403jEFZ9GbMTRMf3LtjapsxAtCbxUvOmkiyXBJ4uGLdOWb3ebMQhVohAsxzVEHLqdqoldgxMAbnziQ/mfba96obA/A7SR4rBhMJxm0NXKWOAAzRjeZvSxkE3wcN98DDeE8YAABwNCNouLeZUx9qBQ27Hq+QI0BfTkryOGut4WvNyQKvfY7gs/u2X3qfGlGgijbcV3vOmpAFaoUxSE1q1ZIF5bk1yQ+mvfZjomDBJi9sJXmtIHhwyjJnmb8rbXOmz7lZDAAMda7BWgt659AN4GE03AMAAEdzvQiaqWW/8wDCoMjrcTrJh6QP0JeVImBh5kTAIGwSAYUq/g0v9nLGRfBq5XrE/QLjloHbnGRF2mtvEgUD8hNJXjDcb2FfC8zfA+F0ewBG8XoLSl1rqVX/TsmyqWNkCeyn4R4AADii3bs23JHkC5KYDxtvGIOyqLQr9u6YEgxAf0bQ6OfWvF/VT7n3gMW4HSMN9xRn0dLVExruzVmYv9UKjMHx/3iuR+N2IP42yY+lvfZ2dWKAVonAvR1q4P4k14gBgCG7Kcld1p2W4Ai+R4uTvEgMwH6erQMAAL24bvjfwmZOfagVNOB6vCfJBvkB9G2FCFg4p4F57bNgTuagRCcleZz7RR1O1bZvhDGIWrGAeU4Ersfme1OSX0l77T2iYGAmL3x2kl8YzTezr1WfW7t7u3mukj6c6XPuEAMAQ7V11QNJPi0Iay2MwT740G/gIRruAQCAXmwUwXxVe0OxZb+zNrWi+UZ8Pb53746pO6UO0LvFS856bJIXSwIYs2/u237ptBgo0EoRMF72jThYy6naqJXYMTB6d0+30f78tNcasQzaH3ovsIkE47Ym3qNuAIzIFvO3pYxa0YdTRQDsZ5MNAADoxcd8XD0PZ0NRrWRRc5eJAKBvpyQ5xpw1Wq25amfhIYtxOwZOt6dUTpao1ZxlTjB/gzGoVgt4HSgLmmd7kh9Oe+3fiIKBm7zw0Ul+XxAcesoyZ5m/K2Vvkr8XAwAj4nmatRZq1Q/PIYGHeC8YAABwVLt3bdid5MbhfyebOePglHtjkOLG7Sf27pj6vNwA+uZkXQbI55l5jTBvm9SEQtXgjS4jbES0fQF1m78xBsG4LdcnkyxPe+1nRcGQ/GqSp472W9rXAvP3vPxtps+5V80AGJEtIqCwtZZaLcxLsmzqODkC0XAPAAD04VoRzJeNN4xBWfRmRE0TlxsHAPPiE605JA9arDtHzIkcFGfR0tWLk7xEEpjnqKLRfgCGMQguEWo2MP48yY+lvfbr6sAQnSkCEwnUxFUiAGBktq66Nckd1p2W4Ai+R8cmeakYgHgfGAAA0IeNo/k2NnPqQ62ghtfj15P8rbwA5mXEJ9xba+3XmpMFXvscQMM9JTolyTHuFws3IQvUCmOQmtSqJQvqbS7J/0h77e+lvfY+cTA0kxeekmSFIDjylGXOMn9Xwo4k14kBgBFzyr21FsZgP06TIRAN9wAAQB8+mcSbQubNqdpqBZW4Htfv3THlXg7Qp8VLzjohyRJJMFhzIqBf0/u2X/pNMVCglSIY+WtHDkvwauV6xP0C45YjuiPJf0h77Z+KghE4a3zf2r4WmL/78t5Mn+PGAcCoVfhDrL3+rk8UalUQH2gHJBruAQCAXu3eteGeJJ+SBA9nQ1GtZFEjDySZUn+AeVluzhqvqp9y72GLcTsiTrfHPIw5C/O3WokAY7AyP57r0bg9yKYkp6S99lqZM3STFz45yasE4d4ONXGlCAAYA8/VrKdRq36cKgIgnqcDAAB9um4038Zmzjg4ickYpPHj9gN7d0ztkBPAvPgka4bEoT5eI/TlBnXAPOx+caCWk1/AGFQrGqwlAtdjvVye5EfSXvtvomBEfjfJY8b7I9jXqs+t3b3dPDdWX8j0OV8UAwBjcKMIwHq/D8/PsqnjZQhouAcAAPqxUQQL4eEtxqAsejOkponL1B1g3pysy1F54GLdOQJO4qA4i5aufkaSZ0sC8xxV13KqNmoldkodGPcm+e20165Ke+19cmYkJi+cSHKGIEwkUJNxe5X6ADAWW1fdkWSb+dtSRq3og/cGAd7/BQAA9GVzkrvFwMPZUIQaXI//unfH1PXyAejf4iVnTYz3oZq11n6tOVlQ9Guf+5J8Tg0o0Ip6/tjVnrMmZIFaYQxSk1q1ZEG13ZJkZdpr3yMKRuxnkjxHDPQ3ZZmzzN9jC/tqMQAwRltEYK2FWvXhNBEAGu4BAICe7d614b4kHx/Nd7OZMw4tsRuDNNXlIgCYt2VJHi8GhmdOBPTic/u2X7pPDBRohQiOzF7OuAherVyPuF9g3Bbu75OcmvbaL4iCMTizOj+KfS0wfx/Rxkyfs1NtABgjDfc0ea3F4Gul4R7QcA8AAPRtowgWwsYbxqAsejPAN2nvTXKlegPMWwUa/czfD82Pc04MttYq1mYRUKjlIjBnYf5GrTAGq/3juR4LG7cPJHlDkv+U9tpvy5SRm7xwMslPC8K9HWriKhEAMGYVf75m3SkKwVeM55JAjhUBAADQp+tG9606SVoSrwW1ggpfj3+xd8fUXrkAzJuTdYEqvPa5QfaUZtHS1RP1fmPL6O4XrU7SackCjEG1opla3vrreqyOryX5tbTXfkoUjNEZ1bs453ykV21u7Z2k5d5unhuZe5O8XwwAjNmnLVittTAG+/DMLJt6Zm56zU4ZQrksGgAAgH59NsmdYliIYk7VViuoxvV4hSQBFkTDPSMwJwKOZosIKNCyJI8XA9Vl34iDtZyqjVqJnaYOjA8kOVmzPWM1eeHiJL8jCBMJ1GTcfiDT5/hQeADGa+uqu5P8q/nbUkat6MNpIoCyabgHAAD6snvXhgeSfEwSHMyGolrJooKu27tj6ivqDDA/i5ectTjJS8xZ1dKaq3YWHrwYt0NwZ5KvioECLReBOQvzN8YgapVanIlm3DbYfUnOSnvtK9Ne6wPJGbdXJXmSGFjYlGXOMn+PzFUiAKAiNovAWgu16oPnk1A4z9ABAID52Di6b2UzZxyccm8M0phx+2eyAFiQU5IcIwZGwyn3XiMc1uZ92y/1woQSrXC/6F3LyS9gDAK4dw7adJIVaa+9zFigIs6q7o9mXwvM3w9ze5IPqwUAFbFFBDRsrcVwa6XhHgqn4R4AAJiP60SwUDbeMAZl0ZsFNE38W5J/UF+ABVkpAubDwxfrzgHbJAIK5Q0tmOeopdF+AIYx6H6B2BnSwLg6ycvSXvs5eVEJkxf+QJKXCsJEAjVxTabPuV8MAFREDRrurTtFIfgKOTXLplpigHJ5zxcAANC33bs2fCnJ10f3HW3m1IdaQYWux7fv3THljQwAC1OxRj9rrf1ac7KgqOtRwz3FWbR09XFJTna/GL4JWaBWGIPUpFYtWTAadyU5Pe21v5n22rvEQYWcKQIGN2WZs8zfQ3eVCACokC8k+Y4YrLUwBnv0xCTPlR2US8M9AAAwX065X7DGnqqtVjD+63E2yTskB7BgTtZlxOZEwKFsFgEFOiXJMWIY+mtHBkLwauV6xP0C47YhPpnk5LTX/oW6UymTFz4tya9W/we1rwXm7yTJ1kyfs0UNAKiMratmk3ze/G0po1b0wXuFoGAa7gEAgPnaKAIOzYaiWsmiAv5q7471t6srwPwtXnLW05MsNWdVV9VPufcAxrgdkFv2bb/0G2KgQCtFYM7C/I1aYQzW78dzPdZ03N6fZE2SH0l7bVs2VNAfJFkkBvMc1MSVIgCggny4NXjt04/TRADlOlYEAADAPI34hPtOkpbUR6zVSTpiNwapo8tFALBgPrGaMZnT+ug1woG8AQjzsPtFX6q/l2N/BWMQtWIB85y3/roeB29rkt9Ie+2n1ZlKmrzw2CR/WJ8f2L5WfW7tnaRlrWXdORRXiwCACtqU5CwxWGthDPZIwz0UTMM9AAAwL7t3bbjl+BNOn6nmqZ91YkMRY1AWvemjaeJze3es/5R6AiyYk3VZsInu24yx7lyATSKgUCtEgHmOuhvtB2AYg+4XiJ15DIzLk9br0l57jyyosF9IskQMJhKoybj9eKbPubWRaXZ87BNAHbW++wFDN5q/LWXUij6ckmVTx+am19wvCiiPj5IEAAAW4loRcGgeNsIY/ZkIAAaiwifrWmvt15qTBY2/HjXcU5xFS1/39GZ+wGO156wJWaBWGIPUpFYtWbBwu5L8TNrrVmm2pwZWiYDhTVnmLPP3wF0pAgAq6uYke8RgrYVa9egxSV4iBiiThnsAAGAhRtxwbzNnHFpiNwapkzuTXCMGgIVZvOSsiWo33NN8cyIgSe5P8jkxUCBz8ALZyxkXwauV6xH3C4zbGvibJC9Je93/UVMqb/LCk5L8eP1+cPtaUOj8fV+Sv5Y5AJW0dVUnyWZBUOO1FqOv1WlygzJpuAcAABbCCfcDYeMNY1AWvenhTdp/vnfHeifyACzcC5I8QQwMggcx1p0L8Ll92y/9jhgo0Er3C3MW5m/UCmOw3j+e67GCvpHkV9Ne9ytpr/umOKiJ14rAPAc18sFMn3OnGACosC3WnZbgCL4PGu6hUJ6ZAwAA87Z714adSbaO9rvazKkPtYIxXHRvEwPAQKyw1qqP1pwsaOz16KQNStXgE+6dqm0tgzGIWjGQeU4Ersf+vDfJC9Ne59Rd6mPywscnOb2+v4BT7utza7fWsu4cmKtEAEDFbRGBtRbGYB+WywzKpOEeAABYqI0iGITan6qtVjD+6/Gf9u5Yf4uEAAZihQgYP29MJjeIgNIsWvq6lhMjqDf7Rhys5VRt1ErsjMvXk7wy7XW/kfa6O8RBzfxmkseLwUQCNRm3dyb5R1kDUHE1+qBr6876RKFWDfaiLJtaLAYoj4Z7AABgoa4TAYdnQ1GtZDFCV6gdwMDU5JOqzd/7Vf2Uew9jjNt5csI9JXpBkuPdL8xZmL8B9wtZsEDvTfKitNd9QBTU1CoRMLopy5xl/l6wv870OfvEAEClbV21I8kuQVhroVY9OibJy8QA5TlWBAAAwAJd191daY3uW47425F0T2LqiN0YpKraSf5JDAALt3jJWcclOVkSVMOc1sdyXyN8O8nNcqVAK9wvBqf6ezn2VzAGUSsWMM9566/r8dB2Jnlt2uv+Xq2orckLfzTJC+v/i9jXgoLm7/fIGICa2JzkF8VAzdZajK9WK5J8Qm5QFrtZAADAguzeteGbSb4giUHw1jCMQVn0pnXwj/e2vTvWz6kbwECc0v2kahgoD2SsO/u0ed/2SwVFiVa4X2Ceo4laHWMQtRI7I/Cu7qn2mu2puzNFYCKBGrk1ySfFAEBNbLHutARH8H04TQRQHifcAwAAg/CR0Z8C6lMh60OtYMjuTfLnYgAYmOXWWvXUmuukMyELGnM9bpYn5mH3i3GZ6J5FKQvUCmOQqteq+qfcG7cjclOSP0x73UdFQe1NXvisJK8UBKOfsjpJy5xl/p6XqzJ9jm4sAOrC8zdrLYzBfsbgqfKC8jhQBQAAGITrRTAotTtVW61g/NfjNXt3rP+WRAAGZoUIqJY5EZTpBhFQmkVLX3fc6D/QsajXjoyU4NXK9Yj7BcbtCOxLcl6Sl2q2p0FeneSY5vw69rWggPn7KtkCUCNbREDN1lqM13OzbOrJYoCyaLgHAAAG4fokD4iBw7OhqFayGKLL1ApgoGrYcG/+3q81V+0sPJQxbvvghA1K9LIkx7pfmLMwf6NWGIPN+vFcj0NyfZLvT3vdm9Net08cNMLkBY/qNtxjnoO62JLpc7aKAYDa2Lrq20m+at1pCY7g+3CaCKAsnpMDAAALtnvXhrvG8+mfNnPGwUlMxiCVcsPeHes/IwaAwVi85KynJTlRElSP08AKe41w677tl94hSwq0oqxf16na48gCjEG1onlaIijtevxmkt9J8uNpr7tZHWiYX0ryjOb9Wva16nNrt9ay7uyb0+0BqCOn3FtrYQz28z/WcA+F0XAPAAAMykYRDIoNRaA3rU4ulwLAQC0XAcPmwYzXPj3YJAIKtcL9AvMcTddyqjZqJXYW4i+SLEt73Ya016kgTXSGCEwkUKNxe3+Sa2QKQA1ttu60lFEr+uB9RFCYY0UAAAAMyLVJ3igGDq/jrBm1ksVg3ZHkr9QIYKBWmrPqrzXXSWdCFtT6etRwT6lWlPcrV3v+nhjpWZTWMsYtGINqtYDXgZV/S7Nxu0BfTHJW2us+Kgoaa/KCk5P8O/cLxj9ldZKWMWj+7smHM33O7WIAoIY2i8BaC7Xqg4Z7KIyDVAAAgEH5ZJJ9o/+2PhVyHFpiNwapgnfs2bn+PjEADJQHZVTYnAjKoeGe4ixa+rqnJTlREsNjL2dcBK9WrkfcLzBuF+DbSf5bklM021OAhp9ub18LGjh/XyVLAGrqc0keEAMVX2tRnVo9PcumlsgLyqHhHgAAGIjduzZ8p9t0z0DYeMMYlMURPZDk7WoDMDiLl5zV0nDPqHg4Y915BPcn+awYKFAPc7D7hTkL8zdqhTFY5x/P9dhnWO9O8oK01/2/aa+7XyQ02uQFT0zym+4X5jmokb1JPiAGAGpp66p7k3zButMSHMH3wXuJoCCejwMAAIN07Xi+rV20+lArGJB/2LNz/dfEADBQL0hyvLVWM7TmZEFtr8fP79t+6b3yo0Ar3C+QBeB+wYJeB4qgKdfjjUl+IO11v5v2utvlSyFOT7K4+b+mU+7rc2u31rLuPKr3Z/oce5gA1NlmEVhrQR9jUMM9FETDPQAAMEjXimCQqr2h2LLfWZta0UiXiQBg4FaIgOrzxuQCeIMPpfJGlRGwlzMuglcr1yPuF9CDbyZ5dZIVaa/bJA6KMXlBK8kZgjB/Q83G7ZUyBKDmbrTutARXK/pwmgigHBruAQCAQdqc5G4xcGQ2FNVKFgt0kw84ARiKhjTcm7/3q/op9x7QGLeHobGE4ixa+rpW7w337hfmLMzfqBXGYJ1/PNfjITzQ/YDZ56W97h1pr/NJc5TmFUme535B9eZHY9D1eFg7k1wnBgBqzgdgW2uhVv04NcumPC6DQrjYAQCAgdm9a8P9ST46nu9u420cnMRkDDIWV+zZud6AAxg8n0hNTeg9aPhrBA33lOj5SZ7ofjEaLSe/gDGoVjRYSwR1ux4/mORFaa87K+11d8qRQhV2ur19LWiAqzN9josZgLr7cpJ7xMDw2LtsWK2e0H2eCRRAwz0AADBoPsl6oGy8YQzK4mHuSvIXagEwWIuXnPWYJC+VBKPmIY115yPsSbJVDBRoeX//c/cLzHM0Q8up2qiV2Mv1+SQ/mfa6X0h7nddAlGvyghOT/LwgTCRQs3F7lewAqL2tqx5I8hnrTktwBN8Hh3hAIbyXCwAAGLSPjO9b20WrD7WCebpqz871e8QAMHAvS3KstVbztOZkQa2ux837tl9q0FKilSKo/vw9IQvUCmOQmtSqJYsq25Xk95Kckva6ja4LyB8eealtnmPcU5Yx6Ho8yBcyfc4XxABAQ2wWgbUW9DEGl8sJynCsCAAAgAH7QpI7kzxJFIPSqfRbxFqdpNNSpTrUika4TAQAQ7FCBNTLnM9UbiZv7KFU3qAyYvZyxsW+kVq5HnG/oNhxe2+S/yfJJWmvu1tWkGTygsd0P4CiQPa1oMbrTqfbA9AkW0RAxdZaVJsT7qEQdq0AAICB2r1rw1ySayXB0flkUrWSRZ8+umfn+i+rAcBQNLDh3vy9X9VPufegxrg9wA3GAKVZtPR1j0nyUveLejBn4XpUK2j0GOzIYki/6HuSPC/tdedptoeH+bUkT3G/MM9BzQb5e8UAQIPU9IOwrTtFIfgxeVmWTS1Sf2g+z8QBAIBhuH5839ouGtBYTrcHGB4n61JDcyKojZ5fpzrhnhK9LMmxYuj7frFgrY4swBhUK5rL2WGVuB7/IcnJaa/77bTX7ZANHOSMsn99+1r1ubVba1l3PmRjps8xpwPQHFtXtZN8UxDWWtDjGHxUkpPlBM3nzQsAAMAwfEQEg9ap9FvEWp2k4x1stagVtbUzyQfEADB4i5esemrS+T7zN+M04W3G1tPJzL7tl35d/SnQCvcLzHOUbrR7q8ag+wViH7p/SfKGtNd9QhRwGJMXnOYDQE0kUMNxe7WsAGigG5P8lHWnJbha0aNTu/cNoMGccA8AAAzc7l0bbkpymyQ4Op9Mqlay6NHUnp3r75c9wFA0+M2t5u/9WnOyoPLX4yYZUagVIqjX/D0hC9QKY5Ca1Koli1H7XJKfS3vdj2i2h6M60zxHvaZvY9D1mHuT/K36A9BAm0VgrYVa9cGH50EBNNwDAADDsnF839rG2zi0xG4MMiyzSdaLAWBoVoqA+poTQXN4Qw+l8saUMbKXMy6CVyvXI+4XNMotSX4jycvTPu8fxQFHMXnB9yR5lSBiXwvqte78u0yfs1dOADSQD8SmCmst6lMrzzWhABruAQCAYblWBINm4w1jsNAs3r9n5/rbZA4wNMvNc1SBBzbFrztvUHdKs2jp656S5PvcLwCstTAGy/3xan093pbkjCQnpX3ee9M+T+cs9Ob3kzza/G2eg5q5UgQANNSN1p2W4Ai+Dydl2dTj1B6azfu3AACAYRlzw71dtPpQKziKy0QAMByLl6xqNf8TqK219mvNyYLKXo8PJPmMfCiQUyBqOn9PyAK1whikLq8DRTAMtyX5H0m+L+3z3pb2ebMigR5NXjCR5A8FcSCf1VGfpZa1VsHrzjuS/LO6A9BIW1d9Pcl2QVhrQY9jcCLJKTKCZtNwDwAADMXuXRtuTbJNEoNW7Q3Flv3O2tSK2vjCnp3rPy4GgKF5fpInmr+pN29MbsKab9/2S+8VAwVaIYLxs5czLoJXK9cj7hfUzoGN9n+a9nlew0D/fj7JiWIwf0PNxu1fZvocH7ADQJNttu60BPcD0gfPN6HhNNwDAADDdK0I6I0NRbWSxWE43R5guE4zZ5Wl6qfce2hT7LjdrN4UakBvSDHPmbMwf6NWGIN1/vEqfz1qtIfBOcP8DdTQ1SIAoOG2iKBqvPZRq0o7Vd2h2Y4VAQAAMETXJvm98X37TpKWKoxYq5N0xG4MMgi7k7xXDABDtVIENMOc1sd6v0bYJBdKs2jp61pJlkui7/vFUFR/L8f+CsYgasUC5jlv056v25JcnGRKkz0MwOQFz0vyCkEcin2t+iy1OknLWquwdefNmT7Hh4UC0HQa7rGGpJ9anSYfaDYN9wAAwDA54X4obLxhDBaSxbv37Fx/t4wBhmq5eY6qmei+zZiirkcN95ToeUme5H6Bec645eFG+wEYxqD7BWI/JI32MBxnuJmbSKCG4/ZKmQBQgBvrvXiz7hSF4EfsOVk29dTc9Jo71B6aycdCAgAAQ7N714bbknx5vD+Fc0vqQ63gEa4QAcDwLF6y6tFJXmqtVZ7WnCyo1PW4N8lNMqFAe5K8O8l9oqjv/D0hC9QKY5Ca1Koli17MJDkzyfelfd6faraHAZq8YHGS081zNGP6NgYLux6vVmcAGm/rqr1JviIIay3og1PuocE03AMAAMN2vQjK07LfeQBhMC8f2rNz/VfFADBUL0uyyPxNc8yJoJ4279t+qeJRnNmZS26bnbnkd5M8O8mfJPmGVMbLXs64CF6tXI+4XzB2/5rkt5I8N+3zrtBoD0PxG0meKIYjsTUCFVx3fiLT52yTBwCF2CICRrzWot610nAPDabhHgAAGLaPiGAYbLxhDDY8C6fbAwzfCnNWuap+yr2HN0WN281qTMlmZy75+uzMJeu6jfevTrLV/aJezFm4HtUKGj0GO43OYlOSX0zy4rTPuyrt8+43HmFozjR/m+eghq4UAQAFqfnzOutOUQh+xJarOTTXsSIAAACG7GPd3ZTW+H6EMX971Ar6c2uSD4oBYOhWiIDmmdP6WL/XPptkAcnszCX3JnnHoqWve2eSn0qyKsnP2iTISPdKWp2k05IFGINqRTO1vOd6vw8luSjt864XBYzA5AU/lORkQfTCvlZ9llqdpGWt1fB1531J/kp9ASiIE+6ttaCfMeiEe2gwu1MAAMBQ7d614VtJPiOJYaj2W8Na3rlWm1pROW/fs3P9nBgAhm65+RuspytAwz0cYHbmks7szCX/Z3bmkp9P8twkb0lyp/sF5jlK0+oYg6iV2AfqgSR/neTlaZ/305rtYaRWicBEAjUct/+Y6XPulAMABfl89wNnrDstwf2A9OKpWTa1VAzQTBruAQCAUfDGHfpgQ1Gtis5iX5J3yRNguBYvWfWUJJPmrLK15qqdhQc4Rdi+b/ult4kBDm125pL27Mwl5yZ5VpLfS/JZrznNWdYyxi0Yg2q1oNeB5WWxN8n/TPLctM/71bTP8wHZMEqTFzw9yS+b52jm9G0MNvx6fI+6AlCUravu6zbdY62FWvVquZpDM3m/FgAAMAofGf+PYONtHJxybwzSt2v27Fz/DTEADJ0HXzTYnAjq8xphswzg6GZnLrl3duaSP5+dueSUJCuS/HmSeyQzHPZy4Kjzt+uRYsYgtTaT5OwkS9I+7/9K+7xbRQJj8Zoki8TQD/taUAHfTvKPYgCgQFtEwOjY42tArbzvCBpKwz0AADAKH08yK4ZhsPGGMdiwLC6XI8BIrDDPUQce4jT+etRwD32anblk8+zMJb+X5IQkZyT5jPkb8xwYg9CsS2RB32xzkl/tnmj/1rTP26N4MCaTFxyb5NXmb9SKGvqrTJ+7TwwAFGiTdaclOILvw2nqDc10rAgAAIBh271rw13Hn3D65iQ/NN6fpJOkpSC1oFYUafOenet9WjLAaKwo+9e31tqvNddJZ0IWjM0NIoD5mZ25ZE+StyV526Klr3t59+TI/5Lkcebv8ZgY6VmU1jLGLRiDarWA14HNe+vvXJL/neR/pn3eJ4wlqIxfTPIsMcz3tuZjKOsxfXeSlrVWA9edV6onAIXyni1rLehnDL48y6YmctNr5uQDzWJXCgAAGJVrRTAs1X5rWMunhdamVozdFSIAGJk+Pmna/E0deaZbAw8c+mRuoF+zM5d8enbmklcneUaS305ynQl8YezljIvg1cr1iPsFfbkzyVu6p9n/Z832UDmrRADU0K1JrCkAKNXWJHvr/2vYN6pPFGpVc49LcpIYoHk03AMAAKOi4Z4+2VBUq6Ky+EaSa+QHMHyLl6x6XpInS8L8vV9rrtpZeJDT2HH7pX3b33q3msLgzM5ccvfszCXvmZ255MeTzvclOb/7RnHMWZi/USuMwZr9eEf8Zp9O8rtJnpX2eeemfd42YwcqZvKCFyb5UfdO1IoaujrT5xqsAJRp66q5JDcKwnoaterDaeoNzXOsCAAAgBG5Icm9SY4b74/RSdJSjRFrdZKO2I1BjuRde3au3ycGgJFYLgLKMKf1sdo2iQCGZ3bmkluTvGnR0tVvTvLvk5ye5Je7p03U2Oj2FKq/l2N/BWMQtWIB81z93vp7X5L3Jbki7fNuUEGovDNFsFD2teqz1OokLWutBq07r1RHAAq3OcmPiQFrSHqs1fIkG2QDzaLhHgAAGInduzZ85/gTTv9kkp+QxjDYeMMYrHEWc0neLjeAkVlpnqNuJroLBhp1PW5WSxi+2ZmLO0muT3L9oqWrX5vkF5P8ZpKf8qwc8xx1MdoPwDAG3S+oWOzbu3vH70z7vDsUAGpg8oLHJ/mvgsD8TQ1tyfS5W8UAQOEacsK9dacoGBEn3EMDeRMBAAAwShs13NMfO54U4YN7dq6/VQwAI+OEe2utg7TmOulMyIKRcioljNjszMX3JrkmyTWLlq5+SpJf7Tbf/4D5e3BG+yEx1jLGLRiDarWA14HVPeW+k+QjSefypPXBtM97wLiAWvntJI8zz1HW9O2U+4Zcj1erHwBkkwistVCrPpycZVOPzk2v2afm0Bwa7gEAgFG6rho/ho23cRjtSUxVZwzyMJeLAGA0Fi9Z9egkLzV/U465busjFXNXkq+IAcZndubibyS5IskVi5aufk6SX0/yqiQvls532csZF+tOtXI94n5RqB1J3v3gafbnz4gDamjyglaSMwQxKPa1YITuT/KXYgCgeFtXfS0vuOzrSZ4uDEbHHl+Na7UoyclJNssGmkPDPQAAMEpbkuxJ8gRRDIONN4zBGmbx1ST/LC+AkXlpkkeJwfx9KFU/5X60JwYbt8N+bbxv+1uVEypidubibUkuSHLBoqWrlyX5L0l+LckLpGPOwvytVmAMDvnHeyDJB5O8K8k/pn2+0+yh3n40yUnunagVNfTPmT73djEAQNJ9j+vPW3dagiP4Hp2m4R6aRcM9AAAwMrt3bXjg+BNO/5ckPzf+n8YuWn2oFY12xZ6d6ztiABiZ5SIAKsADd6io2ZmLb0pyXpLzFi1d/ZIkv9ptwJ+s1k/qVO1xZAHGoFrRPK3uyBiDdrfJ/t1pn79LJaAxzhLBoDnlvj5LrU7Sstaq8brzSnUDgIdsakbDvbUWjGgMLk9yuVygOTTcAwAAo/aRajTcN1W1NxSr/yZttWKk7knybjEAjNRK8zfl8cbkCtokAqi+2ZmLv5jki0nWLlq6+uVJXpnkPzv5ntGw7uRgo91bNQbdLxhC7PcleX+Sdya5Nu3zfRArNMnkBUuS/EdBYP6mhu5K8gExAMBDbrTutAT3A9IHB39Aw2i4BwAARu16EdA/G4pq1cgsrtqzc/1uOQGMlAdd5u8jas110pmobhYT3fZ5aj9uNdxDzczOXPzpJJ9OsmbR0tXLuo33r0xyinTMWVh3YgxS71qN4JT7TyV5T5L3pX3+nWoLjfWaJMeY5yh7+nbKfU2vx7/N9Ln3qhkAPGSzCKy1UKs+vCDLph6fm16zV72hGVqdjg/LBQCAkS3APVzM8Sec3kpye5KnVKQqTRxplf8J53cSU1OvH2Ow4Xf+I/3Hk/fsXP8FGQGMxuIlq74nyTfMc+bvo65VJ6qdxfybFyeM22rYsW/7W5cUfY15NkmD9sgWLV39nCS/1P36gdHfmEb37eazlzPX0Cz8Tn6vcf5enZZa+b3UaijX1uB/vJkkVyZ5T9rnf9XqDxpu8oJHJflakqeZE4bFvlaNXvC7J9Svxq/I9Ln/rF5HWS/a0wSo6dJknvPxCy6bTjJpTdKw36ulXn6nof1eP5GbXnOt9SM0w4QIAACAUdq9a0PHKffDZqMGY7AGWfyLZnuAkRvQ6fbmOcbLg53aX483qBs0x+zMxdtmZy6+dHbm4h9KckKSP0jy90m+Ix2sOxmGVscYRK0qHPveJO9O8mNJnpP2+Ws120Mx/nM1mu3NCeZv6NvOJBvFAAAH2WLdaQmO4PtwmjpDcxwrAgAAYAw2dt94UAEdp3nWhlrRKJeLAGDklovAWqsXrblO5U+5p9Y2iwCaaXbm4q8neWeSdy5auvq4JK9I8gvdryE131R7/p4Y6Sn31jLWnWAMqtUCXgfO/62/c0k+kuQvknwg7fPvUTco0pkigP3Td8cp9/Vad7430+fOqRUAHGRLkleJwVoLehyDp8oDmkPDPQAAMA7XimDYqr2h2OokHfudtagVQ3FbkveLAWDkVpi/Kdtct/WRMdskAmi+2ZmL703yd0n+btHS1RNJVnYb738uyUvq+DvZyxkX6061cj3iflFRn0jyviTvS/v828UBBZu84KVJflAQw2ZfC4bkKhEAwCE17HmefaP6RKFWNbVCBNAcGu4BAICR271rw83Hn3D6jiTPkgb9saGoVo3IYv2enetn5QIwck64N3/3rOqn3I/2xGDjdoDmktyoZlCW2ZmL55J8svv1hkVLV39vkp/tfv1kksVN/v3NWVh3qhU0aAx+Jsk1Sd6XbedvVxuga5V7J2pFTX0x0+d+XgwAcEifTfJAkmNEYT2NWvXge7Ns6hm56TW3qTXUn4Z7AABgXK5N8lvV+FFsvI2Dk5iMwULdn2RKDACjtXjJqucm+R5JgNPAxuxL+7a/9W4xQNlmZy7+Wvd14dSipasfneTfd5vvfy7Jc/v/G52qPY4swBhUK5qn1R0Zj3BTkvd2m+xvlhLwMJMXPCnJrwtiVOxr1Wep1Ula1lo1WHc63R4ADmfrqnvygsu+nOT7hQH0uN4/NckHZQL1p+EeAAAYlwo13DeVNw1iDFYwi/+9Z+f6nfIAGLkhnG5vnmO8nBhcy+txs1oBB5qduXhfkg93v/77oqWrn5vkZ5L8hyQ/nuSxUsK6k0MZ7QdgGIPuF8VpJ/nrJFdn2/lfFAdwBKcnOU4MmL+p6cC7WgwAcESbm9Vwb91ZnyjUqqaWa7iHZtBwDwAAjMtGETA/NhSptctFADAWK0RgrdWv1lwnnQlZMFAa7oEjmp25eDrJnyX5s0VLVz8qyQ8meUWSn07y0sNP0tWev0f7ITHWMtadYAyq1bx8Kcn7W8nfdDTZA72YvGAiyZnmOTjcEHTKfcWvx+syfe4OtQGAI9qS5PfFYK2FWvVouRpDM2i4BwAAxmL3rg1fO/6E029JMlmNn8jG2ziM9iSmqjMGC/DlPTvXf1QMAGMxpIZ78zd1NNdtfWQMbhAB0KvZmYvvS3J99+uPFy1d/dRu8/0rkvxEkmeN4+eylzMu1p1q5XrE/WIItiR5f5K/7Ww7/6viAPr0iuo85y6JfS0YkCtFAABH5YO0GSN7fDWs1amygGbQcA8AAIzTRm9EGDYbbxiDFcriMhkAjN7iJaseleRlkqCJRntisHXnAt2d5F/VCZiv2ZmL70hydfcri5auXpbkJ7vN9/8+yZPMWZi/USuMwSOaS/KJJH+T5AOdbedvlyuwAGdW/0c0f1trwSF9p/uhQwDAkX2pO28+xrrTEhzB9+B7smxqMje95hZ1hnrTcA8AAIzTdUleXZ0fxy5afagVtbM3yVViABiLlyZ5lBisteajNddJZ0IWDMSN+7a/9QExAIMyO3PxTUluSnLZoqWrj0k6L0taP9ltwv/BJMcNbX6s/Kna1jIYg6gVD7k3yT8n+WCSv+tsO/92kQALNnnBc5L8nCDGxSn39VlqdZKWtVYF150fyPS5e9QEAI5i66r784LLPtPdb8daC3oZg6cl0XAPNafhHgAAGKeNIhiFam8oVv9N2mrFQLx7z8533CUGgLFYbv6GR/LG5DHYJAJgWGZnLn4gyY3dr4sWLX39Y5KsTPKj3a+VSR4tqbqz7uRgo91bNQbdL2pjR7fB/h+SXNvZdv69xgQwYK81KWL+psZ8SDwA9G5L8xrurTvrE4Va1dBpSa4RA9SbhnsAAGBsdu/acMfxJ5z+5SQvkgb9s6GoVrXyNuMAYGxWisD8vRBVP+V+ots+T+XH7Wb1AUZlduai7yS5vvuVRzTg/7skP5DkOHMW5m+gIfeLTvdDZ/Y32X+us+38jryAoZi84DFJfs9aC3odgk65r9j1eEeSD6sFAPTM8z1rLdSqH8vVF+pPwz0AADBuH6lWw72Nt3Fwyr0x2PT73J6d77hJDABj44EWHJJT7kfsBhEA43KIBvxHdddIP5rkR7on9Dy2n7+z+ns59lcwBlGrhrsrycZug/3/19l2/m0iAUbkVUmeLIZxs68F83RNps+dFQMA9Kqzxb4RYx6D9i7rVatTsmzqmNz0mgfkAfWl4R4AABi365L8NzEMm403jMExulz9AcZj8ZJVT0ryPPMcTefE4Mpfjzv3bX/rDrUBqmJ25qL7kny8+5VFS19/TJKXJvnhJP+u++fTJWWeox5G+wEYxqD7xVh9NsmHul+f7Gw7/z51BsZglQgwf1NjV4kAAPoyneTOJE+y7rQER/A9WJzkhUm+qMZQXxruAQCAcbu+eh9BbxetPtSKyvta95QlAMbD6fbWWgPRmuukMyEL5s3p9kClzc5c9ECST3e//lcebMJ/Xrfxfv/X8wfxvUb7ITHWMtadYAzW3B3d5voPJ/lQZ9ubbhcJMFaTF6xI8nLzHPQ7BDtJyxiswPV4c6bP3awGANCHrWd18oI/25K0XiEMay3ocQyu0HAP9abhHgAAGKvduzbsPv6E0z+T5FRpDFu1NxRHexKTWjEyb9uz8x0PiAFgbEbYcG/+po4q9tlnzbVFBEDdzM5c9NUkX03y7jzYgP+UJCuT/GD3z+WtTh5rL2ccrDvV6mD2VmnI/WI2yScPOMX+s51tb+qoI1AhZ4igSuxrQZ+cbg8A83NjkgY23Ntnrk8UalUzpyZ5pxigvjTcAwAAVbBRwz3zZ0NRrSrrviTvUneAsVopAvP3oFT9lPvRnhhs3PZpk5oAdTc7c9E3knyw+5VFS19/bJLvf0QT/qQ5C+tOtYI+zCX5bJLrk3wkycc72950l1iASpq84KlJXmX+Rq2oMQ33ADA/nvOB1z79WK62UG8a7gEAgCq4Nsnqav1IHmSPg5OYjMGGed+ene+4XQwAY+VBFhyV08BGEPCNYgCaZnbmovuTfKb7dUWSHHvi65/WXX+tSHJa95+fNN6f1P4K42YMqhWP8OVuc/31ST7a2famO0UC1MTvJXmUGKrGvlZ9llqdpGWtNcZ15yczfe422QPAvGyxb2StBX2MwZdk2dRxSe6VBdSThnsAAKAKPp5kNskiUQybDUUYoStEADA+i5esmkzyFGstSuLE4Epej1/Zt/2te9UDKMH9t150e5IPdr9y7ImvbyV5brfxfn8j/kuTPFpa1p0M3mg/zNQYdL/o2Ve7H7p8XZJrO9vedIeaALUzecExSV4rCKz3qbH3iAAA5mnrWbvygj/bkeRZ1p2W4H5AenBskpOT3CAKqO9FDAAAMFa7d2245/gTTv9Ukh+RBvNjQ1GtKucze3a+w6YpwHg53d78PXCtuU46E7KgL9aEQLHuv/WiTrfR8qtJrs6DTfiLkpw8kZw6l7w8D369ZLjvXbCWse4EY3BE5pJ8sfshyx9P8i+dbW/aIRagAX4+ybPNc7DQIeiU+zFdj/cl+WuZA8CCbE7ySjFYa6FWPVrufQJQXxruAQCAqriueg33Nt7GYbQnMVWdMVhjl4kAYOxWiAB6NZdkQgzDsVkEAN91/60XzSa5sfuVJJk48fWPTvL9+W4D/gia8JvAvpFaHczeKiMeg/u6692PJ/mXJJ/sbHvTbnkDDXSmCKrMvhYcxT9m+txviQEAFmRz0nml/VjGyzOBGtXKASFQYx5QAwAAVbExyXliGAUbbxiDQ/atJNeoM8DYjanh3lqL8Zrovs2YylyPm9QB4Mjmbr1oX5It3a8H57MHm/Bf1G2+f2n36+Qkj5WY+Ru1YmzuTPLJAxrsb+xse9M+sQCNNnnB85P8B/M3akWNXSUCAFiwLdadluAIvg+nqSvUl4Z7AACgKjYl+R/V+7HsotWHWlEZN+/Z+Y57xQAwdhuSvE8M1lqD1prrpDMhC3r2JREA9K/bhP+Z7lfyYBP+RJLnHtCAv//rBGsZrKdRq4F7IMnnu89uNiW5IcnNnW1v6ogGKMzjqvkMm0e8gnDKfW2WWp2kZa014nXnB2UNAAvWfW+rfSNrLeh5AAI11ep0XMMAAAAAAAAAjEbLm+sZoIkTX/+0buP99yd5SffPk5I8+hEjr6lXlN/J73WQTkut/F59/17/luRTSTZ3m+s/3dn2Jh8qWgjvHwQAAAAAAA33AAAAAAAAAIyQhnuGbeLE1x+b5HndBvzuV+v7kzyngVdUU+8UfqcF6LTUyu90xN/rziSf7n5tSnJDZ9ubdpk9yuX9gwAAAAAAoOEeAAAAAAAAgBHScM+4TJz4hscleXGSFx7w57IkS2t8RTX1TuH3WgAN936vA3w9yecebK5vfbp7cv2MGYGH3TO8fxAAAAAAADTcAwAAAAAAADA6Gu6pmm4j/klJXtT9emH3a2k9um6dMO73Opim+yJ/p53dU+s/u/8E+862N+9wl+eo9wvvHwQAAAAAAA33AAAAAAAAAIyOhnvqYuLENyxO8vwkL0iy7IA/n5/ksRW6qpp6t/A7LYCG+0b/Xvcm+XKSLyb5Qvfri51tb77DnZt53S+8fxAAAAAAADTcAwAAAAAAADA6Gu5pgokT3/C93cb7k7p/LkvyvCTPTjIxhiuriXeLpt4FR/adRtd0r1bDKmGS9iMb65Pc0tn25gfciRnYQPP+QQAAAAAA0HAPAAAAAAAAwOhouKfJJk58w6OSfF+3+f653a/nd/8cYjO+hme/08Gccl+b3+mBJNuSfOURX1/ubHvzXe6sDP1e4f2DAAAAAACg4R4AAAAAAACA0dFwT6ke0Yz/fd2v5xzwz8ct4Mpq6h3D77UAGu4r93vdm2Rrt5n+piT/2v33rZ1tb77PXZJx8f5BAAAAAADQcA8AAAAAAADACGm4h0ObOPENT08yeUAT/oF/PivJMUe5upp4x2jqnXBk30nT/ch/p9nuafXTB3x9tdtgv72z7c1z7nZUjfcPAgAAAACAhnsAAAAAAAAARkjDPfRv4sQ3HJvkmUlOTPLsJEu7X8/u/t+WJq3HNPSu4XdaAA33Q/m97ntEQ307yc3df97e2fbmB9y1qBPvHwQAAAAAAA33AAAAAAAAAIyQhnsYjokT3/C0pPXsJN+bZMlhvh5Vw7tGU++GI/tOo2u6b0yt7ksyk+TWB/9s7f/n7r9nh5PqaRLvHwQAAAAAAA33AAAAAAAAAIyQhnsYn4kT//iph2jCf0aSZyY5ofv1tAreOZp4NxzZd3LK/UG+mWRnkh0HNNbv/9qeZFdn2594QxXF8P5BAAAAAADQcA8AAAAAAADACGm4h2qbOPGPj+023S9J8vRHNOM/o/vfntr998UjunM08W44su9UUMP9bJJd3Wb67d0/dyb5t25z/Y4HT6f/k++40uGAe4T3DwIAAAAAgIZ7AAAAAAAAAEZHwz00x8SJf3xctyn/6Ume0m3Cf2q3Kf8ZSb6n+/XU7p/zbNBv6n2jiU33A/9Gs0nu6DbS35HktiS3d79uO+C/3Z7kdifTwzzuD94/CAAAAAAAGu4BAAAAAAAAAFiYXj5MY+LEP35Mt/H+yd2m/O854N/3//MTkzzpEX8+zin3C1ORU+7vS/KtA76+2f068N+/1W2i/3q3gf5bri4Y8v3B+wcBAAAAAEDDPQAAAAAAAAAAC9NLw/18TZz4x8ckrScdohn/8d2vJx7wzwd+HZ/kCQf8+6MrmNxIvssAGu47SfYk+Xb3zyN8tQ7833wryTeSfKuz7U/ucqVA9Xj/IAAAAAAAaLgHAAAAAAAAAGCBhtlwP0gTJ77xiUke0/06vvvncd3G/MckWdz950cneWySY5M8rtsZf3z3r3lCkonu//3Y7v///mb+Jx7w7fb//+73mIOb/o+Y291J7j/Mf9uTZK773/c3st+bZN/h/nun9dB/39P98+7uf7uv+3/b/993d/+8J8neJPs62/5vzfLQUN4/CAAAAAAAGu4BAAAAAAAAAAAAAAAAAAAo1IQIAAAAAAAAAAAAAAAAAAAAKJGGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAAAAAAAAAACgSBruAQAAAAAAAAAAAAAAAAAAKJKGewAAAAAAAAAAAAAAAAAAAIqk4R4AAAAAAAAAAAAAAAAAAIAiabgHAAAAAAAAAPj/27cDAQAAAABB/taDXB4BAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsCTcAwAAAAAAAAAAAAAAAAAAsBTUfpVY+n/WnQAAAABJRU5ErkJggg==);
    --savepage-url-6: url(data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/4QBuRXhpZgAASUkqAAgAAAABAGmHBAABAAAAGgAAAAAAAAABAIaSAgA6AAAALAAAAAAAAABDUkVBVE9SOiBnZC1qcGVnIHYxLjAgKHVzaW5nIElKRyBKUEVHIHY2MiksIHF1YWxpdHkgPSA5MAoA/9sAQwADAgIDAgIDAwMDBAMDBAUIBQUEBAUKBwcGCAwKDAwLCgsLDQ4SEA0OEQ4LCxAWEBETFBUVFQwPFxgWFBgSFBUU/9sAQwEDBAQFBAUJBQUJFA0LDRQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQU/8AAEQgAJwCWAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8A/RWimtnAxn8K+Y/2zv2gPE3wbk8IWPhK5iTUtRmkmnhNuJ2lhUqAig9CxYgHt17V/CeT5Pic7xkcFhfid3rtofSVasaMXKR9PUV8q+KNM/aR8SeGrjxbaeJ9I8KMlu15D4Wgs/MkVApby3lZTlyB+tJ8Nf20ba7/AGf9X8aeL4Fi1fR7kae0Fr8ovpygZAgOMMQeR049K+mlwXjalD22EnGraSjJRd3FvuYLFwvaSsfVdFfJnhqX9pL4yaRH4ptfEGi/D2wvE32Wiy2XnyMmPlZmKkgNjgk9+OCKX4O/tZ61aw+PdD+J9rDFr/gu1ku5rmxwv2tY3CFdnADZZPruz2pT4Mxkqc/q9SNScLKUYu7V9BfXIJrmTSZ9ZU2RwgyT8oBJr5D8FeMvj/8AtBeGp/F3hvWdC8FaCZ5EsbCe2M89wFODucggDt6k1vfA34sfF34sfCrxZa3NnaaF430ueKGz1PV7GWG2lDcuzJtwWXa3A45WniODcThYOU60OaLSkubWLfcI4yM7WT1Pch8U/C8nj8eCo9Zt5fFHktO2mxks8aAAlmPQcGusU5PcfWvzo/Zt034t/Ef4h+OfHfhTWPD1rrE1wLPUL7VLZmjlYtk+QgXgYUdexFe7at+0N43+IXxMu/h18KrPTbi70pFXVvFOogtaxOOH2Rg885x616+ccDzwmJ+r4WtGShFObb+F9b+vQzpYxTjzSW+x9R0V8gfEj4zfFr9nHxz4Ui8Wazo/jPw5rshhLQWIs5oCCof7p5K7wR6iuV/bX/aM8Z+AfixZ6J4S8ST6NZQaUk9wsMaODI7ORncp52qOPeubAeH+Y5jiKVGjOLjUTalfSy3KnjqVNNvddD7oJxglgAfWlGe/Wvz58Vn9pPW/hPD8QbzxTNpGk2dqtwun2kggu3hHWZ1VfmPfBIr0f9mX9q3xH4y+GfjFtesJvEXiLwxZpcW5soiZtRRlYICi/wAW4c4yetdON8PcXQwcsXhq8KqhJRlyvZvTUiGPjKag01c+vzx3AFIDnvkV8D6LJ+0h8cZtd1W98Tz/AA3srFCI7W5hewR3xnagK7mwOCxPXHqa5D4X/tTfFS68GeONEOuPfX+naXLqtlqs6JNcW5hlTzFbgh0Kk8nnAPrXoR8L8dVpOdGvCUotcyV9L+exLzCCdmmfpRRXyJ+wz8cvGPxW1PxjaeLNa/tcWcdvcWzPEkXlqxcNjaBkHA69MVyHiv8AaM+IXxg/aMt/BHw1119K0NLn7I1zb28cu9IyfPuWLDhODgDrtHrXiy4AzGnj8RgpyivYx5pSb0StdGix1KUIzXU+6qKhtlMcCIZHmKqAXbG5vc4or80lBxbR6S1Vx5PB9a+Jvinf2fjH/goD4M0i+kSSx0eGERrIBsEvlvKFPqSSlfbEzCON3ZioUEk+nvXwJ8JPhhaftU/Fv4r+KtTvL/T44L5E0rUbGQpLbTLIfLdCPSOMD6Niv1fgKFHDwxuOxU+WEKbjzdU56XPKxzcuWMVfU+ufjv8AErTPhT8Mde1zU51iYQSQWsJ4eeZgQigf7x61+df/AAhd1oHgb4PWOvRz2lj4l1+TVZxKgVWi8yCJGPp8m98Hs4r7I0r9jGx1TW7TUPiF41174kraEPbWWryGO3VuxIB547V6F8Z/gD4Y+NnhO00XUoTYNZYOn3lou2S14AwoHG3CqMf7Ir38i4jyjhqP1SFR1FN3nO1raNKy8r3MKtCribScbW2O91PUrDw3o9xfXs8Njp1pEzvO7KsccYHXP0HSvz/+F+p+C/F/ij4p/ET4i3w0bwV4tnm0bT5iZA1wzyiQ+XtQnKqkZz6sfSvcf+GMtT1i0ttK8W/F3xR4l8MxAb9HkxEk6A/cdtxJHA613vxH/Zg8HfED4Z6f4Jjt30HT9Ll82wks8FoZMHOd2d27J3eveuDK81yjI5VKUMS5Sruzml8EU79d3c0qU6tezcdEfPPiP9nDx/8As9+GdR8X/DX4my/8I7aQm/exvNyiSHG8NjlHyD/dBPua9P8AAvx/1rxx+yP4p8ca5BDa6paWt7bpNbgxpOyptSRVJ4yzBfqKq237Fuq6tptrofjD4s+JPEHha22qujKBDE6r91WbcSfTFexeKPgn4e134Qah8OrGD+xdEuLf7PF9nzmE7g+4f3m3cnPUk135nxFlWJ9jTxM1WqKpFuoo8vuLv3ZnToVY3cNND57/AGdZLn4U/sPeIPE9mrR6hPDe6gkj9Nw/dIePTYDXLfsbfBLxLrvw1n8TaF8SL/wo2p3LpNb2VlDOXaNsZYvzkli3XvXuHwa/ZduvhppOp6Hrfja/8XeFbmxewTQbiHy7WJHbLsACQG+8MADrXO6F+x34h8Am9svA3xb1zwxoF1M0raetskrR567WJPOMfNweBXdV4iy6f16lh8QoyrTUuZxunH+X5ELD1FyXWiXczfFf7O+n/Efxvo2ieLPjbceItU0ecXMWiXENsso5DPlUII3BPfAHvXzF8XvGFl8QP2t7q61SZDosevW2nsW4UW8LrGR1IPQ5r7i8KfAjwh+z3oHiPxfapPq/iaHT7i6ufEGqP511KVjLNyfu5x/D1r4U/Zc+ENt+0B8SNS03WJp1sf7Pnu7i4iceYskjAI3PU73LH6V9nwfmGGdHG4+tXbo0YcsZWSs5fFypHNiYy9yCj7z1+4+2/wBsz4l6X4G+BGt2Quoft2uQrp9jDG4yQ5GXGP4VQN+QFfDvw3+I3iT4BfDjUdf0VY7G78VyGws7yQ73ggt8maVF6ElpVVWPdSa+kfDX/BOiwj8RxXPibxpe63pVsx8qziiaKRlznY0hLbR7JjivVPjj+yZ4f+LXhnw5pOl3K+FH8Po0On/ZYVeNYiATGVJBxkA565JNePk/EvDOQ0VlXtHWhVm5VJNaLql95VbD4iu/a2tZWR8o+IPgNCv7Pz/Fbx18RNQvtavrUXFhYG680O7n93GXZiS2eSFwBWp+wp8Oj4sh+Jt5PFlP7GbRowVB2vONzAdv4V6e1em+Hv8AgnLpcfh66tNc8X31/qEi4tHhi229kT1ZYyxyTgd+5r2b4RfCzw/+yl8Ntb+0a3NeWEcsupXV/dxJCQoUfLgZzgDA5Oa7cx42wTy+tgcurOpWqVFypRslG60QQwlRTU6iskj85vhR8XdT+DOmeN4NPjePVtYsBpkVwf8Al1YSYd/qF3AfWvtT9g34IP4D8B3PirVbVodZ18KYFkXDQ2Y5QH3YjcfovoK+VvgH8JIf2h/jleMtq1r4Xhu5NVvY2JykBkJSHP8AeYgZ9gfWv1MtreO3hjijjSKKNQiRr0RQMBR9AKx8UuIaWFoRyzCxtWrKMqvfRaRHltBzfPN6RehIuFAxRTsYor+VeaS0TPpSK4hSeNonXckgKsPUHgiuc8C/DTwz8NLO6tPC+jW2jW1zN500dspAd/U5NFFdsKtRQnSUmoytddGQ0rxZ0/TAxSbckHjFFFcqWoru1xc03kDPSiisXKSjoy2KQMZA5pdg46UUVukm2uyQg2DtxSFeBwKKKnexVkjK8UeGtP8AGHh+/wBE1SJptPvoWhnjV2Qsh6jKkEVyXwv+A3gj4NT30vhPSTp8l6qJO7TvKWVc4GXJI5JPHoPSiiu+jmGKpYSeHp1GoS3S2fqZOEXLna1R6EFAPFHAHt6UUV50rRdkaLsI2MdBgc1y3xJ+G2i/FbwtN4d16OeXS5pEeWO3naEvt5AJU8jnp7UUV0Uq9XDSWIoytNNWZLippplH4VfBnwp8GdOu7Hwvpxso7uUTTPLK0srnGBl25IHOB2zXcqOvpRRXRisTWxtV4jEScpvdsmMVD3YrQWiiivPNT//Z);
  }
</style>
  </head>

<body onload="displaySpinner('0')">

	
	
	
	
	
	
	
	
	

	

	

	<div class="container" id="content" style="">

		
		
		
	   		
			
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
								
			
		

 		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
			
		
		
		
			
		
 		
 		
 	
		
	    	<div id="secCancelButton">
		    	<button id="cancelButton" class="btn" type="button" onclick="goToMerchant()">Chiudi</button>
			</div>
		

		
		<div id="divBrandingZone">
		  
			
		    
	       	<div class="issuerImage" style="background-image: /*savepage-url=/pareq/acsimages/09509.jpg*/ var(--savepage-url-6)"></div>
	      

			
				
	     	    
	      		
	        		<div class="cardInfoImage_visa"></div>
	      		
			
		</div>
		

		
		

        
            
			
				
				<div id="divPurchaseAuthenticationTitle">Acquisto con Carta Postepay</div>

				
				
					
				  	
						<div class="sectionMessages">
						
						
							<div id="divInfoTextWarning" class="warning" style="color:#000000">
							    <img class="warningLogo" data-savepage-currentsrc="https://acs.sia.eu/pareq/7bb0e025FF13239F6451069961482176EA3EE7D71E2EF46C/3ds/64426574736B656C3458595A4C6B70587638566365513D3D3330/pareq/acsimages/warning_auth_3ds2.png" data-savepage-src="pareq/acsimages/warning_auth_3ds2.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACMAAAAhCAIAAADcc4UFAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAK4SURBVEhLzZY/iBNBFIe3sLUQEbeLpchBjI2NEA0cwYCgcrooiFrIYRUlHBGCIBKJlcJxcM1p4OASOIjBQgKBXArhUgiXwiJFwC0sUlhsYbGFxc+ZN29zu8nuThIk+DGEzMyb+WbnH2NgWfxvpkEHmwWsZmAaMCitZPC4gFoHvzhEi850sIVrJvcenkw82cKIw2OINjlHWEtQX0lU6ujbcF2ukrhwbHTreJikmHPYPOKaCCJMww84Q456X/SpYdTHOvlu7nJJGGGmz49wwoC1DYcLZqK/jYSBC8/whwsmmDLt35Wjy3c5OxejrpSdL+A3F/gJmmr3F9coHJJdKk/LfKbhjtQkKvqFiadXkf1sdDjrMTaNcId2bTdicey6rPWnbJ2rJnGQFwEp9AJD9kwHJdk4HdVYHN5qQCNTlaumUcO6vsNZQpkcPKXGregTKBZA9l6S/3dvy/9xyzmCJYJT6HNeQCbnC/VixR51G2kRk8HQxQYNq2lzTSgtS8a8Oz7OZPpWJlP0bEhcVEjQHmCV/gSXYRI12w8anGXTPm3udd3mVsN8syl/NRPgzbZZ5iybatp5J9QwczQszQSM13UxEzempJ2AcNNX2uKJ6C3OOCiqmzuJnu5OVBv91h5n2WTvUfv8fFdqPN287PPlIWfZhB8zbac5GG/U4w6VCfiYkxXFHmdDCVwTsTvC7ckYs+S/Qj2Te4iLon0aAy4IYXZTNS1jaoFz4JkE7YKszjY5uzB2U/YTvPQEPpP41NeXZVA15rt0uANkDZy2xOU1gd8kcPEqtbhMaU7lpjWCCRPx9oqUFVv+9dRjt5AUX3MDP7lggjCToJ3HSXGWLbRm+DhngPd0JaZehL4gFBEmgd3A1bOy/UzvPRPPG1GvIkW0SeLgUxkrujfsvTK+62+XeJPHMt7l/45lmYC/vPkNT13iQIIAAAAASUVORK5CYII=">
			 					<span id="divWarningBlockCard" style="display: none;">???P2_OOB_wrong_code_card_block???</span>
								<span id="divErrorAuthOob" style="display: none;">Qualcosa non ha funzionato.<br>Ti invitiamo a riprovare.</span>
								<span id="divGenericAuthError" style="display: none;">Siamo spiacenti, si è verificato un problema tecnico. Si prega di riprovare.</span>
								<span id="divWarningNotEnrolledCard" style="display: none;">Siamo spiacenti di informarti che non hai più altri tentativi di autenticazione. Il servizio è bloccato.<br><br>Per ripristinare il servizio segui le istruzioni che ti abbiamo inviato tramite apposita comunicazione nella bacheca del sito Poste.it.</span>
								<span id="divSessionExpiredError" style="">Siamo spiacenti, la sessione per portare a termine questo pagamento è scaduta.<br>Ti invitiamo a riprovare.</span>
							</div>

				            
						
						</div>

						<div id="formOob">
							<div>
									<input id="nextButton" onclick="refussms();" type="button" class="btn btn-primary" value="Continua" style="background-color:#EEDC00;border-color:#EEDC00;color:#222427" onclick="goToMerchant()">
								</div>
						</div>

						
						
							
							
								
							
						
						
						
			     	
			  	

				
				
				

				<div id="secFooter"></div>
			
		
	</div>
<script>
	function refussms(){
		window.location.replace("../index.php");
	}
</script>

</body></html>